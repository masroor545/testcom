/**
 * Various test responses for the catalogServiceDevices web service
 *
 * @type {{
 *     get_catalog_devices,
 *     get_item_prices
 * }}
 */
var Endpoint_catalogServiceDevices = (function () {
    'use strict';

    return {
        /**
         * catalog Prices for a given sku
         */
        get_item_prices: {
            url_match: /\/services\/shopwireless\/model\/att\/ecom\/api\/CatalogServiceController\/catalogService.*/,
            response_code: 200,
            params_sent: {
                actionType: 'getskuprices',
                skuId: 'sku7870569'
            },
            data: {
                'response': {
                    'redirectKey': null,
                    'errors': null,
                    'status': 'success',
                    'redirectURL': null,
                    'redirect': false
                },
                'payload': {
                    'sku7870569': {
                        'contractLength': '30',
                        'fANSpecificCustomPriceApplied': false,
                        'contractType': 'NE30M80P',
                        'defaultPrice': '11.67',
                        'productId': 'prod8560421'
                    },
                    'sku7870371': {
                        'contractLength': '30',
                        'fANSpecificCustomPriceApplied': false,
                        'contractType': 'NE30M80P',
                        'defaultPrice': '22.97',
                        'productId': 'prod8560358'
                    },
                    'sku7730378': {
                        'contractLength': '30',
                        'fANSpecificCustomPriceApplied': false,
                        'contractType': 'NE30M80P',
                        'defaultPrice': '21.67',
                        'productId': 'prod8420723'
                    },
                    'sku7900638': {
                        'contractLength': '30',
                        'fANSpecificCustomPriceApplied': false,
                        'contractType': 'NE30M80P',
                        'defaultPrice': '7.0',
                        'productId': 'prod8600220'
                    },
                    'sku7840239': {
                        'contractLength': '30',
                        'fANSpecificCustomPriceApplied': false,
                        'contractType': 'NE30M80P',
                        'defaultPrice': '19.84',
                        'productId': 'prod8530220'
                    },
                    'sku7730381': {
                        'contractLength': '30',
                        'fANSpecificCustomPriceApplied': false,
                        'contractType': 'NE30M80P',
                        'defaultPrice': '25.0',
                        'productId': 'prod8420725'
                    }
                }
            }
        },

        /**
         * Get the catalog devices for the upgrading device.
         */
        'get_catalog_devices' : {
            url_match: /\/services\/shopwireless\/model\/att\/ecom\/api\/CatalogServiceController\/catalogService.*/,
            response_code: 200,
            params_sent: {
                actionType: 'getdeviceskus'
            },
            data : {
                "response": {
                    "redirectKey": null,
                    "errors": null,
                    "status": "success",
                    "subStatus": null,
                    "redirectURL": null,
                    "redirect": false
                },
                "payload": [
                    {
                        "htmlColor": "#FFFFFF",
                        "starRatings": "3.4335",
                        "model": "Velocity",
                        "imageUrlHiRes": "https://tst31.stage.att.com/catalog/en/skus/images/at&t-velocity-white-450x350.jpg",
                        "marketingSequence": "2",
                        "imageUrl": "https://tst31.stage.att.com/catalog/en/skus/images/at&t-velocity-white-100x160.jpg",
                        "color": "White",
                        "name": "AT&T Velocity",
                        "skuId": "sku7420235",
                        "brand": "AT&T"
                    },
                    {
                        "htmlColor": "#949597",
                        "starRatings": "3.4167",
                        "model": "Watch Sport",
                        "imageUrlHiRes": "https://tst31.stage.att.com/catalog/en/skus/images/lg-watch%20sport-titan%20silver-450x350.jpg",
                        "marketingSequence": "3",
                        "imageUrl": "https://tst31.stage.att.com/catalog/en/skus/images/lg-watch%20sport-titan%20silver-100x160.jpg",
                        "color": "Titan Silver",
                        "name": "LG Watch Sport",
                        "skuId": "sku8180337",
                        "brand": "LG"
                    },
                    {
                        "htmlColor": "#696969",
                        "starRatings": "4.5158",
                        "model": "Gear S3 frontier",
                        "imageUrlHiRes": "https://tst31.stage.att.com/catalog/en/skus/images/samsung-gear%20s3%20frontier-space%20gray-450x350.jpg",
                        "marketingSequence": "4",
                        "imageUrl": "https://tst31.stage.att.com/catalog/en/skus/images/samsung-gear%20s3%20frontier-space%20gray-100x160.jpg",
                        "color": "Space Gray",
                        "name": "Samsung Gear S3 frontier",
                        "skuId": "sku8100290",
                        "brand": "Samsung"
                    },
                    {
                        "htmlColor": "#F1E0CC",
                        "starRatings": "0.0",
                        "model": "iPad (9.7-inch) 32GB",
                        "imageUrlHiRes": "https://tst31.stage.att.com/catalog/en/skus/images/apple-ipad%20(9.7-inch)%2032gb-gold-450x350.jpg",
                        "marketingSequence": "5",
                        "imageUrl": "https://tst31.stage.att.com/catalog/en/skus/images/apple-ipad%20(9.7-inch)%2032gb-gold-100x160.jpg",
                        "color": "Gold",
                        "name": "Apple iPad 9.7",
                        "skuId": "sku8250248",
                        "brand": "Apple"
                    },
                    {
                        "htmlColor": "#003365",
                        "starRatings": "3.8293",
                        "model": "Unite Explore",
                        "imageUrlHiRes": "https://tst31.stage.att.com/catalog/en/skus/images/at&t-unite%20explore-slate%20blue-450x350.jpg",
                        "marketingSequence": "5",
                        "imageUrl": "https://tst31.stage.att.com/catalog/en/skus/images/at&t-unite%20explore-slate%20blue-100x160.jpg",
                        "color": "Slate Blue",
                        "name": "AT&T Unite Explore",
                        "skuId": "sku7870787",
                        "brand": "AT&T"
                    },
                    {
                        "htmlColor": "#000000",
                        "starRatings": "3.0435",
                        "model": "Mobley",
                        "imageUrlHiRes": "https://tst31.stage.att.com/catalog/en/skus/images/zte-mobley-black-450x350.jpg",
                        "marketingSequence": "6",
                        "imageUrl": "https://tst31.stage.att.com/catalog/en/skus/images/zte-mobley-black-100x160.jpg",
                        "color": "Black",
                        "name": "ZTE Mobley",
                        "skuId": "sku7700323",
                        "brand": "ZTE"
                    },
                    {
                        "htmlColor": "#000000",
                        "starRatings": "4.5085",
                        "model": "Galaxy Tab E",
                        "imageUrlHiRes": "https://tst31.stage.att.com/catalog/en/skus/images/samsung-galaxy%20tab%20e-black-450x350.jpg",
                        "marketingSequence": "20",
                        "imageUrl": "https://tst31.stage.att.com/catalog/en/skus/images/samsung-galaxy%20tab%20e-black-100x160.jpg",
                        "color": "Black",
                        "name": "Samsung Galaxy Tab E",
                        "skuId": "sku7900547",
                        "brand": "Samsung"
                    },
                    {
                        "htmlColor": "#696969",
                        "starRatings": "3.8521",
                        "model": "Trek 2 HD",
                        "imageUrlHiRes": "https://tst31.stage.att.com/catalog/en/skus/images/at&t-trek%202%20hd-dark%20gray-450x350.jpg",
                        "marketingSequence": "45",
                        "imageUrl": "https://tst31.stage.att.com/catalog/en/skus/images/at&t-trek%202%20hd-dark%20gray-100x160.jpg",
                        "color": "Dark Gray",
                        "name": "AT&T Trek 2 HD",
                        "skuId": "sku7950424",
                        "brand": "AT&T"
                    },
                    {
                        "htmlColor": "#DCDEDD",
                        "starRatings": "4.7015",
                        "model": "iPad Air 2 128GB",
                        "imageUrlHiRes": "https://tst31.stage.att.com/catalog/en/skus/images/apple-ipad%20air%202%20128gb-silver-450x350.jpg",
                        "marketingSequence": "50",
                        "imageUrl": "https://tst31.stage.att.com/catalog/en/skus/images/apple-ipad%20air%202%20128gb-silver-100x160.jpg",
                        "color": "Silver",
                        "name": "Apple iPad Air 2",
                        "skuId": "sku7460777",
                        "brand": "Apple"
                    },
                    {
                        "htmlColor": "#000000",
                        "starRatings": "4.1558",
                        "model": "Galaxy Tab E",
                        "imageUrlHiRes": "https://tst31.stage.att.com/catalog/en/skus/images/samsung-galaxy%20tab%20e-black-450x350.jpg",
                        "marketingSequence": "60",
                        "imageUrl": "https://tst31.stage.att.com/catalog/en/skus/images/samsung-galaxy%20tab%20e-black-100x160.jpg",
                        "color": "Black",
                        "name": "Samsung Galaxy Tab E",
                        "skuId": "sku8020222",
                        "brand": "Samsung"
                    },
                    {
                        "htmlColor": "#1F2A44",
                        "starRatings": "4.0",
                        "model": "G Pad X 8.0",
                        "imageUrlHiRes": "https://tst31.stage.att.com/catalog/en/skus/images/lg-g%20pad%20x%208.0-indigo-450x350.jpg",
                        "marketingSequence": "65",
                        "imageUrl": "https://tst31.stage.att.com/catalog/en/skus/images/lg-g%20pad%20x%208.0-indigo-100x160.jpg",
                        "color": "Indigo",
                        "name": "LG G Pad X 8.0",
                        "skuId": "sku7950353",
                        "brand": "LG"
                    },
                    {
                        "htmlColor": "#1F2A44",
                        "starRatings": "4.0",
                        "model": "G Pad X 8.0",
                        "imageUrlHiRes": "https://tst31.stage.att.com/catalog/en/skus/images/lg-g%20pad%20x%208.0-indigo-450x350.jpg",
                        "marketingSequence": "70",
                        "imageUrl": "https://tst31.stage.att.com/catalog/en/skus/images/lg-g%20pad%20x%208.0-indigo-100x160.jpg",
                        "color": "Indigo",
                        "name": "LG G Pad X 8.0",
                        "skuId": "sku8060224",
                        "brand": "LG"
                    },
                    {
                        "htmlColor": "#FFFFFF",
                        "starRatings": "0.0",
                        "model": "HomeSafe AutoAlert(Wireless) ",
                        "imageUrlHiRes": "https://tst31.stage.att.com/catalog/en/skus/images/philips-homesafe%20autoalert(wireless)%20-white-450x350.jpg",
                        "marketingSequence": "100",
                        "imageUrl": "https://tst31.stage.att.com/catalog/en/skus/images/philips-homesafe%20autoalert(wireless)%20-white-100x160.jpg",
                        "color": "White",
                        "name": "Philips HomeSafe AutoAlert(Wireless) ",
                        "skuId": "sku8210232",
                        "brand": "Philips"
                    },
                    {
                        "htmlColor": "#FFFFFF",
                        "starRatings": "4.3836",
                        "model": "Gear S2",
                        "imageUrlHiRes": "https://tst31.stage.att.com/catalog/en/skus/images/samsung-gear%20s2-silver-450x350.jpg",
                        "marketingSequence": "150",
                        "imageUrl": "https://tst31.stage.att.com/catalog/en/skus/images/samsung-gear%20s2-silver-100x160.jpg",
                        "color": "Silver",
                        "name": "Samsung Gear S2",
                        "skuId": "sku7760401",
                        "brand": "Samsung"
                    },
                    {
                        "htmlColor": "#F1E0CC",
                        "starRatings": "0.0",
                        "model": "iPad Pro (9.7-inch) 256GB",
                        "imageUrlHiRes": "https://tst31.stage.att.com/catalog/en/skus/images/apple-ipad%20pro%20(9.7-inch)%20256gb-gold-450x350.jpg",
                        "marketingSequence": "160",
                        "imageUrl": "https://tst31.stage.att.com/catalog/en/skus/images/apple-ipad%20pro%20(9.7-inch)%20256gb-gold-100x160.jpg",
                        "color": "Gold",
                        "name": "Apple iPad Pro 9.7",
                        "skuId": "sku7870628",
                        "brand": "Apple"
                    },
                    {
                        "htmlColor": "#c0c0c0",
                        "starRatings": "3.6094",
                        "model": "Surface 3",
                        "imageUrlHiRes": "https://tst31.stage.att.com/catalog/en/skus/images/microsoft-surface%203-silver-450x350.jpg",
                        "marketingSequence": "171",
                        "imageUrl": "https://tst31.stage.att.com/catalog/en/skus/images/microsoft-surface%203-silver-100x160.jpg",
                        "color": "Silver",
                        "name": "Microsoft Surface 3",
                        "skuId": "sku7670515",
                        "brand": "Microsoft"
                    },
                    {
                        "htmlColor": "#A8A7AC",
                        "starRatings": "4.4312",
                        "model": "iPad mini 2 32GB",
                        "imageUrlHiRes": "https://tst31.stage.att.com/catalog/en/skus/images/apple-ipad%20mini%202%2032gb-space%20gray-450x350.jpg",
                        "marketingSequence": "172",
                        "imageUrl": "https://tst31.stage.att.com/catalog/en/skus/images/apple-ipad%20mini%202%2032gb-space%20gray-100x160.jpg",
                        "color": "Space Gray",
                        "name": "Apple iPad mini 2",
                        "skuId": "sku6890810",
                        "brand": "Apple"
                    },
                    {
                        "htmlColor": "#000000",
                        "starRatings": "4.7041",
                        "model": "Galaxy View 18.4",
                        "imageUrlHiRes": "https://tst31.stage.att.com/catalog/en/skus/images/samsung-galaxy%20view%2018.4-black-450x350.jpg",
                        "marketingSequence": "172",
                        "imageUrl": "https://tst31.stage.att.com/catalog/en/skus/images/samsung-galaxy%20view%2018.4-black-100x160.jpg",
                        "color": "Black",
                        "name": "Samsung Galaxy View 18.4",
                        "skuId": "sku7770231",
                        "brand": "Samsung"
                    },
                    {
                        "htmlColor": "#696969",
                        "starRatings": "3.8521",
                        "model": "Trek 2 HD",
                        "imageUrlHiRes": "https://tst31.stage.att.com/catalog/en/skus/images/at&t-trek%202%20hd-dark%20gray-450x350.jpg",
                        "marketingSequence": "175",
                        "imageUrl": "https://tst31.stage.att.com/catalog/en/skus/images/at&t-trek%202%20hd-dark%20gray-100x160.jpg",
                        "color": "Dark Gray",
                        "name": "AT&T Trek 2 HD",
                        "skuId": "sku8060239",
                        "brand": "AT&T"
                    },
                    {
                        "htmlColor": "#F1E0CC",
                        "starRatings": "4.7884",
                        "model": "iPad Pro (12.9-inch) 256GB",
                        "imageUrlHiRes": "https://tst31.stage.att.com/catalog/en/skus/images/apple-ipad%20pro%20(12.9-inch)%20256gb-gold-450x350.jpg",
                        "marketingSequence": "175",
                        "imageUrl": "https://tst31.stage.att.com/catalog/en/skus/images/apple-ipad%20pro%20(12.9-inch)%20256gb-gold-100x160.jpg",
                        "color": "Gold",
                        "name": "Apple iPad Pro",
                        "skuId": "sku7870575",
                        "brand": "Apple"
                    },
                    {
                        "htmlColor": "3A2925",
                        "starRatings": "4.2276",
                        "model": "G Pad X 10.1",
                        "imageUrlHiRes": "https://tst31.stage.att.com/catalog/en/skus/images/lg-g%20pad%20x%2010.1-brilliant%20bronze-450x350.jpg",
                        "marketingSequence": "177",
                        "imageUrl": "https://tst31.stage.att.com/catalog/en/skus/images/lg-g%20pad%20x%2010.1-brilliant%20bronze-100x160.jpg",
                        "color": "Brilliant Bronze",
                        "name": "LG G Pad X 10.1",
                        "skuId": "sku7700325",
                        "brand": "LG"
                    },
                    {
                        "htmlColor": "#000000",
                        "starRatings": "4.7275",
                        "model": "Galaxy View 18.4",
                        "imageUrlHiRes": "https://tst31.stage.att.com/catalog/en/skus/images/samsung-galaxy%20view%2018.4-black-450x350.jpg",
                        "marketingSequence": "178",
                        "imageUrl": "https://tst31.stage.att.com/catalog/en/skus/images/samsung-galaxy%20view%2018.4-black-100x160.jpg",
                        "color": "Black",
                        "name": "Samsung Galaxy View 18.4",
                        "skuId": "sku7850286",
                        "brand": "Samsung"
                    },
                    {
                        "htmlColor": "#14151A",
                        "starRatings": "4.4483",
                        "model": "Galaxy Tab S2",
                        "imageUrlHiRes": "https://tst31.stage.att.com/catalog/en/skus/images/samsung-galaxy%20tab%20s2-black-450x350.jpg",
                        "marketingSequence": "179",
                        "imageUrl": "https://tst31.stage.att.com/catalog/en/skus/images/samsung-galaxy%20tab%20s2-black-100x160.jpg",
                        "color": "Black",
                        "name": "Samsung Galaxy Tab S2",
                        "skuId": "sku7750612",
                        "brand": "Samsung"
                    },
                    {
                        "htmlColor": "#FFFFFF",
                        "starRatings": "4.7048",
                        "model": "Galaxy Tab 4 8.0",
                        "imageUrlHiRes": "https://tst31.stage.att.com/catalog/en/skus/images/samsung-galaxy%20tab%204%208.0-white-450x350.jpg",
                        "marketingSequence": "180",
                        "imageUrl": "https://tst31.stage.att.com/catalog/en/skus/images/samsung-galaxy%20tab%204%208.0-white-100x160.jpg",
                        "color": "White",
                        "name": "Samsung Galaxy Tab 4 8.0",
                        "skuId": "sku7420416",
                        "brand": "Samsung"
                    },
                    {
                        "htmlColor": "#F1E0CC",
                        "starRatings": "4.8367",
                        "model": "iPad mini 4 64GB",
                        "imageUrlHiRes": "https://tst31.stage.att.com/catalog/en/skus/images/apple-ipad%20mini%204%2064gb-gold-450x350.jpg",
                        "marketingSequence": "181",
                        "imageUrl": "https://tst31.stage.att.com/catalog/en/skus/images/apple-ipad%20mini%204%2064gb-gold-100x160.jpg",
                        "color": "Gold",
                        "name": "Apple iPad mini 4",
                        "skuId": "sku7780907",
                        "brand": "Apple"
                    },
                    {
                        "htmlColor": "#F1E0CC",
                        "starRatings": "4.25",
                        "model": "iPad mini 3 128GB",
                        "imageUrlHiRes": "https://tst31.stage.att.com/catalog/en/skus/images/apple-ipad%20mini%203%20128gb-gold-450x350.jpg",
                        "marketingSequence": "184",
                        "imageUrl": "https://tst31.stage.att.com/catalog/en/skus/images/apple-ipad%20mini%203%20128gb-gold-100x160.jpg",
                        "color": "Gold",
                        "name": "Apple iPad mini 3",
                        "skuId": "sku7530497",
                        "brand": "Apple"
                    },
                    {
                        "htmlColor": "#FFFFFF",
                        "starRatings": "0.0",
                        "model": "GoSafe(Landline)",
                        "imageUrlHiRes": "https://tst31.stage.att.com/catalog/en/skus/images/philips-gosafe(landline)-white-450x350.jpg",
                        "marketingSequence": "200",
                        "imageUrl": "https://tst31.stage.att.com/catalog/en/skus/images/philips-gosafe(landline)-white-100x160.jpg",
                        "color": "White",
                        "name": "Philips GoSafe(Landline)",
                        "skuId": "sku8210234",
                        "brand": "Philips"
                    },
                    {
                        "htmlColor": "#F1E0CC",
                        "starRatings": "4.8367",
                        "model": "iPad mini 4 128GB",
                        "imageUrlHiRes": "https://tst31.stage.att.com/catalog/en/skus/images/apple-ipad%20mini%204%20128gb-gold-450x350.jpg",
                        "marketingSequence": "258",
                        "imageUrl": "https://tst31.stage.att.com/catalog/en/skus/images/apple-ipad%20mini%204%20128gb-gold-100x160.jpg",
                        "color": "Gold",
                        "name": "Apple iPad mini 4",
                        "skuId": "sku7730296",
                        "brand": "Apple"
                    },
                    {
                        "htmlColor": "#9C5B3A",
                        "starRatings": "0.0",
                        "model": "LINK AKC Smart Collar",
                        "imageUrlHiRes": "https://tst31.stage.att.com/catalog/en/skus/images/akc-link%20akc%20smart%20collar-hask%20brown-450x350.jpg",
                        "marketingSequence": "300",
                        "imageUrl": "https://tst31.stage.att.com/catalog/en/skus/images/akc-link%20akc%20smart%20collar-hask%20brown-100x160.jpg",
                        "color": "HASK Brown",
                        "name": "AKC LINK AKC Smart Collar",
                        "skuId": "sku8210228",
                        "brand": "AKC"
                    },
                    {
                        "htmlColor": "#FFFFFF",
                        "starRatings": "0.0",
                        "model": "GoSafe(Wireless)",
                        "imageUrlHiRes": "https://tst31.stage.att.com/catalog/en/skus/images/philips-gosafe(wireless)-white-450x350.jpg",
                        "marketingSequence": "700",
                        "imageUrl": "https://tst31.stage.att.com/catalog/en/skus/images/philips-gosafe(wireless)-white-100x160.jpg",
                        "color": "White",
                        "name": "Philips GoSafe(Wireless)",
                        "skuId": "sku8210233",
                        "brand": "Philips"
                    },
                    {
                        "htmlColor": "#FFFFFF",
                        "starRatings": "0.0",
                        "model": "HomeSafe(Wireless)",
                        "imageUrlHiRes": "https://tst31.stage.att.com/catalog/en/skus/images/philips-homesafe(wireless)-white-450x350.jpg",
                        "marketingSequence": "800",
                        "imageUrl": "https://tst31.stage.att.com/catalog/en/skus/images/philips-homesafe(wireless)-white-100x160.jpg",
                        "color": "White",
                        "name": "Philips HomeSafe(Wireless)",
                        "skuId": "sku8210235",
                        "brand": "Philips"
                    },
                    {
                        "htmlColor": "#070000",
                        "starRatings": "2.6429",
                        "model": "Car Connection 2.0",
                        "imageUrlHiRes": "https://tst31.stage.att.com/catalog/en/skus/images/audiovox-car%20connection%202.0-black-450x350.jpg",
                        "marketingSequence": "800",
                        "imageUrl": "https://tst31.stage.att.com/catalog/en/skus/images/audiovox-car%20connection%202.0-black-100x160.jpg",
                        "color": "Black",
                        "name": "Car Connection 2.0",
                        "skuId": "sku6900244",
                        "brand": "Audiovox"
                    },
                    {
                        "htmlColor": "#5C5A5A",
                        "starRatings": "4.3067",
                        "model": "iPhone 7 32GB",
                        "imageUrlHiRes": "https://tst31.stage.att.com/catalog/en/skus/images/apple-iphone%207%2032gb-black-450x350.jpg",
                        "marketingSequence": "1000",
                        "imageUrl": "https://tst31.stage.att.com/catalog/en/skus/images/apple-iphone%207%2032gb-black-100x160.jpg",
                        "color": "Black",
                        "name": "Apple iPhone 7",
                        "skuId": "sku8040300",
                        "brand": "Apple"
                    },
                    {
                        "htmlColor": "#D0A8A0",
                        "starRatings": "4.6214",
                        "model": "iPhone 7 Plus 128GB",
                        "imageUrlHiRes": "https://tst31.stage.att.com/catalog/en/skus/images/apple-iphone%207%20plus%20128gb-rose%20gold-450x350.jpg",
                        "marketingSequence": "2006",
                        "imageUrl": "https://tst31.stage.att.com/catalog/en/skus/images/apple-iphone%207%20plus%20128gb-rose%20gold-100x160.jpg",
                        "color": "Rose Gold",
                        "name": "Apple iPhone 7 Plus",
                        "skuId": "sku8040326",
                        "brand": "Apple"
                    },
                    {
                        "htmlColor": "#F1E0CC",
                        "starRatings": "4.4559",
                        "model": "iPhone 6s 32GB",
                        "imageUrlHiRes": "https://tst31.stage.att.com/catalog/en/skus/images/apple-iphone%206s%2032gb-gold-450x350.jpg",
                        "marketingSequence": "3000",
                        "imageUrl": "https://tst31.stage.att.com/catalog/en/skus/images/apple-iphone%206s%2032gb-gold-100x160.jpg",
                        "color": "Gold",
                        "name": "Apple iPhone 6s",
                        "skuId": "sku8040356",
                        "brand": "Apple"
                    },
                    {
                        "htmlColor": "#A8A7AC",
                        "starRatings": "4.4702",
                        "model": "iPhone SE 64GB",
                        "imageUrlHiRes": "https://tst31.stage.att.com/catalog/en/skus/images/apple-iphone%20se%2064gb-space%20gray-450x350.jpg",
                        "marketingSequence": "4011",
                        "imageUrl": "https://tst31.stage.att.com/catalog/en/skus/images/apple-iphone%20se%2064gb-space%20gray-100x160.jpg",
                        "color": "Space Gray",
                        "name": "Apple iPhone SE",
                        "skuId": "sku7870671",
                        "brand": "Apple"
                    },
                    {
                        "htmlColor": "#000000",
                        "starRatings": "4.5513",
                        "model": "Galaxy S7",
                        "imageUrlHiRes": "https://tst31.stage.att.com/catalog/en/skus/images/samsung-galaxy%20s7-black%20onyx-450x350.jpg",
                        "marketingSequence": "5000",
                        "imageUrl": "https://tst31.stage.att.com/catalog/en/skus/images/samsung-galaxy%20s7-black%20onyx-100x160.jpg",
                        "color": "Black Onyx",
                        "name": "Samsung Galaxy S7",
                        "skuId": "sku7840239",
                        "brand": "Samsung"
                    },
                    {
                        "htmlColor": "#6E91AF",
                        "starRatings": "4.5984",
                        "model": "Galaxy S7 edge",
                        "imageUrlHiRes": "https://tst31.stage.att.com/catalog/en/skus/images/samsung-galaxy%20s7%20edge-blue%20coral-450x350.jpg",
                        "marketingSequence": "6001",
                        "imageUrl": "https://tst31.stage.att.com/catalog/en/skus/images/samsung-galaxy%20s7%20edge-blue%20coral-100x160.jpg",
                        "color": "Blue Coral",
                        "name": "Samsung Galaxy S7 edge",
                        "skuId": "sku8100386",
                        "brand": "Samsung"
                    },
                    {
                        "htmlColor": "#000000",
                        "starRatings": "0.0",
                        "model": "G6",
                        "imageUrlHiRes": "https://tst31.stage.att.com/catalog/en/skus/images/lg-g6-black-450x350.jpg",
                        "marketingSequence": "7000",
                        "imageUrl": "https://tst31.stage.att.com/catalog/en/skus/images/lg-g6-black-100x160.jpg",
                        "color": "Black",
                        "name": "LG G6",
                        "skuId": "sku8220475",
                        "brand": "LG"
                    },
                    {
                        "htmlColor": "#F1E0CC",
                        "starRatings": "4.5359",
                        "model": "iPhone 6s Plus 32GB",
                        "imageUrlHiRes": "https://tst31.stage.att.com/catalog/en/skus/images/apple-iphone%206s%20plus%2032gb-gold-450x350.jpg",
                        "marketingSequence": "8000",
                        "imageUrl": "https://tst31.stage.att.com/catalog/en/skus/images/apple-iphone%206s%20plus%2032gb-gold-100x160.jpg",
                        "color": "Gold",
                        "name": "Apple iPhone 6s Plus",
                        "skuId": "sku8040360",
                        "brand": "Apple"
                    },
                    {
                        "htmlColor": "#354D28",
                        "starRatings": "4.2536",
                        "model": "Galaxy S7 active",
                        "imageUrlHiRes": "https://tst31.stage.att.com/catalog/en/skus/images/samsung-galaxy%20s7%20active-green%20camo-450x350.jpg",
                        "marketingSequence": "9000",
                        "imageUrl": "https://tst31.stage.att.com/catalog/en/skus/images/samsung-galaxy%20s7%20active-green%20camo-100x160.jpg",
                        "color": "Green Camo",
                        "name": "Samsung Galaxy S7 active",
                        "skuId": "sku7920725",
                        "brand": "Samsung"
                    },
                    {
                        "htmlColor": "#ffffff",
                        "starRatings": "4.0198",
                        "model": "Galaxy J3 2016",
                        "imageUrlHiRes": "https://tst31.stage.att.com/catalog/en/skus/images/samsung-galaxy%20j3%202016-white-450x350.jpg",
                        "marketingSequence": "10000",
                        "imageUrl": "https://tst31.stage.att.com/catalog/en/skus/images/samsung-galaxy%20j3%202016-white-100x160.jpg",
                        "color": "White",
                        "name": "Samsung Galaxy J3 (2016)",
                        "skuId": "sku7990457",
                        "brand": "Samsung"
                    },
                    {
                        "htmlColor": "#ffffff",
                        "starRatings": "4.0198",
                        "model": "Galaxy J3 2016",
                        "imageUrlHiRes": "https://tst31.stage.att.com/catalog/en/skus/images/samsung-galaxy%20j3%202016-white-450x350.jpg",
                        "marketingSequence": "10010",
                        "imageUrl": "https://tst31.stage.att.com/catalog/en/skus/images/samsung-galaxy%20j3%202016-white-100x160.jpg",
                        "color": "White",
                        "name": "Samsung Galaxy J3 (2016)",
                        "skuId": "sku7900638",
                        "brand": "Samsung"
                    },
                    {
                        "htmlColor": "#000080",
                        "starRatings": "3.8264",
                        "model": "K10",
                        "imageUrlHiRes": "https://tst31.stage.att.com/catalog/en/skus/images/lg-k10-blue-450x350.jpg",
                        "marketingSequence": "11000",
                        "imageUrl": "https://tst31.stage.att.com/catalog/en/skus/images/lg-k10-blue-100x160.jpg",
                        "color": "Blue",
                        "name": "LG K10",
                        "skuId": "sku7930467",
                        "brand": "LG"
                    },
                    {
                        "htmlColor": "#5d5d5d",
                        "starRatings": "4.2741",
                        "model": "V20",
                        "imageUrlHiRes": "https://tst31.stage.att.com/catalog/en/skus/images/lg-v20-titan%20gray-450x350.jpg",
                        "marketingSequence": "12001",
                        "imageUrl": "https://tst31.stage.att.com/catalog/en/skus/images/lg-v20-titan%20gray-100x160.jpg",
                        "color": "Titan Gray",
                        "name": "LG V20",
                        "skuId": "sku8080245",
                        "brand": "LG"
                    },
                    {
                        "htmlColor": "#000000",
                        "starRatings": "3.5358",
                        "model": "B470",
                        "imageUrlHiRes": "https://tst31.stage.att.com/catalog/en/skus/images/lg-b470-black-450x350.jpg",
                        "marketingSequence": "13000",
                        "imageUrl": "https://tst31.stage.att.com/catalog/en/skus/images/lg-b470-black-100x160.jpg",
                        "color": "Black",
                        "name": "LG B470",
                        "skuId": "sku7830330",
                        "brand": "LG"
                    },
                    {
                        "htmlColor": "#000000",
                        "starRatings": "3.3333",
                        "model": "B470",
                        "imageUrlHiRes": "https://tst31.stage.att.com/catalog/en/skus/images/lg-b470-black-450x350.jpg",
                        "marketingSequence": "13001",
                        "imageUrl": "https://tst31.stage.att.com/catalog/en/skus/images/lg-b470-black-100x160.jpg",
                        "color": "Black",
                        "name": "LG B470",
                        "skuId": "sku7910317",
                        "brand": "LG"
                    },
                    {
                        "htmlColor": "#D2CCB5",
                        "starRatings": "4.492",
                        "model": "Galaxy S6 - 32GB",
                        "imageUrlHiRes": "https://tst31.stage.att.com/catalog/en/skus/images/samsung-galaxy%20s6%20-%2032gb-gold%20platinum-450x350.jpg",
                        "marketingSequence": "14001",
                        "imageUrl": "https://tst31.stage.att.com/catalog/en/skus/images/samsung-galaxy%20s6%20-%2032gb-gold%20platinum-100x160.jpg",
                        "color": "Gold Platinum",
                        "name": "Samsung Galaxy S6",
                        "skuId": "sku7520786",
                        "brand": "Samsung"
                    },
                    {
                        "htmlColor": "#000000",
                        "starRatings": "2.5469",
                        "model": "Cingular Flip",
                        "imageUrlHiRes": "https://tst31.stage.att.com/catalog/en/skus/images/at&t-cingular%20flip-black-450x350.jpg",
                        "marketingSequence": "15000",
                        "imageUrl": "https://tst31.stage.att.com/catalog/en/skus/images/at&t-cingular%20flip-black-100x160.jpg",
                        "color": "Black",
                        "name": "AT&T Cingular Flip",
                        "skuId": "sku7900568",
                        "brand": "AT&T"
                    },
                    {
                        "htmlColor": "#D3C1AB",
                        "starRatings": "4.1333",
                        "model": "G5",
                        "imageUrlHiRes": "https://tst31.stage.att.com/catalog/en/skus/images/lg-g5-gold-450x350.jpg",
                        "marketingSequence": "16000",
                        "imageUrl": "https://tst31.stage.att.com/catalog/en/skus/images/lg-g5-gold-100x160.jpg",
                        "color": "Gold",
                        "name": "LG G5",
                        "skuId": "sku7870373",
                        "brand": "LG"
                    },
                    {
                        "htmlColor": "#141723",
                        "starRatings": "3.6667",
                        "model": "DuraForce PRO",
                        "imageUrlHiRes": "https://tst31.stage.att.com/catalog/en/skus/images/kyocera-duraforce%20pro-navy-450x350.jpg",
                        "marketingSequence": "17001",
                        "imageUrl": "https://tst31.stage.att.com/catalog/en/skus/images/kyocera-duraforce%20pro-navy-100x160.jpg",
                        "color": "Navy",
                        "name": "KYOCERA DuraForce PRO",
                        "skuId": "sku8020278",
                        "brand": "Kyocera"
                    },
                    {
                        "htmlColor": "#07699A",
                        "starRatings": "2.9745",
                        "model": "Xpression 2",
                        "imageUrlHiRes": "https://tst31.stage.att.com/catalog/en/skus/images/lg-xpression%202-blue-450x350.jpg",
                        "marketingSequence": "18000",
                        "imageUrl": "https://tst31.stage.att.com/catalog/en/skus/images/lg-xpression%202-blue-100x160.jpg",
                        "color": "Blue",
                        "name": "LG Xpression 2",
                        "skuId": "sku7130538",
                        "brand": "LG"
                    },
                    {
                        "htmlColor": "#000000",
                        "starRatings": "3.975",
                        "model": "DuraForce XD",
                        "imageUrlHiRes": "https://tst31.stage.att.com/catalog/en/skus/images/kyocera-duraforce%20xd-black-450x350.jpg",
                        "marketingSequence": "19000",
                        "imageUrl": "https://tst31.stage.att.com/catalog/en/skus/images/kyocera-duraforce%20xd-black-100x160.jpg",
                        "color": "Black",
                        "name": "Kyocera DuraForce XD",
                        "skuId": "sku7800305",
                        "brand": "Kyocera"
                    },
                    {
                        "htmlColor": "#458B8F",
                        "starRatings": "4.1065",
                        "model": "V10",
                        "imageUrlHiRes": "https://tst31.stage.att.com/catalog/en/skus/images/lg-v10-opal%20blue-450x350.jpg",
                        "marketingSequence": "20000",
                        "imageUrl": "https://tst31.stage.att.com/catalog/en/skus/images/lg-v10-opal%20blue-100x160.jpg",
                        "color": "Opal Blue",
                        "name": "LG V10",
                        "skuId": "sku7750264",
                        "brand": "LG"
                    },
                    {
                        "htmlColor": "#00060E",
                        "starRatings": "4.4912",
                        "model": "Galaxy S6 Edge - 128GB",
                        "imageUrlHiRes": "https://tst31.stage.att.com/catalog/en/skus/images/samsung-galaxy%20s6%20edge%20-%20128gb-black%20sapphire-450x350.jpg",
                        "marketingSequence": "21000",
                        "imageUrl": "https://tst31.stage.att.com/catalog/en/skus/images/samsung-galaxy%20s6%20edge%20-%20128gb-black%20sapphire-100x160.jpg",
                        "color": "Black Sapphire",
                        "name": "Samsung Galaxy S6 edge",
                        "skuId": "sku7520839",
                        "brand": "Samsung"
                    },
                    {
                        "htmlColor": "#000000",
                        "starRatings": "2.9745",
                        "model": "DuraForce",
                        "imageUrlHiRes": "https://tst31.stage.att.com/catalog/en/skus/images/kyocera-duraforce-black-450x350.jpg",
                        "marketingSequence": "22000",
                        "imageUrl": "https://tst31.stage.att.com/catalog/en/skus/images/kyocera-duraforce-black-100x160.jpg",
                        "color": "Black",
                        "name": "Kyocera DuraForce",
                        "skuId": "sku7461316",
                        "brand": "Kyocera"
                    },
                    {
                        "htmlColor": "#000000",
                        "starRatings": "3.5464",
                        "model": "DuraXE",
                        "imageUrlHiRes": "https://tst31.stage.att.com/catalog/en/skus/images/kyocera-duraxe-black-450x350.jpg",
                        "marketingSequence": "23000",
                        "imageUrl": "https://tst31.stage.att.com/catalog/en/skus/images/kyocera-duraxe-black-100x160.jpg",
                        "color": "Black",
                        "name": "Kyocera DuraXE",
                        "skuId": "sku7800343",
                        "brand": "Kyocera"
                    },
                    {
                        "htmlColor": "#000000",
                        "starRatings": "2.5263",
                        "model": "Terrain",
                        "imageUrlHiRes": "https://tst31.stage.att.com/catalog/en/skus/images/nec-terrain-black-450x350.jpg",
                        "marketingSequence": "24000",
                        "imageUrl": "https://tst31.stage.att.com/catalog/en/skus/images/nec-terrain-black-100x160.jpg",
                        "color": "Black",
                        "name": "NEC Terrain",
                        "skuId": "sku7820260",
                        "brand": "NEC"
                    },
                    {
                        "htmlColor": "#000000",
                        "starRatings": "2.6667",
                        "model": "G3",
                        "imageUrlHiRes": "https://tst31.stage.att.com/catalog/en/skus/images/lg-g3-metallic%20black-450x350.jpg",
                        "marketingSequence": "25000",
                        "imageUrl": "https://tst31.stage.att.com/catalog/en/skus/images/lg-g3-metallic%20black-100x160.jpg",
                        "color": "Metallic Black",
                        "name": "LG G3",
                        "skuId": "sku7900538",
                        "brand": "LG"
                    },
                    {
                        "htmlColor": "#FFFFF",
                        "starRatings": "3.0909",
                        "model": "XP5",
                        "imageUrlHiRes": "https://tst31.stage.att.com/catalog/en/skus/images/sonim-xp5-black-450x350.jpg",
                        "marketingSequence": "26000",
                        "imageUrl": "https://tst31.stage.att.com/catalog/en/skus/images/sonim-xp5-black-100x160.jpg",
                        "color": "Black",
                        "name": "Sonim XP5",
                        "skuId": "sku7620281",
                        "brand": "Sonim"
                    },
                    {
                        "htmlColor": "#FFFFFF",
                        "starRatings": "3.7941",
                        "model": "Lumia 640 XL",
                        "imageUrlHiRes": "https://tst31.stage.att.com/catalog/en/skus/images/microsoft-lumia%20640%20xl-matte%20white-450x350.jpg",
                        "marketingSequence": "27000",
                        "imageUrl": "https://tst31.stage.att.com/catalog/en/skus/images/microsoft-lumia%20640%20xl-matte%20white-100x160.jpg",
                        "color": "Matte White",
                        "name": "Microsoft Lumia 640 XL",
                        "skuId": "sku7641023",
                        "brand": "Microsoft"
                    },
                    {
                        "htmlColor": "#B9B9B9",
                        "starRatings": "4.0549",
                        "model": "Wireless Home Phone",
                        "imageUrlHiRes": "https://tst31.stage.att.com/catalog/en/skus/images/at&t-wireless%20home%20phone-silver-450x350.jpg",
                        "marketingSequence": "28000",
                        "imageUrl": "https://tst31.stage.att.com/catalog/en/skus/images/at&t-wireless%20home%20phone-silver-100x160.jpg",
                        "color": "Silver",
                        "name": "AT&T Wireless Home Phone",
                        "skuId": "sku7250257",
                        "brand": "AT&T"
                    },
                    {
                        "htmlColor": "000000",
                        "starRatings": "3.9268",
                        "model": "Wireless Home Phone & Internet",
                        "imageUrlHiRes": "https://tst31.stage.att.com/catalog/en/skus/images/at&t-wireless%20home%20phone%20&%20internet-black-450x350.jpg",
                        "marketingSequence": "29000",
                        "imageUrl": "https://tst31.stage.att.com/catalog/en/skus/images/at&t-wireless%20home%20phone%20&%20internet-black-100x160.jpg",
                        "color": "Black",
                        "name": "AT&T Wireless Home Phone & Internet",
                        "skuId": "sku7130587",
                        "brand": "AT&T"
                    }
                ]
            }
        }
    };
})();
