var Endpoint_upgradeEligibilityPayment = (function () {
    'use strict';

    return {

        /**
         * Get upgrade eligibility users by calling api
         */

        'get_upgrade_payment_details': {
            url_match: /\/apis\/checkout\/upgradepayment\/v1\/upgradePaymentInfo\/976b99d3-9220-0054-61f3-a745c98d6bd2.*/,
            response_code: 200,
            params_sent: '?',
            result: {
                "payload": {
                    "paymentInfo": {
                        "paymentMethods": {
                            "PAYMENT_OPTION_01": {
                                "id": "PG1",
                                "paymentType": "paymentProfile",
                                "cardNumber": "XXXXXXXXXXXX2200",
                                "expMonth": "07",
                                "expYear": "19",
                                "name": "BEDROCK DONOTUSE",
                                "addToWallet": false,
                                "inOrder": false,
                                "inAccount": false,
                                "appliedTo": null,
                                "cardType": "MC",
                                "cardExpired": false,
                                "billingZipCode": "98011",
                                "accountNumber": null,
                                "routingNumber": null,
                                "sameCardForAutopay": null,
                                "autopayEnrolled": null,
                                "displayName": "MC ending With 2200",
                                "verifiedSecurity": true,
                                "attAccessCardFlag": null
                            }
                        },
                        "metadata": null,
                        "eligibilepaymentmethods": null,
                        "savePaymentProfileOption": false,
                        "displayACHInfo": false,
                        "advancePaymentAmount": null,
                        "creditManagementFee": null,
                        "dueToday": null,
                        "totalDueTodayFee": null,
                        "wirelessSecurityDepositAmount": null,
                        "autoPayTerms": null,
                        "autoPayTermsSelected": false,
                        "dtvSecurityFeeAmount": null,
                        "nonRefundableFee": null,
                        "sameCardForAutopay": null,
                        "dueMonthly": 0,
                        "fmoFlag": false,
                        "oneTimeTerms": null,
                        "citiCustomerFlow": false,
                        "autopayEnrolled": null,
                        "creditCardOnFile": false,
                        "wireLessUnified": false,
                        "dtvunified": false,
                        "onlyDTVInCart": false,
                        "masterPass": false
                    }
                }
            }
            // End result

        }
    }
})();