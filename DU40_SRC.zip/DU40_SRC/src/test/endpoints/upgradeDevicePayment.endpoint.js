var Endpoint_upgradeDevicePayment = (function () {
    'use strict';

    return {

        /**
         * Get upgrade eligibility users by calling api
         */
        'getUpgradingDevicePaymentData': {
            url_match: /\/services\/shopwireless\/model\/att\/ecom\/api\/BuyFlowController\/service.*/,
            response_code: 200,
            params_sent: '?actionType=getupoptions',
            result: {
                "response": {
                    "redirectKey": null,
                    "errors": null,
                    "status": "success",
                    "subStatus": null,
                    "redirectURL": null,
                    "redirect": false
                },
                "payload": {
                    "payUpAmount": 0,
                    "upgradeOptionSelected": "PAYOFF",
                    "payOffAmount": 100.00,
                    "installmentID": "300000000020410",
                    "selectedSubscriber": "4252050545",
                    "errorCodeDetails": null
                }
            }
        }
    }
})();