var Endpoint_upgradeEligibility = (function () {
    'use strict';

    return {

        /**
         * Get upgrade eligibility users by calling api
         */

        'get_device_details': {
            url_match: /\/services\/shopwireless\/model\/att\/ecom\/api\/WirelessUpgradeSelectionActor\/getUpgradeEligibility.*/,
            response_code: 200,
            params_sent: '?',
            result: {
                'response': {
                    'redirectKey': null,
                    'errors': null,
                    'status': 'success',
                    'subStatus': null,
                    'redirectURL': null,
                    'redirect': false
                },
                'payload': {
                    'upgradedLinesInProgress': ['4252050545'],
                    'G20251984': [
                        {
                            'hideUpgradeOption': false,
                            'regUpgradeEligible': false,
                            'contractEndDate': {'time': 1541116800000},
                            'planChangeRequired': false,
                            'groupId': 'G20251984',
                            'eligibilityInfo': {
                                'futureLeaseEligibilityDate': null,
                                'payUpAmount': 0,
                                'crossUpgradeEligibile': false,
                                'upgradeType': 'NO_COMMIT',
                                'futureEarlyEligibilityDate': null,
                                'earlyUpgrade': false,
                                'payOffAmount': 0,
                                'tradeInEligible': true,
                                'eligibility': 'INELIGIBLE',
                                'offerReasonCodes': [
                                    'messageCode.LTV999_Lease'
                                ],
                                'firstEligibilityDate': null,
                                'futureEligibilityDate': null,
                                'offerCodeDiscountAmtMap': {},
                                'eligibilityDate': null
                            },
                            'partOfSharedData': true,
                            'subscriberNumber': '4256862891',
                            'term': 24,
                            'subscriptionClass': null,
                            'contractType': 'lease',
                            'device': {
                                'model': 'iPhone6sPlus',
                                'color': 'Space Gray',
                                'manufacturerForImage': 'Apple',
                                'modelForImage': 'iPhone 6 - 16GB',
                                'deviceType': 'pda',
                                'deviceGroupType': 'Cellphone',
                                'make': 'APPLE',
                                'shortDisplayName': 'Apple Iphone 6s Plus'
                            },
                            'sharedDataMember': true,
                            'noCommitUpgradeEligible': true,
                            'IRUSplitLiability': false,
                            'customerFirstName': 'BEDROCK'
                        },
                        {
                            'hideUpgradeOption': false,
                            'regUpgradeEligible': false,
                            'contractEndDate': {'time': 1541116800000},
                            'planChangeRequired': false,
                            'groupId': 'G20251984',
                            'eligibilityInfo': {
                                'futureLeaseEligibilityDate': {
                                    'time': 1537228800000
                                },
                                'payUpAmount': 0,
                                'crossUpgradeEligibile': false,
                                'upgradeType': 'NO_COMMIT',
                                'futureEarlyEligibilityDate': null,
                                'earlyUpgrade': false,
                                'payOffAmount': 0,
                                'tradeInEligible': false,
                                'eligibility': 'FUTURE_DISCOUNT_ELIGIBLE',
                                'offerReasonCodes': [
                                    'messageCode.LTV998_Lease'
                                ],
                                'firstEligibilityDate': {
                                    'time': 1537228800000
                                },
                                'futureEligibilityDate': {
                                    'time': 1550448000000
                                },
                                'offerCodeDiscountAmtMap': {},
                                'eligibilityDate': null
                            },
                            'partOfSharedData': true,
                            'subscriberNumber': '4256862890',
                            'term': 24,
                            'subscriptionClass': null,
                            'contractType': 'regular',
                            'device': {
                                'model': 'iPhone6sPlus',
                                'color': 'Space Gray',
                                'manufacturerForImage': 'Apple',
                                'modelForImage': 'iPhone 6 - 16GB',
                                'deviceType': 'pda',
                                'deviceGroupType': 'Cellphone',
                                'make': 'APPLE'
                            },
                            'sharedDataMember': true,
                            'noCommitUpgradeEligible': true,
                            'IRUSplitLiability': false,
                            'customerFirstName': 'BEDROCK'
                        }
                    ],
                    'Individual': [
                        {
                            'hideUpgradeOption': false,
                            'regUpgradeEligible': false,
                            'contractEndDate': {'time': 1541116800000},
                            'planChangeRequired': false,
                            'groupId': null,
                            'eligibilityInfo': {
                                'futureLeaseEligibilityDate': null,
                                'payUpAmount': 0,
                                'crossUpgradeEligibile': false,
                                'upgradeType': 'NO_COMMIT',
                                'futureEarlyEligibilityDate': null,
                                'earlyUpgrade': false,
                                'payOffAmount': 0,
                                'tradeInEligible': false,
                                'eligibility': 'DISCOUNT_ELIGIBLE',
                                'offerReasonCodes': [
                                    'messageCode.LTV999_Lease'
                                ],
                                'firstEligibilityDate': null,
                                'futureEligibilityDate': null,
                                'offerCodeDiscountAmtMap': {},
                                'eligibilityDate': null
                            },
                            'partOfSharedData': false,
                            'subscriberNumber': '4252951808',
                            'term': 0,
                            'subscriptionClass': null,
                            'contractType': 'regular',
                            'device': {
                                'model': 'iPhone6sPlus',
                                'color': 'Space Gray',
                                'manufacturerForImage': 'Apple',
                                'modelForImage': 'iPhone 6 - 16GB',
                                'deviceType': 'pda',
                                'deviceGroupType': 'Cellphone',
                                'make': 'APPLE'
                            },
                            'sharedDataMember': false,
                            'noCommitUpgradeEligible': true,
                            'IRUSplitLiability': false,
                            'customerFirstName': 'BEDROCK'
                        },
                        {
                            'hideUpgradeOption': false,
                            'regUpgradeEligible': false,
                            'contractEndDate': {'time': 1541116800000},
                            'planChangeRequired': true,
                            'groupId': null,
                            'eligibilityInfo': {
                                'futureLeaseEligibilityDate': {
                                    'time': 1537228800000
                                },
                                'payUpAmount': 0,
                                'crossUpgradeEligibile': false,
                                'upgradeType': 'NO_COMMIT',
                                'futureEarlyEligibilityDate': null,
                                'earlyUpgrade': false,
                                'payOffAmount': 0,
                                'tradeInEligible': false,
                                'eligibility': 'INELIGIBLE',
                                'offerReasonCodes': [
                                    'messageCode.LTV998_Lease'
                                ],
                                'firstEligibilityDate': {
                                    'time': 1537228800000
                                },
                                'futureEligibilityDate': {
                                    'time': 1550448000000
                                },
                                'offerCodeDiscountAmtMap': {},
                                'eligibilityDate': null
                            },
                            'partOfSharedData': false,
                            'subscriberNumber': '4256862880',
                            'term': 24,
                            'subscriptionClass': null,
                            'contractType': 'regular',
                            'device': {
                                'model': 'iPhone6sPlus',
                                'color': 'Space Gray',
                                'manufacturerForImage': 'Apple',
                                'modelForImage': 'iPhone 6 - 16GB',
                                'deviceType': 'pda',
                                'deviceGroupType': 'Cellphone',
                                'make': 'APPLE'
                            },
                            'sharedDataMember': false,
                            'noCommitUpgradeEligible': false,
                            'IRUSplitLiability': true,
                            'customerFirstName': 'BEDROCK'
                        }
                    ],
                    '4252951809': [
                        {
                            'hideUpgradeOption': false,
                            'regUpgradeEligible': false,
                            'contractEndDate': {'time': 1541116800000},
                            'planChangeRequired': false,
                            'groupId': null,
                            'eligibilityInfo': {
                                'futureLeaseEligibilityDate': null,
                                'payUpAmount': 50,
                                'crossUpgradeEligibile': false,
                                'upgradeType': 'NO_COMMIT',
                                'futureEarlyEligibilityDate': null,
                                'earlyUpgrade': false,
                                'payOffAmount': 0,
                                'tradeInEligible': false,
                                'eligibility': 'ELIGIBLE',
                                'offerReasonCodes': [
                                    'messageCode.LTV999_Lease'
                                ],
                                'firstEligibilityDate': null,
                                'futureEligibilityDate': null,
                                'offerCodeDiscountAmtMap': {},
                                'eligibilityDate': null
                            },
                            'partOfSharedData': false,
                            'subscriberNumber': '4252951809',
                            'term': 24,
                            'subscriptionClass': null,
                            'contractType': 'install',
                            'device': {
                                'model': 'iPhone6sPlus',
                                'color': 'Space Gray',
                                'manufacturerForImage': 'Apple',
                                'modelForImage': 'iPhone 6 - 16GB',
                                'deviceType': 'pda',
                                'deviceGroupType': 'Cellphone',
                                'make': 'Apple'
                            },
                            'sharedDataMember': false,
                            'noCommitUpgradeEligible': true,
                            'IRUSplitLiability': false,
                            'customerFirstName': 'BEDROCK'
                        },
                        {
                            'hideUpgradeOption': false,
                            'regUpgradeEligible': false,
                            'contractEndDate': {'time': 1541116800000},
                            'planChangeRequired': false,
                            'groupId': null,
                            'eligibilityInfo': {
                                'futureLeaseEligibilityDate': null,
                                'payUpAmount': 0,
                                'crossUpgradeEligibile': false,
                                'upgradeType': 'NO_COMMIT',
                                'futureEarlyEligibilityDate': null,
                                'earlyUpgrade': false,
                                'payOffAmount': 70,
                                'tradeInEligible': false,
                                'eligibility': 'ELIGIBLE',
                                'offerReasonCodes': [
                                    'messageCode.LTV999_Lease'
                                ],
                                'firstEligibilityDate': null,
                                'futureEligibilityDate': null,
                                'offerCodeDiscountAmtMap': {},
                                'eligibilityDate': null
                            },
                            'partOfSharedData': false,
                            'subscriberNumber': '4256862873',
                            'term': 24,
                            'subscriptionClass': null,
                            'contractType': 'regular',
                            'device': {
                                'model': 'iPhone6sPlus',
                                'color': 'Space Gray',
                                'manufacturerForImage': 'Apple',
                                'modelForImage': 'iPhone 6 - 16GB',
                                'deviceType': 'pda',
                                'deviceGroupType': 'Cellphone',
                                'make': 'APPLE'
                            },
                            'sharedDataMember': false,
                            'noCommitUpgradeEligible': true,
                            'IRUSplitLiability': false,
                            'customerFirstName': 'BEDROCK'
                        }
                    ]
                }
            }
            // End result

        },

        /**
         * Get linesData for reporting parameters
         */
        'lines_data_for_reporting_params': {
            result: {
                selectedLines: [
                    {
                        tradeInOptions: {
                            eligibleFlag: 'REPLACE',
                            displayUpgradeOptionLink: false
                        },
                        subscriberNumber: 'false',
                        device: {
                            color: 'Black',
                            make: 'Samsung',
                            model: 'Galaxy S8',
                            skuId: 'sku12345'
                        },
                        eligibilityInfo: {
                            futureLeaseEligibilityDate: null,
                            payUpAmount: 50,
                            crossUpgradeEligibile: false,
                            upgradeType: 'Pay Up',
                            futureEarlyEligibilityDate: null,
                            earlyUpgrade: false,
                            payOffAmount: 0,
                            tradeInEligible: false,
                            eligibility: 'INELIGIBLE',
                            offerReasonCodes: [
                                'messageCode.LTV999_Lease'
                            ],
                            tradeInOptions: {
                                disableTile: false,
                                displayUpgradeOptionLink: true,
                                eligibleFlag: 'PAYUP',
                                message: 'Pay $50.00 and trade in your device to upgrade early ',
                                showInfoIcon: false,
                                tradeInEligible: false
                            }
                        }
                    },
                    {
                        tradeInOptions: {
                            eligibleFlag: 'REPLACE',
                            displayUpgradeOptionLink: false
                        },
                        subscriberNumber: 'false',
                        device: {
                            color: 'Red',
                            make: 'Apple',
                            model: 'iPhone 7',
                            skuId: 'sku1234',
                            shortDisplayName: 'Apple Iphone 6s Plus'
                        }
                    },
                    {
                        tradeInOptions: {
                            eligibleFlag: 'REPLACE',
                            displayUpgradeOptionLink: false
                        },
                        subscriberNumber: 'false',
                        device: {
                            color: 'Blue',
                            make: 'Samsung',
                            model: 'Galaxy S7',
                            skuId: 'sku123'
                        }
                    }
                ],
                lines: [
                    {
                        customerFirstName: 'BEDROCK',
                        device: {
                            color: 'Space Gray',
                            make: 'APPLE',
                            manufacturerForImage: 'Apple',
                            model: 'iPhone6sPlus',
                            modelForImage: 'iPhone 6 - 16GB',
                            skuId: 'sku12345',
                            shortDisplayName: 'Apple Iphone 6s Plus'
                        },
                        eligibilityInfo: {
                            futureLeaseEligibilityDate: null,
                            payUpAmount: 50,
                            crossUpgradeEligibile: false,
                            upgradeType: 'Pay Up',
                            futureEarlyEligibilityDate: null,
                            earlyUpgrade: false,
                            payOffAmount: 0,
                            tradeInEligible: false,
                            eligibility: 'ELIGIBLE',
                            offerReasonCodes: [
                                'messageCode.LTV999_Lease'
                            ],
                            tradeInOptions: {
                                disableTile: false,
                                displayUpgradeOptionLink: true,
                                eligibleFlag: 'PAYUP',
                                message: 'Pay $50.00 and trade in your device to upgrade early ',
                                showInfoIcon: false,
                                tradeInEligible: false
                            }
                        },
                        contractType: 'Two-year contract ends Nov. 01, 2018',
                        contractLength: '24',
                        contractTypeWithoutDate: 'regular'
                    },
                    {
                        customerFirstName: 'BEDROCK',
                        device: {
                            color: 'Gray',
                            make: 'APPLE',
                            manufacturerForImage: 'Apple',
                            model: 'iPhone6sPlus',
                            modelForImage: 'iPhone 6 - 32GB',
                            skuId: 'sku12378'
                        },
                        eligibilityInfo: {
                            futureLeaseEligibilityDate: null,
                            payUpAmount: 0,
                            crossUpgradeEligibile: false,
                            upgradeType: 'Pay Up',
                            futureEarlyEligibilityDate: null,
                            earlyUpgrade: false,
                            payOffAmount: 0,
                            tradeInEligible: true,
                            eligibility: 'DISCOUNT_ELIGIBLE',
                            offerReasonCodes: [
                                'messageCode.LTV999_Lease'
                            ],
                            tradeInOptions: {
                                disableTile: false,
                                displayUpgradeOptionLink: true,
                                eligibleFlag: 'PAYUP',
                                message: 'Pay $50.00 and trade in your device to upgrade early ',
                                showInfoIcon: false,
                                tradeInEligible: false
                            }
                        },
                        contractType: '0-month installment plan ends Apr. 4, 2008',
                        contractLength: '0',
                        contractTypeWithoutDate: 'regular'
                    },
                    {
                        customerFirstName: 'BEDROCK',
                        device: {
                            color: 'Black',
                            make: 'APPLE',
                            manufacturerForImage: 'Apple',
                            model: 'iPhone6sPlus',
                            modelForImage: 'iPhone 6 - 32GB',
                            skuId: 'sku12394'
                        },
                        eligibilityInfo: {
                            futureLeaseEligibilityDate: null,
                            payUpAmount: 0,
                            crossUpgradeEligibile: false,
                            upgradeType: 'Pay Off',
                            futureEarlyEligibilityDate: null,
                            earlyUpgrade: true,
                            payOffAmount: 30,
                            tradeInEligible: false,
                            eligibility: '',
                            offerReasonCodes: [
                                'messageCode.LTV999_Lease'
                            ],
                            tradeInOptions: {
                                disableTile: false,
                                displayUpgradeOptionLink: true,
                                eligibleFlag: 'PAYOFF',
                                message: 'Pay $50.00 and trade in your device to upgrade early ',
                                showInfoIcon: false,
                                tradeInEligible: false
                            }
                        },
                        contractType: 'Two-year contract ends Nov. 01, 2018',
                        contractLength: '24',
                        contractTypeWithoutDate: 'regular'
                    },
                    {
                        customerFirstName: 'BEDROCK',
                        device: {
                            color: 'Black',
                            make: 'Samsung',
                            manufacturerForImage: 'Samsung',
                            model: 'S8',
                            modelForImage: 'Galaxy S8 - 32GB',
                            skuId: 'sku12332'
                        },
                        eligibilityInfo: {
                            futureLeaseEligibilityDate: null,
                            payUpAmount: 0,
                            crossUpgradeEligibile: false,
                            upgradeType: 'Pay Off',
                            futureEarlyEligibilityDate: null,
                            earlyUpgrade: true,
                            payOffAmount: 0,
                            tradeInEligible: false,
                            eligibility: '',
                            offerReasonCodes: [
                                'messageCode.LTV999_Lease'
                            ],
                            tradeInOptions: {
                                disableTile: false,
                                displayUpgradeOptionLink: true,
                                eligibleFlag: 'PAYOFF',
                                message: 'Pay $50.00 and trade in your device to upgrade early ',
                                showInfoIcon: false,
                                tradeInEligible: false
                            }
                        },
                        contractType: 'Two-year contract ends Nov. 01, 2018',
                        contractLength: '24',
                        contractTypeWithoutDate: 'regular'
                    },
                    {
                        customerFirstName: 'BEDROCK',
                        device: {
                            color: 'Black',
                            make: 'Samsung',
                            manufacturerForImage: 'Samsung',
                            model: 'S8',
                            modelForImage: 'Galaxy S8 - 32GB',
                            skuId: 'sku12332'
                        },
                        eligibilityInfo: {
                            futureLeaseEligibilityDate: null,
                            payUpAmount: 0,
                            crossUpgradeEligibile: false,
                            upgradeType: 'Pay Off',
                            futureEarlyEligibilityDate: null,
                            earlyUpgrade: false,
                            payOffAmount: 0,
                            tradeInEligible: false,
                            eligibility: '',
                            offerReasonCodes: [
                                'messageCode.LTV999_Lease'
                            ],
                            tradeInOptions: {
                                disableTile: false,
                                displayUpgradeOptionLink: true,
                                eligibleFlag: 'PAYOFF',
                                message: 'Pay $50.00 and trade in your device to upgrade early ',
                                showInfoIcon: false,
                                tradeInEligible: false
                            }
                        },
                        noCommitUpgradeEligible: false,
                        contractType: 'Two-year contract ends Nov. 01, 2018',
                        contractLength: '24',
                        contractTypeWithoutDate: 'regular'
                    },
                    {
                        customerFirstName: 'BEDROCK',
                        device: {
                            color: 'Black',
                            make: 'Samsung',
                            manufacturerForImage: 'Samsung',
                            model: 'S8',
                            modelForImage: 'Galaxy S8 - 32GB',
                            skuId: 'sku12332'
                        },
                        eligibilityInfo: {
                            futureLeaseEligibilityDate: null,
                            payUpAmount: 0,
                            crossUpgradeEligibile: false,
                            upgradeType: 'Pay Off',
                            futureEarlyEligibilityDate: null,
                            earlyUpgrade: false,
                            payOffAmount: 0,
                            tradeInEligible: false,
                            eligibility: '',
                            offerReasonCodes: [
                                'messageCode.LTV999_Lease'
                            ],
                            tradeInOptions: {
                                disableTile: false,
                                displayUpgradeOptionLink: true,
                                eligibleFlag: 'PAYOFF',
                                message: 'Pay $50.00 and trade in your device to upgrade early ',
                                showInfoIcon: false,
                                tradeInEligible: false
                            }
                        },
                        noCommitUpgradeEligible: true,
                        contractType: 'Two-year contract ends Nov. 01, 2018',
                        contractLength: '24',
                        contractTypeWithoutDate: 'regular'
                    }
                ]
            }
            // End result
        }
    };
})();