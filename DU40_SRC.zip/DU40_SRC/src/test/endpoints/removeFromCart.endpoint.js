/**
 * Test response for the remove from cart
 *
 * @example
 * $httpBackend.whenGET(removeFromCart.url_match)
 *      .respond(200, Endpoint_removeFromCart.remove_item_from_cart.result);
 */
var Endpoint_removeFromCart = (function () {
    'use strict';

    return {
        'url_match': /services\/shopwireless\/model\/att\/ecom\/api\/BuyFlowController\/service/,
        'remove_item_from_cart': {
            'params_sent': {
            	'removalCommerceIds': '123456789'
            },
            'result': {
                'response': {
                    'redirectKey': '',
                    'errors': null,
                    'status': 'success',
                    'redirectURL': null,
                    'redirect': false
                }
            }
        }
    };


})();