/**
 * Utility functions used to streamline unit tests
 * @type {{
 *      callServiceFunction,
 *      createFakePromiseFunc,
 *      createMockServiceCall,
 *      performPlainDataServiceTest,
 *      performQPromiseTest,
 *      performServiceTest,
 *      verifyExpectationsComplete
 * }}
 */
var EndpointUtils = (function () {
    'use strict';

    return {
        callServiceFunction: callServiceFunction,
        createFakePromiseFunc: createFakePromiseFunc,
        createMockServiceCall: createMockServiceCall,
        performPlainDataServiceTest: performPlainDataServiceTest,
        performQPromiseTest: performQPromiseTest,
        performServiceTest: performServiceTest,
        verifyExpectationsComplete: verifyExpectationsComplete
    };

    /**
     * Executes commands to verify test expectations
     * @param {object} $httpBackend - object used to create mock response.
     */
    function verifyExpectationsComplete($httpBackend) {
        $httpBackend.verifyNoOutstandingExpectation();
        $httpBackend.verifyNoOutstandingRequest();
    }

    /**
     * Provides a mock function response for functions that return promises
     * @param {object} config - configuration object for promise function
     * @param {function} config.spyFn - the spy call that returns a promise
     * @param {object} [config.data] - information to pass to the promise callback
     * @param {boolean} [config.error = false] - if failure function should be triggered
     */
    function createFakePromiseFunc(config) {
        config.spyFn.and.callFake(function () {
            return {
                then: function (success, failure) {
                    var data = angular.copy(config.data);

                    if (config.error === true) {
                        failure(data);
                    } else {
                        success(data);
                    }
                }
            }
        });
    }

    /**
     * Used to create a mock response from a backend service
     * @param config - configuration object for mock service call
     * @param {object} config.$httpBackend - the angular service used to create backend mocks
     * @param {HttpMethod} config.method - HTTP method used for this interaction
     * @param {Endpoint} config.endpoint - the endpoint object to use for creating the mock
     * @param {ResponseCallback} [config.callback] - function that can be used to test the values of url, passed params, data and headers
     */
    function createMockServiceCall(config) {
        config.$httpBackend.expect(config.method, config.endpoint.url_match)
            .respond(function (method, url, data, headers, params) {
                if (config.callback instanceof Function) {
                    config.callback(url, params, data, headers);
                }

                return [
                    config.endpoint.response_code,
                    angular.copy(config.endpoint.result || config.endpoint.data),
                    angular.copy(config.endpoint.headers)
                ];
            });
    }

    /**
     * @param {object} $httpBackend - the service used for mocking backend requests
     * @param {function} fn - angular service function under test
     * @param {object[]} [args] - arguments to the service function
     *
     * @param {object} request - configuration used to test a request
     * @param {function} request.callback - called in the promise when the request has been completed
     * @param {boolean} [request.expectPromiseFail] - expect the promise to be rejected
     * @param {string} [request.failMessage] - message to display if the wrong promise callback triggered
     * @param {function} [request.preFlush] - function to call before flushing backend
     */
    function callServiceFunction($httpBackend, fn, args, request) {
        fn.apply(null, args).then(
            function (results) {
                if (request.expectPromiseFail === true) {
                    fail(request.failMessage || 'No valid reason provided!!! Promise success function');
                } else {
                    request.callback(results);
                }
            },
            function (results) {
                if (request.expectPromiseFail !== true) {
                    fail(request.failMessage || 'No valid reason provided!!! Promise fail function');
                } else {
                    request.callback(results);
                }
            });

        if (request.preFlush instanceof Function) {
            request.preFlush();
        }

        $httpBackend.flush();
    }

    /**
     * Utility function used to perform network call related tests on services.
     * @param {function} fn - angular service function under test
     * @param {object[]} [args] - arguments to the service function
     *
     * @param {object} response - config used passed to {@link createMockServiceCall}
     *
     * @param {object} request - configuration used to test a request
     * @param {function} request.callback - called in the promise when the request has been completed
     * @param {boolean} [request.expectPromiseFail] - expect the promise to be rejected
     * @param {string} [request.failMessage] - message to display if the wrong promise callback triggered
     * @param {function} [request.preFlush] - function to call before flushing backend
     */
    function performServiceTest(fn, args, response, request) {
        createMockServiceCall(response);
        callServiceFunction(response.$httpBackend, fn, args, request);
    }

    /**
     * Performs basic test to verify that a service returns data that matches the results
     * sent by the backend API and nothing else about the resolved promise
     * @param {function} fn - angular service function under test
     * @param {object[]} [args] - arguments to the service function
     *
     * @param {object} response - config used passed to {@link createMockServiceCall}
     */
    function performPlainDataServiceTest(fn, args, response) {
        performServiceTest(fn, args, response, {
            callback: function (results) {
                expect(results).toEqual(response.endpoint.result || response.endpoint.data);
            }
        });
    }

    /**
     * Executes a simple test against a angular $q related promise that is not tied to a network call.
     * @param config
     * @param {function} config.done - completion function of the unit test case
     * @param {object} config.scope - angular scope to use to trigger $q processing
     * @param {function} config.fn - the function to be unit tested
     * @param {object[]} [config.args] - arguments to pass to unit tested function
     * @param {GenericPromiseCallback} config.test - test to perform before completing functionality
     */
    function performQPromiseTest(config) {
        config.fn.apply(null, config.args).then(function (result) {
            config.test(result);
            config.done();
        });

        config.scope.$apply();
    }

    /**
     * A HTTP method 'GET', 'POST', 'PUT' or 'HEAD'
     * @typedef {string} HttpMethod
     */

    /**
     * Represents an example response from a backend API and the information needed to get
     * the specific response.
     * @typedef {object} Endpoint
     * @property {number} response_code - represents the HTTP response code of the request
     * @property {regex|string} url_match - used to match to the expected request url
     * @property {object} [result] - data that is returned upon completion
     * @property {object} [data] - data that is returned upon completion
     * @property {object} [headers] - key value pairs making up the headers to include in the response
     * @property {object} [params] - key value pairs that make up the query parameters
     */

    /**
     * @callback ResponseCallback
     * @param {string} url - the complete requested url
     * @param {object} params - the query parameters passed
     * @param {object} data - information sent in post
     * @param {object} headers - HTTP headers included in the request
     */

    /**
     * @callback GenericPromiseCallback
     * @param {*} data - the results of the promise
     */

}());