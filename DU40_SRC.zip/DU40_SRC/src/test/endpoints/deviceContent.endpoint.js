/**
 * Various test responses for the device content service
 *
 * @example
 * $httpBackend.whenGET(Endpoint_deviceContentNode.get_content_node.url_match)
 *      .respond(200, Endpoint_deviceContentNode.get_content_node.result);
 */
var Endpoint_deviceContentNode = (function () {
    'use strict';

    return {
        "get_content_node": {
            url_match: /\/cellphones\/iphone\/apple-iphone-7\/jcr:content\/devicetabs.eternity.json/,
            response_code: 200,
            params_sent: '',
            result: {
                "jcr:lastModifiedBy": "admin",
                "excludeDeviceDDRRVXBY": "false",
                "sling:resourceType": "att/wireless/components/devicedetails/devicedetailtabsredesign",
                "jcr:lastModified": "Tue Nov 29 2016 19:38:24 GMT-0800",
                "excludeDeviceDDRRVXVY": "false",
                "jcr:primaryType": "nt:unstructured",
                "overviewpar": {
                    "sling:resourceType": "foundation/components/parsys",
                    "jcr:primaryType": "nt:unstructured",
                    "rwdoverviewsection": {
                        "description": " <div class=\" offset1 span6  top-space \">\n\n   <div class=\"hidden-desktop\"><br><\/div> \n\n <p class=\"heading-sub-section\">This is iPhone 7 Plus<\/p>\n\n        <p>iPhone 7 Plus dramatically improves the most important aspects of the iPhone experience. It introduces advanced new camera systems. The best performance and battery life ever in an iPhone. Immersive stereo speakers. The brightest, most colorful iPhone display. Splash and water resistance.<sup>1<\/sup> And it looks every bit as powerful as it is.<\/p> \n\n<\/div>",
                        "title": "<h2 class=\"overviewDS2 heading-page text-center overviewHeadingBackgroundBlack\">Overview<\/h2>",
                        "backgroundColor": "black",
                        "sling:resourceType": "att/wireless/components/rwdOverviewsection",
                        "descriptionWithOwnCSSAndText": "<p>&lt;div class=&quot;span10 top-space&quot;&gt;<\/p>\n<p>&nbsp; &nbsp;&lt;div class=&quot;hidden-desktop&quot;&gt;&lt;br&gt;&lt;/div&gt;&nbsp;<\/p>\n<p>&nbsp; &nbsp; &nbsp; &nbsp; &lt;p class=&quot;heading-sub-section&quot;&gt;This is iPhone 7&lt;/p&gt;&nbsp;<\/p>\n<p>&nbsp; &nbsp; &nbsp; &nbsp; &lt;p&gt;iPhone 7 dramatically improves the most important aspects of the iPhone experience. It introduces advanced new camera systems. The best performance and battery life ever in an iPhone. Immersive stereo speakers. The brightest, most colorful iPhone display. Splash and water resistance.&lt;sup&gt;1&lt;/sup&gt; And it looks every bit as powerful as it is. &lt;/p&gt;&nbsp;<\/p>\n<p>&lt;/div&gt;<\/p>\n",
                        "oneheading": "true",
                        "jcr:created": "Mon Nov 28 2016 18:54:36 GMT-0800",
                        "fontColor": "white",
                        "jcr:primaryType": "nt:unstructured",
                        "jcr:lastModifiedBy": "pm0558",
                        "bottomSpacingBelowEachSection": "<div class=\"SpacingBottom60\"><\/div>",
                        "jcr:createdBy": "aa4589",
                        "spacing": "4",
                        "overViewTitleShow": "true",
                        "imagePosition": "alignLeftWithText",
                        "jcr:lastModified": "Tue Apr 18 2017 15:16:46 GMT-0700",
                        "frontimage": {
                            "jcr:lastModifiedBy": "pm0558",
                            "imageRotate": "0",
                            "sling:resourceType": "foundation/components/image",
                            "jcr:lastModified": "Tue Apr 18 2017 15:16:46 GMT-0700",
                            "linkURL": "/catalog/en/skus/Apple/iPhone 7 Plus/overview/304963-pdp-overview-apple-iphone7-tile_01.jpg",
                            "jcr:primaryType": "nt:unstructured"
                        },
                        "backimage": {
                            "jcr:lastModifiedBy": "pm0558",
                            "imageRotate": "0",
                            "sling:resourceType": "foundation/components/image",
                            "jcr:lastModified": "Tue Apr 18 2017 15:16:46 GMT-0700",
                            "jcr:primaryType": "nt:unstructured"
                        }
                    },
                    "rwdoverviewsection_5": {
                        "description": "<div style=\"position: relative;width: 100%;\"> \n\t<div>\n\t\t<img src=\"/catalog/en/skus/Apple/Apple iPhone 7 Plus/overview/304963-pdp-overview-apple-iphone7-tile_07.jpg\" alt=\"\" style=\"visibility: hidden; width:100%\">\n\t<\/div>\n<\/div>",
                        "backgroundColor": "#121212",
                        "jcr:lastModifiedBy": "pm0558",
                        "sling:resourceType": "att/wireless/components/rwdOverviewsection",
                        "jcr:createdBy": "pm0558",
                        "backgroundImage": "true",
                        "imagePosition": "noImageJustText",
                        "jcr:created": "Wed Mar 29 2017 11:03:53 GMT-0700",
                        "jcr:lastModified": "Wed Mar 29 2017 11:52:40 GMT-0700",
                        "jcr:primaryType": "nt:unstructured",
                        "frontimage": {
                            "jcr:lastModifiedBy": "pm0558",
                            "imageRotate": "0",
                            "sling:resourceType": "foundation/components/image",
                            "jcr:lastModified": "Wed Mar 29 2017 11:52:40 GMT-0700",
                            "linkURL": "/catalog/en/skus/Apple/Apple iPhone 7 Plus/overview/304963-pdp-overview-apple-iphone7-tile_07.jpg",
                            "jcr:primaryType": "nt:unstructured"
                        },
                        "backimage": {
                            "jcr:lastModifiedBy": "pm0558",
                            "imageRotate": "0",
                            "sling:resourceType": "foundation/components/image",
                            "jcr:lastModified": "Wed Mar 29 2017 11:52:40 GMT-0700",
                            "jcr:primaryType": "nt:unstructured"
                        }
                    },
                    "rwdoverviewsection_0": {
                        "description": "Almost everything you experience with your iPhone comes to life on its display. It's where you look at the photos, messages, news, and countless other things that make up your day. The iPhone 7 display uses the same color space as the digital cinema industry, so what you see will be noticeably more brilliant and vibrant. Because we all deserve a bit more brightness in our day.",
                        "backgroundColor": "black",
                        "sling:resourceType": "att/wireless/components/rwdOverviewsection",
                        "jcr:created": "Mon Nov 28 2016 19:04:56 GMT-0800",
                        "fontColor": "white",
                        "jcr:primaryType": "nt:unstructured",
                        "spacingBetweenComponents": "<div class=\"SpacingTop60\"><\/div>",
                        "bleedImage": "true",
                        "bottomSpacingBelowEachSection": "<div class=\"SpacingBottom60\"><\/div>\n",
                        "jcr:lastModifiedBy": "pm0558",
                        "subHeadingTwo": "The brightest, most colorful iPhone display yet",
                        "subHeadingOne": "<span class=\"SpacingTop60 whiteColorFont\">Retina hd display<\/span>",
                        "jcr:createdBy": "aa4589",
                        "imagePosition": "alignMiddleWithText",
                        "jcr:lastModified": "Wed Mar 15 2017 00:16:51 GMT-0700",
                        "frontimage": {
                            "jcr:lastModifiedBy": "pm0558",
                            "imageRotate": "0",
                            "sling:resourceType": "foundation/components/image",
                            "jcr:lastModified": "Wed Mar 15 2017 00:16:51 GMT-0700",
                            "linkURL": "/catalog/en/skus/Apple/iPhone 7/overview/304963-pdp-overview-apple-iphone7-tile_02.jpg",
                            "jcr:primaryType": "nt:unstructured"
                        },
                        "backimage": {
                            "jcr:lastModifiedBy": "pm0558",
                            "imageRotate": "0",
                            "sling:resourceType": "foundation/components/image",
                            "jcr:lastModified": "Wed Mar 15 2017 00:16:51 GMT-0700",
                            "jcr:primaryType": "nt:unstructured"
                        }
                    },
                    "rwdoverviewsection_3": {
                        "description": "For the first time, iPhone comes with stereo speakers, delivering two times the audio output of iPhone 6s and increased dynamic range. So whether you're listening to music, watching videos, or making speakerphone calls, iPhone 7 lets you crank it up. Way, way up.",
                        "backgroundColor": "black",
                        "sling:resourceType": "att/wireless/components/rwdOverviewsection",
                        "jcr:created": "Tue Nov 29 2016 18:38:56 GMT-0800",
                        "fontColor": "white",
                        "jcr:primaryType": "nt:unstructured",
                        "spacingBetweenComponents": "<div class=\"SpacingTop60\"><\/div>",
                        "jcr:lastModifiedBy": "pm0558",
                        "bottomSpacingBelowEachSection": "<div class=\"SpacingBottom60\"><\/div>",
                        "subHeadingOne": "<span class=\"SpacingTop60 whiteColorFont\">Audio<\/span>",
                        "subHeadingTwo": "iPhone: Now in stereo",
                        "jcr:createdBy": "aa4589",
                        "imagePosition": "alignMiddleWithText",
                        "jcr:lastModified": "Wed Mar 15 2017 00:17:44 GMT-0700",
                        "frontimage": {
                            "jcr:lastModifiedBy": "pm0558",
                            "imageRotate": "0",
                            "sling:resourceType": "foundation/components/image",
                            "jcr:lastModified": "Wed Mar 15 2017 00:17:44 GMT-0700",
                            "linkURL": "/catalog/en/skus/Apple/iPhone 7/overview/304963-pdp-overview-apple-iphone7-tile_03.jpg",
                            "jcr:primaryType": "nt:unstructured"
                        },
                        "backimage": {
                            "jcr:lastModifiedBy": "pm0558",
                            "imageRotate": "0",
                            "sling:resourceType": "foundation/components/image",
                            "jcr:lastModified": "Wed Mar 15 2017 00:17:44 GMT-0700",
                            "jcr:primaryType": "nt:unstructured"
                        }
                    },
                    "rwdoverviewsection_1": {
                        "description": "iPhone is the most popular camera in the world. Now we've reengineered that beloved camera, adding optical image stabilization, an Æ’/1.8 aperture, and a six-element lens to make it even better for shooting photos and videos in low light. And with advanced new features like wide color capture, your photos and Live Photos will look even more vibrant.",
                        "backgroundColor": "black",
                        "sling:resourceType": "att/wireless/components/rwdOverviewsection",
                        "jcr:created": "Tue Nov 29 2016 18:43:13 GMT-0800",
                        "fontColor": "white",
                        "jcr:primaryType": "nt:unstructured",
                        "spacingBetweenComponents": "<div class=\"SpacingTop60\"><\/div>",
                        "bleedImage": "true",
                        "jcr:lastModifiedBy": "pm0558",
                        "bottomSpacingBelowEachSection": "<div class=\"SpacingBottom60\"><\/div>",
                        "subHeadingTwo": "An entirely new camera enters the picture",
                        "subHeadingOne": "<span class=\"SpacingTop60 whiteColorFont\">Iphone 7 camera<\/span>",
                        "jcr:createdBy": "aa4589",
                        "imagePosition": "alignMiddleWithText",
                        "jcr:lastModified": "Wed Mar 15 2017 00:19:14 GMT-0700",
                        "frontimage": {
                            "jcr:lastModifiedBy": "pm0558",
                            "imageRotate": "0",
                            "sling:resourceType": "foundation/components/image",
                            "jcr:lastModified": "Wed Mar 15 2017 00:19:14 GMT-0700",
                            "linkURL": "/catalog/en/skus/Apple/iPhone 7/overview/304963-pdp-overview-apple-iphone7-tile_04.jpg",
                            "jcr:primaryType": "nt:unstructured"
                        },
                        "backimage": {
                            "jcr:lastModifiedBy": "pm0558",
                            "imageRotate": "0",
                            "sling:resourceType": "foundation/components/image",
                            "jcr:lastModified": "Wed Mar 15 2017 00:19:14 GMT-0700",
                            "jcr:primaryType": "nt:unstructured"
                        }
                    },
                    "rwdoverviewsection_2": {
                        "spacingBetweenComponents": "<div class=\"SpacingTop60\"><\/div>",
                        "description": "                              <div class=\"span4 top-space\"> \n                                      <p class=\"eyebrow\"><span class=\"whiteColorFont\">Design<\/span><\/p> \n                                                     <p class=\"heading-sub-section\">Built to be water resistant<\/p> \n                                                     <p>With its entire enclosure reengineered, iPhone 7 is the very first water resistant iPhone.<sup>1<\/sup> So now you're protected like never before against spills, splashes, and even dust.<\/p> \n                              <\/div> \n<div class=\"span1\"><\/div>\n",
                        "jcr:lastModifiedBy": "pm0558",
                        "backgroundColor": "black",
                        "bottomSpacingBelowEachSection": "<div class=\"SpacingBottom60\"><\/div>",
                        "sling:resourceType": "att/wireless/components/rwdOverviewsection",
                        "jcr:createdBy": "admin",
                        "spacing": "7",
                        "imagePosition": "alignRightWithText",
                        "jcr:created": "Tue Nov 29 2016 21:39:59 GMT-0800",
                        "jcr:lastModified": "Wed Mar 15 2017 00:21:12 GMT-0700",
                        "fontColor": "white",
                        "jcr:primaryType": "nt:unstructured",
                        "frontimage": {
                            "jcr:lastModifiedBy": "pm0558",
                            "imageRotate": "0",
                            "sling:resourceType": "foundation/components/image",
                            "jcr:lastModified": "Wed Mar 15 2017 00:21:12 GMT-0700",
                            "linkURL": "/catalog/en/skus/Apple/iPhone 7/overview/304963-pdp-overview-apple-iphone7-tile_05.jpg",
                            "jcr:primaryType": "nt:unstructured"
                        },
                        "backimage": {
                            "jcr:lastModifiedBy": "pm0558",
                            "imageRotate": "0",
                            "sling:resourceType": "foundation/components/image",
                            "jcr:lastModified": "Wed Mar 15 2017 00:21:12 GMT-0700",
                            "jcr:primaryType": "nt:unstructured"
                        }
                    },
                    "rwdoverviewsection_4": {
                        "spacingBetweenComponents": "<div class=\"SpacingTop60\"><\/div>",
                        "description": "<div class=\" offset1 span6 top-space\"> \n                                      <p class=\"eyebrow\"><span class=\"whiteColorFont\">A10 fusion chip<\/span><\/p> \n                                                     <p class=\"heading-sub-section\">The most powerful chip ever in a smartphone<\/p> \n                                                     <p>iPhone 7 is supercharged by the most powerful chip ever in a smartphone. It's not just faster than any previous iPhone \u2014 it's also more efficient. That's because the A10 Fusion chip uses an all-new architecture that enables faster processing when you need it, and the ability to use even less power when you don't. And with the longest battery life ever in an iPhone, you can work at twice the speed of iPhone 6 and still enjoy more time between charges.<\/p>\n\n<\/div>",
                        "backgroundColor": "black",
                        "jcr:lastModifiedBy": "pm0558",
                        "sling:resourceType": "att/wireless/components/rwdOverviewsection",
                        "jcr:createdBy": "sa789f",
                        "spacing": "4",
                        "jcr:created": "Wed Feb 22 2017 19:48:41 GMT-0800",
                        "imagePosition": "alignLeftWithText",
                        "jcr:lastModified": "Wed Mar 15 2017 00:22:28 GMT-0700",
                        "fontColor": "white",
                        "jcr:primaryType": "nt:unstructured",
                        "frontimage": {
                            "jcr:lastModifiedBy": "pm0558",
                            "imageRotate": "0",
                            "sling:resourceType": "foundation/components/image",
                            "jcr:lastModified": "Wed Mar 15 2017 00:22:28 GMT-0700",
                            "linkURL": "/catalog/en/skus/Apple/iPhone 7/overview/304963-pdp-overview-apple-iphone7-tile_06.jpg",
                            "jcr:primaryType": "nt:unstructured"
                        },
                        "backimage": {
                            "jcr:lastModifiedBy": "pm0558",
                            "imageRotate": "0",
                            "sling:resourceType": "foundation/components/image",
                            "jcr:lastModified": "Wed Mar 15 2017 00:22:28 GMT-0700",
                            "jcr:primaryType": "nt:unstructured"
                        }
                    }
                },
                "leftfeaturepar": {
                    "sling:resourceType": "foundation/components/parsys",
                    "jcr:primaryType": "nt:unstructured",
                    "reference_1": {
                        "jcr:lastModifiedBy": "aa4589",
                        "sling:resourceType": "foundation/components/reference",
                        "jcr:createdBy": "ak277p",
                        "path": "/content/att/cellphones/iphone/sharedcontent/specifications_en/jcr:content/features/twocolumnshared_2/rightpar/feature_0",
                        "jcr:created": "Tue Nov 08 2016 17:30:01 GMT-0800",
                        "jcr:lastModified": "Thu Dec 08 2016 21:11:23 GMT-0800",
                        "jcr:primaryType": "nt:unstructured"
                    },
                    "reference_0": {
                        "jcr:lastModifiedBy": "ak277p",
                        "sling:resourceType": "foundation/components/reference",
                        "jcr:createdBy": "ak277p",
                        "path": "/content/att/cellphones/iphone/sharedcontent/specifications_en/jcr:content/features/twocolumnshared_0/leftpar/feature_1",
                        "jcr:created": "Tue Nov 08 2016 17:27:58 GMT-0800",
                        "jcr:lastModified": "Tue Nov 08 2016 17:28:13 GMT-0800",
                        "jcr:primaryType": "nt:unstructured"
                    },
                    "reference": {
                        "jcr:lastModifiedBy": "ak277p",
                        "sling:resourceType": "foundation/components/reference",
                        "jcr:createdBy": "ak277p",
                        "jcr:created": "Tue Nov 08 2016 17:22:27 GMT-0800",
                        "jcr:lastModified": "Tue Nov 08 2016 17:22:27 GMT-0800",
                        "jcr:primaryType": "nt:unstructured"
                    }
                },
                "rwdDetailsSection": {
                    "sling:resourceType": "foundation/components/parsys",
                    "jcr:primaryType": "nt:unstructured",
                    "rwddetailssection": {
                        "title": "Dimensions",
                        "jcr:lastModifiedBy": "sa789f",
                        "sling:resourceType": "att/wireless/components/rwdDetailsSection",
                        "jcr:createdBy": "sa789f",
                        "jcr:created": "Mon Feb 06 2017 16:33:17 GMT-0800",
                        "jcr:lastModified": "Tue Mar 14 2017 10:43:40 GMT-0700",
                        "jcr:primaryType": "nt:unstructured",
                        "subCatagorytag": {
                            "jcr:primaryType": "nt:unstructured",
                            "0": {
                                "description": "5.44 x 2.64 x 0.28",
                                "subtitle": "Size (L x W x D in inches)<sup>8<\/sup>",
                                "jcr:primaryType": "nt:unstructured"
                            },
                            "1": {
                                "description": "4.87",
                                "subtitle": "Weight (ounces)<sup>8<\/sup>",
                                "jcr:primaryType": "nt:unstructured"
                            }
                        }
                    },
                    "rwddetailssection_0": {
                        "title": "Display",
                        "jcr:lastModifiedBy": "sa789f",
                        "sling:resourceType": "att/wireless/components/rwdDetailsSection",
                        "jcr:createdBy": "sa789f",
                        "jcr:created": "Mon Feb 06 2017 16:33:20 GMT-0800",
                        "jcr:lastModified": "Wed Feb 15 2017 13:55:36 GMT-0800",
                        "jcr:primaryType": "nt:unstructured",
                        "subCatagorytag": {
                            "jcr:primaryType": "nt:unstructured",
                            "0": {
                                "description": "4.7 Retina HD display with LED-backlit widescreen",
                                "subtitle": "Display size (inches)",
                                "jcr:primaryType": "nt:unstructured"
                            },
                            "1": {
                                "description": "1334-by-750-pixel resolution at 326 ppi",
                                "subtitle": "Resolution (pixels)",
                                "jcr:primaryType": "nt:unstructured"
                            }
                        }
                    },
                    "rwddetailssection_1": {
                        "title": "Rear facing camera",
                        "jcr:lastModifiedBy": "pm0558",
                        "sling:resourceType": "att/wireless/components/rwdDetailsSection",
                        "jcr:createdBy": "sa789f",
                        "jcr:created": "Mon Feb 06 2017 16:33:22 GMT-0800",
                        "jcr:lastModified": "Thu Mar 30 2017 16:24:10 GMT-0700",
                        "jcr:primaryType": "nt:unstructured",
                        "subCatagorytag": {
                            "jcr:primaryType": "nt:unstructured",
                            "0": {
                                "description": "Quad-LED True Tone flash",
                                "subtitle": "12 MP camera",
                                "jcr:primaryType": "nt:unstructured"
                            },
                            "5": {
                                "showCheckMark": "true",
                                "description": "checkbox",
                                "subtitle": "Live Photos with stabilization",
                                "jcr:primaryType": "nt:unstructured"
                            },
                            "4": {
                                "showCheckMark": "true",
                                "description": "checkbox",
                                "subtitle": "Optical image stabilization",
                                "jcr:primaryType": "nt:unstructured"
                            },
                            "1": {
                                "description": "Æ’/1.8",
                                "subtitle": "Aperture",
                                "jcr:primaryType": "nt:unstructured"
                            },
                            "10": {
                                "showCheckMark": "true",
                                "description": "checkbox",
                                "subtitle": "Burst mode",
                                "jcr:primaryType": "nt:unstructured"
                            },
                            "9": {
                                "showCheckMark": "true",
                                "description": "checkbox",
                                "subtitle": "Auto HDR for photos",
                                "jcr:primaryType": "nt:unstructured"
                            },
                            "7": {
                                "showCheckMark": "true",
                                "description": "checkbox",
                                "subtitle": "Autofocus with Focus Pixels",
                                "jcr:primaryType": "nt:unstructured"
                            },
                            "8": {
                                "showCheckMark": "true",
                                "description": "checkbox",
                                "subtitle": "Exposure control",
                                "jcr:primaryType": "nt:unstructured"
                            },
                            "2": {
                                "description": "Digital zoom up to 5x",
                                "subtitle": "Zoom",
                                "jcr:primaryType": "nt:unstructured"
                            },
                            "3": {
                                "description": "Up to 63 megapixels",
                                "subtitle": "Panorama",
                                "jcr:primaryType": "nt:unstructured"
                            },
                            "6": {
                                "showCheckMark": "true",
                                "description": "checkbox",
                                "subtitle": "Wide color capture for photos and Live Photos",
                                "jcr:primaryType": "nt:unstructured"
                            }
                        }
                    },
                    "rwddetailssection_13": {
                        "title": "Front facing camera",
                        "jcr:lastModifiedBy": "pm0558",
                        "sling:resourceType": "att/wireless/components/rwdDetailsSection",
                        "jcr:createdBy": "pm0558",
                        "jcr:created": "Wed Mar 29 2017 15:16:26 GMT-0700",
                        "jcr:lastModified": "Thu Mar 30 2017 14:22:47 GMT-0700",
                        "jcr:primaryType": "nt:unstructured",
                        "subCatagorytag": {
                            "jcr:primaryType": "nt:unstructured",
                            "3": {
                                "showCheckMark": "true",
                                "description": "checkbox",
                                "subtitle": "Wide color capture for photos and Live Photos",
                                "jcr:primaryType": "nt:unstructured"
                            },
                            "0": {
                                "description": "HD photos",
                                "subtitle": "7 MP camera",
                                "jcr:primaryType": "nt:unstructured"
                            },
                            "5": {
                                "showCheckMark": "true",
                                "description": "checkbox",
                                "subtitle": "Auto HDR",
                                "jcr:primaryType": "nt:unstructured"
                            },
                            "7": {
                                "showCheckMark": "true",
                                "description": "checkbox",
                                "subtitle": "Auto image stabilization",
                                "jcr:primaryType": "nt:unstructured"
                            },
                            "4": {
                                "showCheckMark": "true",
                                "description": "checkbox",
                                "subtitle": "1080p HD video recording",
                                "jcr:primaryType": "nt:unstructured"
                            },
                            "1": {
                                "description": "Æ’/1.8",
                                "subtitle": "Aperture",
                                "jcr:primaryType": "nt:unstructured"
                            },
                            "9": {
                                "showCheckMark": "true",
                                "description": "checkbox",
                                "subtitle": "Exposure control",
                                "jcr:primaryType": "nt:unstructured"
                            },
                            "8": {
                                "showCheckMark": "true",
                                "description": "checkbox",
                                "subtitle": "Burst mode",
                                "jcr:primaryType": "nt:unstructured"
                            },
                            "2": {
                                "showCheckMark": "true",
                                "description": "checkbox",
                                "subtitle": "Retina Flash",
                                "jcr:primaryType": "nt:unstructured"
                            },
                            "6": {
                                "showCheckMark": "true",
                                "description": "checkbox",
                                "subtitle": "Body and face detection",
                                "jcr:primaryType": "nt:unstructured"
                            }
                        }
                    },
                    "rwddetailssection_2": {
                        "title": "Video",
                        "jcr:lastModifiedBy": "pm0558",
                        "sling:resourceType": "att/wireless/components/rwdDetailsSection",
                        "jcr:createdBy": "pm0558",
                        "jcr:created": "Wed Mar 29 2017 15:16:20 GMT-0700",
                        "jcr:lastModified": "Thu Mar 30 2017 14:23:19 GMT-0700",
                        "jcr:primaryType": "nt:unstructured",
                        "subCatagorytag": {
                            "jcr:primaryType": "nt:unstructured",
                            "3": {
                                "showCheckMark": "true",
                                "description": "checkbox",
                                "subtitle": "4K video recording at 30 fps",
                                "jcr:primaryType": "nt:unstructured"
                            },
                            "0": {
                                "description": "30 fps or 60 fps",
                                "subtitle": "1080p HD video",
                                "jcr:primaryType": "nt:unstructured"
                            },
                            "5": {
                                "showCheckMark": "true",
                                "description": "checkbox",
                                "subtitle": "Quad-LED True Tone flash",
                                "jcr:primaryType": "nt:unstructured"
                            },
                            "2": {
                                "description": "1080p at 120 fps and 720p at 240 fps",
                                "subtitle": "Slo-mo video support",
                                "jcr:primaryType": "nt:unstructured"
                            },
                            "4": {
                                "showCheckMark": "true",
                                "description": "checkbox",
                                "subtitle": "Optical image stabilization for video",
                                "jcr:primaryType": "nt:unstructured"
                            },
                            "1": {
                                "description": "Up to 3x",
                                "subtitle": "Digital zoom",
                                "jcr:primaryType": "nt:unstructured"
                            },
                            "10": {
                                "showCheckMark": "true",
                                "description": "checkbox",
                                "subtitle": "Playback zoom",
                                "jcr:primaryType": "nt:unstructured"
                            },
                            "9": {
                                "showCheckMark": "true",
                                "description": "checkbox",
                                "subtitle": "Take 8-megapixel still photos while recording 4K video",
                                "jcr:primaryType": "nt:unstructured"
                            },
                            "6": {
                                "showCheckMark": "true",
                                "description": "checkbox",
                                "subtitle": "Cinematic video stabilization",
                                "jcr:primaryType": "nt:unstructured"
                            },
                            "7": {
                                "showCheckMark": "true",
                                "description": "checkbox",
                                "subtitle": "Continuous autofocus video",
                                "jcr:primaryType": "nt:unstructured"
                            },
                            "8": {
                                "showCheckMark": "true",
                                "description": "checkbox",
                                "subtitle": "Time-lapse video with stabilization",
                                "jcr:primaryType": "nt:unstructured"
                            }
                        }
                    },
                    "rwddetailssection_3": {
                        "title": "Battery",
                        "jcr:lastModifiedBy": "pm0558",
                        "sling:resourceType": "att/wireless/components/rwdDetailsSection",
                        "jcr:createdBy": "sa789f",
                        "jcr:created": "Mon Feb 06 2017 16:33:26 GMT-0800",
                        "jcr:lastModified": "Thu Mar 30 2017 14:23:26 GMT-0700",
                        "jcr:primaryType": "nt:unstructured",
                        "subCatagorytag": {
                            "jcr:primaryType": "nt:unstructured",
                            "0": {
                                "showCheckMark": "true",
                                "description": "checkbox",
                                "subtitle": "Built-in rechargeable<br>lithium-ion battery",
                                "jcr:primaryType": "nt:unstructured"
                            },
                            "2": {
                                "description": "Up to 10",
                                "subtitle": "Standby time (days)<sup>7<\/sup>",
                                "jcr:primaryType": "nt:unstructured"
                            },
                            "5": {
                                "description": "Up to 12 on 3G<br>Up to 12 on LTE<br>Up to 14 on Wi-Fi",
                                "subtitle": "Internet use (hours)<sup>7<\/sup>",
                                "jcr:primaryType": "nt:unstructured"
                            },
                            "4": {
                                "description": "Up to 13",
                                "subtitle": "Wireless video playback time (hours)<sup>7<\/sup>",
                                "jcr:primaryType": "nt:unstructured"
                            },
                            "3": {
                                "description": "Up to 40",
                                "subtitle": "Wireless audio playback time (hours)<sup>7<\/sup>",
                                "jcr:primaryType": "nt:unstructured"
                            },
                            "1": {
                                "description": "Up to 14 on 3G",
                                "subtitle": "Talk Time (hours)<sup>7<\/sup>",
                                "jcr:primaryType": "nt:unstructured"
                            }
                        }
                    },
                    "rwddetailssection_4": {
                        "title": "Processor",
                        "jcr:lastModifiedBy": "pm0558",
                        "sling:resourceType": "att/wireless/components/rwdDetailsSection",
                        "jcr:createdBy": "sa789f",
                        "jcr:created": "Mon Feb 06 2017 16:33:29 GMT-0800",
                        "jcr:lastModified": "Fri Feb 17 2017 13:35:08 GMT-0800",
                        "jcr:primaryType": "nt:unstructured",
                        "subCatagorytag": {
                            "jcr:primaryType": "nt:unstructured",
                            "0": {
                                "description": "A10 Fusion chip with 64-bit architecture and embedded M10 motion coprocessor",
                                "subtitle": "Chipset",
                                "jcr:primaryType": "nt:unstructured"
                            }
                        }
                    },
                    "rwddetailssection_5": {
                        "title": "Memory",
                        "jcr:lastModifiedBy": "pm0558",
                        "sling:resourceType": "att/wireless/components/rwdDetailsSection",
                        "jcr:createdBy": "sa789f",
                        "jcr:created": "Mon Feb 06 2017 16:33:31 GMT-0800",
                        "jcr:lastModified": "Wed Apr 19 2017 15:54:39 GMT-0700",
                        "jcr:primaryType": "nt:unstructured",
                        "subCatagorytag": {
                            "jcr:primaryType": "nt:unstructured",
                            "0": {
                                "description": "id:putMemoryHere",
                                "subtitle": "Internal memory storage<sup>9<\/sup> (up to)",
                                "jcr:primaryType": "nt:unstructured"
                            }
                        }
                    },
                    "rwddetailssection_6": {
                        "title": "Operating system",
                        "jcr:lastModifiedBy": "sa789f",
                        "sling:resourceType": "att/wireless/components/rwdDetailsSection",
                        "jcr:createdBy": "sa789f",
                        "jcr:created": "Mon Feb 06 2017 16:33:32 GMT-0800",
                        "jcr:lastModified": "Thu Feb 23 2017 09:57:41 GMT-0800",
                        "jcr:primaryType": "nt:unstructured",
                        "subCatagorytag": {
                            "jcr:primaryType": "nt:unstructured",
                            "2": {
                                "showCheckMark": "true",
                                "description": "checkbox",
                                "subtitle": "iOS<sup>Â®<\/sup>",
                                "jcr:primaryType": "nt:unstructured"
                            },
                            "0": {
                                "description": "10.0",
                                "subtitle": "OS Version",
                                "jcr:primaryType": "nt:unstructured"
                            },
                            "1": {
                                "description": "Use your voice to send messages, set reminders, and more",
                                "subtitle": "Siri<sup>6<\/sup>",
                                "jcr:primaryType": "nt:unstructured"
                            }
                        }
                    },
                    "rwddetailssection_7": {
                        "title": "Wireless technology",
                        "jcr:lastModifiedBy": "pm0558",
                        "sling:resourceType": "att/wireless/components/rwdDetailsSection",
                        "jcr:createdBy": "sa789f",
                        "jcr:created": "Mon Feb 06 2017 16:33:34 GMT-0800",
                        "jcr:lastModified": "Thu Mar 30 2017 14:24:50 GMT-0700",
                        "jcr:primaryType": "nt:unstructured",
                        "subCatagorytag": {
                            "jcr:primaryType": "nt:unstructured",
                            "0": {
                                "description": "Bands 1, 2, 3, 4, 5, 8, 12, 13, 17, 18, 19, 20, 25, 26, 29, 30, 38, 39, 40, and 41",
                                "subtitle": "4G-LTE",
                                "jcr:primaryType": "nt:unstructured"
                            },
                            "5": {
                                "description": "802.11a/b/g/n/ac Wi\u2011Fi with MIMO",
                                "subtitle": "Wi-Fi connectivity",
                                "jcr:primaryType": "nt:unstructured"
                            },
                            "11": {
                                "showCheckMark": "true",
                                "description": "checkbox",
                                "subtitle": "Near Field Communication (NFC)",
                                "jcr:primaryType": "nt:unstructured"
                            },
                            "1": {
                                "description": "HSPA+ with enhanced backhaul",
                                "subtitle": "4G",
                                "jcr:primaryType": "nt:unstructured"
                            },
                            "4": {
                                "description": "Quad-band",
                                "subtitle": "World Phone",
                                "jcr:primaryType": "nt:unstructured"
                            },
                            "10": {
                                "showCheckMark": "true",
                                "description": "checkbox",
                                "subtitle": "5GHz Wi-Fi-capable",
                                "jcr:primaryType": "nt:unstructured"
                            },
                            "9": {
                                "showCheckMark": "true",
                                "description": "checkbox",
                                "subtitlelink": "/shop/wireless/features/wifi-calling.html",
                                "subtitle": "Wi-Fi Calling capable",
                                "jcr:primaryType": "nt:unstructured"
                            },
                            "7": {
                                "description": "<a href=/cellphones/att/nano-sim.html>Nano SIM<\/a>",
                                "subtitle": "SIM Type",
                                "jcr:primaryType": "nt:unstructured"
                            },
                            "8": {
                                "showCheckMark": "true",
                                "description": "checkbox",
                                "subtitlelink": "/shop/wireless/features/hd-voice.html",
                                "subtitle": "HD Voice capable",
                                "jcr:primaryType": "nt:unstructured"
                            },
                            "2": {
                                "description": "850/900/1700-2100/1900/2100MHz",
                                "subtitle": "3G \u2013 UMTS",
                                "jcr:primaryType": "nt:unstructured"
                            },
                            "3": {
                                "description": "850/900/1800/1900MHz",
                                "subtitle": "GSM/GPRS/EDGE",
                                "jcr:primaryType": "nt:unstructured"
                            },
                            "6": {
                                "description": "v4.2",
                                "subtitle": "BluetoothÂ® technology",
                                "jcr:primaryType": "nt:unstructured"
                            }
                        }
                    },
                    "rwddetailssection_8": {
                        "title": "Apps",
                        "jcr:lastModifiedBy": "sa789f",
                        "sling:resourceType": "att/wireless/components/rwdDetailsSection",
                        "jcr:createdBy": "sa789f",
                        "jcr:created": "Mon Feb 06 2017 16:33:36 GMT-0800",
                        "jcr:lastModified": "Thu Feb 23 2017 10:04:11 GMT-0800",
                        "jcr:primaryType": "nt:unstructured",
                        "subCatagorytag": {
                            "jcr:primaryType": "nt:unstructured",
                            "2": {
                                "description": "Safari<sup>Â®<\/sup>",
                                "subtitle": "Web Browser",
                                "jcr:primaryType": "nt:unstructured"
                            },
                            "0": {
                                "description": "Camera, Photos, Health, Messages, Phone, Facetime4, Mail, Music, Wallet, SafariÂ®, Maps, Calendar, iTunes StoreÂ®, App StoreÂ®, Notes, News, Contacts, iBooksÂ®, Home, Weather, Reminders, Clock, Videos, Stocks, Calculator, Voice Memos, Compass, Podcasts, Watch, Tips, iCloud Drive, Find My iPhone, Find My Friends",
                                "subtitle": "Included apps",
                                "jcr:primaryType": "nt:unstructured"
                            },
                            "1": {
                                "description": "iMovie<sup>Â®<\/sup>, Pages<sup>Â®<\/sup>, Keynote<sup>Â®<\/sup>, Numbers, iTunes U<sup>Â®<\/sup>, GarageBand, Apple Store, Trailers, Apple TV Remote, iTunes Remote, Music Memos",
                                "subtitle": "Free apps from Apple<sup>5<\/sup>",
                                "jcr:primaryType": "nt:unstructured"
                            }
                        }
                    },
                    "rwddetailssection_9": {
                        "title": "Sensors",
                        "jcr:lastModifiedBy": "sa789f",
                        "sling:resourceType": "att/wireless/components/rwdDetailsSection",
                        "jcr:createdBy": "sa789f",
                        "jcr:created": "Mon Feb 06 2017 16:33:38 GMT-0800",
                        "jcr:lastModified": "Wed Feb 15 2017 15:46:04 GMT-0800",
                        "jcr:primaryType": "nt:unstructured",
                        "subCatagorytag": {
                            "jcr:primaryType": "nt:unstructured",
                            "0": {
                                "description": "Touch ID fingerprint, Barometer, Three-axis gyro, Accelerometer, Proximity, Ambient light",
                                "subtitle": "Sensors",
                                "jcr:primaryType": "nt:unstructured"
                            }
                        }
                    },
                    "rwddetailssection_10": {
                        "title": "Messaging & email",
                        "jcr:lastModifiedBy": "sa789f",
                        "sling:resourceType": "att/wireless/components/rwdDetailsSection",
                        "jcr:createdBy": "sa789f",
                        "jcr:created": "Mon Feb 06 2017 16:33:40 GMT-0800",
                        "jcr:lastModified": "Fri Feb 10 2017 14:10:16 GMT-0800",
                        "jcr:primaryType": "nt:unstructured",
                        "subCatagorytag": {
                            "jcr:primaryType": "nt:unstructured",
                            "0": {
                                "showCheckMark": "true",
                                "description": "checkbox",
                                "subtitle": "iMessage",
                                "jcr:primaryType": "nt:unstructured"
                            }
                        }
                    },
                    "rwddetailssection_11": {
                        "title": "Music",
                        "jcr:lastModifiedBy": "pm0558",
                        "sling:resourceType": "att/wireless/components/rwdDetailsSection",
                        "jcr:createdBy": "sa789f",
                        "jcr:created": "Mon Feb 06 2017 16:33:42 GMT-0800",
                        "jcr:lastModified": "Fri Feb 17 2017 13:40:33 GMT-0800",
                        "jcr:primaryType": "nt:unstructured",
                        "subCatagorytag": {
                            "jcr:primaryType": "nt:unstructured",
                            "0": {
                                "description": "iTunes<sup>Â®<\/sup>",
                                "subtitle": "Music player",
                                "jcr:primaryType": "nt:unstructured"
                            },
                            "1": {
                                "description": "AAC (8 to 320 Kbps), Protected AAC (from iTunes Store), HE-AAC, MP3 (8 to 320 Kbps), MP3 VBR, Audible (formats 2, 3, 4, Audible Enhanced Audio, AAX, and AAX+), Apple Lossless, AIFF, and WAV",
                                "subtitle": "Supported music formats",
                                "jcr:primaryType": "nt:unstructured"
                            }
                        }
                    },
                    "rwddetailssection_12": {
                        "title": "Accessibility",
                        "jcr:lastModifiedBy": "sa789f",
                        "sling:resourceType": "att/wireless/components/rwdDetailsSection",
                        "jcr:createdBy": "sa789f",
                        "jcr:created": "Mon Feb 06 2017 16:33:44 GMT-0800",
                        "jcr:lastModified": "Wed Feb 15 2017 15:47:24 GMT-0800",
                        "jcr:primaryType": "nt:unstructured",
                        "subCatagorytag": {
                            "jcr:primaryType": "nt:unstructured",
                            "1": {
                                "showCheckMark": "true",
                                "description": "checkbox",
                                "subtitle": "TTY/TTD compatible",
                                "jcr:primaryType": "nt:unstructured"
                            },
                            "0": {
                                "description": "M3,T4",
                                "subtitle": "Hearing Aid (HAC) rating",
                                "jcr:primaryType": "nt:unstructured"
                            }
                        }
                    }
                },
                "rwdDetailsInTheBox": {
                    "sling:resourceType": "foundation/components/parsys",
                    "jcr:primaryType": "nt:unstructured",
                    "rwdintheboxsection_0": {
                        "jcr:lastModifiedBy": "sa789f",
                        "sling:resourceType": "att/wireless/components/rwdInTheBoxSection",
                        "jcr:createdBy": "sa789f",
                        "spacing": "4",
                        "jcr:created": "Mon Feb 06 2017 16:49:56 GMT-0800",
                        "jcr:lastModified": "Wed Feb 15 2017 15:53:30 GMT-0800",
                        "jcr:primaryType": "nt:unstructured",
                        "subCatagorytag": {
                            "jcr:primaryType": "nt:unstructured",
                            "0": {
                                "subtitle": "EarPods with lightning connector",
                                "iconselected": "accessories_191919",
                                "jcr:primaryType": "nt:unstructured"
                            },
                            "1": {
                                "subtitle": "Lightning to 3.5 mm headphone jack adapter",
                                "iconselected": "cable_191919",
                                "jcr:primaryType": "nt:unstructured"
                            },
                            "3": {
                                "subtitle": "USB power adapter",
                                "iconselected": "easyinstallation_191919",
                                "jcr:primaryType": "nt:unstructured"
                            },
                            "2": {
                                "subtitle": "Lightning to USB cable",
                                "iconselected": "cable_191919",
                                "jcr:primaryType": "nt:unstructured"
                            }
                        }
                    }
                },
                "rwdDetailsFeaturesSection": {
                    "sling:resourceType": "foundation/components/parsys",
                    "jcr:primaryType": "nt:unstructured",
                    "rwddetailstopfeature": {
                        "jcr:lastModifiedBy": "pm0558",
                        "sling:resourceType": "att/wireless/components/rwdDetailsTopFeaturesSection",
                        "jcr:createdBy": "sa789f",
                        "spacing": "4",
                        "jcr:created": "Mon Feb 06 2017 16:25:12 GMT-0800",
                        "jcr:lastModified": "Thu Mar 30 2017 10:09:04 GMT-0700",
                        "jcr:primaryType": "nt:unstructured",
                        "subCatagorytag": {
                            "jcr:primaryType": "nt:unstructured",
                            "0": {
                                "description": "With a new wide color gamut, the Retina HD display is able to deliver cinema-standard color.",
                                "subtitle": "4.7-inch display",
                                "iconselected": "mobilesmartphoneL_191919",
                                "jcr:primaryType": "nt:unstructured"
                            },
                            "1": {
                                "description": "When you use 3D Touch, your iPhone responds with subtle taps. So not only will you see what a press can do\u2014you\u2019ll feel it.",
                                "subtitle": "3D Touch",
                                "iconselected": "touchscreenL_191919",
                                "jcr:primaryType": "nt:unstructured"
                            },
                            "3": {
                                "description": "With its entire enclosure reengineered, iPhone 7 is the very first water-resistant iPhone.<sup>1<\/sup> You're now protected against spills, splashes, and even dust.",
                                "subtitle": "Splash, water, and dust resistant<sup>1<\/sup>",
                                "iconselected": "waterL_191919",
                                "jcr:primaryType": "nt:unstructured"
                            },
                            "2": {
                                "description": "New 12 MP camera with optical image stabilization, Quad-LED True Tone flash, and Live Photos",
                                "subtitle": "12 MP camera",
                                "iconselected": "cameraL_191919",
                                "jcr:primaryType": "nt:unstructured"
                            }
                        }
                    }
                }
            }
        }
    }
})();