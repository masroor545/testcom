/**
 * Various test responses for the cart lookup service
 *
 * @example
 * $httpBackend.whenGET(Endpoint_cartLookupApi.get_cart_lookup_new.url_match)
 *      .respond(200, Endpoint_cartLookupApi.get_cart_lookup_new.result);
 */
var Endpoint_cartLookupApi = (function () {
    'use strict';

    return {
        'get_cart_lookup_empty_new': {
            url_match: /\/services\/shopwireless\/model\/att\/ecom\/api\/CartLookup\/getCartInfo/,
            response_code: 200,
            params_sent: '?lobType=ALL',
            result: {
                'result': {
                    'methodReturnValue': {
                        'orderSource': 'DESKTOP',
                        'lobTypes': {},
                        'orderBuyFlowType': 'NEW'
                    },
                    'serviceErrors': [],
                    'redirectKey': null,
                    'inputErrors': {},
                    'status': 'Status: Success(600)',
                    'redirectURL': null,
                    'doRedirect': false
                }
            }
        },

        /**
         * Get cart data for single losg in cart from checkout cart api
         */
        'get_checkout_data_for_singleLOSG': {
            losgId: {
                'losg20230750': {
                    'status': 'complete',
                    'line_items': ['84208002790-1', '84208002790-2', '5400002', '84208002790', '84208002789', '22400008'],
                    'activation_fee': 0.0,
                    'waiver_fee': 0.0,
                    'flow_type': 'UP',
                    'messageList': [],
                    'sequenceNo': 1,
                    'losgType': 'UP',
                    'extra_attributes': {
                        'parentLOSGID': null,
                        'primaryline': 'true',
                        'associatedCtn': '2069925031',
                        'ACCOUNT_CONVERSION_STATUS': null,
                        'subtype': 'DEFAULT_LINE',
                        'volDownpaymant': '0.0',
                        'data_group_id': 'CbsDataGroupID',
                        'donorDeviceMake': 'APPLE',
                        'donorDeviceModel': 'iPhone 6',
                        'subscriberName': 'BEDROCK'
                    }
                }
            },
            commerceItem: {
                'itemType': 'device',
                'itemID': '84208002789',
                'skuID': 'sku8040290',
                'productID': 'prod8730225',
                'quantity': 1,
                'preorder': false,
                'billCode': '6480A',
                'displayName': 'Apple iPhone 7 - 128GB - Gold',
                'imageUrl': '/catalog/en/skus/images/apple-iphone 7-gold-100x160.png',
                'maxQuantity': 5,
                'contractLength': 30,
                'downPaymentAmt': 0.0,
                'eligibleActions': ['change'],
                'itemPriceInfo': {
                    'type': 'due_monthly',
                    'due_monthly': 25.0,
                    'listPrice': 0.0,
                    'due_today': 0.0,
                    'additionalProperties': {},
                    'isBasedOnUsage': false
                },
                'priceAdjustments': [],
                'isAttNext': false,
                'isEnjoyEligible': false,
                'isEnjoyQualifying': true,
                'contractType': 'lease',
                'shortDisplayName': 'Apple iPhone 7',
                'displayColor': 'Gold',
                'upgradeFee': '40.0',
                'displaySize': '128GB',
                'make': 'Apple',
                'primaryLine': false,
                'flowType': 'UP',
                'IPIdentifier': 'NE30M80P'
            }
        },

        /**
         * Get cart data for mixed cart losg in cart from checkout cart api
         */
        'get_checkout_data_for_mixedCartLOSG': {
            losgId: {
                'losg20230750': {
                    'status': 'complete',
                    'line_items': ['84208002790-1', '84208002790-2', '5400002', '84208002790', '84208002789', '22400008'],
                    'activation_fee': 0.0,
                    'waiver_fee': 0.0,
                    'flow_type': 'AL',
                    'messageList': [],
                    'sequenceNo': 1,
                    'losgType': 'AL',
                    'extra_attributes': {
                        'parentLOSGID': null,
                        'primaryline': 'true',
                        'associatedCtn': '2069925031',
                        'ACCOUNT_CONVERSION_STATUS': null,
                        'subtype': 'DEFAULT_LINE',
                        'volDownpaymant': '0.0',
                        'data_group_id': 'CbsDataGroupID',
                        'donorDeviceMake': 'APPLE',
                        'donorDeviceModel': 'iPhone 6',
                        'subscriberName': 'BEDROCK'
                    }
                }
            },
            commerceItem: {
                'itemType': 'device',
                'itemID': '84208002789',
                'skuID': 'sku8040290',
                'productID': 'prod8730225',
                'quantity': 1,
                'preorder': false,
                'billCode': '6480A',
                'displayName': 'Apple iPhone 7 - 128GB - Gold',
                'imageUrl': '/catalog/en/skus/images/apple-iphone 7-gold-100x160.png',
                'maxQuantity': 5,
                'contractLength': 30,
                'downPaymentAmt': 0.0,
                'eligibleActions': ['change'],
                'itemPriceInfo': {
                    'type': 'due_monthly',
                    'due_monthly': 25.0,
                    'listPrice': 0.0,
                    'due_today': 0.0,
                    'additionalProperties': {},
                    'isBasedOnUsage': false
                },
                'priceAdjustments': [],
                'isAttNext': false,
                'isEnjoyEligible': false,
                'isEnjoyQualifying': true,
                'contractType': 'lease',
                'shortDisplayName': 'Apple iPhone 7',
                'displayColor': 'Gold',
                'upgradeFee': '40.0',
                'displaySize': '128GB',
                'make': 'Apple',
                'primaryLine': false,
                'flowType': 'AL',
                'IPIdentifier': 'NE30M80P'
            }
        },

        /**
         * Cart information after plans, device, accessories and feature has been added to cart.
         * "result->methodReturnValue->lobTypes->WIRELESS->losgs->losg14580100->cartItems" represents
         * the information of all the plans/devices/accessories/features added in cart
         */
        'get_cart_lookup_new': {
            url_match: /\/services\/shopwireless\/model\/att\/ecom\/api\/CartLookup\/getCartInfo/,
            response_code: 200,
            params_sent: '?lobType=ALL',
            result: {
                'result': {
                    'methodReturnValue': {
                        'orderSource': 'DESKTOP',
                        'lobTypes': {
                            'WIRELESS': {
                                'cartOneTimeAmount': 25,
                                'losgs': {
                                    'losg14580100': {
                                        'cartItems': {
                                            // Represents plans added in cart
                                            'plan': {
                                                'sku6220543': {
                                                    'parentConsolidatedProducts': null,
                                                    'productDisplayName': 'Mobile Share Plan',
                                                    'planType': 'voiceplan',
                                                    'paymentType': 'postpaid',
                                                    'dataGroupId': null,
                                                    'quantity': 0,
                                                    'commerceItemId': '83602000148',
                                                    'productId': 'prod6130421'
                                                },
                                                'sku8200352': {
                                                    'parentConsolidatedProducts': null,
                                                    'productDisplayName': 'AT&T Unlimited Plus',
                                                    'planType': 'sharedDataGroup',
                                                    'paymentType': 'postpaid',
                                                    'dataGroupId': null,
                                                    'quantity': 0,
                                                    'commerceItemId': '83602000146',
                                                    'productId': 'prod8890259'
                                                },
                                                'sku8200451': {
                                                    'parentConsolidatedProducts': null,
                                                    'productDisplayName': 'Access for iPhone on 4G LTE w/ VVM',
                                                    'planType': 'sharedDataPlan',
                                                    'paymentType': 'postpaid',
                                                    'dataGroupId': null,
                                                    'quantity': 0,
                                                    'commerceItemId': '83602000147',
                                                    'productId': 'prod8890328'
                                                }
                                            },
                                            // Represents accessories added in cart
                                            'accessory': {
                                                'sku8140322': {
                                                    'parentConsolidatedProducts': null,
                                                    'productDisplayName': 'Apple AirPods with Remote and Mic',
                                                    'planType': null,
                                                    'paymentType': null,
                                                    'dataGroupId': null,
                                                    'quantity': 1,
                                                    'commerceItemId': '83602000144',
                                                    'productId': 'prod8830354'
                                                },
                                                'sku8030508': {
                                                    'parentConsolidatedProducts': null,
                                                    'productDisplayName': 'OtterBox Defender Series Case and Holster - iPhone 7',
                                                    'planType': null,
                                                    'paymentType': null,
                                                    'dataGroupId': null,
                                                    'quantity': 1,
                                                    'commerceItemId': '83602000145',
                                                    'productId': 'prod8720393'
                                                }
                                            },
                                            // Represents devices added in cart
                                            'device': {
                                                'sku8040300': {
                                                    'model': 'iPhone 7 32GB',
                                                    'marketingSequence': 1000,
                                                    'hexValue': '#5C5A5A',
                                                    'paymentType': 'postpaid',
                                                    'priceList': [
                                                        {
                                                            'leaseTotalMonths': 30,
                                                            'dueToday': 0,
                                                            'nextSpecificPriceApplied': false,
                                                            'monthlyLeasePrice': 21.67,
                                                            'commitmentTermDiscountName': null,
                                                            'tradeInAmount': 519.99,
                                                            'monthsToUpgrade': "Apr'19",
                                                            'offerReqOrPriceDetailLink': 'See AT&T Next details.',
                                                            'type': 'lease',
                                                            'tradeInPercentage': 80,
                                                            'higherCommitmentTermDiscount': 0,
                                                            'contractGroupType': 'lease',
                                                            'listPrice': 649.99,
                                                            'commitmentTermDiscount': 0,
                                                            'name': 'NE30M80P',
                                                            'dueMonthlyLeasePrice': 21.67,
                                                            'displayFlexDP': true,
                                                            'baseNextPrice': 649.99,
                                                            'savingUptoMsg': null,
                                                            'legalName': '!label.priceblock.leasename.NE30M80P!',
                                                            'defaultSelectionSequence': 1,
                                                            'sortOrder': 100,
                                                            'activationFee': 25,
                                                            'mailInRebate': 0,
                                                            'MREDiscount': 0,
                                                            'itemPrice': 0,
                                                            'legalContent': 'Fees, monthly and other charges apply. Qual. wireless service (voice & data) req’d. <b>Upgrade with trade-in:<\/b> Requires payment of 80% of sales price, trade-in of financed device in good physical and fully functional condition through the AT&T Next trade-in program (excludes AT&T trade-in program where you receive instant credit or an AT&T promotion card), and eligible upgrade. Shown date is an estimate. Actual date may vary by more than a month based on shipping, billing cycle, payments, and other factors. Fees, monthly and other charges, and restrictions apply. ',
                                                            'fANSpecificCustomPriceApplied': false,
                                                            'nextSpecificDiscount': 0,
                                                            'dueTodayLease': 0,
                                                            'salePrice': 0,
                                                            'noCommitmentTermPrice': 649.99,
                                                            'identifierRelatedTradeInTerm': null
                                                        },
                                                        {
                                                            'leaseTotalMonths': 24,
                                                            'dueToday': 0,
                                                            'nextSpecificPriceApplied': false,
                                                            'monthlyLeasePrice': 27.09,
                                                            'commitmentTermDiscountName': null,
                                                            'tradeInAmount': 324.99,
                                                            'monthsToUpgrade': "Apr'18",
                                                            'offerReqOrPriceDetailLink': 'See AT&T Next details.',
                                                            'type': 'lease',
                                                            'tradeInPercentage': 50,
                                                            'higherCommitmentTermDiscount': 0,
                                                            'contractGroupType': 'lease',
                                                            'listPrice': 649.99,
                                                            'commitmentTermDiscount': 0,
                                                            'name': 'NE24M50P',
                                                            'dueMonthlyLeasePrice': 27.09,
                                                            'displayFlexDP': true,
                                                            'baseNextPrice': 649.99,
                                                            'savingUptoMsg': null,
                                                            'legalName': '!label.priceblock.leasename.NE24M50P!',
                                                            'defaultSelectionSequence': 2,
                                                            'sortOrder': 200,
                                                            'activationFee': 25,
                                                            'mailInRebate': 0,
                                                            'MREDiscount': 0,
                                                            'itemPrice': 0,
                                                            'legalContent': 'Fees, monthly and other charges apply. Qual. wireless service (voice & data) req’d.  <b>Upgrade with trade-in:<\/b> Requires payment of 50% of sales price, trade-in of financed device in good physical and fully functional condition through the AT&T Next trade-in program (excludes AT&T trade-in program where you receive instant credit or an AT&T promotion card), and eligible upgrade. Shown date is an estimate. Actual date may vary by more than a month based on shipping, billing cycle, payments, and other factors. Fees, monthly and other charges, and restrictions apply. ',
                                                            'fANSpecificCustomPriceApplied': false,
                                                            'nextSpecificDiscount': 0,
                                                            'dueTodayLease': 0,
                                                            'salePrice': 0,
                                                            'noCommitmentTermPrice': 649.99,
                                                            'identifierRelatedTradeInTerm': null
                                                        },
                                                        {
                                                            'leaseTotalMonths': 0,
                                                            'dueToday': 649.99,
                                                            'nextSpecificPriceApplied': false,
                                                            'monthlyLeasePrice': 0,
                                                            'commitmentTermDiscountName': 'No Commitment:PDA',
                                                            'tradeInAmount': 0,
                                                            'monthsToUpgrade': null,
                                                            'offerReqOrPriceDetailLink': '!label.seeofferdetails!',
                                                            'type': 'regular',
                                                            'tradeInPercentage': 0,
                                                            'higherCommitmentTermDiscount': 25,
                                                            'contractGroupType': null,
                                                            'listPrice': 649.99,
                                                            'commitmentTermDiscount': 15,
                                                            'name': '1',
                                                            'dueMonthlyLeasePrice': 0,
                                                            'displayFlexDP': false,
                                                            'baseNextPrice': 0,
                                                            'savingUptoMsg': null,
                                                            'legalName': 'No annual contract*',
                                                            'defaultSelectionSequence': 7,
                                                            'sortOrder': 700,
                                                            'activationFee': 25,
                                                            'mailInRebate': 0,
                                                            'MREDiscount': 0,
                                                            'itemPrice': 649.99,
                                                            'legalContent': '!pb.legal.contract.regular1!  qualified credit, and wireless service (voice & data). ',
                                                            'fANSpecificCustomPriceApplied': false,
                                                            'nextSpecificDiscount': 0,
                                                            'dueTodayLease': 649.99,
                                                            'salePrice': null,
                                                            'noCommitmentTermPrice': 649.99,
                                                            'identifierRelatedTradeInTerm': null
                                                        }
                                                    ],
                                                    'skuDisplayName': 'Apple iPhone 7 - 32GB - Black',
                                                    'isWHP': 0,
                                                    'averageUsageInGb': 3,
                                                    'isWHPI': 0,
                                                    'size': 32,
                                                    'productId': 'prod8730224',
                                                    'preOwned': false,
                                                    'imgUrl': 'Apple iPhone 7 - 32GB - Black-iPhone 7 32GB-Black-450x350.png',
                                                    'shortDisplayName': 'Apple iPhone 7',
                                                    'subtypeKey': 'pda',
                                                    'color': 'Black',
                                                    'uom': 'GB',
                                                    'isGoPhone': 0,
                                                    'deviceType': 'pda',
                                                    'manufacturer': 'Apple',
                                                    'refurbished': false,
                                                    'skuId': 'sku8040300',
                                                    'commerceItemId': null,
                                                    'displayName': 'Apple iPhone 7 - 32GB'
                                                }
                                            },
                                            // Represents feature added in cart
                                            'feature': {
                                                'sku5370279': {
                                                    'parentConsolidatedProducts': null,
                                                    'productDisplayName': 'AT&T Mobile Insurance',
                                                    // "insuranceFeature: true" tells that this is an Insurance feature
                                                    'insuranceFeature': true,
                                                    'planType': null,
                                                    'paymentType': null,
                                                    'dataGroupId': null,
                                                    'quantity': 0,
                                                    'commerceItemId': '83602000143',
                                                    'productId': 'prod5280349'
                                                }
                                            }
                                        },
                                        'contractLength': '30',
                                        'mrcAmount': 0,
                                        'productDisplayName': null,
                                        'nextSpecificPriceApplied': false,
                                        'losgFlowType': null,
                                        'IMEIProductId': null,
                                        'FANSpecificCustomPriceApplied': false,
                                        'type': 'wirelessLineOfServiceGroup',
                                        'IMEIDeviceSubType': null,
                                        'childLosgId': null,
                                        'IMEIDeviceType': null,
                                        'nextSpecificDiscount': 0,
                                        'parentLOsgId': null,
                                        'contractType': 'lease',
                                        'volDownPayment': 0,
                                        'lineNumber': 0,
                                        'commitTerm': '4500010',
                                        'contractName': 'NE30M80P'
                                    }
                                },
                                'lastOrderStorePickup': false,
                                'cartDiscounts': 15,
                                'storePickupOrder': false,
                                'currentLOSGId': 'losg14580100',
                                'cartTotalAmount': 194,
                                'cartMonthlyAmount': 124.66,
                                'cartDownPaymentAmt': 0,
                                'noOfdeviceInLOB': 1
                            }
                        },
                        'orderBuyFlowType': 'NEW'
                    },
                    'serviceErrors': [],
                    'redirectKey': null,
                    'inputErrors': {},
                    'status': 'Status: Success(600)',
                    'redirectURL': null,
                    'doRedirect': false
                }
            }
        },

        // Get cart after accessory has been removed
        // removed skuId: sku8030508
        'get_cart_lookup_accessory_removed': {
            url_match: /\/services\/shopwireless\/model\/att\/ecom\/api\/CartLookup\/getCartInfo/,
            response_code: 200,
            params_sent: '?lobType=ALL',
            result: {
                'result': {
                    'methodReturnValue': {
                        'orderSource': 'DESKTOP',
                        'lobTypes': {
                            'WIRELESS': {
                                'cartOneTimeAmount': 25,
                                'losgs': {
                                    'losg14580100': {
                                        'cartItems': {
                                            'plan': {
                                                'sku6220543': {
                                                    'parentConsolidatedProducts': null,
                                                    'productDisplayName': 'Mobile Share Plan',
                                                    'planType': 'voiceplan',
                                                    'paymentType': 'postpaid',
                                                    'dataGroupId': null,
                                                    'quantity': 0,
                                                    'commerceItemId': '83602000148',
                                                    'productId': 'prod6130421'
                                                },
                                                'sku8200352': {
                                                    'parentConsolidatedProducts': null,
                                                    'productDisplayName': 'AT&T Unlimited Plus',
                                                    'planType': 'sharedDataGroup',
                                                    'paymentType': 'postpaid',
                                                    'dataGroupId': null,
                                                    'quantity': 0,
                                                    'commerceItemId': '83602000146',
                                                    'productId': 'prod8890259'
                                                },
                                                'sku8200451': {
                                                    'parentConsolidatedProducts': null,
                                                    'productDisplayName': 'Access for iPhone on 4G LTE w/ VVM',
                                                    'planType': 'sharedDataPlan',
                                                    'paymentType': 'postpaid',
                                                    'dataGroupId': null,
                                                    'quantity': 0,
                                                    'commerceItemId': '83602000147',
                                                    'productId': 'prod8890328'
                                                }
                                            },
                                            'accessory': {
                                                'sku8140322': {
                                                    'parentConsolidatedProducts': null,
                                                    'productDisplayName': 'Apple AirPods with Remote and Mic',
                                                    'planType': null,
                                                    'paymentType': null,
                                                    'dataGroupId': null,
                                                    'quantity': 1,
                                                    'commerceItemId': '83602000144',
                                                    'productId': 'prod8830354'
                                                }
                                            },
                                            'device': {
                                                'sku8040300': {
                                                    'model': 'iPhone 7 32GB',
                                                    'marketingSequence': 1000,
                                                    'hexValue': '#5C5A5A',
                                                    'paymentType': 'postpaid',
                                                    'priceList': [
                                                        {
                                                            'leaseTotalMonths': 30,
                                                            'dueToday': 0,
                                                            'nextSpecificPriceApplied': false,
                                                            'monthlyLeasePrice': 21.67,
                                                            'commitmentTermDiscountName': null,
                                                            'tradeInAmount': 519.99,
                                                            'monthsToUpgrade': "Apr'19",
                                                            'offerReqOrPriceDetailLink': 'See AT&T Next details.',
                                                            'type': 'lease',
                                                            'tradeInPercentage': 80,
                                                            'higherCommitmentTermDiscount': 0,
                                                            'contractGroupType': 'lease',
                                                            'listPrice': 649.99,
                                                            'commitmentTermDiscount': 0,
                                                            'name': 'NE30M80P',
                                                            'dueMonthlyLeasePrice': 21.67,
                                                            'displayFlexDP': true,
                                                            'baseNextPrice': 649.99,
                                                            'savingUptoMsg': null,
                                                            'legalName': '!label.priceblock.leasename.NE30M80P!',
                                                            'defaultSelectionSequence': 1,
                                                            'sortOrder': 100,
                                                            'activationFee': 25,
                                                            'mailInRebate': 0,
                                                            'MREDiscount': 0,
                                                            'itemPrice': 0,
                                                            'legalContent': 'Fees, monthly and other charges apply. Qual. wireless service (voice & data) req’d. <b>Upgrade with trade-in:<\/b> Requires payment of 80% of sales price, trade-in of financed device in good physical and fully functional condition through the AT&T Next trade-in program (excludes AT&T trade-in program where you receive instant credit or an AT&T promotion card), and eligible upgrade. Shown date is an estimate. Actual date may vary by more than a month based on shipping, billing cycle, payments, and other factors. Fees, monthly and other charges, and restrictions apply. ',
                                                            'fANSpecificCustomPriceApplied': false,
                                                            'nextSpecificDiscount': 0,
                                                            'dueTodayLease': 0,
                                                            'salePrice': 0,
                                                            'noCommitmentTermPrice': 649.99,
                                                            'identifierRelatedTradeInTerm': null
                                                        },
                                                        {
                                                            'leaseTotalMonths': 24,
                                                            'dueToday': 0,
                                                            'nextSpecificPriceApplied': false,
                                                            'monthlyLeasePrice': 27.09,
                                                            'commitmentTermDiscountName': null,
                                                            'tradeInAmount': 324.99,
                                                            'monthsToUpgrade': "Apr'18",
                                                            'offerReqOrPriceDetailLink': 'See AT&T Next details.',
                                                            'type': 'lease',
                                                            'tradeInPercentage': 50,
                                                            'higherCommitmentTermDiscount': 0,
                                                            'contractGroupType': 'lease',
                                                            'listPrice': 649.99,
                                                            'commitmentTermDiscount': 0,
                                                            'name': 'NE24M50P',
                                                            'dueMonthlyLeasePrice': 27.09,
                                                            'displayFlexDP': true,
                                                            'baseNextPrice': 649.99,
                                                            'savingUptoMsg': null,
                                                            'legalName': '!label.priceblock.leasename.NE24M50P!',
                                                            'defaultSelectionSequence': 2,
                                                            'sortOrder': 200,
                                                            'activationFee': 25,
                                                            'mailInRebate': 0,
                                                            'MREDiscount': 0,
                                                            'itemPrice': 0,
                                                            'legalContent': 'Fees, monthly and other charges apply. Qual. wireless service (voice & data) req’d.  <b>Upgrade with trade-in:<\/b> Requires payment of 50% of sales price, trade-in of financed device in good physical and fully functional condition through the AT&T Next trade-in program (excludes AT&T trade-in program where you receive instant credit or an AT&T promotion card), and eligible upgrade. Shown date is an estimate. Actual date may vary by more than a month based on shipping, billing cycle, payments, and other factors. Fees, monthly and other charges, and restrictions apply. ',
                                                            'fANSpecificCustomPriceApplied': false,
                                                            'nextSpecificDiscount': 0,
                                                            'dueTodayLease': 0,
                                                            'salePrice': 0,
                                                            'noCommitmentTermPrice': 649.99,
                                                            'identifierRelatedTradeInTerm': null
                                                        },
                                                        {
                                                            'leaseTotalMonths': 0,
                                                            'dueToday': 649.99,
                                                            'nextSpecificPriceApplied': false,
                                                            'monthlyLeasePrice': 0,
                                                            'commitmentTermDiscountName': 'No Commitment:PDA',
                                                            'tradeInAmount': 0,
                                                            'monthsToUpgrade': null,
                                                            'offerReqOrPriceDetailLink': '!label.seeofferdetails!',
                                                            'type': 'regular',
                                                            'tradeInPercentage': 0,
                                                            'higherCommitmentTermDiscount': 25,
                                                            'contractGroupType': null,
                                                            'listPrice': 649.99,
                                                            'commitmentTermDiscount': 15,
                                                            'name': '1',
                                                            'dueMonthlyLeasePrice': 0,
                                                            'displayFlexDP': false,
                                                            'baseNextPrice': 0,
                                                            'savingUptoMsg': null,
                                                            'legalName': 'No annual contract*',
                                                            'defaultSelectionSequence': 7,
                                                            'sortOrder': 700,
                                                            'activationFee': 25,
                                                            'mailInRebate': 0,
                                                            'MREDiscount': 0,
                                                            'itemPrice': 649.99,
                                                            'legalContent': '!pb.legal.contract.regular1!  qualified credit, and wireless service (voice & data). ',
                                                            'fANSpecificCustomPriceApplied': false,
                                                            'nextSpecificDiscount': 0,
                                                            'dueTodayLease': 649.99,
                                                            'salePrice': null,
                                                            'noCommitmentTermPrice': 649.99,
                                                            'identifierRelatedTradeInTerm': null
                                                        }
                                                    ],
                                                    'skuDisplayName': 'Apple iPhone 7 - 32GB - Black',
                                                    'isWHP': 0,
                                                    'averageUsageInGb': 3,
                                                    'isWHPI': 0,
                                                    'size': 32,
                                                    'productId': 'prod8730224',
                                                    'preOwned': false,
                                                    'imgUrl': 'Apple iPhone 7 - 32GB - Black-iPhone 7 32GB-Black-450x350.png',
                                                    'shortDisplayName': 'Apple iPhone 7',
                                                    'subtypeKey': 'pda',
                                                    'color': 'Black',
                                                    'uom': 'GB',
                                                    'isGoPhone': 0,
                                                    'deviceType': 'pda',
                                                    'manufacturer': 'Apple',
                                                    'refurbished': false,
                                                    'skuId': 'sku8040300',
                                                    'commerceItemId': null,
                                                    'displayName': 'Apple iPhone 7 - 32GB'
                                                }
                                            },
                                            'feature': {
                                                'sku5370279': {
                                                    'parentConsolidatedProducts': null,
                                                    'productDisplayName': 'AT&T Mobile Insurance',
                                                    'planType': null,
                                                    'paymentType': null,
                                                    'dataGroupId': null,
                                                    'quantity': 0,
                                                    'commerceItemId': '83602000143',
                                                    'productId': 'prod5280349'
                                                }
                                            }
                                        },
                                        'contractLength': '30',
                                        'mrcAmount': 0,
                                        'productDisplayName': null,
                                        'nextSpecificPriceApplied': false,
                                        'losgFlowType': null,
                                        'IMEIProductId': null,
                                        'FANSpecificCustomPriceApplied': false,
                                        'type': 'wirelessLineOfServiceGroup',
                                        'IMEIDeviceSubType': null,
                                        'childLosgId': null,
                                        'IMEIDeviceType': null,
                                        'nextSpecificDiscount': 0,
                                        'parentLOsgId': null,
                                        'contractType': 'lease',
                                        'volDownPayment': 0,
                                        'lineNumber': 0,
                                        'commitTerm': '4500010',
                                        'contractName': 'NE30M80P'
                                    }
                                },
                                'lastOrderStorePickup': false,
                                'cartDiscounts': 15,
                                'storePickupOrder': false,
                                'currentLOSGId': 'losg14580100',
                                'cartTotalAmount': 194,
                                'cartMonthlyAmount': 124.66,
                                'cartDownPaymentAmt': 0,
                                'noOfdeviceInLOB': 1
                            }
                        },
                        'orderBuyFlowType': 'NEW'
                    },
                    'serviceErrors': [],
                    'redirectKey': null,
                    'inputErrors': {},
                    'status': 'Status: Success(600)',
                    'redirectURL': null,
                    'doRedirect': false
                }
            }
        },

        // Get cart after accessory has been added
        // added skuId: sku1234567
        'get_cart_lookup_accessory_added': {
            url_match: /\/services\/shopwireless\/model\/att\/ecom\/api\/CartLookup\/getCartInfo/,
            response_code: 200,
            params_sent: '?lobType=ALL',
            result: {
                'result': {
                    'methodReturnValue': {
                        'orderSource': 'DESKTOP',
                        'lobTypes': {
                            'WIRELESS': {
                                'cartOneTimeAmount': 25,
                                'losgs': {
                                    'losg14580100': {
                                        'cartItems': {
                                            'plan': {
                                                'sku6220543': {
                                                    'parentConsolidatedProducts': null,
                                                    'productDisplayName': 'Mobile Share Plan',
                                                    'planType': 'voiceplan',
                                                    'paymentType': 'postpaid',
                                                    'dataGroupId': null,
                                                    'quantity': 0,
                                                    'commerceItemId': '83602000148',
                                                    'productId': 'prod6130421'
                                                },
                                                'sku8200352': {
                                                    'parentConsolidatedProducts': null,
                                                    'productDisplayName': 'AT&T Unlimited Plus',
                                                    'planType': 'sharedDataGroup',
                                                    'paymentType': 'postpaid',
                                                    'dataGroupId': null,
                                                    'quantity': 0,
                                                    'commerceItemId': '83602000146',
                                                    'productId': 'prod8890259'
                                                },
                                                'sku8200451': {
                                                    'parentConsolidatedProducts': null,
                                                    'productDisplayName': 'Access for iPhone on 4G LTE w/ VVM',
                                                    'planType': 'sharedDataPlan',
                                                    'paymentType': 'postpaid',
                                                    'dataGroupId': null,
                                                    'quantity': 0,
                                                    'commerceItemId': '83602000147',
                                                    'productId': 'prod8890328'
                                                }
                                            },
                                            'accessory': {
                                                'sku8140322': {
                                                    'parentConsolidatedProducts': null,
                                                    'productDisplayName': 'Apple AirPods with Remote and Mic',
                                                    'planType': null,
                                                    'paymentType': null,
                                                    'dataGroupId': null,
                                                    'quantity': 1,
                                                    'commerceItemId': '83602000144',
                                                    'productId': 'prod8830354'
                                                },
                                                'sku8030508': {
                                                    'parentConsolidatedProducts': null,
                                                    'productDisplayName': 'OtterBox Defender Series Case and Holster - iPhone 7',
                                                    'planType': null,
                                                    'paymentType': null,
                                                    'dataGroupId': null,
                                                    'quantity': 1,
                                                    'commerceItemId': '83602000145',
                                                    'productId': 'prod8720393'
                                                },
                                                'sku1234567': {
                                                    'parentConsolidatedProducts': null,
                                                    'productDisplayName': 'Ottermox Defender',
                                                    'planType': null,
                                                    'paymentType': null,
                                                    'dataGroupId': null,
                                                    'quantity': 1,
                                                    'commerceItemId': '123456789',
                                                    'productId': 'prod1234567'
                                                }
                                            },
                                            'device': {
                                                'sku8040300': {
                                                    'model': 'iPhone 7 32GB',
                                                    'marketingSequence': 1000,
                                                    'hexValue': '#5C5A5A',
                                                    'paymentType': 'postpaid',
                                                    'priceList': [
                                                        {
                                                            'leaseTotalMonths': 30,
                                                            'dueToday': 0,
                                                            'nextSpecificPriceApplied': false,
                                                            'monthlyLeasePrice': 21.67,
                                                            'commitmentTermDiscountName': null,
                                                            'tradeInAmount': 519.99,
                                                            'monthsToUpgrade': "Apr'19",
                                                            'offerReqOrPriceDetailLink': 'See AT&T Next details.',
                                                            'type': 'lease',
                                                            'tradeInPercentage': 80,
                                                            'higherCommitmentTermDiscount': 0,
                                                            'contractGroupType': 'lease',
                                                            'listPrice': 649.99,
                                                            'commitmentTermDiscount': 0,
                                                            'name': 'NE30M80P',
                                                            'dueMonthlyLeasePrice': 21.67,
                                                            'displayFlexDP': true,
                                                            'baseNextPrice': 649.99,
                                                            'savingUptoMsg': null,
                                                            'legalName': '!label.priceblock.leasename.NE30M80P!',
                                                            'defaultSelectionSequence': 1,
                                                            'sortOrder': 100,
                                                            'activationFee': 25,
                                                            'mailInRebate': 0,
                                                            'MREDiscount': 0,
                                                            'itemPrice': 0,
                                                            'legalContent': 'Fees, monthly and other charges apply. Qual. wireless service (voice & data) req’d. <b>Upgrade with trade-in:<\/b> Requires payment of 80% of sales price, trade-in of financed device in good physical and fully functional condition through the AT&T Next trade-in program (excludes AT&T trade-in program where you receive instant credit or an AT&T promotion card), and eligible upgrade. Shown date is an estimate. Actual date may vary by more than a month based on shipping, billing cycle, payments, and other factors. Fees, monthly and other charges, and restrictions apply. ',
                                                            'fANSpecificCustomPriceApplied': false,
                                                            'nextSpecificDiscount': 0,
                                                            'dueTodayLease': 0,
                                                            'salePrice': 0,
                                                            'noCommitmentTermPrice': 649.99,
                                                            'identifierRelatedTradeInTerm': null
                                                        },
                                                        {
                                                            'leaseTotalMonths': 24,
                                                            'dueToday': 0,
                                                            'nextSpecificPriceApplied': false,
                                                            'monthlyLeasePrice': 27.09,
                                                            'commitmentTermDiscountName': null,
                                                            'tradeInAmount': 324.99,
                                                            'monthsToUpgrade': "Apr'18",
                                                            'offerReqOrPriceDetailLink': 'See AT&T Next details.',
                                                            'type': 'lease',
                                                            'tradeInPercentage': 50,
                                                            'higherCommitmentTermDiscount': 0,
                                                            'contractGroupType': 'lease',
                                                            'listPrice': 649.99,
                                                            'commitmentTermDiscount': 0,
                                                            'name': 'NE24M50P',
                                                            'dueMonthlyLeasePrice': 27.09,
                                                            'displayFlexDP': true,
                                                            'baseNextPrice': 649.99,
                                                            'savingUptoMsg': null,
                                                            'legalName': '!label.priceblock.leasename.NE24M50P!',
                                                            'defaultSelectionSequence': 2,
                                                            'sortOrder': 200,
                                                            'activationFee': 25,
                                                            'mailInRebate': 0,
                                                            'MREDiscount': 0,
                                                            'itemPrice': 0,
                                                            'legalContent': 'Fees, monthly and other charges apply. Qual. wireless service (voice & data) req’d.  <b>Upgrade with trade-in:<\/b> Requires payment of 50% of sales price, trade-in of financed device in good physical and fully functional condition through the AT&T Next trade-in program (excludes AT&T trade-in program where you receive instant credit or an AT&T promotion card), and eligible upgrade. Shown date is an estimate. Actual date may vary by more than a month based on shipping, billing cycle, payments, and other factors. Fees, monthly and other charges, and restrictions apply. ',
                                                            'fANSpecificCustomPriceApplied': false,
                                                            'nextSpecificDiscount': 0,
                                                            'dueTodayLease': 0,
                                                            'salePrice': 0,
                                                            'noCommitmentTermPrice': 649.99,
                                                            'identifierRelatedTradeInTerm': null
                                                        },
                                                        {
                                                            'leaseTotalMonths': 0,
                                                            'dueToday': 649.99,
                                                            'nextSpecificPriceApplied': false,
                                                            'monthlyLeasePrice': 0,
                                                            'commitmentTermDiscountName': 'No Commitment:PDA',
                                                            'tradeInAmount': 0,
                                                            'monthsToUpgrade': null,
                                                            'offerReqOrPriceDetailLink': '!label.seeofferdetails!',
                                                            'type': 'regular',
                                                            'tradeInPercentage': 0,
                                                            'higherCommitmentTermDiscount': 25,
                                                            'contractGroupType': null,
                                                            'listPrice': 649.99,
                                                            'commitmentTermDiscount': 15,
                                                            'name': '1',
                                                            'dueMonthlyLeasePrice': 0,
                                                            'displayFlexDP': false,
                                                            'baseNextPrice': 0,
                                                            'savingUptoMsg': null,
                                                            'legalName': 'No annual contract*',
                                                            'defaultSelectionSequence': 7,
                                                            'sortOrder': 700,
                                                            'activationFee': 25,
                                                            'mailInRebate': 0,
                                                            'MREDiscount': 0,
                                                            'itemPrice': 649.99,
                                                            'legalContent': '!pb.legal.contract.regular1!  qualified credit, and wireless service (voice & data). ',
                                                            'fANSpecificCustomPriceApplied': false,
                                                            'nextSpecificDiscount': 0,
                                                            'dueTodayLease': 649.99,
                                                            'salePrice': null,
                                                            'noCommitmentTermPrice': 649.99,
                                                            'identifierRelatedTradeInTerm': null
                                                        }
                                                    ],
                                                    'skuDisplayName': 'Apple iPhone 7 - 32GB - Black',
                                                    'isWHP': 0,
                                                    'averageUsageInGb': 3,
                                                    'isWHPI': 0,
                                                    'size': 32,
                                                    'productId': 'prod8730224',
                                                    'preOwned': false,
                                                    'imgUrl': 'Apple iPhone 7 - 32GB - Black-iPhone 7 32GB-Black-450x350.png',
                                                    'shortDisplayName': 'Apple iPhone 7',
                                                    'subtypeKey': 'pda',
                                                    'color': 'Black',
                                                    'uom': 'GB',
                                                    'isGoPhone': 0,
                                                    'deviceType': 'pda',
                                                    'manufacturer': 'Apple',
                                                    'refurbished': false,
                                                    'skuId': 'sku8040300',
                                                    'commerceItemId': null,
                                                    'displayName': 'Apple iPhone 7 - 32GB'
                                                }
                                            },
                                            'feature': {
                                                'sku5370279': {
                                                    'parentConsolidatedProducts': null,
                                                    'productDisplayName': 'AT&T Mobile Insurance',
                                                    'planType': null,
                                                    'paymentType': null,
                                                    'dataGroupId': null,
                                                    'quantity': 0,
                                                    'commerceItemId': '83602000143',
                                                    'productId': 'prod5280349'
                                                }
                                            }
                                        },
                                        'contractLength': '30',
                                        'mrcAmount': 0,
                                        'productDisplayName': null,
                                        'nextSpecificPriceApplied': false,
                                        'losgFlowType': null,
                                        'IMEIProductId': null,
                                        'FANSpecificCustomPriceApplied': false,
                                        'type': 'wirelessLineOfServiceGroup',
                                        'IMEIDeviceSubType': null,
                                        'childLosgId': null,
                                        'IMEIDeviceType': null,
                                        'nextSpecificDiscount': 0,
                                        'parentLOsgId': null,
                                        'contractType': 'lease',
                                        'volDownPayment': 0,
                                        'lineNumber': 0,
                                        'commitTerm': '4500010',
                                        'contractName': 'NE30M80P'
                                    }
                                },
                                'lastOrderStorePickup': false,
                                'cartDiscounts': 15,
                                'storePickupOrder': false,
                                'currentLOSGId': 'losg14580100',
                                'cartTotalAmount': 194,
                                'cartMonthlyAmount': 124.66,
                                'cartDownPaymentAmt': 0,
                                'noOfdeviceInLOB': 1
                            }
                        },
                        'orderBuyFlowType': 'NEW'
                    },
                    'serviceErrors': [],
                    'redirectKey': null,
                    'inputErrors': {},
                    'status': 'Status: Success(600)',
                    'redirectURL': null,
                    'doRedirect': false
                }
            }
        },

        /**
         * Get cart if the cartItem's deviceType is a pda, so the upgrading device ultimately would be a phone.
         */
        "get_cart_lookup_deviceType_phone": {
            url_match: /\/services\/shopwireless\/model\/att\/ecom\/api\/CartLookup\/getCartInfo/,
            response_code: 200,
            params_sent: '?lobType=ALL',
            result: {
                "result": {
                    "methodReturnValue": {
                        "orderSource": "DESKTOP",
                        "lobTypes": {
                            "WIRELESS": {
                                "cartOneTimeAmount": 25,
                                "losgs": {
                                    "losg14580100": {
                                        "cartItems": {
                                            "device": {
                                                "sku8040300": {
                                                    "deviceType": "pda"
                                                }
                                            }
                                        }
                                    }
                                },
                                "currentLOSGId": "losg14580100"
                            }
                        }
                    }
                }
            }
        },

        /**
         * Get cart if the cartItem's deviceType is a netbook, so the upgrading device ultimately would be a tablet.
         */
        "get_cart_lookup_deviceType_tablet": {
            url_match: /\/services\/shopwireless\/model\/att\/ecom\/api\/CartLookup\/getCartInfo/,
            response_code: 200,
            params_sent: '?lobType=ALL',
            result: {
                "result": {
                    "methodReturnValue": {
                        "orderSource": "DESKTOP",
                        "lobTypes": {
                            "WIRELESS": {
                                "cartOneTimeAmount": 25,
                                "losgs": {
                                    "losg14580100": {
                                        "cartItems": {
                                            "device": {
                                                "sku8040300": {
                                                    "deviceType": "netbook"
                                                }
                                            }
                                        }
                                    }
                                },
                                "currentLOSGId": "losg14580100"
                            }
                        }
                    }
                }
            }
        }
    };
})();
