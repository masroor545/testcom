var Endpoint_refreshUpgradeEligibility = (function () {
    'use strict';

    return {

        /**
         * Get upgrade eligibility users by calling api
         */

        'get_device_details': {
            url_match: /\/services\/shopwireless\/model\/att\/ecom\/api\/WirelessUpgradeSelectionActor\/getUpgradeEligibility.*/,
            response_code: 200,
            params_sent: '?refreshEligibility=true',
            result: {
                'response': {
                    'redirectKey': null,
                    'errors': null,
                    'status': 'success',
                    'subStatus': null,
                    'redirectURL': null,
                    'redirect': false
                },
                'payload': {
                    'G20251984': [
                        {
                            'hideUpgradeOption': false,
                            'regUpgradeEligible': false,
                            'contractEndDate': {'time': 1541116800000},
                            'planChangeRequired': false,
                            'groupId': 'G20251984',
                            'eligibilityInfo': {
                                'futureLeaseEligibilityDate': null,
                                'payUpAmount': 0,
                                'crossUpgradeEligibile': false,
                                'upgradeType': 'NO_COMMIT',
                                'futureEarlyEligibilityDate': null,
                                'earlyUpgrade': false,
                                'payOffAmount': 0,
                                'tradeInEligible': true,
                                'eligibility': 'INELIGIBLE',
                                'offerReasonCodes': [
                                    'messageCode.LTV999_Lease'
                                ],
                                'firstEligibilityDate': null,
                                'futureEligibilityDate': null,
                                'offerCodeDiscountAmtMap': {},
                                'eligibilityDate': null
                            },
                            'partOfSharedData': true,
                            'subscriberNumber': '4256862891',
                            'term': 24,
                            'subscriptionClass': null,
                            'contractType': 'lease',
                            'device': {
                                'model': 'iPhone6sPlus',
                                'color': 'Space Gray',
                                'deviceType': 'pda',
                                'deviceGroupType': 'Cellphone',
                                'make': 'APPLE'
                            },
                            'sharedDataMember': true,
                            'noCommitUpgradeEligible': true,
                            'IRUSplitLiability': false,
                            'customerFirstName': 'BEDROCK'
                        },
                        {
                            'hideUpgradeOption': false,
                            'regUpgradeEligible': false,
                            'contractEndDate': {'time': 1541116800000},
                            'planChangeRequired': false,
                            'groupId': 'G20251984',
                            'eligibilityInfo': {
                                'futureLeaseEligibilityDate': {
                                    'time': 1537228800000
                                },
                                'payUpAmount': 0,
                                'crossUpgradeEligibile': false,
                                'upgradeType': 'NO_COMMIT',
                                'futureEarlyEligibilityDate': null,
                                'earlyUpgrade': false,
                                'payOffAmount': 0,
                                'tradeInEligible': false,
                                'eligibility': 'FUTURE_DISCOUNT_ELIGIBLE',
                                'offerReasonCodes': [
                                    'messageCode.LTV998_Lease'
                                ],
                                'firstEligibilityDate': {
                                    'time': 1537228800000
                                },
                                'futureEligibilityDate': {
                                    'time': 1550448000000
                                },
                                'offerCodeDiscountAmtMap': {},
                                'eligibilityDate': null
                            },
                            'partOfSharedData': true,
                            'subscriberNumber': '4256862890',
                            'term': 24,
                            'subscriptionClass': null,
                            'contractType': 'regular',
                            'device': {
                                'model': 'iPhone6sPlus',
                                'color': 'Space Gray',
                                'deviceType': 'pda',
                                'deviceGroupType': 'Cellphone',
                                'make': 'APPLE'
                            },
                            'sharedDataMember': true,
                            'noCommitUpgradeEligible': true,
                            'IRUSplitLiability': false,
                            'customerFirstName': 'BEDROCK'
                        }
                    ],
                    'Individual': [
                        {
                            'hideUpgradeOption': false,
                            'regUpgradeEligible': false,
                            'contractEndDate': {'time': 1541116800000},
                            'planChangeRequired': false,
                            'groupId': null,
                            'eligibilityInfo': {
                                'futureLeaseEligibilityDate': null,
                                'payUpAmount': 0,
                                'crossUpgradeEligibile': false,
                                'upgradeType': 'NO_COMMIT',
                                'futureEarlyEligibilityDate': null,
                                'earlyUpgrade': false,
                                'payOffAmount': 0,
                                'tradeInEligible': false,
                                'eligibility': 'DISCOUNT_ELIGIBLE',
                                'offerReasonCodes': [
                                    'messageCode.LTV999_Lease'
                                ],
                                'firstEligibilityDate': null,
                                'futureEligibilityDate': null,
                                'offerCodeDiscountAmtMap': {},
                                'eligibilityDate': null
                            },
                            'partOfSharedData': false,
                            'subscriberNumber': '4252951808',
                            'term': 0,
                            'subscriptionClass': null,
                            'contractType': 'regular',
                            'device': {
                                'model': 'iPhone6sPlus',
                                'color': 'Space Gray',
                                'deviceType': 'pda',
                                'deviceGroupType': 'Cellphone',
                                'make': 'APPLE'
                            },
                            'sharedDataMember': false,
                            'noCommitUpgradeEligible': true,
                            'IRUSplitLiability': false,
                            'customerFirstName': 'BEDROCK'
                        },
                        {
                            'hideUpgradeOption': false,
                            'regUpgradeEligible': false,
                            'contractEndDate': {'time': 1541116800000},
                            'planChangeRequired': true,
                            'groupId': null,
                            'eligibilityInfo': {
                                'futureLeaseEligibilityDate': {
                                    'time': 1537228800000
                                },
                                'payUpAmount': 0,
                                'crossUpgradeEligibile': false,
                                'upgradeType': 'NO_COMMIT',
                                'futureEarlyEligibilityDate': null,
                                'earlyUpgrade': false,
                                'payOffAmount': 0,
                                'tradeInEligible': false,
                                'eligibility': 'INELIGIBLE',
                                'offerReasonCodes': [
                                    'messageCode.LTV998_Lease'
                                ],
                                'firstEligibilityDate': {
                                    'time': 1537228800000
                                },
                                'futureEligibilityDate': {
                                    'time': 1550448000000
                                },
                                'offerCodeDiscountAmtMap': {},
                                'eligibilityDate': null
                            },
                            'partOfSharedData': false,
                            'subscriberNumber': '4256862880',
                            'term': 24,
                            'subscriptionClass': null,
                            'contractType': 'regular',
                            'device': {
                                'model': 'iPhone6sPlus',
                                'color': 'Space Gray',
                                'deviceType': 'pda',
                                'deviceGroupType': 'Cellphone',
                                'make': 'APPLE'
                            },
                            'sharedDataMember': false,
                            'noCommitUpgradeEligible': false,
                            'IRUSplitLiability': true,
                            'customerFirstName': 'BEDROCK'
                        }
                    ],
                    '4252951809': [
                        {
                            'hideUpgradeOption': false,
                            'regUpgradeEligible': false,
                            'contractEndDate': {'time': 1541116800000},
                            'planChangeRequired': false,
                            'groupId': null,
                            'eligibilityInfo': {
                                'futureLeaseEligibilityDate': null,
                                'payUpAmount': 50,
                                'crossUpgradeEligibile': false,
                                'upgradeType': 'NO_COMMIT',
                                'futureEarlyEligibilityDate': null,
                                'earlyUpgrade': false,
                                'payOffAmount': 0,
                                'tradeInEligible': false,
                                'eligibility': 'ELIGIBLE',
                                'offerReasonCodes': [
                                    'messageCode.LTV999_Lease'
                                ],
                                'firstEligibilityDate': null,
                                'futureEligibilityDate': null,
                                'offerCodeDiscountAmtMap': {},
                                'eligibilityDate': null
                            },
                            'partOfSharedData': false,
                            'subscriberNumber': '4252951809',
                            'term': 0,
                            'subscriptionClass': null,
                            'contractType': 'install',
                            'device': {
                                'model': 'iPhone6sPlus',
                                'color': 'Space Gray',
                                'deviceType': 'pda',
                                'deviceGroupType': 'Cellphone',
                                'make': 'APPLE'
                            },
                            'sharedDataMember': false,
                            'noCommitUpgradeEligible': true,
                            'IRUSplitLiability': false,
                            'customerFirstName': 'BEDROCK'
                        },
                        {
                            'hideUpgradeOption': false,
                            'regUpgradeEligible': false,
                            'contractEndDate': {'time': 1541116800000},
                            'planChangeRequired': false,
                            'groupId': null,
                            'eligibilityInfo': {
                                'futureLeaseEligibilityDate': null,
                                'payUpAmount': 0,
                                'crossUpgradeEligibile': false,
                                'upgradeType': 'NO_COMMIT',
                                'futureEarlyEligibilityDate': null,
                                'earlyUpgrade': false,
                                'payOffAmount': 70,
                                'tradeInEligible': false,
                                'eligibility': 'ELIGIBLE',
                                'offerReasonCodes': [
                                    'messageCode.LTV999_Lease'
                                ],
                                'firstEligibilityDate': null,
                                'futureEligibilityDate': null,
                                'offerCodeDiscountAmtMap': {},
                                'eligibilityDate': null
                            },
                            'partOfSharedData': false,
                            'subscriberNumber': '4256862873',
                            'term': 0,
                            'subscriptionClass': null,
                            'contractType': 'regular',
                            'device': {
                                'model': 'iPhone6sPlus',
                                'color': 'Space Gray',
                                'deviceType': 'pda',
                                'deviceGroupType': 'Cellphone',
                                'make': 'APPLE'
                            },
                            'sharedDataMember': false,
                            'noCommitUpgradeEligible': true,
                            'IRUSplitLiability': false,
                            'customerFirstName': 'BEDROCK'
                        }
                    ]
                }
            }
            // End result

        }
    };
})();