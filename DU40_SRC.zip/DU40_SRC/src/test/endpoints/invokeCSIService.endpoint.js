/**
 * Various test responses for the invokeCSIService web service
 *
 * @type {{
 *     csiServiceSuccess,
 *     csiServiceAuthError,
 *     csiServiceFailure
 * }}
 */
var Endpoint_invokeCSIService = (function () {
    'use strict';

    return {
        /**
         * Service response is completely successful
         */
        'csiServiceSuccess': {
            url_match: /\/services\/shopwireless\/model\/att\/ecom\/api\/CsiCallForPostAuthorizationServiceActor\/invokeCSIService.*/,
            response_code: 200,
            result: {
                redirectURL: '/shop/login/passcode.html',
                authenticationError: false,
                csiCallCompleted: true,
                slidAssocAccts: 'WLS~177067869278|UVS~336013403~336013403'
            }
        },

        /**
         * Service response contains authentication error
         */
        'csiServiceAuthError': {
            url_match: /\/services\/shopwireless\/model\/att\/ecom\/api\/CsiCallForPostAuthorizationServiceActor\/invokeCSIService.*/,
            response_code: 200,
            result: {
                redirectURL: '/shop/login/passcode.html',
                authenticationError: true,
                csiCallCompleted: true
            }
        },

        /**
         * Service responds with a 500 error
         */
        'csiServiceFailure': {
            url_match: /\/services\/shopwireless\/model\/att\/ecom\/api\/CsiCallForPostAuthorizationServiceActor\/invokeCSIService.*/,
            response_code: 500,
            result: {}
        }
    };
})();
