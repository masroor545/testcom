/**
 * Test responses for the exCqTranslatorKeyService.getCqTranslatorKeys function.
 *
 * @example
 * $httpBackend.whenGET(Endpoint_cqTranslatorKeys.get_cq_translator_keys.url_match)
 *      .respond(200, Endpoint_cqTranslatorKeys.get_cq_translator_keys.result);
 */
var Endpoint_cqTranslatorKeys = (function () {
    'use strict';

    return {
        /**
         * Return the 360 xml file for SKU 8040300.
         */
        'get_cq_translator_keys': {
            url_match: /\/services\/shopwireless\/model\/att\/ecom\/api\/CQKeyResolverServiceActor\/getCQKeys/,
            response_code: 200,
            params_sent: 'cmsKeys=label.devicelist.viewAllDevices,label.defaultListPage.numberOfElement',
            result: {
                "result": {
                    "statusCode": "400",
                    "methodReturnValue": {
                        "label.devicelist.viewAllDevices": "Viewing all devices compatible with: {plan name}",
                        "label.defaultListPage.numberOfElement": "label.defaultListPage.numberOfElement"
                    },
                    "redirectKey": null,
                    "redirectURL": null,
                    "doRedirect": false,
                    "statusName": "Success"
                }
            }
        },
        'get_cq_translator_key_singular': {
            url_match: /\/services\/shopwireless\/model\/att\/ecom\/api\/CQKeyResolverServiceActor\/getCQKeys/,
            response_code: 200,
            params_sent: 'cmsKeys=label.defaultListPage.numberOfElement',
            result: {
                "result": {
                    "statusCode": "400",
                    "methodReturnValue": {
                        "label.defaultListPage.numberOfElement": "label.defaultListPage.numberOfElement"
                    },
                    "redirectKey": null,
                    "redirectURL": null,
                    "doRedirect": false,
                    "statusName": "Success"
                }
            }
        },
		'getShortLegalCmsKey': {
			result: {
				'label.dlist.legal.nocommitment.alldevices': "Req's activ. on qual. plan.",
				'label.dlist.legal.NE30M80P.pda': "Requires 30-mo. installment agmt., qual. credit, and services."
            }
        },
        //Labels for device config
		'getLabelsForDeviceConfig': {
			result: {
				'label.pb.leasename.NE30M80P': "AT&T Next<sup>�<\/sup>",
			    'label.2yr.noasterisk': "2-year Contract",
			    'label.pb.leasename.IP20A.mobile': "Installment Plan",
			    'label.pb.leasename.NE24M50P': "AT&T Next Every Year&#8480;",
			    'label.devices.nocommitment': "No annual contract",
                'label.hylaOffer.credit.message' : 'Trade in for $650 in credit',
                'label.hylaOffer.credit.qualify' : 'Get up to $650 in bill credit',
                'label.hylaOffer.credit.details' : 'See offer details and terms',
                'label.hylaOffer.credit.optin' : 'Yes, I like to trade in my old device',
			    'priceblock.starting.lease.lbl': "Requires 0% APR {0}-month installment agreement, well-qualified credit and service. Other options available.",
				'two.year.qualifying.plan.lbl': "With 2-year contract\nw/qual. plans",
				'lbl.two.year.qual.plan': "with 2-year contract w/qual. plans",
				'priceblock.starting.regular.lbl': "Retail price. Requires qualified service.",
                'omni.suppress.productid.lbl': "prod8730224"
            }
        }
    };
})();
