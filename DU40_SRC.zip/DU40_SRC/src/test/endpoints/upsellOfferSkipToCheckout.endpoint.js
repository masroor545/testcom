var Endpoint_upsellOfferSkipToCheckoutApi = (function () {
    'use strict';

    return {

        'skip_to_checkout': {
            url_match: /services\/shopwireless\/model\/att\/ecom\/api\/ExUpHandOffToCheckoutActor\/exUpCheckoutHandoffService/,
            response_code: 200,
            params_sent: '?skipToCheckout=true',
            result: {
                'response': {
                    'redirectKey': null,
                    'errors': null,
                    'status': "success",
                    'subStatus': null,
                    'redirectURL': "/cart/mycart.html#/cart/mycart",
                    'redirect': true
                }
            }
        }
    };
})();