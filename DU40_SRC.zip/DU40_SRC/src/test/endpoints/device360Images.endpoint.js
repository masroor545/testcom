/**
 * Test responses for the contentService.getDevice360Images and contentService.transformThreeSixtyXml2Json functions.
 *
 * @example
 * $httpBackend.whenGET(Endpoint_device360Images.get_device_360_images.url_match)
 *      .respond(200, Endpoint_device360Images.get_device_360_images.result);
 */
var Endpoint_device360Images = (function () {
    'use strict';

    return {
        /**
         * Return the 360 xml file for SKU 8040300.
         */
        'get_device_360_images': {
            url_match: /\/shopcms\/360s\/xml\/8040300.xml/,
            response_code: 200,
            params_sent: '',
            result: '<?xml version="1.0" encoding="UTF-8"?>' +
            '<phone spritePath="">' +
            '      <features>' +
            '  ' +
            '   </features>' +
            '   <movies>' +
            '    ' +
            '   </movies>' +
            '   <images>' +
            '' +
            '    ' +
            '<image_info path="/shopcms/media/att/2016/shop/360s/devices/8040300/6472a-1" suffix=".jpg" title_en="Apple iPhone 7 - 32GB - Black" title_es=""/>' +
            '	 ' +
            '<image_info path="/shopcms/media/att/2016/shop/360s/devices/8040300/6472a-2" suffix=".jpg" title_en="Apple iPhone 7 - 32GB - Black" title_es=""/>' +
            '	 ' +
            '  	 ' +
            '   </images>' +
            '    ' +
            '</phone>'
        },
        'get_device_360_images_missing_attributes': {
            url_match: /\/shopcms\/360s\/xml\/8040300.xml/,
            response_code: 200,
            params_sent: '',
            result: '<?xml version="1.0" encoding="UTF-8"?>' +
            '<phone spritePath="">' +
            '      <features>' +
            '  ' +
            '   </features>' +
            '   <movies>' +
            '    ' +
            '   </movies>' +
            '   <images>' +
            '' +
            '    ' +
            '<image_info path="/shopcms/media/att/2016/shop/360s/devices/8040300/6472a-1" suffix=".jpg" title_es=""/>' +
            '	 ' +
            '<image_info title_en="Apple iPhone 7 - 32GB - Black" title_es=""/>' +
            '	 ' +
            '  	 ' +
            '   </images>' +
            '    ' +
            '</phone>'
        },
        'get_device_360_images_missing_elements': {
            url_match: /\/shopcms\/360s\/xml\/8040300.xml/,
            response_code: 200,
            params_sent: '',
            result: '<?xml version="1.0" encoding="UTF-8"?>' +
            '<phone spritePath="">' +
            '      <features>' +
            '  ' +
            '   </features>' +
            '   <movies>' +
            '    ' +
            '   </movies>' +
            '   <images>' +
            '' +
            '    ' +
            '  	 ' +
            '   </images>' +
            '    ' +
            '</phone>'
        }
    };
})();
