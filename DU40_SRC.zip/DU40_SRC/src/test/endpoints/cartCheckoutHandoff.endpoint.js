/**
 * Test response for the checkout handoff service.
 *
 * @example
 * $httpBackend.whenGET(Endpoint_accessoryRecommenderApi.get_accessory_recommendations.url_match)
 *      .respond(200, Endpoint_accessoryRecommenderApi.get_accessory_recommendations.result);
 */

var Endpoint_checkoutHandoff = (function () {
    'use strict';

    return {
        'proceed_to_checkout': {
            url_match: /services\/shopwireless\/model\/att\/ecom\/api\/ExUpHandOffToCheckoutActor\/exUpCheckoutHandoffService/,
            response_code: 200,
            result: {
                'response': {
                    'redirectKey': null,
                    'errors': null,
                    'status': 'success',
                    'subStatus': null,
                    'redirectURL': '/shop/xpress/upsell-offer.html',
                    'redirect': true
                }
            }
        }
    };
})();