/**
 * Test responses for the upsell offer service
 *
 * @example
 * $httpBackend.whenGET(Endpoint_upsellOfferContentNode.get_legal_content_node.url_match)
 *      .respond(200, Endpoint_upsellOfferContentNode.get_legal_content_node.result);
 */
var Endpoint_upsellOfferContentNode = (function () {
    'use strict';

    return {
        'get_legal_content_node': {
            url_match: /\/shop\/wireless\/legal.sharedcontentdetailsasjson.html/,
            response_code: 200,
            params_sent: '',

            result: {
                'offercontent/200004': {
                    'legalcontent': [
                        '&lt;p&gt;&lt;strong&gt;SAMSUNG GALAXY S8 INTEGRATED BOGO: Limited Time Offer (ends 5/31/17 in Puerto Rico).&amp;nbsp;&lt;/strong&gt; Select locations.&amp;nbsp; &lt;strong&gt;Elig. Devices:&lt;/strong&gt; Samsung Galaxy S8, S8+, Galaxy S7, Galaxy S7 Active, and Galaxy S7 Edge on 0% APR AT&amp;amp;T Next (30-mo. at $25) or AT&amp;amp;T Next Every Year (24-mo. at $31.25) installment agmts. $0 down for well-qualified credit or down payment may be req&amp;rsquo;d. Retail price is divided into monthly installments. &lt;strong&gt;Tax on full retail price due at sale.&lt;/strong&gt;&amp;nbsp; After all credits, get S8 up to $750 (credits are $25/mo. or $31.25/mo.) for free.&amp;nbsp; May apply max credit towards S8+ devices priced up to $850, which will be discounted but not free.&amp;nbsp; May also apply credit towards Galaxy S7 (priced at $595, credits are 30-mo. at $19.84 or 24-mo. at $24.80) or to Galaxy S7 Edge or S7 Active (priced at $695, credits are 30-mo. at $23.17 or 24-mo. at $28.96).&amp;nbsp; &lt;strong&gt;Wireless:&lt;/strong&gt; Monthly postpaid voice &amp;amp; data plan req&amp;rsquo;d on both (existing customers can add to elig. current plans). &lt;strong&gt;If you cancel service you will owe device balance of up to $850.&amp;nbsp; DIRECTV:&lt;/strong&gt; Excludes streaming only svcs. If new customer, 24-month agmt req&amp;rsquo;d. Must be installed w/in 30 days of device activation to receive credits; if svc cannot be installed must return device w/in 14 days of notification from AT&amp;amp;T or will owe device balance of up to $850.&amp;nbsp;&lt;strong&gt; Bill Credit:&amp;nbsp;&lt;/strong&gt; Applied in equal amounts based on lower priced device over entire agmt term &amp;amp; will not exceed $750 for S8 or S8+ and will not exceed $695 for Samsung Galaxy S7, S7 Edge, and S7 Active. Addresses for TV and wireless accounts must match and both wireless lines must be on same acct, be active &amp;amp; in good standing for 30 days to qualify. To get all credits (up to max bill credit of lower priced device), free/discounted wireless line and TV service must remain active and on agmts for entire term. If upgrade or pay up/off agmts early your credits may cease. &lt;strong&gt;Offer Limits:&lt;/strong&gt; May not be combinable w/ other offers, discounts or credits. Participation in this offer may make your wireless account ineligible for select other offers (including select bill credit offers) for a 12 month period.&amp;nbsp; &lt;strong&gt;Return:&lt;/strong&gt; Restocking fee up to $45 may apply. See store or att.com/buyonegiveone for offer details.&lt;br /&gt;&lt;strong&gt;GEN. WIRELESS SVC: Subj. to Wireless Customer Agmt&lt;/strong&gt; (att.com/wca). &lt;strong&gt;Deposit:&lt;/strong&gt; may apply. &lt;strong&gt;Limits:&lt;/strong&gt; Purch. limits apply. &lt;strong&gt;Activation:&lt;/strong&gt; $25 Fee. Credit approval, taxes, fees, monthly, other charges, usage, speed, coverage &amp;amp; other restrs apply. See att.com/additionalcharges for details on fees &amp;amp; charges. &lt;strong&gt;Promotion, terms, &amp;amp; restr&amp;rsquo;s subject to change &amp;amp; may be modified or terminated at any time without notice.&lt;/strong&gt;&amp;nbsp; AT&amp;amp;T service is subject to AT&amp;amp;T network management policies. See att.com/broadbandinfo for details.&lt;/p&gt; &lt;p&gt;&lt;br /&gt;&lt;strong&gt;DIRECTV:&amp;nbsp; Subj. to Equip. Lease &amp;amp; Customer Agreements&lt;/strong&gt; (directv.com/legal). Residential customers only. Hardware and programming avail. separately. Early termination fee of $20/mo. for each mo. remaining on agmt., $35 activation, equipment non-return &amp;amp; add&amp;rsquo;l fees apply. Programming, pricing, terms &amp;amp; conditions subject to change at any time.&lt;/p&gt;'
                    ],
                    'jcr:description': [
                        'SAMSUNG GALAXY S8 INTEGRATED BOGO: Limited Time Offer (ends 5/31/17 in Puerto Rico).&amp;nbsp; Select locations.&amp;nbsp; Elig. Devices: Samsung Galaxy S8, S8+, Galaxy S7, Galaxy S7 Active, and Galaxy S7 Edge on 0% APR AT&amp;amp;T Next (30-mo. at $25) or AT&amp;amp;T Next Every Year (24-mo. at $31.25) installment agmts. $0 down for well-qualified credit or down payment may be req&amp;rsquo;d. Retail price is divided into monthly installments. Tax on full retail price due at sale.&amp;nbsp; After all credits, get S8 up to $750 (credits are $25/mo. or $31.25/mo.) for free.&amp;nbsp; May apply max credit towards S8+ devices priced up to $850, which will be discounted but not free.&amp;nbsp; May also apply credit towards Galaxy S7 (priced at $595, credits are 30-mo. at $19.84 or 24-mo. at $24.80) or to Galaxy S7 Edge or S7 Active (priced at $695, credits are 30-mo. at $23.17 or 24-mo. at $28.96).&amp;nbsp; Wireless: Monthly postpaid voice &amp;amp; data plan req&amp;rsquo;d on both (existing customers can add to elig. current plans). If you cancel service you will owe device balance of up to $850.&amp;nbsp; DIRECTV: Excludes streaming only svcs. If new customer, 24-month agmt req&amp;rsquo;d. Must be installed w/in 30 days of device activation to receive credits; if svc cannot be installed must return device w/in 14 days of notification from AT&amp;amp;T or will owe device balance of up to $850.&amp;nbsp; Bill Credit:&amp;nbsp; Applied in equal amounts based on lower priced device over entire agmt term &amp;amp; will not exceed $750 for S8 or S8+ and will not exceed $695 for Samsung Galaxy S7, S7 Edge, and S7 Active. Addresses for TV and wireless accounts must match and both wireless lines must be on same acct, be active &amp;amp; in good standing for 30 days to qualify. To get all credits (up to max bill credit of lower priced device), free/discounted wireless line and TV service must remain active and on agmts for entire term. If upgrade or pay up/off agmts early your credits may cease. Offer Limits: May not be combinable w/ other offers, discounts or credits. Participation in this offer may make your wireless account ineligible for select other offers (including select bill credit offers) for a 12 month period.&amp;nbsp; Return: Restocking fee up to $45 may apply. See store or &lt;a href=&quot;att.com/buyonegiveone&quot;&gt;att.com/buyonegiveone&lt;/a&gt; for offer details.&lt;br /&gt;GEN. WIRELESS SVC: Subj. to Wireless Customer Agmt (&lt;a href=&quot;att.com/wca&quot;&gt;att.com/wca&lt;/a&gt;). Deposit: may apply. Limits: Purch. limits apply. Activation: $25 Fee. Credit approval, taxes, fees, monthly, other charges, usage, speed, coverage &amp;amp; other restrs apply. See &lt;a href=&quot;att.com/additionalcharges&quot;&gt;att.com/additionalcharges&lt;/a&gt; for details on fees &amp;amp; charges. Promotion, terms, &amp;amp; restr&amp;rsquo;s subject to change &amp;amp; may be modified or terminated at any time without notice.&amp;nbsp; AT&amp;amp;T service is subject to AT&amp;amp;T network management policies. See &lt;a href=&quot;att.com/broadbandinfo&quot;&gt;att.com/broadbandinfo&lt;/a&gt; for details.&lt;br /&gt;DIRECTV:&amp;nbsp; Subj. to Equip. Lease &amp;amp; Customer Agreements (&lt;a href=&quot;directv.com/legal&quot;&gt;directv.com/legal&lt;/a&gt;). Residential customers only. Hardware and programming avail. separately. Early termination fee of $20/mo. for each mo. remaining on agmt., $35 activation, equipment non-return &amp;amp; add&amp;rsquo;l fees apply. Programming, pricing, terms &amp;amp; conditions subject to change at any time.'
                    ],
                    'sling:resourceType': [
                        'att/wireless/components/page/sharedcontent/devices/warrantyinfo'
                    ],
                    'jcr:uuid': [
                        '5961f436-88d2-468a-bf8c-09a6d66f4603'
                    ],
                    'jcr:mixinTypes': [
                        'mix:versionable'
                    ],
                    'jcr:title': [
                        '200004'
                    ],
                    'subheadline': [
                        '&lt;strong&gt;Buy a Samsung Galaxy S8, and get one free when you buy both on AT&amp;amp;T Next&lt;sup&gt;&amp;reg;&lt;/sup&gt; with monthly eligible wireless (min. 1&lt;sup&gt;st&lt;/sup&gt; line $50; 2&lt;sup&gt;nd&lt;/sup&gt; line $20) and DIRECTV service (min. $29.99/mo.).&lt;/strong&gt;'
                    ],
                    'attcms:currentProject': [
                        '1707b_DU40_SDD'
                    ],
                    'subtitle': [
                        '*Each req&rsquo;s $750 on installment agmt &amp; elig. svc. Req&rsquo;s a new line. Free after $750 in credits over 30 months. Credits start in 2 to 3 bills. If svc cancelled, device balance due. Taxes &amp; fees apply. For email: add at end &ldquo;See details below.&rdquo; For direct mail &ndash; (if Bottom legal is on a different page): Limited Time Offer (ends 5/31/17 in Puerto Rico). Req&rsquo;s well-qual. credit. Free after $750 in bill credits over 30 mos. Credits start in 2-3 bills. If svc cancelled, device balance due. Taxes &amp; fees apply. See att.com/buyonegiveone for more details.'
                    ],
                    'inbody': [
                        '&lt;ol style=&quot;list-style-type: lower-alpha;&quot;&gt; &lt;li&gt;*Each req&amp;rsquo;s $750 on installment agmt &amp;amp; elig. svc. Req&amp;rsquo;s a new line. Free after $750 in credits over 30 months. Credits start in 2 to 3 bills.&lt;strong&gt; If svc cancelled, device balance due.&lt;/strong&gt; Taxes &amp;amp; fees apply.&lt;/li&gt; &lt;li&gt;&lt;strong&gt;For email:&lt;/strong&gt; add at end &amp;ldquo;See details below.&amp;rdquo;&lt;/li&gt; &lt;li&gt;&lt;strong&gt;For direct mail:&lt;/strong&gt; Limited Time Offer (ends 5/31/17 in Puerto Rico).&amp;nbsp; Req&amp;rsquo;s well-qual. credit.&amp;nbsp; Free after $750 in bill credits over 30 mos.&amp;nbsp; Credits start in 2-3 bills.&amp;nbsp; If svc cancelled, device balance due.&amp;nbsp; Taxes &amp;amp; fees apply.&amp;nbsp; See att.com/buyonegiveone for more details.&lt;strong&gt;&lt;br /&gt;&lt;/strong&gt;&lt;/li&gt; &lt;/ol&gt;'
                    ],
                    'jcr:created': [
                        '2017-05-22T11:47:23.249-07:00'
                    ],
                    'jcr:baseVersion': [
                        '3c53fe74-fe2a-4072-b24a-ce8c9347f7d0'
                    ],
                    'navTitle': [
                        'Buy a Samsung Galaxy S8, and get one free when you buy both on AT&amp;amp;T Next&lt;sup&gt;&amp;reg;&lt;/sup&gt; with monthly eligible wireless (min. 1&lt;sup&gt;st&lt;/sup&gt; line $50; 2&lt;sup&gt;nd&lt;/sup&gt; line $20) and DIRECTV service (min. $29.99/mo.)'
                    ],
                    'jcr:primaryType': [
                        'cq:PageContent'
                    ],
                    'jcr:isCheckedOut': [
                        'true'
                    ],
                    'cq:template': [
                        '/apps/att/wireless/templates/sharedcontent/devices/warrantyinfo'
                    ],
                    'cq:lastModifiedBy': [
                        'ss445y'
                    ],
                    'pageTitle': [
                        'Get a Samsung Galaxy S8 for FREE*'
                    ],
                    'jcr:predecessors': [
                        '3c53fe74-fe2a-4072-b24a-ce8c9347f7d0'
                    ],
                    'headline': [
                        '&lt;strong&gt;Get a Samsung Galaxy S8 for FREE*&lt;/strong&gt;'
                    ],
                    'jcr:createdBy': [
                        'admin'
                    ],
                    'jcr:versionHistory': [
                        '   e3123674-0f04-4fe6-958b-e60d6eaa0055'
                    ],
                    'cq:lastModified': [
                        '2017-05-22T11:45:44.420-07:00'
                    ],
                    'commonLegalFooter': [
                        '/content/sharedcontent/en/legal/commonLegalFooter/commonLegalFooter'
                    ]
                }
            }
        }
    };

})();