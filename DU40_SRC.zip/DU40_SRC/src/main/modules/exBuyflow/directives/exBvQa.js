(function () {
    'use strict';

    angular.module('exBuyflow')

        .directive('exBvQa', ['$window', 'exCommonConstants', '$rootScope', function ($window, exCommonConstants, $rootScope) {
            return {
                restrict: 'E',
                templateUrl: function (ele, attr) {
                    return attr.templateName ? attr.templateName : '/templates/exbvqa.html';
                },
                link: function (scope) {
                    scope.$on(exCommonConstants.event.BVSkuSelected, function (event, data) {
                        $window.require(['bazaar-voice'], function () {
                            if ($window.$BV !== 'undefined') {
                                $window.$BV.ui('qa', 'show_questions', {
                                    subjectType: 'product',
                                    productId: data.skuId
                                });
                            }
                        });

                    });
                    $rootScope.$broadcast(exCommonConstants.event.BVInitiated, null);
                }
            };
        }]);
})();
