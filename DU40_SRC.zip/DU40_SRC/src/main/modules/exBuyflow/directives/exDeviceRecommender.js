(function () {
    'use strict';

    angular.module('exBuyflow')

        .directive('exDeviceRecommender', [function () {
            return {
                restrict: 'A',
                templateUrl: function (ele, attr) {
                    return attr.templateName ? attr.templateName : '/templates/exdevicerecommender.html';
                },
                scope: {
                    initialDevicesLoaded: '@',
                    heroConfidenceThreshold: '@',
                    displayHeroDevice: '@'
                },
                controller: 'deviceRecommenderCtrl'
            };
        }]);
})();
