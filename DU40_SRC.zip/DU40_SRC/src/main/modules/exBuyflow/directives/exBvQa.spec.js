(function () {
    'use strict';

    define(['exBvQa'], function () {
        describe('src/main/modules/exBuyflow/directives/exBvQa.spec.js', function () {
            describe('exBvQa directive of exBuyflow', function () {
                var mockWindow, element, scope, $rootScope, $compile, exCommonConstants;
                beforeEach(function () {
                    mockWindow = {
                        require: jasmine.createSpy('require'),
                        $BV: jasmine.createSpyObj('$BV', ['ui'])
                    };
                    mockWindow.require.and.callFake(function (key, func) { func(); });

                    module('exBuyflow', {
                        $window: mockWindow
                    });

                    inject(function ($injector) {
                        exCommonConstants = $injector.get('exCommonConstants');
                        $rootScope = $injector.get('$rootScope');
                        $compile = $injector.get('$compile');
                    });
                    expect(mockWindow.require).not.toHaveBeenCalled();
                    expect(mockWindow.$BV.ui).not.toHaveBeenCalled();

                    var html = '<ex-bv-qa>' +
                                '</ex-bv-qa>';

                    element = angular.element(html);
                    scope = $rootScope.$new();
                    $compile(element)(scope);
                    scope.$apply();
                    scope = element.isolateScope() || element.scope();
                });

                afterEach(function () {
                    mockWindow.require.calls.reset();
                    mockWindow.$BV.ui.calls.reset();

                });

                describe('general functionality', function () {
                    it('should check if the require script has been called from the window', function () {
                        var data = {
                            devicePageURL: '/content/att/cellphones/iphone/apple-iphone-7/',
                            skuId: 'sku8040302'
                        };

                        $rootScope.$broadcast(exCommonConstants.event.BVSkuSelected, data);
                        expect(mockWindow.require).toHaveBeenCalledWith(['bazaar-voice'], jasmine.any(Function));
                    });
                    it('sshould check if the Bazaar Voice script has been called from the window', function () {
                        var data = {
                            devicePageURL: '/content/att/cellphones/iphone/apple-iphone-7/',
                            skuId: 'sku8040302'
                        };

                        $rootScope.$broadcast(exCommonConstants.event.BVSkuSelected, data);
                        expect(mockWindow.$BV.ui).toHaveBeenCalledWith('qa', 'show_questions', {
                            subjectType: 'product',
                            productId: data.skuId
                        });

                    });

                });
            });
        });
    });
})();
