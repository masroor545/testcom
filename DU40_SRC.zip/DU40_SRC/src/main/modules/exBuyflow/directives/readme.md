# exBuyflow Directives

### <a name='exDdeviceRecommender'></a> `exDeviceRecommender`

##### Description:
This directive serves the purpose show device recommender page.

##### Usage:

```html
<exDeviceRecommender templateName="/templates/exDeviceRecommender.html">
</exDeviceRecommender>
```

##### Attributes:
* ```templateName``` (optional) - /templates/exDeviceRecommender.html
* ```initialDevicesLoaded: Number``` - number of devices to display on page load
* ```heroConfidenceThreshold: Number``` - confidence threshold for hero device recommendation
* ```displayHeroDevice: Boolean``` - flag to initially display hero device maximized

##### Requirements:
* Loads the device recommender page
* Initially X devices are loaded, first device being the hero device(depending on the configuration of hero device's display flag).
* Filter displayed devices based on user's selected options

---
---

### <a name='exAccessoryRecommender'></a> `exAccessoryRecommender`

##### Description:
This directive serves the purpose show accessory recommender page.

##### Usage:

```html
<exAccessoryRecommender templateName="/templates/exaccessoryrecommender.html">
</exAccessoryRecommender>
```

##### Attributes:
* ```templateName``` (optional) - /templates/exaccessoryrecommender.html
* ```initialAccessoriesLoaded: Number``` - number of accessories to display on page load
* ```accessoryCategories: Array<String>``` - Array of categories that we want recommendations for. Ex: ['cases', 'screen-protectors']
* ```relaxStoreIndicator: Boolean``` - StoreId to be considered while recommending accessories from REX API or not.

##### Requirements:
* Loads the accessory recommender page
* Initially X accessories are loaded
---
---

### <a name='exProtectionPlan'></a> `exProtectionPlan`

##### Description:
This directive serves the purpose show protection plan on accessory hub page.

##### Usage:

```html
<exProtectionPlan templateName="/templates/exprotectionplan.html">
</exProtectionPlan>
```

##### Attributes:
* ```templateName``` (optional) - /templates/exprotectionplan.html

##### Requirements:
* Loads the protection plan on accessory hub page
* It will be shown if user has not insurance on their current device

---
---

### <a name='exProtectionPlan'></a> `exBvReviews`

##### Description:
This directive serves the purpose show bazaar voice Reviews on the details pages.
Loads the bv script from requrire on window load
It shows the bv review ratings for the selected device

##### Usage:

```html
<exProtectionPlan templateName="/templates/exbvreviews.html">
</exProtectionPlan>
```


##### Requirements:
* Depends on the "bazaar-voice" script being fired by $window.require when directive is called
* Depends on a broadcast (BVSkuSelected) set from the device details service once renderend will send out skuid to us.

---
---

### <a name='exProtectionPlan'></a> `exBvQa`

##### Description:
This directive serves the purpose show bazaar voice QA on the details pages.
Loads the bv script from requrire on window load
It shows the bv QA for the selected device

##### Usage:

```html
<exProtectionPlan templateName="/templates/exbvqa.html">
</exProtectionPlan>
```


##### Requirements:
* Depends on the "bazaar-voice" script being fired by $window.require when directive is called
* Depends on a broadcast (BVSkuSelected) set from the device details service once renderend will send out skuid to us.

---
---

### <a name='upsellOffer'></a> `upsellOffer`

##### Description:
This directive serves the purpose show offer legal content details on the upsell offer page. The template defaults to /templates/upselloffer.html

##### Usage:

```html
<div upsell-offer template-name="/templates/upselloffer.html"></div>
or
<div upsell-offer></div>
```

##### Requirements:
* displays upsell offer legal content details
* displays an upsell offer add to cart button

---
---

### <a name='exDeviceLegalDetails'></a> `exDeviceLegalDetails`

##### Description:
Display the long legal content. The template defaults to /templates/exdevicelegaldetails.html

##### Usage:

```html
<exDeviceLegalDetails templateName="/templates/exdevicelegaldetails.html">
</exDeviceLegalDetails>
```
##### Attributes:
* ```templateName``` (optional) - /templates/exdevicelegaldetails.html

##### Requirements:
* Display the long legal content for the selected sku on device legal overlay.
---
---

### <a name='exProtectionPlanDetails'></a> `exProtectionPlanDetails`

##### Description:
This directive serves the purpose to show protection plan details overlay to user.

##### Usage:

```html
<exProtectionPlanDetails templateName="/templates/exprotectionplandetails.html">
</exProtectionPlanDetails>
```
##### Attributes:
* ```templateName``` (optional) - /templates/exprotectionplandetails.html

##### Requirements:
* Open the protection plan details overlay when user click on add to cart. 
* Display the protection plan legal content on overlay.

---
---
### <a name='exAccessorySubtotalTooltip'></a> `exAccessorySubtotalTooltip`

##### Description:
This directive serves the purpose to show subtotal tool tip overlay to user.

##### Usage:

```html
<exAccessorySubtotalTooltip templateName="/templates/exaccessorysubtotaltooltip.html">
</exAccessorySubtotalTooltip>
```
##### Attributes:
* ```templateName``` (optional) - /templates/exaccessorysubtotaltooltip.html

##### Requirements:
* Open the subtotal tool tip overlay when user click on tool tip for subtotal. 
* User should be on accesories and protection hub page.

---
---

### <a name='exDeviceConfigHylaPromoDetails'></a> `exDeviceConfigHylaPromoDetails`

##### Description:
This directive serves the purpose to show hyla promotion details overlay to user.

##### Usage:

```html
<exDeviceConfigHylaPromoDetails templateName="/templates/exdeviceconfighylapromodetails.html">
</exDeviceConfigHylaPromoDetails>
```
##### Attributes:
* ```templateName``` (optional) - /templates/exdeviceconfighylapromodetails.html

##### Requirements:
* Open the hyla promotion details overlay when user click hyla promotion hyperlink on device config page. 
* Display the hyla promotion details content on overlay.

---
---