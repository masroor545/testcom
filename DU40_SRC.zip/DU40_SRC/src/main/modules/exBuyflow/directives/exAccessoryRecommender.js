(function () {
    'use strict';

    angular.module('exBuyflow')

        .directive('exAccessoryRecommender', [function () {
            return {
                restrict: 'A',
                templateUrl: function (ele, attr) {
                    return attr.templateName ? attr.templateName : '/templates/exaccessoryrecommender.html';
                },
                scope: {
                    initialAccessoriesLoaded: '@',
                    defaultInsuranceBillCode: '@',
                    accessoryCategories: '@',
                    subTitle: '@',
                    relaxStoreIndicator: '@',
                    subTitleNoAccessory: '@'
                },
                controller: 'accessoryRecommenderCtrl'
            };
        }]);
})();
