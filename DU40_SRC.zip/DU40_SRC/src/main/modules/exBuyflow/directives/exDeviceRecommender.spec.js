(function () {
    'use strict';

    define(['exDeviceRecommender'], function () {
        describe('src/main/modules/exBuyflow/directives/exDeviceRecommender.spec.js', function () {
            describe('exDeviceRecommender directive of exBuyflow', function () {
                var element, scope, $rootScope, $compile, $httpBackend;


                beforeEach(function () {
                    module('exBuyflow', function ($provide, $controllerProvider, $compileProvider) {
                        $controllerProvider.register('deviceRecommenderCtrl', function ($scope) {
                            $scope.selectSku = function () { $scope.deviceRecommender.showDeviceConfig = true; };
                            $scope.showDeviceLegalDetailsOverlay = function () { };
                            $scope.filterItems = function () { };
                            $scope.clearFilterSelections = function () { };
                            $scope.toggleFilter = function () { };
                            $scope.deviceRecommender = {
                                showDeviceConfig: false,
                                devicesToBeDisplayed: 2,
                                items: [
                                    {
                                        skuId: 'sku12345',
                                        brand: 'Apple',
                                        model: 'iPhone 7',
                                        starRatings: 4.2,
                                        numOfStarReviews: 113
                                    },
                                    {
                                        skuId: 'sku232456',
                                        brand: 'Apple',
                                        model: 'iPhone 7',
                                        starRatings: 4.2,
                                        numOfStarReviews: 113
                                    }
                                ],
                                displayedItems: [
                                    {
                                        skuId: 'sku12345',
                                        brand: 'Apple',
                                        model: 'iPhone 7',
                                        starRatings: 4.2,
                                        numOfStarReviews: 113
                                    },
                                    {
                                        skuId: 'sku232456',
                                        brand: 'Apple',
                                        model: 'iPhone 7',
                                        starRatings: 4.2,
                                        numOfStarReviews: 113
                                    }
                                ],
                                displayedTotalItems: [
                                    {
                                        skuId: 'sku12345',
                                        brand: 'Apple',
                                        model: 'iPhone 7',
                                        starRatings: 4.2,
                                        numOfStarReviews: 113
                                    },
                                    {
                                        skuId: 'sku232456',
                                        brand: 'Apple',
                                        model: 'iPhone 7',
                                        starRatings: 4.2,
                                        numOfStarReviews: 113
                                    }
                                ],
                                filteredItems: [
                                    {
                                        skuId: 'sku12345',
                                        brand: 'Apple',
                                        model: 'iPhone 7',
                                        starRatings: 4.2,
                                        numOfStarReviews: 113
                                    },
                                    {
                                        skuId: 'sku232456',
                                        brand: 'Apple',
                                        model: 'iPhone 7',
                                        starRatings: 4.2,
                                        numOfStarReviews: 113
                                    }
                                ],
                                filterOptions: [
                                    {
                                        values: [
                                            {
                                                value: 'Apple',
                                                isSelected: false
                                            },
                                            {
                                                value: 'Samsung',
                                                isSelected: true
                                            }
                                        ]
                                    }
                                ],
                                itemPrice: [
                                    {
                                        defaultPrice: 699.99
                                    },
                                    {
                                        defaultPrice: 688.88
                                    }
                                ]
                            };
                        });

                        $controllerProvider.register('deviceConfigCtrl', function () {
                        });

                        $compileProvider.directive('exBvReviews', function () {
                            var def = {
                                priority: 10000,
                                terminal: true,
                                restrict: 'E',
                                link: function () {
                                    // do nothing
                                }
                            };
                            return def;
                        });

                        $compileProvider.directive('exBvQa', function () {
                            var def = {
                                priority: 10000,
                                terminal: true,
                                restrict: 'E',
                                link: function () {
                                    // do nothing
                                }
                            };
                            return def;
                        });
                    });

                    inject(function ($injector) {
                        $rootScope = $injector.get('$rootScope');
                        $httpBackend = $injector.get('$httpBackend');
                        $compile = $injector.get('$compile');
                    });

                    // Catches all backend calls because we have directives that make calls we don't care about
                    $httpBackend.whenGET('').respond(200, '');

                    var directive = '<div' +
                        ' ex-device-recommender initial-devices-loaded="6"' +
                        ' template-name="/templates/exdevicerecommender.html"' +
                        ' hero-confidence-threshold="0.8"' +
                        ' display-hero-device="true"' +
                        '></div>';

                    element = angular.element(directive);
                    scope = $rootScope.$new();
                    $compile(element)(scope);
                    scope.$apply();
                    scope = element.isolateScope() || element.scope();
                });

                describe('exdevicerecommender template of exBuyflow', function () {
                    it('should bind its attributes to the scope', function () {
                        expect(scope.initialDevicesLoaded).toBeDefined();
                        expect(scope.initialDevicesLoaded).toEqual('6');
                        expect(scope.heroConfidenceThreshold).toBeDefined();
                        expect(scope.heroConfidenceThreshold).toEqual('0.8');
                        expect(scope.displayHeroDevice).toBeDefined();
                        expect(scope.displayHeroDevice).toEqual('true');
                    });

                    describe('initialDevicesLoaded functionality of deviceRecommender directive', function () {
                        it('should pass the initialDevicesLoaded from template to deviceRecommenderCtrl', function () {
                            expect(scope).toBeDefined();
                            expect(scope.initialDevicesLoaded).toBeDefined();
                        });
                    });

                    describe('device tile', function () {
                        it('should display the device config when clicked', function () {
                            spyOn(scope, 'selectSku');
                            element.find('.device-grid')[0].click();
                            expect(scope.selectSku).toHaveBeenCalledWith(scope.deviceRecommender.items[0].skuId, 0);
                        });
                    });

                    describe('device tile long legal link click', function () {
                        it('should display the long legal overlay when clicked', function () {
                            spyOn(scope, 'showDeviceLegalDetailsOverlay');
                            element.find('.shortLegalContainer>a')[0].click();
                            expect(scope.showDeviceLegalDetailsOverlay).toHaveBeenCalledWith(scope.deviceRecommender.items[0].skuId);
                        });
                    });

                    describe('show more', function () {
                        it('should be visible when there are more devices to show', function () {
                            var showMore = element.find('.btn.btn-primary-functional.align-middle')[0];
                            expect(scope.deviceRecommender.displayedItems.length).toEqual(scope.deviceRecommender.displayedTotalItems.length);
                            expect(scope.deviceRecommender.displayedTotalItems.length).toBeLessThanOrEqual(scope.deviceRecommender.devicesToBeDisplayed);
                            expect(showMore.getAttribute('class')).toContain('ng-hide');

                            scope.deviceRecommender.devicesToBeDisplayed = 1;
                            scope.$digest();
                            expect(scope.deviceRecommender.displayedItems.length).toEqual(scope.deviceRecommender.displayedTotalItems.length);
                            expect(scope.deviceRecommender.displayedTotalItems.length).toBeGreaterThan(scope.deviceRecommender.devicesToBeDisplayed);
                            expect(showMore.getAttribute('class')).not.toContain('ng-hide');

                            scope.deviceRecommender.devicesToBeDisplayed = 2;
                            scope.deviceRecommender.displayedItems = scope.deviceRecommender.displayedItems.slice(0, 1);
                            scope.$digest();
                            expect(scope.deviceRecommender.displayedItems.length).not.toEqual(scope.deviceRecommender.displayedTotalItems.length);
                            expect(scope.deviceRecommender.displayedTotalItems.length).toBeLessThanOrEqual(scope.deviceRecommender.devicesToBeDisplayed);
                            expect(showMore.getAttribute('class')).not.toContain('ng-hide');

                            scope.deviceRecommender.displayedTotalItems.push('nothing important');
                            scope.$digest();
                            expect(scope.deviceRecommender.displayedItems.length).not.toEqual(scope.deviceRecommender.displayedTotalItems.length);
                            expect(scope.deviceRecommender.displayedTotalItems.length).toBeGreaterThan(scope.deviceRecommender.devicesToBeDisplayed);
                            expect(showMore.getAttribute('class')).not.toContain('ng-hide');
                        });
                    });

                    describe('device filter', function () {
                        it('should contain the criteria for all recommended devices', function () {
                            scope.$digest();
                            var filter = element.find('.device-filter')[0];
                            scope.deviceRecommender.filterOptions.forEach(function (criterion) {
                                criterion.values.forEach(function (value) {
                                    expect(filter.innerHTML).toContain(value.value);
                                });
                            });
                        });

                        it('should expand/collapse when dropdown is clicked', function () {
                            var filterHeader = element.find('.device-filter-header')[0];
                            spyOn(scope, 'toggleFilter');
                            expect(scope.toggleFilter).not.toHaveBeenCalled();
                            filterHeader.click();
                            expect(scope.toggleFilter).toHaveBeenCalled();
                        });

                        it('should toggle values when selected', function () {
                            var filterOption = element.find('.device-filter-option')[0];
                            spyOn(scope, 'filterItems');
                            expect(scope.deviceRecommender.filterOptions[0].values[0].isSelected).toEqual(false);
                            filterOption.children[1].click();
                            expect(scope.deviceRecommender.filterOptions[0].values[0].isSelected).toEqual(true);
                            expect(scope.filterItems).toHaveBeenCalled();
                        });

                        it('should clear all selections when clear filters is clicked', function () {
                            spyOn(scope, 'clearFilterSelections');
                            expect(scope.clearFilterSelections).not.toHaveBeenCalled();
                            var filterClear = element.find('.device-filter-clear')[0];
                            filterClear.click();
                            expect(scope.clearFilterSelections).toHaveBeenCalled();
                        });

                    });

                });

            });
        });
    });
})();
