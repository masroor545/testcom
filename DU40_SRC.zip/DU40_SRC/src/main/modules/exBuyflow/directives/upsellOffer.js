(function () {
    'use strict';

    angular.module('exBuyflow')

        .directive('upsellOffer', [function () {
            return {
                restrict: 'EA',
                templateUrl: function (ele, attr) {
                    return attr.templateName ? attr.templateName : '/templates/upselloffer.html';
                },
                controller: 'upsellOfferCtrl',
                scope: {
                    deviceImage: '@'
                }
            };
        }]);
})();
