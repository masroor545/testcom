(function () {
    'use strict';

    angular.module('exBuyflow')

        .directive('exDeviceLegalDetails', [function () {
            return {
                restrict: 'E',
                templateUrl: function (ele, attr) {
                    return attr.templateName ? attr.templateName : '/templates/exdevicelegaldetails.html';
                },
                controller: 'deviceLegalDetailCtrl'
            };
        }]);
})();
