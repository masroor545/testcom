(function () {
    'use strict';

    angular.module('exBuyflow')

        .directive('exBvReviews', ['$window', 'exCommonConstants', '$rootScope', function ($window, exCommonConstants, $rootScope) {
            return {
                restrict: 'E',
                templateUrl: function (ele, attr) {
                    return attr.templateName ? attr.templateName : '/templates/exbvreviews.html';
                },
                link: function (scope) {
                    scope.$on(exCommonConstants.event.BVSkuSelected, function (event, data) {
                        $window.require(['bazaar-voice'], function () {
                            if ($window.$BV !== 'undefined') {
                                $window.$BV.ui('rr', 'show_reviews', {
                                    productId: data.skuId
                                });
                            }
                        });

                    });
                    $rootScope.$broadcast(exCommonConstants.event.BVInitiated, null);
                }
            };
        }]);
})();
