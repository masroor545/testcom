(function () {
    'use strict';

    angular.module('exBuyflow')

        .directive('exAccessorySubtotalTooltip', [function () {
            return {
                restrict: 'EA',
                templateUrl: function (ele, attr) {
                    return attr.templateName ? attr.templateName : '/templates/exaccessorysubtotaltooltip.html';
                },
                controller: 'accessorySubtotalTooltipCtrl'
            };
        }]);
})();