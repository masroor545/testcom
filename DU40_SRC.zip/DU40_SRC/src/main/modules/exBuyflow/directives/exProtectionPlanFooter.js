(function () {
    'use strict';

    angular.module('exBuyflow')

        .directive('exProtectionPlanFooter', [function () {
            return {
                restrict: 'EA',
                templateUrl: function (ele, attr) {
                    return attr.templateName ? attr.templateName : '/templates/exprotectionplanfooter.html';
                },
                controller: 'protectionPlanDetailsCtrl'
            };
        }]);
})();