(function () {
    'use strict';

    define(['exDeviceLegalDetails'], function () {
        describe('src/main/modules/exBuyflow/directives/exDeviceLegalDetails.spec.js', function () {
            describe('exDeviceLegalDetails directive of exBuyflow', function () {
                var element, scope, $rootScope, $compile, $sce;

                beforeEach(function () {
                    module('exBuyflow', function ($controllerProvider) {
                        $controllerProvider.register('deviceLegalDetailCtrl', function () {
                        });
                    });

                    inject(function ($injector) {
                        $rootScope = $injector.get('$rootScope');
                        $compile = $injector.get('$compile');
                        $sce = $injector.get('$sce');
                    });

                    var html = '<ex-device-legal-details>' +
                                '</ex-device-legal-details>';

                    element = angular.element(html);
                    scope = $rootScope.$new();
                    scope.deviceLegalDetail = {};
                    scope.deviceLegalDetail.longLegalContent = [$sce.trustAsHtml('2016 Apple Inc. All rights reserved'), $sce.trustAsHtml('LTE is a trademark of ETSI')];
                    scope.$dismiss = function () {
                        return true;
                    };
                    $compile(element)(scope);
                    scope.$apply();
                    scope = element.isolateScope() || element.scope();
                });

                describe('exdevicelegaldetails template of exBuyflow', function () {
                    it('should display information about the legal content', function () {
                        angular.forEach(scope.deviceLegalDetail.longLegalContent, function (longLegal) {
                            expect(element.html()).toContain(longLegal);
                        });
                    });

                    it('should have a control to close it when clicked from full width button', function () {
                        spyOn(scope, '$dismiss');
                        element.find('.device-legal-footer button').click();
                        expect(scope.$dismiss).toHaveBeenCalledWith('cancel');
                    });

                    it('should have a control to close it when clicked from close button', function () {
                        spyOn(scope, '$dismiss');
                        element.find('.legal-close-btn').click();
                        expect(scope.$dismiss).toHaveBeenCalledWith('cancel');
                    });
                });
            });
        });
    });
})();