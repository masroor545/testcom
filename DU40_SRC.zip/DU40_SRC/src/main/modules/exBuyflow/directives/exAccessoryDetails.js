(function () {
    'use strict';

    angular.module('exBuyflow')

        .directive('exAccessoryDetails', [function () {
            return {
                restrict: 'E',
                templateUrl: function (ele, attr) {
                    return attr.templateName ? attr.templateName : '/templates/exaccessorydetails.html';
                },
                controller: 'accessoryDetailsCtrl'
            };
        }]);
})();
