(function () {
    'use strict';

    define(['upsellOffer'], function () {
        describe('src/main/modules/exBuyflow/directives/upsellOffer.spec.js', function () {
            describe('upsellOffer directive of exBuyflow', function () {
                var element, scope, $rootScope, $compile;
                beforeEach(function () {
                    module('exBuyflow', function ($provide, $controllerProvider) {
                        $controllerProvider.register('upsellOfferCtrl', function ($scope) {
                            $scope.upsellOfferDetails = {
                                'upsellSubtotalDetails': {
                                    'offerCartTotalAmount': 0,
                                    'offerCartMonthlyAmount': 0
                                },
                                'offerSubheadLine': 'Buy a Samsung Galaxy S8, and get one free',
                                'offerInBodyContent': 'Free after $750 in credits over 30 months. Credits start in 2 to 3 bills.'
                            };

                            $scope.upsellOfferAddItemToCart = function () { return true; };
                            $scope.multiSkuUpsellOffer = function () { return true; };
                            $scope.onSkipToCheckout = function () { return true; };

                        });
                    });
                    inject(function ($injector) {
                        $rootScope = $injector.get('$rootScope');
                        $compile = $injector.get('$compile');
                    });
                    var html = '<upsell-offer' +
                                '</upsell-offer>';

                    element = angular.element(html);
                    scope = $rootScope.$new();
                    $compile(element)(scope);
                    scope.$apply();
                    scope = element.isolateScope() || element.scope();
                });

                describe('upsell offer template of exBuyflow', function () {
                    it('should display subtotal details', function () {
                        expect(element.html()).toContain(scope.upsellOfferDetails.offerHeadLine);
                        expect(element.html()).toContain(scope.upsellOfferDetails.offerSubheadLine);
                        expect(element.html()).toContain(scope.upsellOfferDetails.offerInBodyContent);
                        expect(element.html()).toContain(scope.upsellOfferDetails.upsellSubtotalDetails.offerCartTotalAmount);
                        expect(element.html()).toContain(scope.upsellOfferDetails.upsellSubtotalDetails.offerCartMonthlyAmount);
                    });

                    it('should have a button to add to cart', function () {
                        if (scope.upsellOfferDetails.isMultiSkuOffer === false) {
                            spyOn(scope, 'upsellOfferAddItemToCart');
                            element.find('.upsell-add-to-cart')[0].click();
                            expect(scope.upsellOfferAddItemToCart).toHaveBeenCalled();
                        }
                    });

                    it('should have a button to get this offer', function () {
                        if (scope.upsellOfferDetails.isMultiSkuOffer === true) {
                            spyOn(scope, 'multiSkuUpsellOffer');
                            element.find('.upsell-add-to-cart')[0].click();
                            expect(scope.multiSkuUpsellOffer).toHaveBeenCalled();
                        }
                    });

                    it('should have No Thanks button', function () {
                        spyOn(scope, 'onSkipToCheckout');
                        element.find('.upsell-no-thanks')[0].click();
                        expect(scope.onSkipToCheckout).toHaveBeenCalled();
                    });
                });
            });
        });
    });
})();

