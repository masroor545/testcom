(function () {
    'use strict';

    define(['exAccessoryRecommender'], function () {
        describe('src/main/modules/exBuyflow/directives/exAccessoryRecommender.spec.js', function () {
            describe('exAccessoryRecommender directive of exBuyflow', function () {
                var templateAsHtml, $scope, $rootScope, $compile, template, directive;

                beforeEach(function () {
                    module('exBuyflow', function ($provide, $controllerProvider) {
                        $controllerProvider.register('accessoryRecommenderCtrl', function ($scope) {
                            $scope.onProceedToCheckout = function () { return true; };
                            $scope.selectAccessory = function () { return true; };
                            $scope.accessoryAddToCart = function () { return true; };
                            $scope.accessoryRecommenderDetail = [{
                                skuId: 'sku1234567'
                            }];
                        });
                        $controllerProvider.register('accessoryConfigCtrl', function () {
                        });
                        $controllerProvider.register('deviceCardCtrl', function () {
                        });
                    });

                    inject(function ($injector) {
                        $rootScope = $injector.get('$rootScope');
                        $compile = $injector.get('$compile');
                    });

                    var directive = '<div ex-accessory-recommender initial-accessories-loaded=3 ' +
                    'default-insurance-bill-code="WPINS"' +
                    'accessory-categories=["cases","screen-protectors","charge-sync-cables","audio"] ' +
                    'sub-title="Your new {0} deserves a little something extra."' +
                    'relax-store-indicator="true" ' +
                    'sub-title-no-accessory="Heres one way to keep your new {0} safe" ' +
                    'data-qa="accessoryRecommender-AccessoryRecommender"></div>';

                    $scope = $rootScope.$new();
                    //$compile the template, and pass in the $scope. This will find your directive and run everything
                    template = $compile(directive)($scope);
                    //Now run a $digest cycle to update your template with new data
                    $scope.$digest();
                    //Render the template as a string
                    templateAsHtml = template.html();
                    $scope = template.isolateScope() || template.scope();
                });

                it('should have the scope of the controller', function () {
                    expect($scope).toBeDefined();
                });

                it('should bind its attributes to the scope', function () {
                    expect($scope.initialAccessoriesLoaded).toBeDefined();
                    expect($scope.defaultInsuranceBillCode).toBeDefined();
                    expect($scope.accessoryCategories).toBeDefined();
                    expect($scope.subTitle).toBeDefined();
                    expect($scope.relaxStoreIndicator).toBeDefined();
                    expect($scope.subTitleNoAccessory).toBeDefined();
                });

                it('should render the accessory recommender static page', function () {
                    //Verify that the content are in the template ngRepeat: (key, accessoryDetails) in accessoryRecommenderDetail
                    expect(templateAsHtml).toContain('ngRepeat: (key, accessoryDetails) in accessoryRecommenderDetail');
                    expect(templateAsHtml).toContain('Checkout');
                    expect(templateAsHtml).toContain('Details');
                    expect(templateAsHtml).not.toContain('Pre-order');
                });

                it('should have a button to proceed to checkout', function () {
                    spyOn($scope, 'onProceedToCheckout');
                    template.find('.accessory-proceed-to-checkout')[0].click();
                    expect($scope.onProceedToCheckout).toHaveBeenCalled();
                });

                it('should have a button to open the accessory config', function () {
                    spyOn($scope, 'selectAccessory');
                    template.find('.see-details').click();
                    expect($scope.selectAccessory).toHaveBeenCalledWith('sku1234567');
                });

                it('should call the ATC service only once, even if user clicks multiple times', function () {
                    var updatedTemplate, atcButton;
                    //button's visibility before first click event
                    expect(template.find('.btn-primary-functional.accessory-add-to-cart').length).toEqual(1);
                    spyOn($scope, 'accessoryAddToCart');
                    atcButton = template.find('.btn-primary-functional.accessory-add-to-cart')[0];
                    atcButton.click();
                    $scope.$digest();
                    updatedTemplate = $compile(directive)($scope);
                    //checking the updatedTemplate that the button is hidden from the page after first button click,
                    //if not visible then multiple click is not possible.
                    expect(updatedTemplate.find('.btn-primary-functional.accessory-add-to-cart').length).toEqual(0);
                });

            });
        });
    });
})();
