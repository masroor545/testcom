(function () {
    'use strict';
    angular.module('exBuyflow')
        .constant('exBuyflowConstants', {
            accessoryCategories: [
                'cases',
                'screen-protectors',
                'charge-sync-cables',
                'audio'
            ],
            catalogApi: '/services/shopwireless/model/att/ecom/api/CatalogServiceController/catalogService',
            deviceFilterOptions: [
                {
                    criterion: 'brand',
                    values: []
                }
            ],
            deviceFilterPriority: [
                'Apple',
                'Samsung',
                'LG',
                'AT&T',
                'BlackBerry',
                'Kyocera',
                'Motorola',
                'Sonim'
            ],
            exUpHandOffToCheckoutUrl: '/services/shopwireless/model/att/ecom/api/ExUpHandOffToCheckoutActor/exUpCheckoutHandoffService',
            exUpHandOffUpgradeToContinueUrl: '/services/shopwireless/model/att/ecom/api/WirelessUpgradeSelectionActor/configureNextUpgradeLine',
            friendlyPageName: {
                deviceDetails: 'DS Upgrade Device Details Pg',
                deviceDetailsHero: 'DS Upgrade Hero Device Details Pg',
                accessoryDetails: 'DS Upgrade Protection And Accessories Details Pg',
                accessoryRecommenderDetails: 'DS Upgrade Protection And Accessories Pg',
                multiSkuUpsellOffer: 'DS Upgrade Add A Line Device Details Pg'
            },
            insuranceCategories: {
                sku5370279: 'label.md5hdr.mpp',
                sku7250407: 'label.md5hdr.mdpp',
                sku1040075: 'label.md5hdr.mi'
            },
            legalContentKeyPrefix: 'tos.sku.',
            legalSubtotalToolTipContentKey: 'label.exup.subtotal.description',
            linkName: {
                chooseOptions: 'Choose your options',
                longLegalLink: 'See price details',
                skipUpsellOffer: 'No, thanks'
            },
            linkPosition: 'Body',
            rexBySkuRecommenderApi: '/rex/recommendation/rexBySku/',
            rexServiceTimeout: 7000,
            showPdpContent: true,
            upsellOfferApi: '/services/shopwireless/model/att/ecom/api/UpsellServiceController/upsellService',
            virtualUrl: {
                accessoryDetails: '/shop/xpress/virtual/protection-accessory-details.html',
                accessoryRecommenderDetails: '/shop/xpress/accessory-service-recommender.html',
                deviceDetails: '/shop/xpress/virtual/device-details.html',
                deviceDetailsHero: '/shop/xpress/virtual/device-details.html+HeroDevice',
                deviceRecommenderDetailsUrl: '/shop/xpress/device-recommender.html',
                multiSkuUpsellOffer: '/shop/xpress/virtual/device-details.html+AddALineOffer',
                onePageCheckout: '/checkout/onepagecheckout.html'
            }
        });
})();
