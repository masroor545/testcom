# exBuyflow Services

### <a name='deviceRecommenderSrv'></a> `deviceRecommenderSrv`

##### Description:
This service serves the purpose of getting the recommended devices from the REX API, also gets their respective prices.

##### Functions:

---
##### ```getRecommendedDevices(upgradingDeviceDetails:object) : Promise```

It makes a call to get recommended devices from REX API.

**Parameters:**
* upgradingDeviceDetails (required) - The upgrading user/device details information

**Returns:**
It returns data for recommended devices for the user based on their current device which they want to upgrade.

```javascript
deviceRecommenderSrv.getRecommendedDevices(upgradingDeviceDetails)
    .then(function (data) {
        // do something with said data object
    });
```
---
##### `createParams(upgradingDeviceDetails:object) : object`
Builds and returns the $http params object for a REX request.

##### Parameters:
`upgradingDeviceDetails` Details of the upgrading device

##### Returns:
`{object}` $http param object for a REX request.

```javascript
deviceRecommenderSrv.createParams(upgradingDeviceDetails);
```
---
##### ```getRecommendationsFromCatalog() : Promise```

It makes a call to get recommended devices from Catalog API.

**Returns:**
It returns data for recommended devices for the user from Catalog API as REX API did not had any recommendations for user's current skuid.

```javascript
deviceRecommenderSrv.getRecommendationsFromCatalog()
    .then(function (data) {
        // do something with said data object
    });
```
---
##### ```getItemPriceData( skuIds ) : Promise```

It gets the corresponding prices for each recommended device form catalog API.

**Parameters:**
* *skuids* (required) - skuid of the device whoose price is to be displayed.

**Returns:**
The prices for each requested skuid.

```javascript
deviceRecommenderSrv.getItemPriceData(skuid)
    .then(function (data) {
        // do something with said data object
    });
```
---
##### ```getDeviceDataForReporting(skuItem) : Object```

returns an object with the Items object u sed for reporting 

**Parameters:**
* *skuItem* (required) - skuItem from device recommender service.

**Returns:**
It returns reporting data for the input device for the user from Catalog API as REX API did not had any recommendations for user's current skuid.

```javascript
deviceRecommenderSrv.getDeviceDataForReporting(skuItem);
```
---
---

### <a name='accessoryRecommenderService'></a> `accessoryRecommenderService`

#### Description:
This service allows for access to accessory recommendations returned by the REX recommendations

#### Functions:
##### `getAccessoryRecommendations(deviceSku:string, categories:array, favStoreId:string, RSI:boolean) : Promise`
Makes a request to the accessory recommendations API for the device sku, favStoreId and categories in context and returns a promise. If the promise resolves the result of the request will be returned.

##### Parameters:
* `deviceSku` Device Sku for which we are looking up accessory recommendations. Ex: 'sku1234567'
* `categories` Array of categories that we want recommendations for. Ex: ['cases', 'screen-protectors']
* `favStoreId` User's favStoreId if any. Ex: '311'
* `RSI` Relax StorId Indicator, a boolean flag indicating whether favStoreId is to be considered by REX while fetching the recommendations or not.

##### Returns:
`{promise}` Returns a promise of accessory recommendations results.

```javascript
accessoryRecommenderService.accessoryRecommenderService(deviceSku, categories, favStoreId, RSI).then(function (result) {
    // code that will use the result goes here
});
```
##### `createParams(categories:array, favStoreId:string, RSI:boolean) : object`
Builds and returns the $http params object from the categories array and favStoreId if available.

##### Parameters:
`categories` Array of  categories.
`favStoreId` User's favStoreId if any. Ex: '311'
`RSI` Relax StorId Indicator, a boolean flag indicating whether favStoreId is to be considered by REX while fetching the recommendations or not.

##### Returns:
`{object}` $http param object including the categories and favStoreId if available, formatted for a REX request.

```javascript
accessoryRecommenderService.getParams(categories, favStoreId, RSI);
```
---
---

### <a name='checkoutHandoffService'></a> `checkoutHandoffService`

#### Description:
This service makes a post call to return the re-direct url in the response.

#### Functions:
##### `proceedToCheckOut() : Promise`
Makes post call to get the redirect url in the response.

##### Returns:
`{promise}` It returns the POST response.

```javascript
checkoutHandoffService.proceedToCheckOut().then(function (result) {
    // code that will use the result goes here
});
```
#### Functions:
##### `proceedToContinue() : Promise`
Makes post call to get the redirect url in the response on continue CTA click in multiline flow.

##### Returns:
`{promise}` It returns the POST response.

```javascript
checkoutHandoffService.proceedToContinue().then(function (result) {
    // code that will use the result goes here
});
```
___
___
### <a name='protectionPlanService'></a> `protectionPlanService`

#### Description:
This service allows for access to protection plan recommendations returned by the catalog protection api

#### Functions:
##### `getInsuranceFeatures() : Promise`
Makes a request to the catalog protection recommendations API in context and returns a promise. If the promise resolves the result of the request will be returned.

##### Returns:
`{promise}` Returns a promise of protection recommendations results.

```javascript
protectionPlanService.getInsuranceFeatures().then(function (result) {
    // code that will use the result goes here
});
```
___
___

### <a name='exBuyflowConstants'></a> `exBuyflowConstants`

##### Description:
This service serves the purpose of storing the actual URL's of device recommender REX API, Catalog API, upsell offer API and  handoff to checkout in constant variables.

##### Constants:
* **deviceFilterOptions** - Criteria determined by business that can be filtered by the user.
* **deviceFilterPriority** - Brands listed in order of priority, with the first item being the highest priority item.
* **friendlyPageName**
     - **deviceDetails** - friendly page name of deviceDetails page
     - **deviceDetailsHero** - friendly page name of hero deviceDetails page
     - **accessoryDetails** - friendly page name of accessoryDetails page.
     - **accessoryRecommenderDetails** - friendly page name of accessoryRecommenderDetails page.
* **linkName**
     - **chooseOptions** - text for choose your options link
     - **longLegalLink** - text for see price details link
     - **skipUpsellOffer** - text for no, thanks link
* **linkPosition** - constant for Body text
* **virtualUrl**
     - **accessoryDetails** - url of accessoryDetails page
     - **accessoryRecommenderDetails** - url of accessoryRecommenderDetails page
     - **deviceDetails** - url of deviceDetails page
     - **deviceDetailsHero** - url of hero deviceDetails page
     - **deviceRecommenderDetailsUrl** - url of device Recommender Details page
     - **onePageCheckout** - url of order review page

---
##### ```rexBySkuRecommenderApi```

It has the URL for device recommender REX API.

---
##### ```rexServiceTimeout```

Timeout in milliseconds that we will wait for on a response from the REX API.

---
##### ```catalogApi```

It has the URL for catalog API.

---

##### ```exUpHandOffToCheckoutUrl```

It has the URL for checkout to cart handoff. 

---

##### ```exUpHandOffUpgradeToContinueUrl```

It has the URL to upgrade next device in multiline flow. 

---

##### ```accessoryCategories```

It has the Categories of compatable accessories that are to be retrieved from API. 
=======
##### ```legalContentKeyPrefix```

It prefix key value required for legal content on protection plan detail page. 

---
##### ```insuranceCategories.sku5370279```

It is map value used for legal header for MPP content on protection plan detail page.. 

---
##### ```insuranceCategories.sku7250407```

It is map value used for legal header for MDPP content on protection plan detail page.. 

---
##### ```insuranceCategories.sku1040075```

It is map value used for legal header for MI content on protection plan detail page.. 

---
=======
##### ```legalSubtotalToolTipContentKey```

It is legal key required for legal content on accessory hub page. 
