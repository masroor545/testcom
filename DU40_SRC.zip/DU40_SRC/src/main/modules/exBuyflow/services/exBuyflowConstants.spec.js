(function () {
    'use strict';

    define(['exBuyflowConstants'], function () {
        describe('src/main/modules/exBuyflow/services/exBuyflowConstants.spec.js', function () {
            var service;

            beforeEach(module('exBuyflow'));

            beforeEach(function () {
                inject(function ($injector) {
                    service = $injector.get('exBuyflowConstants');
                });
            });

            it('Should check the constant values to be defined', function () {
                expect(service.exUpHandOffToCheckoutUrl).toBeDefined();
                expect(service.rexBySkuRecommenderApi).toBeDefined();
                expect(service.rexServiceTimeout).toBeDefined();
                expect(service.deviceFilterOptions).toBeDefined();
                expect(service.deviceFilterPriority).toBeDefined();
                expect(Array.isArray(service.deviceFilterPriority)).toEqual(true);
                expect(service.showPdpContent).toBeDefined();
                expect(service.accessoryCategories).toBeDefined();
                expect(service.friendlyPageName).toBeDefined();
                expect(service.virtualUrl).toBeDefined();
                expect(service.exUpHandOffUpgradeToContinueUrl).toBeDefined();
                expect(service.linkName).toBeDefined();
                expect(service.linkPosition).toBeDefined();
            });

            describe('Device selection criteria', function () {
                it('should be an array of objects', function () {
                    expect(Array.isArray(service.deviceFilterOptions)).toEqual(true);
                    service.deviceFilterOptions.forEach(function (item) {
                        expect(item.criterion).toBeDefined();
                        expect(typeof item.criterion).toEqual('string');
                        expect(item.values).toBeDefined();
                        expect(Array.isArray(item.values)).toEqual(true);
                    });
                });
            });
        });
    });
})();
