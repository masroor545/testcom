(function () {
    'use strict';

    define(['deviceRecommenderSrv'], function () {
        describe('src/main/modules/exBuyflow/services/deviceRecommenderSrv.spec.js', function () {
            describe('deviceRecommenderSrv service of exBuyflow', function () {
                var $httpBackend, $timeout, deviceRecommenderSrv, exBuyflowConstants;

                beforeEach(function () {
                    module('exBuyflow');

                    inject(function ($injector) {
                        $httpBackend = $injector.get('$httpBackend');
                        $timeout = $injector.get('$timeout');
                        exBuyflowConstants = $injector.get('exBuyflowConstants');
                        deviceRecommenderSrv = $injector.get('deviceRecommenderSrv');
                    });
                });

                describe('backend service call behavior', function () {
                    var testUpgradeDetails;

                    beforeEach(function () {
                        testUpgradeDetails = {
                            'deviceSkuId': 'sku7380579',
                            'sharedDataGroupSocCode': 'SDGUNLTV',
                            'planSocCode': 'SDDVRP'
                        };
                    });

                    afterEach(function () {
                        EndpointUtils.verifyExpectationsComplete($httpBackend);
                    });

                    it('should be able to get recommended devices from rex instead of catalog if rex is not down', function () {
                        var endpoint = Endpoint_rexBySku.get_recommended_devices,
                            endpoint_catalog = Endpoint_catalogServiceDevices.get_catalog_devices;

                        EndpointUtils.createMockServiceCall({
                            method: 'GET',
                            endpoint: endpoint,
                            $httpBackend: $httpBackend,
                            callback: function (url, params) {
                                expect(url).toContain(testUpgradeDetails.deviceSkuId); // verify sku
                                expect(params).toEqual(endpoint.params_sent); // verify parameters
                            }
                        });

                        EndpointUtils.createMockServiceCall({
                            method: 'GET',
                            endpoint: endpoint_catalog,
                            $httpBackend: $httpBackend,
                            callback: function (url, params) {
                                expect(params).toEqual(endpoint_catalog.params_sent); // verify parameters
                            }
                        });

                        EndpointUtils.callServiceFunction(
                            $httpBackend,
                            deviceRecommenderSrv.getRecommendedDevices,
                            [testUpgradeDetails],
                            {
                                callback: function (result) {
                                    expect(result).toEqual(endpoint.result); // verify data returned
                                }
                            });

                    });

                    it('should get devices from catalog if rex is down', function () {
                        var endpoint_rex = Endpoint_rexBySku.get_recommended_devices_down,
                            endpoint_catalog = Endpoint_catalogServiceDevices.get_catalog_devices;

                        EndpointUtils.createMockServiceCall({
                            method: 'GET',
                            endpoint: endpoint_rex,
                            $httpBackend: $httpBackend,
                            callback: function (url, params) {
                                expect(url).toContain(testUpgradeDetails.deviceSkuId); // verify sku
                                expect(params).toEqual(endpoint_rex.params_sent); // verify parameters
                            }
                        });

                        EndpointUtils.createMockServiceCall({
                            method: 'GET',
                            endpoint: endpoint_catalog,
                            $httpBackend: $httpBackend,
                            callback: function (url, params) {
                                expect(params).toEqual(endpoint_catalog.params_sent); // verify parameters
                            }
                        });

                        EndpointUtils.callServiceFunction(
                            $httpBackend,
                            deviceRecommenderSrv.getRecommendedDevices,
                            [testUpgradeDetails],
                            {
                                callback: function (result) {
                                    expect(result).toEqual(endpoint_catalog.data.payload); // verify catalog data
                                }
                            });
                    });

                    it('should get devices from catalog if rex times out', function () {
                        var endpoint_rex = Endpoint_rexBySku.get_recommended_devices,
                            endpoint_catalog = Endpoint_catalogServiceDevices.get_catalog_devices;

                        EndpointUtils.createMockServiceCall({
                            method: 'GET',
                            endpoint: endpoint_rex,
                            $httpBackend: $httpBackend,
                            callback: function () {
                                fail('service should have timed out without response');
                            }
                        });

                        EndpointUtils.createMockServiceCall({
                            method: 'GET',
                            endpoint: endpoint_catalog,
                            $httpBackend: $httpBackend,
                            callback: function (url, params) {
                                expect(params).toEqual(endpoint_catalog.params_sent); // verify parameters
                            }
                        });

                        EndpointUtils.callServiceFunction(
                            $httpBackend,
                            deviceRecommenderSrv.getRecommendedDevices,
                            [testUpgradeDetails],
                            {
                                preFlush: function () {
                                    $timeout.flush(exBuyflowConstants.rexServiceTimeout + 100); // run time
                                },
                                callback: function (result) {
                                    expect(result).toEqual(endpoint_catalog.data.payload); // verify catalog data
                                }
                            });
                    });

                    it('should be able to get the item price information of a sku', function () {
                        var endpoint = Endpoint_catalogServiceDevices.get_item_prices;

                        EndpointUtils.performServiceTest(
                            deviceRecommenderSrv.getItemPriceData,
                            [endpoint.params_sent.skuId], // pass skuid
                            {
                                method: 'GET',
                                endpoint: endpoint,
                                $httpBackend: $httpBackend,
                                callback: function (url, params) {
                                    expect(params).toEqual(endpoint.params_sent); // verify params
                                }
                            }, {
                                callback: function (result) {
                                    expect(result).toEqual(endpoint.data);
                                }
                            });
                    });
                });
            });
        });
    });
})();
