(function () {
    'use strict';

    define(['checkoutHandoffService'], function () {
        describe('src/main/modules/exBuyflow/services/checkoutHandoffService.spec.js', function () {
            describe('checkoutHandoffService service of exBuyflow', function () {
                var $httpBackend, service;

                beforeEach(function () {

                    module('exBuyflow');

                    inject(function ($injector) {
                        $httpBackend = $injector.get('$httpBackend');
                        service = $injector.get('checkoutHandoffService');
                    });
                });

                afterEach(function () {
                    EndpointUtils.verifyExpectationsComplete($httpBackend);
                });

                it('proceed to checkout should perform a post to appropriate service and return data (nothing else)',
                    function () {
                        EndpointUtils.performPlainDataServiceTest(service.proceedToCheckOut, undefined, {
                            $httpBackend: $httpBackend,
                            method: 'POST',
                            endpoint: Endpoint_checkoutHandoff.proceed_to_checkout
                        });
                    });

                it('proceed to continue should perform a post to appropriate service and return data (nothing else)',
                    function () {
                        EndpointUtils.performPlainDataServiceTest(service.proceedToContinue, undefined, {
                            $httpBackend: $httpBackend,
                            method: 'POST',
                            endpoint: Endpoint_configureNextUpgradeLine.proceed_to_continue
                        });
                    });
            });
        });
    });
})();
