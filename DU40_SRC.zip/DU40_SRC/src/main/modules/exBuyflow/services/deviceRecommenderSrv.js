(function () {
    'use strict';

    angular.module('exBuyflow')

        .factory('deviceRecommenderSrv', ['$http', 'exBuyflowConstants',
            function ($http, exBuyflowConstants) {
                var services = {};

                /**
                 * Gets the recommended devices from device recommender API
                 * @function getRecommendedDevices
                 * @param {object} upgradingDeviceDetails - Details of the upgrading device
                 * @returns {object} promise of recommended devices from the REX API
                 */
                services.getRecommendedDevices = function (upgradingDeviceDetails) {
                    var deviceRecommenderApi = exBuyflowConstants.rexBySkuRecommenderApi,
                        params = services.createParams(upgradingDeviceDetails),
                        recommendationsFromCatalog,
                        recommendedDevices;

                    deviceRecommenderApi = deviceRecommenderApi + upgradingDeviceDetails.deviceSkuId;

                    recommendedDevices = $http.get(deviceRecommenderApi, params)
                        .then(function (response) {
                            if (!response.data || response.data[0] === undefined) {
                                // returns the promise of getRecommendationsFromCatalog
                                return recommendationsFromCatalog;
                            } else {
                                return response.data;
                            }
                        }).catch(function () {
                            // returns promise of getRecommendationsFromCatalog
                            return recommendationsFromCatalog;
                        });

                    recommendationsFromCatalog = services.getRecommendationsFromCatalog();

                    return recommendedDevices;
                };

                /**
                 * Builds and returns the $http params object for a REX request.
                 * @param {object} upgradingDeviceDetails - Details of the upgrading device
                 * @return {Object} $http param object
                 */
                services.createParams = function (upgradingDeviceDetails) {

                    var params = {
                        params: {
                            profile: 'DeviceUpgrade',
                            filter: ['type:device', 'type:displayByGrp'],
                            exclude: ['type:removeDuplicateSibling', 'flowTypes:up'],
                            plancode: upgradingDeviceDetails.planSocCode,
                            sdgid: upgradingDeviceDetails.sharedDataGroupSocCode,
                            // REX needs this flag to expose special flair flags for each recommendation
                            showDisplayContent: 'true'
                        },
                        timeout: exBuyflowConstants.rexServiceTimeout,
                        spinner: true
                    };

                    return params;
                };

                /**
                 * Gets the recommended devices from Catalog if REX fails
                 * @function getRecommendationsFromCatalog
                 * @returns {object} promise object recommended devices
                 */
                services.getRecommendationsFromCatalog = function () {
                    return $http.get(exBuyflowConstants.catalogApi, {
                        params: {
                            actionType: 'getdeviceskus'
                        },
                        spinner: true
                    }).then(function (catalogApiResponse) {
                        return catalogApiResponse.data.payload;
                    });
                };

                /**
                 * Gets the Item price based on comma separated skuId
                 * @function getItemPriceData
                 * @returns {object} promise object map of skuid and item price
                 */
                services.getItemPriceData = function (skuId) {
                    return $http.get(exBuyflowConstants.catalogApi, {
                        params: {
                            actionType: 'getskuprices',
                            skuId: skuId
                        },
                        spinner: true
                    }).then(function (response) {
                        return response.data;
                    });
                };

                return services;
            }
        ]);
})();