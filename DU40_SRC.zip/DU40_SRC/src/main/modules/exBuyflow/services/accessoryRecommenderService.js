(function () {
    'use strict';

    angular.module('exBuyflow')

        .factory('accessoryRecommenderService', ['$log', '$q', '$http', 'exBuyflowConstants', 'exCacheManager',
            function ($log, $q, $http, exBuyflowConstants, exCacheManager) {
                var accessoryRecommender = {
                    getAccessoryRecommendations: getAccessoryRecommendations,
                    createParams: createParams
                };

                /**
                 * Makes a request to the accessory recommendations API for the device sku and categories in context and
                 *  returns a promise. If the promise resolves the result of the request will be returned.
                 * @function getAccessoryRecommendations
                 * @param {String} deviceSku Device Sku for which we are looking up accessory recommendations
                 * @param {Array<String>} categories Array of categories that we want recommendations for. Ex: ['cases', 'screen-protectors']
                 * @param {Object} options Object with optional parameters.
                 * @property {String} options.FavStoreId if the upgrading user if any Ex: '311'
                 * @property {Boolean} options.RSI Relax StoreId Indicator telling storeId is to be considered while
                 * @property {Boolean} options.hideSpinner Hides the spinner for this request if set to true.
                 * fetching the recommendations or not i.e True/False;
                 * @returns {Promise<Object>} Returns a promise of accessory recommendations results.
                 * @namespace accessoryRecommender
                 */
                function getAccessoryRecommendations (deviceSku, categories, options) {
                    options = typeof(options) !== 'undefined' ? options : {};
                    options.favStoreId = typeof(options.favStoreId) !== 'undefined' ? options.favStoreId : undefined;
                    options.RSI = typeof(options.RSI) !== 'undefined' ? options.RSI : undefined;
                    options.hideSpinner = typeof(options.hideSpinner) !== 'undefined' ? options.hideSpinner : false;

                    var params = createParams(categories, options.favStoreId, options.RSI, options.hideSpinner);

                    return $http.get(exBuyflowConstants.rexBySkuRecommenderApi + deviceSku, params)
                        .then(getRecommendationsCompleted)
                        .catch(getRecommendationsFailed);
                }

                /**
                 * Returns the data property of the accessory recommendation response object.
                 * @function getRecommendationsCompleted
                 * @param {Object} result Accessory recommendations response
                 * @returns {Promise<Object>} Returns the accessory recommendation response data
                 */
                function getRecommendationsCompleted (result) {
                    return result.data;
                }

                /**
                 * Logs an error and rejects the promise returned by the getAccessoryRecommendations function.
                 * @param {Error} error Accessory recommendation response error object.
                 * @return {Promise<Error>} Returns rejected promise
                 */
                function getRecommendationsFailed (error) {
                    var message = 'accessoryRecommenderService.getAccessoryRecommendations call failed.';
                    if (error.data && error.data.description) {
                        message += '\n' + error.data.description;
                    }
                    $log.error(message);
                    return $q.reject(error);
                }

                /**
                 * Builds and returns the $http params object from the categories array
                 * @param {Array<String>} categories Array of categories.
                 * @param {String} favStoreId of the upgrading user.
                 * @param {Boolean} Relax StorId Indicator, a boolean flag indicating whether favStoreId is to be
                 * considered by REX while fetching the recommendations or not.
                 * @return {Object} $http param object including the categories.
                 */
                function createParams (categories, favStoreId, RSI, hideSpinner) {
                    var params = {
                        params: {
                            exclude: 'type:device',
                            // REX needs this flag to expose special flair flags for each recommendation
                            showDisplayContent: 'true'
                        },
                        timeout: exBuyflowConstants.rexServiceTimeout,
                        cache: exCacheManager.getCache()
                    };

                    params['spinner'] = hideSpinner ? false : true;

                    var filters = [];

                    // build the categories filter array as per REX API
                    categories.forEach(function (category) {
                        filters.push('Category:' + category);
                    });

                    // to get compatible accessories for the selected device.
                    filters.push('COMPATIBILITY');
                    params.params['filter'] = filters;

                    if (favStoreId !== undefined) {

                        // If favStoreId is available then only the Relax Store Indicator is to
                        // be passed as parameter to REX
                        params.params['storeId'] = favStoreId;
                        // The 'rsi' param key name is to be passed in lower case
                        // It will let REX know if no accessories in every category requested due to invalid/closed store
                        params.params['rsi'] = RSI;
                    }
                    return params;
                }

                return accessoryRecommender;
            }]);
})();
