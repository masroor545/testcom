(function () {
    'use strict';

    angular.module('exBuyflow')

        .factory('checkoutHandoffService', ['$http', 'exBuyflowConstants',
            function ($http, exBuyflowConstants) {
                var checkoutHandoff = {
                    proceedToCheckOut: proceedToCheckOut,
                    proceedToContinue: proceedToContinue
                };

                /**
                 * Makes a post service when clicked on proceed to checkout button
                 * @function proceedToCheckOut
                 * @return {Object} data post response
                 */
                function proceedToCheckOut () {
                    return $http.post(exBuyflowConstants.exUpHandOffToCheckoutUrl).then(function (response) {
                        return response.data;
                    });
                }

                /**
                 * Makes a post service when clicked on proceed to continue button
                 * @function proceedToContinue
                 * @return {Object} data post response
                 */
                function proceedToContinue () {
                    return $http.post(exBuyflowConstants.exUpHandOffUpgradeToContinueUrl).then(function (response) {
                        return response.data;
                    });
                }

                return checkoutHandoff;
            }]);
})();
