(function () {
    'use strict';

    define(['accessoryRecommenderCtrl'], function () {
        describe('src/main/modules/exBuyflow/controllers/accessoryRecommenderCtrl.spec.js', function () {
            describe('accessoryRecommenderCtrl controller of exBuyFlow', function () {

                var $controller, $window, $modal, $rootScope, accessoryRecommenderService,
                    deviceRecommenderSrv, profileInfoService, protectionPlanService, exCartService,
                    exCommonConstants, selectedSkuSrv, checkoutHandoffService,
                    exBuyflowConstants, $scope, imagePathService, reportingDataSrv, upgradingUserInfoSrv, upgradeLinesInfoService;

                beforeEach(function () {
                    reportingDataSrv = jasmine.createSpyObj('reportingDataSrv', ['getAddToCartAccessoryRecommenderPayload',
                        'getOnProceedToCheckoutPayload', 'getMultilineReportingPayload', 'addEventSuccessToPayload',
                        'getRemovePayload']);
                    reportingDataSrv.getAddToCartAccessoryRecommenderPayload.and.returnValue({
                        items: [{itemSku: 'sku1234567'}]
                    });

                    reportingDataSrv.getOnProceedToCheckoutPayload.and.returnValue({
                        items: [{itemSku: 'sku1234567'}]
                    });
                });

                beforeEach(function () {
                    module('exBuyflow', function ($provide) {
                        accessoryRecommenderService = jasmine.createSpyObj('accessoryRecommenderService', ['getAccessoryRecommendations']);
                        checkoutHandoffService = jasmine.createSpyObj('checkoutHandoffService', ['proceedToCheckOut', 'proceedToContinue']);
                        upgradingUserInfoSrv = jasmine.createSpyObj('upgradingUserInfoSrv', ['getDeviceType', 'clearUpgradingLineCache', 'getUpgradingDeviceDetailsData']);
                        $provide.value('accessoryRecommenderService', accessoryRecommenderService);
                        protectionPlanService = jasmine.createSpyObj('protectionPlanService', ['getInsuranceFeatures']);
                        $provide.value('protectionPlanService', protectionPlanService);
                        exCartService = jasmine.createSpyObj('exCartService', ['getCart', 'addItemToCart', 'removeItemFromCart']);
                        $provide.value('exCartService', exCartService);
                        selectedSkuSrv = jasmine.createSpyObj('selectedSkuSrv', ['setSelectedAccessory']);
                        $provide.value('exCommonConstants', exCommonConstants);
                        deviceRecommenderSrv = jasmine.createSpyObj('deviceRecommenderSrv', ['getItemPriceData']);
                        $provide.value('deviceRecommenderSrv', deviceRecommenderSrv);
                        $provide.value('exBuyflowConstants', exBuyflowConstants);
                        imagePathService = jasmine.createSpyObj('imagePathService', ['getXpressImagePath']);
                        $provide.value('imagePathService', imagePathService);
                        profileInfoService = jasmine.createSpyObj('profileInfoService', ['getProfileInfo']);
                        upgradeLinesInfoService = jasmine.createSpyObj('upgradeLinesInfoService', ['getUpgradeLinesInfo']);
                        $provide.value('upgradeLinesInfoService', upgradeLinesInfoService);
                        $modal = jasmine.createSpyObj('$modal', ['open']);
                        $provide.value('$modal', $modal);
                    });

                    inject(function ($injector) {
                        $controller = $injector.get('$controller');
                        $window = $injector.get('$window');
                        $rootScope = $injector.get('$rootScope');
                        exCommonConstants = $injector.get('exCommonConstants');
                        exBuyflowConstants = $injector.get('exBuyflowConstants');
                    });
                    $scope = $rootScope.$new();
                    spyOn($rootScope, '$broadcast').and.callThrough();

                    // Values passed from the directive attributes
                    $scope.initialAccessoriesLoaded = '3';
                    $scope.accessoryCategories = '["cases","screen-protectors","charge-sync-cables","audio"]';
                    $scope.subTitle = 'Your new {0} deserves a little something extra.';
                    $scope.subTitleNoAccessory = "Here's one way to keep your new {0} safe";
                    $scope.relaxStoreIndicator = 'true';

                    accessoryRecommenderService.getAccessoryRecommendations.and.returnValue({
                        'then': function (callBackFN) {
                            callBackFN(Endpoint_accessoryRecommenderApi.get_accessory_recommendations.result);
                        }
                    });

                    checkoutHandoffService.proceedToCheckOut.and.returnValue({
                        'then': function (callback) {
                            callback(Endpoint_checkoutHandoff.proceed_to_checkout.result);
                        }
                    });

                    checkoutHandoffService.proceedToContinue.and.returnValue({
                        'then': function (callback) {
                            callback(Endpoint_checkoutHandoff.proceed_to_checkout.result);
                        }
                    });

                    protectionPlanService.getInsuranceFeatures.and.returnValue({
                        'then': function (callBackFN) {
                            callBackFN(Endpoint_protectionApi.get_insurance_features.result);
                        }
                    });

                    exCartService.getCart.and.returnValue({
                        'then': function (callBackFN) {
                            callBackFN(Endpoint_cartLookupApi.get_cart_lookup_new.result);
                        }
                    });

                    exCartService.addItemToCart.and.returnValue({
                        'then': function (callback) {
                            callback(true);
                        }
                    });

                    exCartService.removeItemFromCart.and.returnValue({
                        'then': function (callback) {
                            callback({
                                response: {
                                    status: 'success'
                                }
                            });
                        }
                    });

                    selectedSkuSrv.setSelectedAccessory.and.returnValue({
                        'then': function (callback) {
                            callback(true);
                        }
                    });

                    deviceRecommenderSrv.getItemPriceData.and.returnValue({
                        'then': function (callBackFN) {
                            callBackFN(Endpoint_accessoryRecommenderApi.get_Item_Prices_Accessory.data);
                        }
                    });

                    imagePathService.getXpressImagePath.and.returnValue({
                        'then': function (callBackFN) {
                            callBackFN(true);
                        }
                    });

                    upgradingUserInfoSrv.getUpgradingDeviceDetailsData.and.returnValue({
                        'then': function (callBackFN) {
                            callBackFN(Endpoint_deviceRecommenderApi.getUpgradingDetails_Phone.result);
                        }
                    });

                    upgradeLinesInfoService.getUpgradeLinesInfo.and.returnValue({
                        'then': function (callBackFN) {
                            callBackFN(true);
                        }
                    });

                    profileInfoService.getProfileInfo.and.returnValue({
                        'then': function (callBackFN) {
                            callBackFN(Endpoint_profileInfoApi.get_profile_info_auth.result);
                        }
                    });

                    $controller('accessoryRecommenderCtrl', {
                        $scope: $scope,
                        accessoryRecommenderService: accessoryRecommenderService,
                        checkoutHandoffService: checkoutHandoffService,
                        upgradingUserInfoSrv: upgradingUserInfoSrv,
                        protectionPlanService: protectionPlanService,
                        exCartService: exCartService,
                        selectedSkuSrv: selectedSkuSrv,
                        imagePathService: imagePathService,
                        reportingDataSrv: reportingDataSrv
                    });
                });

                afterEach(function () {
                    selectedSkuSrv.setSelectedAccessory.calls.reset();
                    exCartService.getCart.calls.reset();
                    $rootScope.$broadcast.calls.reset();
                    upgradingUserInfoSrv.clearUpgradingLineCache.calls.reset();
                    checkoutHandoffService.proceedToContinue.calls.reset();
                });

                describe('Recommended accessories and their respective prices', function () {

                    it('should get title and subtile on accessory recommender dynamically on the basis of '
                        + 'device/phone/tablet been added to cart from device recommender page', function () {
                        var subTitle;

                        // if cartItem in cart is a phone.
                        exCartService.getCart.and.returnValue({
                            'then': function (callBackFN) {
                                callBackFN(Endpoint_cartLookupApi.get_cart_lookup_deviceType_phone.result);
                            }
                        });
                        $scope.getCartData();
                        subTitle = $scope.subTitle.replace('{0}', $scope.accessoryRecommender.formattedDeviceType);
                        expect($scope.accessoryRecommender.subTitle).toEqual(subTitle);

                        // Resetting get cart calls
                        exCartService.getCart.calls.reset();

                        // if cartItem in cart is a tablet.
                        exCartService.getCart.and.returnValue({
                            'then': function (callBackFN) {
                                callBackFN(Endpoint_cartLookupApi.get_cart_lookup_deviceType_tablet.result);
                            }
                        });
                        $scope.getCartData();
                        subTitle = $scope.subTitle.replace('{0}', $scope.accessoryRecommender.formattedDeviceType);
                        expect($scope.accessoryRecommender.subTitle).toEqual(subTitle);
                    });

                    it('should have the cart details including current device skuid and other details', function () {
                        expect($scope).toBeDefined();
                        expect($scope.accessoryRecommender.deviceSku).toEqual('sku8040300');
                        expect($scope.accessoryRecommender.initialAccessoriesLoaded).toEqual(3);
                        expect($scope.accessoryRecommender.categories).toEqual(exBuyflowConstants.accessoryCategories);
                        expect($scope.accessoryRecommender.RSI).toEqual('true');
                    });

                    it('should pass the favStoreId and relaxStoreIndicator to REX api if favStoreId of user is ' +
                        'available and skuExcludedFromBOPISForFlow flag for device is false', function () {
                        $window.sessionStorage.setItem(exCommonConstants.favStoreStorageKey, '311');
                        var skuExcludedFromBOPISForFlow = false,
                            favStoreId = '311';
                        $scope.getRecommendedAccessories($scope.accessoryRecommender.deviceSku,
                                $scope.accessoryCategories, skuExcludedFromBOPISForFlow);
                        expect(accessoryRecommenderService.getAccessoryRecommendations).toHaveBeenCalled();
                        expect(accessoryRecommenderService.getAccessoryRecommendations).toHaveBeenCalledWith(
                                $scope.accessoryRecommender.deviceSku, $scope.accessoryCategories, 
                                {'favStoreId': favStoreId, 'RSI': $scope.relaxStoreIndicator});
                    }
                    );

                    it('should not pass the favStoreId and relaxStoreIndicator to REX api if favStoreId of user is' +
                        'available but skuExcludedFromBOPISForFlow flag for device is true', function () {
                        var skuExcludedFromBOPISForFlow = true,
                            favStoreId = '311';
                        $scope.getRecommendedAccessories($scope.accessoryRecommender.deviceSku,
                                $scope.accessoryCategories, skuExcludedFromBOPISForFlow);
                        expect(accessoryRecommenderService.getAccessoryRecommendations).toHaveBeenCalled();
                        expect(accessoryRecommenderService.getAccessoryRecommendations).not.toHaveBeenCalledWith(favStoreId);
                    }
                    );

                    it('should not pass the favStoreId and relaxStoreIndicator to REX api if favStoreId of user is' +
                        'not available but skuExcludedFromBOPISForFlow flag for device is false', function () {
                        $window.sessionStorage.removeItem(exCommonConstants.favStoreStorageKey);
                        var skuExcludedFromBOPISForFlow = false,
                            favStoreId = '311';
                        $scope.getRecommendedAccessories($scope.accessoryRecommender.deviceSku,
                                $scope.accessoryCategories, skuExcludedFromBOPISForFlow);
                        expect(accessoryRecommenderService.getAccessoryRecommendations).toHaveBeenCalled();
                        expect(accessoryRecommenderService.getAccessoryRecommendations).not.toHaveBeenCalledWith(favStoreId);
                    }
                    );

                    it('should get the recommended accessories and there respective prices when protectionPlan is ON', function () {
                        var skuids = 'sku8030509,sku8000353,sku8140322';
                        $scope.accessoryRecommender.protectionPlanFlag = true;
                        expect($scope.accessoryRecommenderDetail).toBeDefined();
                        expect(Object.keys($scope.accessoryRecommenderDetail).length).toEqual($scope.accessoryRecommender.initialAccessoriesLoaded);
                        expect($scope.heroAccessory).not.toEqual(Object);
                        expect(deviceRecommenderSrv.getItemPriceData).toHaveBeenCalledWith(skuids);
                        expect(deviceRecommenderSrv.getItemPriceData.calls.mostRecent().args.length).toEqual(1);
                        expect($scope.accessoryRecommenderDetail[0].skuId).toEqual('sku8030509');
                        expect($scope.accessoryRecommenderDetail[1].skuId).toEqual('sku8000353');
                        expect($scope.accessoryRecommenderDetail[2].skuId).toEqual('sku8140322');

                        // getting the accessory images
                        expect(imagePathService.getXpressImagePath).toHaveBeenCalled();
                        expect(typeof imagePathService.getXpressImagePath.calls.mostRecent().args[1]).toEqual('object');
                        expect(imagePathService.getXpressImagePath.calls.count()).toEqual(3);
                        expect($scope.imgUrl['sku8030509']).toBeDefined();
                        expect($scope.subTitleToDisplay['subtitle']).toEqual(true);

                        // see if variants with life i.e. mEndofLife equals false, are available for the accessories
                        expect($scope.isAccessoryVariantsAvailable['sku8030509']).toEqual(true);
                        expect($scope.isAccessoryVariantsAvailable['sku8000353']).toEqual(true);
                        // sku8140322 has no variants with mEndofLife equals false
                        expect($scope.isAccessoryVariantsAvailable['sku8140322']).toEqual(undefined);
                    });

                    it('should filter out out-of-stock and end-of-life recommended accessories', function () {
                        angular.forEach($scope.categorizedAccessories, function (categorizedAccessory) {
                            expect(categorizedAccessory).toEqual(jasmine.objectContaining({
                                outOfStock: false,
                                endOfLife: false
                            }));
                        });
                    });

                    it('should get the recommended accessories and there respective prices when protectionPlan is OFF', function () {
                        imagePathService.getXpressImagePath.calls.reset();
                        var skuids = 'sku8110287,sku8000353,sku8140322,sku8030509';
                        protectionPlanService.getInsuranceFeatures.and.returnValue({
                            'then': function (callBackFN) {
                                callBackFN(Endpoint_protectionApi.insurance_features_not_available.result);
                            }
                        });
                        $scope.getCartData('load');
                        expect($rootScope.$broadcast).toHaveBeenCalled();
                        expect($scope.accessoryRecommenderDetail).toBeDefined();
                        expect($scope.heroAccessory).toBeDefined();
                        expect(Object.keys($scope.accessoryRecommenderDetail).length).toEqual($scope.accessoryRecommender.initialAccessoriesLoaded);
                        expect(typeof $scope.heroAccessory).toEqual('object');
                        expect(deviceRecommenderSrv.getItemPriceData).toHaveBeenCalledWith(skuids);
                        expect(deviceRecommenderSrv.getItemPriceData.calls.mostRecent().args.length).toEqual(1);
                        expect($scope.accessoryRecommenderDetail[0].skuId).toEqual('sku8110287');
                        expect($scope.accessoryRecommenderDetail[1].skuId).toEqual('sku8000353');
                        expect($scope.accessoryRecommenderDetail[2].skuId).toEqual('sku8140322');
                        expect($scope.heroAccessory[0].skuId).toEqual('sku8030509');

                        // getting the accessory images
                        expect(imagePathService.getXpressImagePath).toHaveBeenCalled();
                        expect(typeof imagePathService.getXpressImagePath.calls.mostRecent().args[1]).toEqual('object');
                        expect(imagePathService.getXpressImagePath.calls.count()).toEqual(4);
                        expect($scope.imgUrl['sku8110287']).toBeDefined();
                        expect($scope.subTitleToDisplay['subtitle']).toEqual(true);

                        // see if variants with life i.e. mEndofLife equals false, are available for the accessories
                        expect($scope.isAccessoryVariantsAvailable['sku8030509']).toEqual(true);
                        expect($scope.isAccessoryVariantsAvailable['sku8000353']).toEqual(true);
                        expect($scope.isAccessoryVariantsAvailable['sku8030509']).toEqual(true);
                        // sku8140322 has no variants with mEndofLife equals false
                        expect($scope.isAccessoryVariantsAvailable['sku8140322']).toEqual(undefined);
                    });

                    it('should get the flair Flags against standard accessories after filtering and sorting', function () {
                        $scope.accFilterFlairFlags($scope.accessoryRecommenderDetail);
                        expect($scope.accessoryRecommenderDetail[0].displayContentItems).toBeDefined();

                        // if all the conditions are satisfied and result is sorted
                        expect($scope.accFlairFlag['sku8030509'].enable).toEqual(true);
                        expect($scope.accFlairFlag['sku8030509'].displayType).toEqual('ribbon');
                        expect($scope.accFlairFlag['sku8030509'].contentType).toEqual('image');
                        expect($scope.accFlairFlag['sku8030509'].flowTypes).toContain('UP');
                        expect($scope.accFlairFlag['sku8030509'].marketingPriority).toEqual(1);

                        // if conditions are not satisfied for any sku
                        expect($scope.accFlairFlag['sku8140322']).toEqual('none');
                    });

                    it('should get the flair Flags against hero accessories after filtering and sorting', function () {
                        protectionPlanService.getInsuranceFeatures.and.returnValue({
                            'then': function (callBackFN) {
                                callBackFN(Endpoint_protectionApi.insurance_features_not_available.result);
                            }
                        });
                        $scope.getCartData('load');
                        $scope.accFilterFlairFlags($scope.heroAccessory);
                        expect($scope.heroAccessory[0].displayContentItems).toBeDefined();

                        // if all the conditions are satisfied and result is sorted
                        expect($scope.accFlairFlag['sku8030509'].enable).toEqual(true);
                        expect($scope.accFlairFlag['sku8030509'].displayType).toEqual('ribbon');
                        expect($scope.accFlairFlag['sku8030509'].contentType).toEqual('image');
                        expect($scope.accFlairFlag['sku8030509'].flowTypes).toContain('UP');
                        expect($scope.accFlairFlag['sku8030509'].marketingPriority).toEqual(1);
                    });

                    it('should check whether the protection plan feature is to be shown or not', function () {
                        $scope.getCartData();
                        expect($scope.accessoryRecommender.protectionPlanFlag).toEqual(true);
                    });

                    it('should add an item to cart', function () {
                        // Mock override
                        exCartService.getCart.and.returnValue({
                            'then': function (callback) {
                                callback(Endpoint_cartLookupApi.get_cart_lookup_accessory_added.result);
                            }
                        });

                        $rootScope.$broadcast.calls.reset();

                        var skuId = 'sku1234567';
                        var productId = 'bar';

                        expect($scope.accessoryInCartItem[skuId]).not.toBeDefined();
                        $scope.accessoryAddToCart(skuId, productId);

                        // service call
                        expect(exCartService.addItemToCart.calls.mostRecent().args.length).toEqual(2);
                        expect(typeof exCartService.addItemToCart.calls.mostRecent().args[0]).toEqual('object');
                        expect(typeof exCartService.addItemToCart.calls.mostRecent().args[1]).toEqual('object');

                        // cart item
                        var cartItem = exCartService.addItemToCart.calls.mostRecent().args[1];
                        expect(cartItem.items.items[0].catalogRefId).toEqual(skuId);

                        // update cart
                        expect(exCartService.getCart).toHaveBeenCalledWith('reload');
                        expect($rootScope.$broadcast).toHaveBeenCalled();
                        expect($scope.accessoryInCartItem[skuId]).toBeDefined();
                    });

                    it('should remove an item from cart', function () {
                        // Mock override
                        exCartService.getCart.and.returnValue({
                            'then': function (callback) {
                                callback(Endpoint_cartLookupApi.get_cart_lookup_accessory_removed.result);
                            }
                        });

                        $rootScope.$broadcast.calls.reset();

                        var skuId = 'sku8030508';
                        var accessoryCommerceItemId = '83602000145';

                        expect($scope.accessoryInCartItem[skuId]).toBeDefined();
                        $scope.accessoryRemoveItemFromCart(accessoryCommerceItemId);

                        // service call
                        expect(exCartService.removeItemFromCart.calls.mostRecent().args.length).toEqual(1);
                        expect(exCartService.removeItemFromCart.calls.mostRecent().args[0].removalCommerceIds).toEqual(accessoryCommerceItemId);

                        // update cart
                        expect(exCartService.getCart).toHaveBeenCalledWith('reload');
                        expect($rootScope.$broadcast).toHaveBeenCalled();
                        expect($scope.accessoryInCartItem[skuId]).not.toBeDefined();
                    });

                    it('should proceed with next upgrading line when onContinueToUpgrade accessory recommender service', function () {
                        $scope.onContinueToUpgrade();
                        expect(checkoutHandoffService.proceedToContinue).toHaveBeenCalled();
                        expect(upgradingUserInfoSrv.clearUpgradingLineCache).toHaveBeenCalled();
                    });

                    it('should call the proceed to checkout on accessory recommender service', function () {
                        $scope.onProceedToCheckout();
                        expect(checkoutHandoffService.proceedToCheckOut).toHaveBeenCalled();
                    });

                    it('should not call imagePathService and pricing service in case no accessories are returned from REX', function () {
                        
                        // Reseting previous call history of recommendation service,
                        // image path service and pricing service to track new calls.
                        accessoryRecommenderService.getAccessoryRecommendations.calls.reset();
                        deviceRecommenderSrv.getItemPriceData.calls.reset();
                        imagePathService.getXpressImagePath.calls.reset();

                        // mocking recommender service to return zero accessories
                        accessoryRecommenderService.getAccessoryRecommendations.and.returnValue({
                            'then': function (callBackFN) {
                                callBackFN([]);
                            }
                        });

                        // calling getRecommendedAccessories function which will ultimately calls pricing service to
                        // get the returned accessories's (Zero accessories in this case) price.
                        $scope.getRecommendedAccessories();

                        // Service call to get accessories recommendations should be made
                        expect(accessoryRecommenderService.getAccessoryRecommendations).toHaveBeenCalled();
                        
                        // Service to get the accessory price and image path should not be called
                        // as REX is returning no accessories in this case.
                        expect(deviceRecommenderSrv.getItemPriceData).not.toHaveBeenCalled();
                        expect(imagePathService.getXpressImagePath).not.toHaveBeenCalled();
                    });

                });

                // Accessory config modal
                describe('Accessory config modal', function () {

                    // Set accessory and open the modal
                    it('should open the modal and display details about the accessory', function () {
                        $scope.selectAccessory('sku7840239');
                        expect(selectedSkuSrv.setSelectedAccessory).toHaveBeenCalledWith('sku7840239');
                    });

                });


                describe('should check reporting functionalities', function () {

                    beforeEach(function () {
                        spyOn($scope, '$emit').and.callThrough();

                        $scope.$emit.calls.reset();
                    });

                    it('should report DS_Upgrade_Cart_Add_Submit when accessory added to cart from accessory recommender', function () {
                        var expectedReportingObjectSubmit = jasmine.objectContaining({
                                eventAction: 'formSubmit',
                                eventCode: 'DS_Upgrade_Cart_Add_Submit'
                            }),
                            expectedReportingObjectResponse = jasmine.objectContaining({
                                eventAction: 'formResponse',
                                eventCode: 'DS_Upgrade_Cart_Add_Submit'
                            }),
                            skuId = 'sku1234567',
                            productId = 'bar';

                        expect($scope.accessoryInCartItem[skuId]).not.toBeDefined();
                        $scope.accessoryAddToCart(skuId, productId);
                        expect($scope.$emit).toHaveBeenCalledWith('DS_Reporting_Event', expectedReportingObjectSubmit, jasmine.anything());
                        expect($scope.$emit).toHaveBeenCalledWith('DS_Reporting_Event', expectedReportingObjectResponse, jasmine.anything());
                        $scope.$apply();
                    });

                    it('should report DS_Upgrade_Cart_Preorder_Submit when preorder accessory added to cart from accessory recommender', function () {
                        var expectedReportingObjectSubmit = jasmine.objectContaining({
                                eventAction: 'formSubmit',
                                eventCode: 'DS_Upgrade_Cart_Preorder_Submit'
                            }),
                            expectedReportingObjectResponse = jasmine.objectContaining({
                                eventAction: 'formResponse',
                                eventCode: 'DS_Upgrade_Cart_Preorder_Submit'
                            }),
                            skuId = 'sku8030509',
                            productId = 'bar';

                        $scope.getCartData();
                        $scope.accessoryRecommenderDetail[0].preOrderable = true;
                        expect($scope.accessoryInCartItem[skuId]).not.toBeDefined();
                        $scope.accessoryAddToCart(skuId, productId);

                        expect($scope.$emit).toHaveBeenCalledWith('DS_Reporting_Event', expectedReportingObjectSubmit, jasmine.anything());
                        expect($scope.$emit).toHaveBeenCalledWith('DS_Reporting_Event', expectedReportingObjectResponse, jasmine.anything());
                        $scope.$apply();
                    });

                    it('should report DS_Upgrade_Proceed_To_Checkout_Submit when user proceeds to checkout from accessory recommender', function () {
                        var expectedReportingObjectSubmit = jasmine.objectContaining({
                                eventAction: 'formSubmit',
                                eventCode: 'DS_Upgrade_Proceed_To_Checkout_Submit'
                            }),
                            expectedReportingObjectResponse = jasmine.objectContaining({
                                eventAction: 'formResponse',
                                eventCode: 'DS_Upgrade_Proceed_To_Checkout_Submit'
                            });
                        $scope.onProceedToCheckout();
                        expect($scope.$emit).toHaveBeenCalledWith('DS_Reporting_Event', expectedReportingObjectSubmit, jasmine.anything());
                        expect($scope.$emit).toHaveBeenCalledWith('DS_Reporting_Event', expectedReportingObjectResponse, jasmine.anything());
                        $scope.$apply();
                    });

                    it('should report DS_Upgrade_Continue_Submit when user proceeds to checkout from accessory recommender', function () {
                        var expectedReportingObjectSubmit = jasmine.objectContaining({
                                eventAction: 'formSubmit',
                                eventCode: 'DS_Upgrade_Continue_Submit'
                            }),
                            expectedReportingObjectResponse = jasmine.objectContaining({
                                eventAction: 'formResponse',
                                eventCode: 'DS_Upgrade_Continue_Submit'
                            });
                        $scope.onContinueToUpgrade();
                        expect($scope.$emit).toHaveBeenCalledWith('DS_Reporting_Event', expectedReportingObjectSubmit, jasmine.anything());
                        expect($scope.$emit).toHaveBeenCalledWith('DS_Reporting_Event', expectedReportingObjectResponse, jasmine.anything());
                        $scope.$apply();
                    });

                    // check that page load event fires when Accessory selected
                    it('should fire page load event with appropriate value when modal accessory selected', function () {
                        var friendlyPageName = 'DS Upgrade Accessory Config Modal Pg',
                            virtualUrl = '/shop/xpress/virtual/accessory-config.html';
                        $scope.selectAccessory('sku7840239');
                        expect($scope.$emit).toHaveBeenCalledWith('DS_Reporting_PageLoad_Event', friendlyPageName, virtualUrl);
                    });


                    // check that link click event fires when user clicks on choose your options for accessories
                    it('should fire link clink event with appropriate value when user clicks on choose your options for accessories', function () {
                        var expectedReportingObject = jasmine.objectContaining({
                            eventAction: 'linkClick',
                            eventCode: 'Link_Click',
                            additionaldata: {
                                'linkName': 'Choose your options',
                                'linkPosition': 'Body',
                                'linkDestinationURL': '/shop/xpress/virtual/accessory-config.html'
                            }
                        });

                        $scope.selectAccessory('sku7840239');
                        expect($scope.$emit).toHaveBeenCalledWith('DS_Reporting_Event', expectedReportingObject, jasmine.anything());
                        $scope.$apply();
                    });
                });
            });
        });
    });
})();