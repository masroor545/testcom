(function () {
    'use strict';

    angular.module('exBuyflow')

        .controller('accessorySubtotalTooltipCtrl', ['$scope', 'exBuyflowConstants', 'exCqTranslatorKeyService',
            function ($scope, exBuyflowConstants, exCqTranslatorKeyService) {
                var subtotalTooltipDetails = {
                    description: {}
                };
                $scope.fetchSubtotalTooltipDetails = fetchSubtotalTooltipDetails;
                $scope.subtotalTooltipDetails = subtotalTooltipDetails;

                /**
                 * Scope function to get subtotal tool tip legal
                 */
                function fetchSubtotalTooltipDetails () {
                    var cmsKeys = [];
                    cmsKeys.push(exBuyflowConstants.legalSubtotalToolTipContentKey);
                    exCqTranslatorKeyService.getCqTranslatorKeys(cmsKeys).then(function (result) {
                        if (result) {
                            subtotalTooltipDetails.description = result[exBuyflowConstants.legalSubtotalToolTipContentKey];
                        }
                    });
                }

                /**
                 * Starts up the controller
                 */
                function activate () {
                    fetchSubtotalTooltipDetails();
                }

                activate();
            }]);
})();
