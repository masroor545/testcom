(function () {
    'use strict';

    angular.module('exBuyflow')

        .controller('deviceLegalDetailCtrl', ['$scope', 'selectedSkuSrv', 'contentService', 'deviceConfigSrv', function ($scope, selectedSkuSrv, contentService, deviceConfigSrv) {
            $scope.deviceLegalDetail = {
                longLegalContent: undefined
            };

            /**
             * Retrieve the devicePageURL of selected sku and get the long legal content for the selected device. .
             * @function getDeviceInformation
             * @param {string} skuId The selected SKU
             */
            function getDeviceInformation (skuId) {
                var params = {
                    groupResultsByVariants: true,
                    includeAssociatedProducts: false,
                    includePrices: true,
                    skuId: skuId
                };
                deviceConfigSrv.getDeviceDetails(skuId, params).then(function (data) {
                    data = data.data.result.methodReturnValue;
                    if (data !== null) {
                        //Fetch legal content for selected device
                        contentService.getProductLegalPaths(data.selectedSkuDetails.devicePageURL).then(function (deviceLegalPaths) {
                            contentService.getProductLegalContent(deviceLegalPaths).then(function (deviceLegalContent) {
                                $scope.deviceLegalDetail.longLegalContent = deviceLegalContent;
                            });
                        });
                    }

                });
            }

            /**
             * Controller startup logic.
             * @private
             */
            function activate () {
                var skuId = selectedSkuSrv.getSelectedDevice();
                getDeviceInformation(skuId);
            }

            activate();
        }]);
})();
