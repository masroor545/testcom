(function () {
    'use strict';

    angular.module('exBuyflow')

        .controller('upsellOfferCtrl', ['$scope', '$modal', 'upsellOfferSrv', 'exCommonConstants', 'exBuyflowConstants', 'exCartService', 'selectedSkuSrv', 'imagePathService', 'reportingDataSrv',
            function ($scope, $modal, upsellOfferSrv, exCommonConstants, exBuyflowConstants, exCartService, selectedSkuSrv, imagePathService, reportingDataSrv) {

                $scope.upsellOfferDetails = {
                    selectedOfferDetails: {},
                    getAddToCartItems: {},
                    offerDetails: [],
                    isMultiSkuOffer: false,
                    offerContentDetails: [],
                    offerHeadLine: '',
                    offerSubheadLine: '',
                    offerInBodyContent: '',
                    offerLegalContent: '',
                    offerId: '',
                    upsellSubtotalDetails: {
                        offerCartTotalAmount: '',
                        offerCartMonthlyAmount: ''
                    },
                    showHeroImage: ' '
                };
                $scope.upsellOfferAddItemToCart = upsellOfferAddItemToCart;
                $scope.multiSkuUpsellOffer = multiSkuUpsellOffer;
                $scope.onSkipToCheckout = onSkipToCheckout;

                /**
                 * Scope function to show see offer details legal content overlay
                 */
                $scope.openSeeOfferDetailsModal = function () {
                    $modal.open({
                        templateUrl: exCommonConstants.upsellSeeOfferDetailsModal,
                        windowClass: 'modal-fullscreen',
                        scope: $scope
                    });
                };
                activate();

                /**
                 * Starts up the controller
                 */
                function activate () {
                    upsellOfferSrv.getUpsellOfferDetails().then(function (data) {
                        if (data !== undefined && data !== null) {
                            $scope.upsellOfferDetails.offerDetails = getRequiredUpsellOfferDetails(data);
                            $scope.upsellOfferDetails.isMultiSkuOffer = $scope.upsellOfferDetails.offerDetails[0].multiSkuOffer;
                            $scope.upsellOfferDetails.showHeroImage = $scope.upsellOfferDetails.offerDetails[0].imagePath;
                            $scope.upsellOfferDetails.offerId = $scope.upsellOfferDetails.offerDetails[0].offerId;
                            upsellOfferSrv.setRequiredOfferId($scope.upsellOfferDetails.offerId);
                            $scope.upsellOfferDetails.upsellSubtotalDetails.offerCartTotalAmount = $scope.upsellOfferDetails.offerDetails[0].offerDueTodayTotal;
                            $scope.upsellOfferDetails.upsellSubtotalDetails.offerCartMonthlyAmount = $scope.upsellOfferDetails.offerDetails[0].offerDueMonthlyTotal;
                            upsellOfferSrv.getUpsellOfferContentDetails($scope.upsellOfferDetails.offerId).then(function (contentDetails) {
                                if (contentDetails) {
                                    $scope.upsellOfferDetails.offerContentDetails = getRequiredUpsellOfferLegalContentDetails(contentDetails);

                                    // Gets upsell offer details - headline, subheadline, description, legal content
                                    if ($scope.upsellOfferDetails.offerContentDetails &&
                                        $scope.upsellOfferDetails.offerContentDetails.length > 0) {

                                        $scope.upsellOfferDetails.offerHeadLine = $scope.upsellOfferDetails.offerContentDetails[0].headLine;
                                        $scope.upsellOfferDetails.offerSubheadLine = $scope.upsellOfferDetails.offerContentDetails[0].subheadLine;
                                        $scope.upsellOfferDetails.offerInBodyContent = $scope.upsellOfferDetails.offerContentDetails[0].inBodyContent;
                                        $scope.upsellOfferDetails.offerLegalContent = $scope.upsellOfferDetails.offerContentDetails[0].legalContent;
                                    }
                                }
                            });

                            var eventPayload = reportingDataSrv.getUpsellPayload($scope.upsellOfferDetails.offerDetails);

                            $scope.$emit(exCommonConstants.event.DS_REPORTING_EVENT, {
                                eventAction: 'systemEvent',
                                eventCode: 'DS_System_Upgrade_UpSell_Offer_Display',
                                additionaldata: eventPayload
                            }, $scope);

                        }
                    });
                }

                /**
                 * this method makes a post service when clicked on proceed to checkout button on upsellOffer page
                 * @function onSkipToCheckout
                 */
                function onSkipToCheckout () {
                    var eventPayload = reportingDataSrv.getUpsellPayload($scope.upsellOfferDetails.offerDetails);

                    // Fire link click event when user clicks No, thanks on upsell page
                    $scope.$emit(exCommonConstants.event.DS_REPORTING_EVENT, {
                        eventAction: 'linkClick',
                        eventCode: 'Link_Click',
                        additionaldata: {
                            'linkName': exBuyflowConstants.linkName.skipUpsellOffer,
                            'linkPosition': exBuyflowConstants.linkPosition,
                            'linkDestinationURL': exBuyflowConstants.virtualUrl.onePageCheckout
                        }
                    }, $scope);

                    $scope.$emit(exCommonConstants.event.DS_REPORTING_EVENT, {
                        eventAction: 'formSubmit',
                        eventCode: 'DS_Upgrade_Proceed_To_Checkout_Submit',
                        additionaldata: eventPayload
                    }, $scope);

                    upsellOfferSrv.skipToCheckout().then(function (data) {

                        if (data.response !== undefined && data.response !== null
                            && data.response.status === exCommonConstants.errorStatus) {
                            eventPayload = reportingDataSrv.updateEventPayloadFailure(eventPayload, data);
                        }

                        $scope.$emit(exCommonConstants.event.DS_REPORTING_EVENT, {
                            eventAction: 'formResponse',
                            eventCode: 'DS_Upgrade_Proceed_To_Checkout_Submit',
                            additionaldata: eventPayload
                        }, $scope);
                    });
                }

                /**
                 * gets the BOGO upsell offer details from UpsellOffer API
                 * @function getRequiredUpsellOfferDetails
                 * @param {Object} upsellDetails Upsell offer information
                 * @returns {object} device offers details
                 */
                function getRequiredUpsellOfferDetails (upsellDetails) {
                    var upsellOfferDetails = [];
                    if (upsellDetails.payload !== undefined
                        && upsellDetails.payload !== null
                        && upsellDetails.payload.statusCode === 'SUCCESS'
                        && Object.keys(upsellDetails.payload.methodReturnValue.skuItems).length > 0) {

                        var upsellOfferId = upsellDetails.payload.methodReturnValue.offerId;
                        var isMultiSku = upsellDetails.payload.methodReturnValue.multiSkuOffer,
                            dueTodayTotal = upsellDetails.payload.methodReturnValue.cartTotalAmount,
                            dueMonthlyTotal = upsellDetails.payload.methodReturnValue.cartMonthlyAmount;

                        Object.keys(upsellDetails.payload.methodReturnValue.skuItems).forEach(function (key) {
                            var details = upsellDetails.payload.methodReturnValue.skuItems[key];
                            upsellOfferDetails.push({
                                redirectURL: upsellDetails.payload.redirectURL,
                                skuId: details.skuId,
                                offerId: upsellOfferId,
                                productId: details.productId,
                                displayName: details.displayName,
                                model: details.model,
                                priceList: details.priceList,
                                imagePath: deviceImageUrl(details),
                                multiSkuOffer: isMultiSku,
                                defaultSku: upsellDetails.payload.methodReturnValue.defaultSkuId,
                                offerDueTodayTotal: dueTodayTotal,
                                offerDueMonthlyTotal: dueMonthlyTotal
                            });
                        });
                        return upsellOfferDetails;
                    }
                }

                /**
                 * Gets the device image from imagePathService.
                 * @param {object} details offer details
                 * @private
                 * @return {string} xpress image url
                 */
                function deviceImageUrl (details) {
                    return imagePathService.getXpressImagePath(details.manufacturer,
                        details.shortDisplayName, details.displayName,
                        details.color, exCommonConstants.heroDeviceImageUrlExtension);
                }

                /**
                 * gets the offer legal content details from sharedContentRetrievalUrl
                 * @function getRequiredUpsellOfferLegalContentDetails
                 * @param {Object} offerContent Offer legal content information
                 * @returns {object} offer specific legal content details
                 */
                function getRequiredUpsellOfferLegalContentDetails (offerContent) {
                    var upsellOfferContentDetails = [];
                    angular.forEach(offerContent, function (item, key) {
                        if (offerContent.hasOwnProperty(key)) {
                            upsellOfferContentDetails.push({
                                headLine: (item.pageTitle) ? item.pageTitle[0] : '',
                                subheadLine: (item.navTitle) ? item.navTitle[0] : '',
                                inBodyContent: (item.subtitle) ? item.subtitle[0] : '',
                                legalContent: (item['jcr:description']) ? item['jcr:description'][0] : ''
                            });
                        }
                    });
                    return upsellOfferContentDetails;
                }

                /**
                 * Adds the upsell offer item to the cart by passing Request Payload items and input parameters to UpsellOffer post service
                 * @function upsellOfferAddItemToCart
                 */
                function upsellOfferAddItemToCart () {
                    $scope.upsellOfferDetails.getAddToCartItems = getAddToCartOfferDetails();

                    var eventPayload = reportingDataSrv.getAddToCartUpsellPayload($scope.upsellOfferDetails.getAddToCartItems,
                        $scope.upsellOfferDetails.offerDetails),
                        eventCode = $scope.upsellOfferDetails.offerDetails[0].preOrderable ? 'DS_Upgrade_Cart_Preorder_Submit' : 'DS_Upgrade_Cart_Add_Submit';

                    $scope.$emit(exCommonConstants.event.DS_REPORTING_EVENT, {
                        eventAction: 'formSubmit',
                        eventCode: eventCode,
                        additionaldata: eventPayload
                    }, $scope);

                    // Request Payload items
                    exCartService.addItemToCart($scope.upsellOfferDetails.getAddToCartItems,
                        {
                            actionType: 'addItemAndGoToNextStep',
                            redirectionUrl: $scope.upsellOfferDetails.offerDetails[0].redirectURL,
                            losgBuyFlowType: 'AL',
                            addNewLine: 'true',
                            wirelessBuyFlowType: 'MIXEDCART',
                            quantity: 1
                        }).then(function (data) {
                            if (data.response !== undefined && data.response !== null
                                && data.response.status === exCommonConstants.errorStatus) {
                                eventPayload = reportingDataSrv.updateEventPayloadFailure(eventPayload, data);
                            }

                            $scope.$emit(exCommonConstants.event.DS_REPORTING_EVENT, {
                                eventAction: 'formResponse',
                                eventCode: eventCode,
                                additionaldata: eventPayload
                            }, $scope);
                        });
                }

                /**
                 * make a post call to redirect to overlay config page in case of multi-Sku offer
                 * @function multiSkuUpsellOffer
                 */
                function multiSkuUpsellOffer () {
                    var defaultSku = $scope.upsellOfferDetails.offerDetails[0].defaultSku;
                    selectedSkuSrv.setSelectedDevice(defaultSku);
                    $modal.open({
                        templateUrl: '/shop/xpress/modals/upsell-offer.modal.html',
                        windowClass: 'modal-fullscreen'
                    });

                    //Fire page load event when Accessory displayed on accessory recommender page as a modal. Should only be fired if getting called to show modal.
                    $scope.$emit(exCommonConstants.event.DS_REPORTING_PAGELOAD_EVENT,
                        exBuyflowConstants.friendlyPageName.multiSkuUpsellOffer,
                        exBuyflowConstants.virtualUrl.multiSkuUpsellOffer);
                }

                /**
                 * Create array of input parameters
                 * @function getAddTOCartOfferDetails
                 * @returns {Object} input params
                 */
                function getAddToCartOfferDetails () {
                    var offerDetailsData = [];
                    var valueMap = {};

                    // For a single skuId of an offer product
                    // Get the skuId details of a single product which is the offer that is
                    // being displayed
                    var priceList = $scope.upsellOfferDetails.offerDetails[0].priceList[0];
                    valueMap.contractType = priceList.type === 'regular' ? 'regular' : priceList.name;

                    // If the contract type is regular then the contract length is the name
                    valueMap.contractLength = valueMap.contractType === 'regular' ? priceList.name.toString() : priceList.leaseTotalMonths.toString();
                    offerDetailsData.push({
                        valueMap: valueMap,
                        catalogRefId: $scope.upsellOfferDetails.offerDetails[0].skuId,
                        productId: $scope.upsellOfferDetails.offerDetails[0].productId,
                        quantity: 1
                    });

                    return {
                        items: {
                            items: offerDetailsData
                        }
                    };
                }

            }]);
})();