(function () {
    'use strict';

    define(['deviceDetailsCtrl'], function () {
        describe('src/main/modules/exBuyflow/controllers/deviceDetailsCtrl.spec.js', function () {
            describe('deviceDetailsCtrl controller of exBuyflow', function () {
                var $rootScope, controller, scope, contentService, exCommonConstants, exCqTranslatorKeyService;

                contentService = jasmine.createSpyObj('contentService',
                    ['getProductOverviewContent', 'getProductFeaturesContent', 'getProduct360Images',
                        'getProductLegalPaths', 'getProductLegalContent']);

                contentService.getProductOverviewContent.and.returnValue({
                    'then': function (callback) {
                        callback(true);
                    }
                });

                contentService.getProductFeaturesContent.and.returnValue({
                    'then': function (callback) {
                        callback(true);
                    }
                });

                contentService.getProduct360Images.and.returnValue({
                    'then': function (callback) {
                        callback(true);
                    }
                });

                contentService.getProductLegalPaths.and.returnValue({
                    'then': function (callback) {
                        contentService.getProductLegalContent.and.returnValue({
                            'then': function (callback) {
                                var unescapedHTML = ['&amp;', '&lt;'];
                                callback(unescapedHTML);
                            }
                        });
                        callback(true);
                    }
                });

                exCqTranslatorKeyService = jasmine.createSpyObj('exCqTranslatorKeyService',
                    ['getCqTranslatorKeys']);

                exCqTranslatorKeyService.getCqTranslatorKeys.and.returnValue({
                    'then': function (callback) {
                        callback(true);
                    }
                });

                beforeEach(function () {
                    module('exBuyflow', {
                        contentService: contentService,
                        exCqTranslatorKeyService: exCqTranslatorKeyService
                    });


                    inject(function ($injector) {
                        exCommonConstants = $injector.get('exCommonConstants');
                        controller = $injector.get('$controller');
                        $rootScope = $injector.get('$rootScope');
                        scope = $rootScope.$new();
                    });
                    scope.deviceConfig = {
                        selectedSku: {
                            skuID: 'sku8040302',
                            devicePageURL: '/content/att/cellphones/iphone/apple-iphone-7/'
                        }
                    };
                    controller('deviceDetailsCtrl', {
                        $scope: scope
                    });

                    $rootScope.$digest();
                });

                describe('general functionality', function () {

                    it('should have all services needed to be defined', function () {
                        expect(contentService.getProductOverviewContent).toBeDefined();
                        expect(contentService.getProductOverviewContent).toBeDefined();
                        expect(contentService.getProductFeaturesContent).toBeDefined();
                        expect(contentService.getProduct360Images).toBeDefined();
                        expect(contentService.getProductLegalPaths).toBeDefined();
                        expect(contentService.getProductLegalContent).toBeDefined();
                        expect(exCqTranslatorKeyService.getCqTranslatorKeys).toBeDefined();
                    });

                    it('should have all services needed to be called on broadcast', function () {
                        var data = {
                            devicePageURL: '/content/att/cellphones/iphone/apple-iphone-7/',
                            skuId: 'sku8040302',
                            'selectedSku': {
                                'legalNotes': [{
                                    'adminDisplay': 'California Legal Disclaimer',
                                    'key': 'prop65'
                                }]
                            }
                        };
                        var translatorKeys = [
                            'proposition.header.lbl.prop65',
                            'proposition.content.body.prop65'
                        ];
                        $rootScope.$broadcast(exCommonConstants.event.selectedSkuInFocus, data);
                        expect(contentService.getProductOverviewContent).toHaveBeenCalled();
                        expect(contentService.getProductFeaturesContent).toHaveBeenCalled();
                        expect(contentService.getProduct360Images).toHaveBeenCalled();
                        expect(contentService.getProductLegalPaths).toHaveBeenCalled();
                        expect(contentService.getProductLegalContent).toHaveBeenCalled();
                        expect(exCqTranslatorKeyService.getCqTranslatorKeys).toHaveBeenCalledWith(translatorKeys);
                    });

                    it('should check whether to display review accordian or not', function () {
                        // Should return true if renderBV is true and rating is greater than 0
                        var renderBV = true,
                            rating = 5,
                            result;
                        result = scope.reviewAccordianToBeDisplayed(renderBV, rating);
                        expect(result).toEqual(true);

                        // Should return false if renderBV is true and rating is not greater than 0
                        renderBV = true,
                        rating = 0,
                        result = scope.reviewAccordianToBeDisplayed(renderBV, rating);
                        expect(result).toEqual(false);

                        // Should return false if renderBV is false
                        renderBV = false,
                        rating = 5,
                        result = scope.reviewAccordianToBeDisplayed(renderBV, rating);
                        expect(result).toEqual(false);
                    });
                });

            });

        });
    });
})();
