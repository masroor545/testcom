(function () {
    'use strict';

    define(['accessorySubtotalTooltipCtrl'], function () {
        describe('src/main/modules/exBuyflow/controllers/accessorySubtotalTooltipCtrl.spec.js', function () {
            describe('accessorySubtotalTooltipCtrl of exBuyflow', function () {
                var $controller, $scope, $rootScope, exCqTranslatorKeyService;

                exCqTranslatorKeyService = jasmine.createSpyObj('exCqTranslatorKeyService',
                    ['getCqTranslatorKeys']);

                exCqTranslatorKeyService.getCqTranslatorKeys.and.returnValue({
                    'then': function (callback) {
                        callback(true);
                    }
                });

                beforeEach(function () {
                    module('exBuyflow', {
                        exCqTranslatorKeyService: exCqTranslatorKeyService
                    });
                    inject(function ($injector) {
                        $controller = $injector.get('$controller');
                        $rootScope = $injector.get('$rootScope');
                    });
                    $scope = $rootScope.$new();
                    $controller('accessorySubtotalTooltipCtrl', {
                        $scope: $scope
                    });
                });

                describe('accessory subtotal tooltip details', function () {

                    it('should have all the initial scope variables defined', function () {
                        expect($scope.fetchSubtotalTooltipDetails).toBeDefined();
                        expect($scope.subtotalTooltipDetails).toBeDefined();
                        expect(exCqTranslatorKeyService.getCqTranslatorKeys).toBeDefined();

                    });

                    it('should have called the CqTranslatorKeyService to get the legal content', function () {
                        var subtotalTooltipKeys = [
                            'label.exup.subtotal.description'
                        ];
                        $scope.fetchSubtotalTooltipDetails();
                        expect(exCqTranslatorKeyService.getCqTranslatorKeys).toHaveBeenCalled();
                        expect(exCqTranslatorKeyService.getCqTranslatorKeys).toHaveBeenCalledWith(subtotalTooltipKeys);
                    });
                });

            });

        });
    });

})();