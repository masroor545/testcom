(function () {
    'use strict';

    angular.module('exBuyflow')

        .controller('deviceDetailsCtrl', ['$scope', '$controller', '$rootScope', 'contentService', 'exCommonConstants',
            'exCqTranslatorKeyService', 'accessoryRecommenderService', 'favStoreService',
            function ($scope, $controller, $rootScope, contentService, exCommonConstants,
                exCqTranslatorKeyService, accessoryRecommenderService, favStoreService) {

                $scope.deviceDetails = {
                    showFeatureContent: false,
                    showImagesContent: false,
                    showDeviceLegalContent: false,
                    showOverviewContent: false
                };
                $scope.deviceConfig = {};
                $scope.displayDeviceDetails = displayDeviceDetails;
                $scope.triggerAddToCart = triggerAddToCart;
                $scope.reviewAccordianToBeDisplayed = reviewAccordianToBeDisplayed;
                $scope.accessoryCategories =
                    typeof($scope.accessoryCategories) !== 'undefined' ? $scope.accessoryCategories : '[]';
                $scope.categories = JSON.parse($scope.accessoryCategories);
                $scope.RSI = $scope.relaxStoreIndicator;

                //scope level broadcasts that gets set when the device details information is returned
                //returns us an object that has SkuID and DevicePathPagePath
                $scope.$on(exCommonConstants.event.selectedSkuInFocus, function (event, data) {
                    $scope.deviceConfig = data;
                    activate(data);
                });

                /**
                 * Calls addToCart function when user has clicked add to cart button from device details
                 * @public
                 */
                function triggerAddToCart () {
                    $rootScope.$broadcast(exCommonConstants.event.deviceAddedFromDetails, true);
                }

                /**
                 * Gets the translator keys and their content for the legalNotes array from the getDeviceProductDetails
                 *  and exCqTranslatorKey services.
                 * @function getLegalNotesTranslatorKeys
                 * @param {Array} legalNotes Legal notes array from the getDeviceProductDetails service.
                 * @returns {Array} Legal notes translator keys ready for submission to the exCqTranslatorKey service.
                 * @private
                 */
                function getLegalNotesTranslatorKeys (legalNotes) {
                    var partialHeader = 'proposition.header.lbl.';
                    var partialBody = 'proposition.content.body.';
                    var translatorKeys = [];
                    var legalNoteContent = [];

                    // catch undefined and null
                    legalNotes = legalNotes || [];

                    // step through each object in the legalNotes array and create head/body translator keys for each.
                    for (var i = 0, len = legalNotes.length; i < len; i++) {
                        translatorKeys.push(partialHeader + legalNotes[i].key);
                        translatorKeys.push(partialBody + legalNotes[i].key);
                    }

                    if (translatorKeys !== []) {
                        exCqTranslatorKeyService.getCqTranslatorKeys(translatorKeys).then(function (cqContent) {
                            // step through the translator keys, two keys at once. One for the head, another for the body.
                            for (var i = 0, len = translatorKeys.length; i < len; i += 2) {
                                legalNoteContent.push({
                                    head: cqContent[translatorKeys[i]],
                                    body: cqContent[translatorKeys[i + 1]]
                                });
                            }
                        });
                    }

                    return legalNoteContent;
                }

                /**
                 * Scope function setter to show or hide the device details section
                 * @public
                 * @param {boolean} visible
                 */
                function displayDeviceDetails (visible) {
                    if (visible === false) {
                        $scope.deviceConfig.openReviewsTab = false;
                        $scope.deviceConfig.legalAccordionOpen = false;
                        $scope.deviceDetails.openQATab = false;
                        $scope.deviceDetails.openImageTab = false;
                    }
                    $scope.deviceConfig.displayDeviceDetails = visible;
                }

                /**
                 * Prefetch the accessory recommendations from the REX service, so that they
                 * are available for the accessory recommender page
                 * @param {object} data Device details of the device in focus
                 */
                function prefetchAccessoryRecommendations (data) {
                    var favStoreId = favStoreService.getFavStoreIdFromSessionStorage();

                    if (data.selectedSku.skuExcludedFromBOPISForFlow === false
                        && favStoreId !== ''
                        && favStoreId !== undefined
                        && favStoreId !== null) {

                        // Passing RSI indicator and favStoreId to REX if favStore is available
                        accessoryRecommenderService.getAccessoryRecommendations(data.skuId, $scope.categories,
                            {
                                'favStoreId': favStoreId,
                                'RSI': $scope.RSI,
                                'hideSpinner': true
                            });
                    } else {
                        // Not passing RSI indicator and favStoreId to REX if favStore is not avilable
                        accessoryRecommenderService.getAccessoryRecommendations(data.skuId, $scope.categories, {'hideSpinner': true});
                    }
                }

                /**
                 * Calls the product tabs services for each tab and outputs the result
                 * @function getRecommendedAccessories
                 * @param {object} data Object from the broadcast which returns the sku id and productDetailsPagePath
                 * @returns {html} Returned result of each tab
                 */
                function activate (data) {
                    var numberOnlySku = data.skuId.substring(3);

                    contentService.getProductOverviewContent(data.devicePageURL).then(function (overviewContent) {
                        $scope.deviceDetails.overviewContent = overviewContent;
                        $scope.deviceDetails.showOverviewContent = $scope.deviceDetails.overviewContent !== undefined &&
                            $scope.deviceDetails.overviewContent.length !== 0;
                    });

                    contentService.getProductFeaturesContent(data.devicePageURL).then(function (featureContent) {
                        $scope.deviceDetails.featureContent = featureContent;
                        $scope.deviceDetails.showFeatureContent = $scope.deviceDetails.featureContent !== undefined &&
                            $scope.deviceDetails.featureContent.length !== 0;
                    });

                    $scope.deviceDetails.legalNotes = getLegalNotesTranslatorKeys(data.selectedSku.legalNotes);

                    contentService.getProduct360Images(numberOnlySku).then(function (device360Images) {
                        $scope.deviceDetails.imagesContent = device360Images;
                        $scope.deviceDetails.showImagesContent = $scope.deviceDetails.imagesContent !== undefined &&
                            $scope.deviceDetails.imagesContent.length !== 0;
                    });

                    contentService.getProductLegalPaths(data.devicePageURL).then(function (deviceLegalPaths) {
                        $scope.deviceDetails.deviceLegalPaths = deviceLegalPaths;
                        contentService.getProductLegalContent(deviceLegalPaths).then(function (deviceLegalContent) {
                            $scope.deviceDetails.deviceLegal = deviceLegalContent;
                            $scope.deviceDetails.showDeviceLegalContent = $scope.deviceDetails.deviceLegal !== undefined &&
                                $scope.deviceDetails.deviceLegal.length !== 0;
                        });
                    });

                    prefetchAccessoryRecommendations(data);
                }

                /**
                 * Checks whether review accordian is to be displayed or not
                 * @function reviewAccordianToBeDisplayed
                 * @param {Boolean} renderBV flag tells whether bazaar voice is rendered or not
                 * @param {number} rating of the selected device
                 * @returns {boolean} true/false
                 */
                function reviewAccordianToBeDisplayed (renderBV, rating) {
                    return (renderBV === true && rating !== 0);
                }
            }
        ]);
})();
