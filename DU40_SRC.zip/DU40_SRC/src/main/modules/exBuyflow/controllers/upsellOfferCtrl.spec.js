(function () {
    'use strict';

    define(['upsellOfferCtrl'], function () {
        describe('src/main/modules/exBuyflow/controllers/upsellOfferCtrl.spec.js', function () {
            describe('upsellOfferCtrl of exBuyflow', function () {
                var controller, mockUpsellController, scope, $modal, $rootScope, upsellOfferSrv, exCartService, selectedSkuSrv, reportingDataSrv;
                var offerDetails = Endpoint_upsellOfferDetailsApi.get_upsell_offer_details;
                var offerContentDetails = Endpoint_upsellOfferContentNode.get_legal_content_node;
                var addToCartDetails = Endpoint_addToCart.upsell_add_to_cart;

                beforeEach(function () {
                    module('exBuyflow');

                    reportingDataSrv = jasmine.createSpyObj('reportingDataSrv', ['getAddToCartUpsellPayload', 'getOnProceedToCheckoutPayload', 'getUpsellPayload']);
                    reportingDataSrv.getAddToCartUpsellPayload.and.returnValue({
                        items: [{'itemSku': 'sku8040303'}]
                    });

                    reportingDataSrv.getOnProceedToCheckoutPayload.and.returnValue({
                        items: [{itemSku: 'sku1234567'}]
                    });

                    inject(function ($injector) {
                        controller = $injector.get('$controller');
                        $rootScope = $injector.get('$rootScope');
                        selectedSkuSrv = $injector.get('selectedSkuSrv');
                        scope = $rootScope.$new();

                        upsellOfferSrv = jasmine.createSpyObj('upsellOfferSrv',
                            [
                                'getUpsellOfferDetails',
                                'getUpsellOfferContentDetails',
                                'skipToCheckout',
                                'setRequiredOfferId',
                                'getRequiredOfferId'
                            ]);
                        upsellOfferSrv.getUpsellOfferDetails.and.returnValue({
                            'then': function (callback) {
                                callback(offerDetails.result);
                            }
                        });
                        upsellOfferSrv.getUpsellOfferContentDetails.and.returnValue({
                            'then': function (callback) {
                                callback(offerContentDetails.result);
                            }
                        });
                        upsellOfferSrv.skipToCheckout.and.returnValue({
                            'then': function (callback) {
                                callback(offerDetails.result);
                            }
                        });
                        upsellOfferSrv.setRequiredOfferId.and.returnValue({
                            'offerId': '200004'
                        });

                        $modal = jasmine.createSpyObj('$modal', ['open']);
                        $modal.open.and.returnValue(true);
                        spyOn(selectedSkuSrv, 'setSelectedDevice');
                        exCartService = jasmine.createSpyObj('exCartService', ['addItemToCart']);
                        exCartService.addItemToCart.and.returnValue({
                            'then': function (callback) {
                                callback(addToCartDetails.result);
                            }
                        });
                        mockUpsellController = controller('upsellOfferCtrl', {
                            $scope: scope,
                            $modal: $modal,
                            upsellOfferSrv: upsellOfferSrv,
                            exCartService: exCartService,
                            reportingDataSrv: reportingDataSrv
                        });

                    });
                    $rootScope.$digest();
                });

                afterEach(function () {
                    selectedSkuSrv.setSelectedDevice.calls.reset();
                    $modal.open.calls.reset();
                });

                it('should return upsell details to view', function () {
                    expect(mockUpsellController).toBeDefined();
                    expect(scope.upsellOfferDetails.offerDetails).toBeDefined();
                    expect(scope.upsellOfferDetails.offerContentDetails).toBeDefined();
                    expect(scope.upsellOfferDetails.offerDetails[0].redirectURL).toEqual('/shop/xpress/accessory-service-recommender.html');
                    expect(scope.upsellOfferDetails.offerDetails[0].skuId).toEqual('sku8040303');
                    expect(scope.upsellOfferDetails.offerDetails[0].productId).toEqual('prod8730224');
                    expect(scope.upsellOfferDetails.offerDetails[0].displayName).toEqual('Apple iPhone 7 - 32GB');
                    expect(scope.upsellOfferDetails.offerDetails[0].model).toEqual('iPhone 7 32GB');
                    expect(scope.upsellOfferDetails.offerDetails[0].multiSkuOffer).toEqual(true);
                    expect(scope.upsellOfferDetails.offerContentDetails[0].headLine).toEqual(offerContentDetails.result['offercontent/200004']['pageTitle'][0]);
                    expect(scope.upsellOfferDetails.offerContentDetails[0].subheadLine).toEqual(offerContentDetails.result['offercontent/200004']['navTitle'][0]);
                    expect(scope.upsellOfferDetails.offerContentDetails[0].inBodyContent).toEqual(offerContentDetails.result['offercontent/200004']['subtitle'][0]);
                    expect(scope.upsellOfferDetails.offerContentDetails[0].legalContent).toEqual(offerContentDetails.result['offercontent/200004']['jcr:description'][0]);
                    expect(scope.upsellOfferDetails.offerDetails[0].defaultSku).toEqual('sku8040300');
                    expect(scope.upsellOfferDetails.offerDetails[0].offerDueTodayTotal).toEqual(0);
                    expect(scope.upsellOfferDetails.offerDetails[0].offerDueMonthlyTotal).toEqual(0);
                    expect(scope.upsellOfferDetails.offerId).toEqual('200004');
                });

                it('should call getUpsellOfferDetails method on upsellOfferSrv on calling upsellOfferSrv', function () {
                    expect(upsellOfferSrv.getUpsellOfferDetails).toHaveBeenCalled();
                    expect(scope.upsellOfferDetails.offerDetails).toBeDefined();
                    expect(scope.upsellOfferDetails.showHeroImage).toBeDefined();
                    expect(scope.upsellOfferDetails.isMultiSkuOffer).toEqual(true);
                });

                it('should expose a cart item', function () {
                    scope.upsellOfferAddItemToCart();
                    var cartItem = scope.upsellOfferDetails.getAddToCartItems.items;
                    expect(cartItem).toBeDefined();
                    expect(typeof cartItem.items[0].valueMap).toEqual('object');
                    expect(typeof cartItem.items[0].valueMap.contractType).toEqual('string');
                    expect(typeof cartItem.items[0].valueMap.contractLength).toEqual('string');
                    expect(cartItem.items[0].quantity).toEqual(1);
                    expect(typeof cartItem.items[0].catalogRefId).toEqual('string');
                    expect(typeof cartItem.items[0].productId).toEqual('string');
                });

                it('should add the upsell offer item to cart', function () {
                    scope.upsellOfferAddItemToCart();
                    expect(exCartService.addItemToCart.calls.mostRecent().args.length).toEqual(2);
                    expect(exCartService.addItemToCart.calls.mostRecent().args[0]).toEqual(scope.upsellOfferDetails.getAddToCartItems);
                    expect(typeof exCartService.addItemToCart.calls.mostRecent().args[1]).toEqual('object');
                });

                it('should make a post call to back-end', function () {
                    scope.onSkipToCheckout();
                    expect(upsellOfferSrv.skipToCheckout).toHaveBeenCalled();
                });

                // click on get this offer button and open modal
                it('should update the device config', function () {
                    selectedSkuSrv.setSelectedDevice.calls.reset();
                    scope.multiSkuUpsellOffer();
                    expect(selectedSkuSrv.setSelectedDevice).toHaveBeenCalled();
                    expect($modal.open).toHaveBeenCalled();
                });

                it('should open the see offer details modal', function () {
                    scope.openSeeOfferDetailsModal();
                    expect($modal.open).toHaveBeenCalled();
                });

                it('should save the offer id', function () {
                    var setOfferId = upsellOfferSrv.setRequiredOfferId();
                    expect(scope.upsellOfferDetails.offerDetails[0].offerId).toEqual(setOfferId.offerId);
                });

                describe('should check add to cart accessory reporting functionalities', function () {

                    beforeEach(function () {
                        spyOn(scope, '$emit').and.callThrough();
                        scope.$emit.calls.reset();
                    });

                    it('should check add to cart accessory reporting functionalities from accessory recommender page', function () {
                        var expectedReportingObjectSubmit = jasmine.objectContaining({
                                eventAction: 'formSubmit',
                                eventCode: 'DS_Upgrade_Cart_Add_Submit',
                                additionaldata: jasmine.objectContaining({
                                    items: [jasmine.objectContaining({itemSku: scope.upsellOfferDetails.offerDetails[0].skuId})]
                                })
                            }),
                            expectedReportingObjectResponse = jasmine.objectContaining({
                                eventAction: 'formResponse',
                                eventCode: 'DS_Upgrade_Cart_Add_Submit',
                                additionaldata: jasmine.objectContaining({
                                    items: [jasmine.objectContaining({itemSku: scope.upsellOfferDetails.offerDetails[0].skuId})]
                                })
                            });
                        scope.upsellOfferAddItemToCart();
                        expect(scope.$emit).toHaveBeenCalledWith('DS_Reporting_Event', expectedReportingObjectSubmit, jasmine.any(Object));
                        expect(scope.$emit).toHaveBeenCalledWith('DS_Reporting_Event', expectedReportingObjectResponse, jasmine.any(Object));
                        scope.$apply();
                    });

                    it('should check add to cart accessory reporting functionalities from accessory recommender page', function () {
                        var expectedReportingObjectSubmit = jasmine.objectContaining({
                                eventAction: 'formSubmit',
                                eventCode: 'DS_Upgrade_Cart_Preorder_Submit',
                                additionaldata: jasmine.objectContaining({
                                    items: [jasmine.objectContaining({itemSku: scope.upsellOfferDetails.offerDetails[0].skuId})]
                                })
                            }),
                            expectedReportingObjectResponse = jasmine.objectContaining({
                                eventAction: 'formResponse',
                                eventCode: 'DS_Upgrade_Cart_Preorder_Submit',
                                additionaldata: jasmine.objectContaining({
                                    items: [jasmine.objectContaining({itemSku: scope.upsellOfferDetails.offerDetails[0].skuId})]
                                })
                            });
                        scope.upsellOfferDetails.offerDetails[0].preOrderable = true;
                        scope.upsellOfferAddItemToCart();
                        expect(scope.$emit).toHaveBeenCalledWith('DS_Reporting_Event', expectedReportingObjectSubmit, jasmine.any(Object));
                        expect(scope.$emit).toHaveBeenCalledWith('DS_Reporting_Event', expectedReportingObjectResponse, jasmine.any(Object));
                        scope.$apply();
                    });

                    it('should check add to cart accessory reporting functionalities from accessory recommender page', function () {
                        var expectedReportingObjectSubmit = jasmine.objectContaining({
                                eventAction: 'formSubmit',
                                eventCode: 'DS_Upgrade_Proceed_To_Checkout_Submit'
                            }),
                            expectedReportingObjectResponse = jasmine.objectContaining({
                                eventAction: 'formResponse',
                                eventCode: 'DS_Upgrade_Proceed_To_Checkout_Submit'
                            });
                        scope.onSkipToCheckout();
                        expect(scope.$emit).toHaveBeenCalledWith('DS_Reporting_Event', expectedReportingObjectSubmit, jasmine.any(Object));
                        expect(scope.$emit).toHaveBeenCalledWith('DS_Reporting_Event', expectedReportingObjectResponse, jasmine.any(Object));
                        scope.$apply();
                    });

                    it('should check page load event called when opening multisku offer modal', function () {
                        var friendlyPageName = 'DS Upgrade Add A Line Device Details Pg',
                            virtualUrl = '/shop/xpress/virtual/device-details.html+AddALineOffer';
                        scope.multiSkuUpsellOffer();
                        expect(scope.$emit).toHaveBeenCalledWith('DS_Reporting_PageLoad_Event', friendlyPageName, virtualUrl);
                    });

                    // check that link click event fires when user clicks on No, thanks on upsell offer page
                    it('should fire link clink event with appropriate value when user clicks on No, thanks on upsell offer page', function () {
                        var expectedReportingObject = jasmine.objectContaining({
                            eventAction: 'linkClick',
                            eventCode: 'Link_Click',
                            additionaldata: {
                                'linkName': 'No, thanks',
                                'linkPosition': 'Body',
                                'linkDestinationURL': '/checkout/onepagecheckout.html'
                            }
                        });
                        scope.onSkipToCheckout();
                        expect(scope.$emit).toHaveBeenCalledWith('DS_Reporting_Event', expectedReportingObject, jasmine.anything());
                        scope.$apply();
                    });
                });
            });
        });
    });
})();
