(function () {
    'use strict';

    angular.module('exBuyflow')

        .controller('deviceRecommenderCtrl', ['$scope', '$window', '$modal', '$filter', '$location', '$q', 'deviceRecommenderSrv', 'exCommonConstants', 'exBuyflowConstants', 'upgradingUserInfoSrv', 'reportingDataSrv',
            'selectedSkuSrv', 'exCqTranslatorKeyService', 'imagePathService', 'profileInfoService',
            'favStoreService', 'deviceConfigSrv', '$rootScope', 'exHelpUtils',
            function ($scope, $window, $modal, $filter, $location, $q, deviceRecommenderSrv, exCommonConstants, exBuyflowConstants, upgradingUserInfoSrv, reportingDataSrv,
                selectedSkuSrv, exCqTranslatorKeyService, imagePathService, profileInfoService,
                favStoreService, deviceConfigSrv, $rootScope, exHelpUtils) {

                $scope.initDevicesLoaded = parseInt($scope.initialDevicesLoaded);
                $scope.deviceRecommender = {
                    items: [],
                    displayedItems: [],
                    displayedTotalItems: [],
                    filteredItems: [],
                    filteredTotalItems: [],
                    filterOptions: [],
                    selectionCount: 0,
                    showDeviceFilterContent: false,
                    itemPrice: undefined,
                    totalRecommendedDevices: [],
                    devicesToBeDisplayed: 0,
                    upgradingDeviceType: undefined,
                    commitmentTerms: undefined,
                    shortLegalContent: undefined,
                    deviceFirstSKU: undefined,
                    heroDeviceTileColorTheme: undefined,
                    showRecommender: false,
                    upgradingDeviceDetails: undefined
                };
                $scope.imgUrl = [];
                $scope.flairFlag = [];

                /**
                 * Scope function to show device legal Overlay
                 * @param {String} deviceSkuId
                 */
                $scope.showDeviceLegalDetailsOverlay = function (deviceSkuId) {
                    selectedSkuSrv.setSelectedDevice(deviceSkuId);
                    $modal.open({
                        templateUrl: '/shop/xpress/modals/device-legaldetails.modal.html',
                        windowClass: 'modal-fullscreen'
                    });

                    // Fire link click event when user clicks on see price details link for devices
                    $scope.$emit(exCommonConstants.event.DS_REPORTING_EVENT, {
                        eventAction: 'linkClick',
                        eventCode: 'Link_Click',
                        additionaldata: {
                            'linkName': exBuyflowConstants.linkName.longLegalLink,
                            'linkPosition': exBuyflowConstants.linkPosition,
                            'linkDestinationURL': exBuyflowConstants.virtualUrl.deviceRecommenderDetailsUrl
                        }
                    }, $scope);
                };

                /**
                 * Scope function that displays the device config with the currently selected sku
                 * @param {String} skuId - sku ID of selected device
                 * @param {boolean} confidenceMet - Selected device is Hero device or not
                 */
                $scope.selectSku = function (skuId, deviceTileIndex, confidenceMet) {
                    selectedSkuSrv.setSelectedDevice(skuId);
                    var modalInstance = $modal.open({
                        templateUrl: '/shop/xpress/modals/device-details.modal.html',
                        windowClass: 'modal-fullscreen'
                    });

                    // Promise resolves when the modal close functionality is triggered.
                    if (modalInstance !== undefined && modalInstance.result !== undefined) {
                        modalInstance.result.then(function () {
                            // This block is never reached. Close is acting like a dismiss due to a Zippy code change.
                        }, function () {
                            // fired when user leaves details page any other way
                            showRecommender();
                        });
                    }

                    if (confidenceMet === false || confidenceMet === undefined) {
                        confidenceMet = ($scope.deviceRecommender.items[0].skuId === skuId) ? true : false;
                    }

                    $scope.$emit(exCommonConstants.event.DS_REPORTING_EVENT, {
                        eventAction: 'systemEvent',
                        eventCode: 'DS_System_Upgrade_Device_Details_Recommend_Display',
                        additionaldata: reportingDataSrv.getDeviceRecommenderDevicePayload($scope.deviceRecommender.items[deviceTileIndex],
                            deviceTileIndex, $scope.deviceRecommender.upgradingDeviceDetails.ctn)
                    }, $scope);

                    //Fire page load event when Device displayed on device recommender page as a modal. Should only be fired if getting called to show modal.
                    if (confidenceMet === true) {
                        $scope.$emit(exCommonConstants.event.DS_REPORTING_PAGELOAD_EVENT);
                    } else {
                        $scope.$emit(exCommonConstants.event.DS_REPORTING_PAGELOAD_EVENT);
                    }
                };

                /**
                * gets the recommended devices from recommender API, their respective prices and short legal
                * @function getRecommendedDevices
                * @param {number} devicesToBeLoaded
                */
                $scope.getRecommendedDevices = function (devicesToBeLoaded) {
                    var skuids;

                    // Slice the number of filtered items needed
                    var loadedFilteredItemsCount = $scope.deviceRecommender.filteredItems.length || 0;
                    var newFilteredItemsCount = 0;
                    while (newFilteredItemsCount < devicesToBeLoaded && $scope.deviceRecommender.items.length < $scope.deviceRecommender.totalRecommendedDevices.length) {
                        newFilteredItemsCount = $scope.deviceRecommender.filteredItems.length - loadedFilteredItemsCount;
                        var devicesToSlice = Math.min(
                            $scope.deviceRecommender.items.length + (devicesToBeLoaded - newFilteredItemsCount),
                            $scope.deviceRecommender.totalRecommendedDevices.length);
                        $scope.deviceRecommender.items = $scope.deviceRecommender.totalRecommendedDevices.slice(0, devicesToSlice);
                        $scope.deviceRecommender.filteredItems = $filter('selectionFilter')($scope.deviceRecommender.items, $scope.deviceRecommender.filterOptions);
                    }

                    $scope.deviceRecommender.items = $scope.deviceRecommender.totalRecommendedDevices.slice(0, $scope.deviceRecommender.devicesToBeDisplayed);

                    // If filtered items is empty then we have no filters applied
                    $scope.deviceRecommender.displayedItems = $scope.deviceRecommender.filteredItems.length > 0 ?
                        $scope.deviceRecommender.filteredItems : $scope.deviceRecommender.items;
                    $scope.deviceRecommender.displayedTotalItems = $scope.deviceRecommender.filteredItems.length > 0 ?
                        $scope.deviceRecommender.filteredItems : $scope.deviceRecommender.totalRecommendedDevices;

                    // Applying FairFlag Filter and sorting the results
                    $scope.filterFlairFlags($scope.deviceRecommender.displayedItems);

                    // Gets hero device color theme based on hex value
                    $scope.deviceRecommender.heroDeviceTileColorTheme = deviceConfigSrv.getColorTheme($scope.deviceRecommender.items[0].htmlColor);

                    // Pass comma separated skuids to getItemPriceData function
                    skuids = exHelpUtils.uniqueByKey($scope.deviceRecommender.items.map(function (item) {
                        return item.skuId;
                    }).concat($scope.deviceRecommender.filteredItems.map(function (filteredItem) {
                        return filteredItem.skuId;
                    })
                    ), function (item) { return item; }).join(',');

                    deviceRecommenderSrv.getItemPriceData(skuids).then(function (result) {
                        var commitmentTerms = {};
                        $scope.deviceRecommender.itemPrice = result.payload;
                        angular.forEach($scope.deviceRecommender.itemPrice, function (itemValue, itemKey) {
                            var commitmentTerm = {};
                            commitmentTerm.name = itemValue.contractType;
                            commitmentTerm.leaseTotalMonths = itemValue.contractLength;
                            commitmentTerm.deviceType = itemValue.deviceType;
                            commitmentTerms[itemKey] = commitmentTerm;
                            // calling method to get all device image paths
                            $scope.imgUrl[itemKey] = imagePathService.getXpressImagePath(
                                itemValue.brand, null, itemValue.shortDisplayName, itemValue.color, '-hero.png');
                        });
                        $scope.deviceRecommender.commitmentTerms = commitmentTerms;

                        $scope.fetchShortLegalContentForDevices($scope.deviceRecommender.commitmentTerms);
                    });
                };

                /**
                 * Filters and sorts the flairFlags against each skuId on the basis of business logic,
                 * and accordingly flair flag is displayed against each device on device recommender
                 * @function filterFlairFlags
                 * @param {Array} devicesToBeDisplayed
                 */
                $scope.filterFlairFlags = function (devicesToBeDisplayed) {
                    angular.forEach(devicesToBeDisplayed, function (deviceItem) {
                        var temp = [];
                        $scope.flairFlag[deviceItem.skuId] = {};
                        angular.forEach(deviceItem.displayContentItems, function (contentItem) {
                            if (contentItem.enable === true &&
                                contentItem.displayType === 'ribbon' &&
                                contentItem.contentType === 'image' &&
                                (contentItem.flowTypes).indexOf('UP') !== -1) {
                                temp.push(contentItem);
                                temp = $filter('orderBy')(temp, 'marketingPriority', false);
                            }
                        });

                        if (temp.length > 0) {
                            $scope.flairFlag[deviceItem.skuId] = temp[0];
                        } else {
                            $scope.flairFlag[deviceItem.skuId] = 'none';
                        }
                    });
                };

                /**
                 * Gets more recommended devices from recommender API and increases the number of devices to be displayed
                 * @function viewMoreDevices
                 * @param {number} devicesToBeLoaded
                 */
                $scope.viewMoreDevices = function (devicesToBeLoaded) {
                    // Update the number of devices that should be listed in the view
                    $scope.deviceRecommender.devicesToBeDisplayed = Math.min($scope.deviceRecommender.devicesToBeDisplayed +
                        parseInt(devicesToBeLoaded), $scope.deviceRecommender.totalRecommendedDevices.length);
                    // Call getRecommendedDevices function to display recommended devices and their prices
                    $scope.getRecommendedDevices(parseInt(devicesToBeLoaded));
                };


                /**
                 * Identify cms key for default price of recommended sku and call cms translator key service to get short legal content
                 * @function fetchShortLegalContentForDevices
                 * @param {list} commitmentTerms
                 */
                $scope.fetchShortLegalContentForDevices = function (commitmentTerms) {
                    var cmsKeys = [], legalCmsKey, commitRef, deviceTypeRef, commitRefObj = {};

                    angular.forEach(commitmentTerms, function (commitmentTerm) {

                        if (commitmentTerm.name === 'regular') {
                            commitRefObj = exCommonConstants.commitmentTermCmsKeyPartForLegal[commitmentTerm.leaseTotalMonths];
                        } else {
                            commitRefObj = exCommonConstants.commitmentTermCmsKeyPartForLegal[commitmentTerm.name];
                        }

                        commitRef = commitRefObj === undefined ? commitmentTerm.name : commitRefObj.termKey;

                        deviceTypeRef = (commitRefObj !== undefined && commitRefObj.deviceType !== undefined) ? commitRefObj.deviceType : commitmentTerm.deviceType;

                        legalCmsKey = exCommonConstants.shortLegalContentCmsKey.replace('{0}', commitRef);

                        legalCmsKey = legalCmsKey.replace('{1}', deviceTypeRef);

                        commitmentTerm.legalCmsKey = legalCmsKey;

                        cmsKeys.push(legalCmsKey);
                    });

                    exCqTranslatorKeyService.getCqTranslatorKeys(cmsKeys).then(function (result) {
                        $scope.deviceRecommender.shortLegalContent = result;
                    });
                };

                /**
                 * Checks if user has selected device first and then choosen to upgrade line.
                 * Open the overlay for selected device to upgrade inplace of hero device.
                 * @function checkDeviceFirst
                 */
                $scope.checkDeviceFirst = function () {
                    $scope.deviceRecommender.deviceFirstSKU = $location.search().skuId;
                    if ($scope.deviceRecommender.deviceFirstSKU !== undefined) {
                        $scope.selectSku($scope.deviceRecommender.deviceFirstSKU);
                    } else {
                        // Determines if initial device should be maximized
                        var confidenceMet = $scope.deviceRecommender.items[0].score >= $scope.heroConfidenceThreshold;
                        if (confidenceMet === true && $scope.displayHeroDevice === 'true') {
                            $scope.selectSku($scope.deviceRecommender.items[0].skuId, 0, true);
                        } else {
                            showRecommender();
                        }
                    }
                };

                /**
                 * Identify hero device and check source of respose should be REX api.
                 * To apply the background color of hero device tile
                 * @function getHeroDeviceBackgroundTheme
                 * @param {object} heroDeviceDetail
                 * @return {string} light-theme/dark-theme
                 */
                $scope.getHeroDeviceBackgroundTheme = function (heroDeviceDetail) {
                    if (heroDeviceDetail.skuId === $scope.deviceRecommender.items[0].skuId &&
                        heroDeviceDetail.source === 'rex' &&
                        $scope.deviceRecommender.heroDeviceTileColorTheme === 'light') {

                        return 'light-theme';

                    } else if (heroDeviceDetail.skuId === $scope.deviceRecommender.items[0].skuId &&
                        heroDeviceDetail.source === 'rex' &&
                        $scope.deviceRecommender.heroDeviceTileColorTheme === 'dark') {

                        return 'dark-theme';
                    }
                };

                /**
                 * Show recommender with global nav header and footer
                 * @function showRecommender
                 */
                function showRecommender () {
                    $rootScope.$broadcast(exCommonConstants.event.showGlobalNav, null);
                    $scope.deviceRecommender.showRecommender = true;

                    $scope.$emit(exCommonConstants.event.DS_REPORTING_EVENT, {
                        eventAction: 'systemEvent',
                        eventCode: 'DS_System_Upgrade_Device_Recommend_Display',
                        additionaldata: reportingDataSrv.getDeviceRecommenderDevicePayload($scope.deviceRecommender.items[0], -1,
                            $scope.deviceRecommender.upgradingDeviceDetails.ctn)
                    }, $scope);
                    $scope.$emit(exCommonConstants.event.DS_REPORTING_PAGELOAD_EVENT
                    );
                }

                /**
                 * Filters the listed devices with the filter options
                 * Sets the displayed items to the filtered items or items if there are no filtered items
                 * @function filterItems
                 */
                $scope.filterItems = function filterItems () {
                    // Assumes total recommended devices never changes. If it does then both arguments MUST be passed as key to exHelpUtils.memoize.
                    // Both arguments would have to be added because memoize needs a better fingerprint (like the skuIds of totalRecommendedDevices and the stringified filter options) of the arguments.
                    // As it stands totalRecommendedDevices never changes, so a real fingerprint of it is not needed.
                    $scope.deviceRecommender.filteredItems = exHelpUtils.memoize($filter('selectionFilter'),
                        JSON.stringify($scope.deviceRecommender.filterOptions) + 'deviceRecommenderTotalRecommendedDevices')($scope.deviceRecommender.totalRecommendedDevices, $scope.deviceRecommender.filterOptions);

                    $scope.deviceRecommender.displayedItems = $scope.deviceRecommender.filteredItems.length > 0 ?
                        $scope.deviceRecommender.filteredItems : $scope.deviceRecommender.items;
                    $scope.deviceRecommender.displayedTotalItems = $scope.deviceRecommender.filteredItems.length > 0 ?
                        $scope.deviceRecommender.filteredItems : $scope.deviceRecommender.totalRecommendedDevices;

                    // Update selection count
                    $scope.deviceRecommender.selectionCount = $scope.deviceRecommender.filterOptions.reduce(function (count, option) {
                        return count + option.values.filter(function (value) {
                            return value.isSelected;
                        }).length;
                    }, 0);
                };

                /**
                 * Toggles filter open and closed
                 * @function toggleFilter
                 */
                $scope.toggleFilter = function toggleFilter () {
                    $scope.deviceRecommender.showDeviceFilterContent = !$scope.deviceRecommender.showDeviceFilterContent;
                };

                /**
                 * Clears filter selections and resets the number of items to be displayed to the initial devices listed
                 * @function clearFilterSelections
                 * @param {object} event - DOM event
                 */
                $scope.clearFilterSelections = function clearFilterSelections (event) {
                    try {
                        $scope.deviceRecommender.filterOptions.forEach(function (option) {
                            option.values.forEach(function (value) {
                                value.isSelected = false;
                            });
                        });
                        $scope.deviceRecommender.devicesToBeDisplayed = $scope.initDevicesLoaded;
                        $scope.filterItems();
                    } catch (e) {
                        throw e;
                    } finally {
                        event.stopPropagation();
                    }
                };

                /**
                 * Starts up the controller
                 */
                function activate () {
                    var recommenderLoadedDeferred = $q.defer();
                    var recommenderInstance = {
                        loaded: recommenderLoadedDeferred.promise
                    };
                    $rootScope.$broadcast(exCommonConstants.event.hideGlobalNav, null);
                    upgradingUserInfoSrv.getUpgradingDeviceDetailsData().then(function (upgradingDeviceDetails) {
                        $scope.deviceRecommender.upgradingDeviceDetails = upgradingDeviceDetails.payload;

                        recommenderLoadedDeferred.resolve(deviceRecommenderSrv.getRecommendedDevices(upgradingDeviceDetails.payload).then(function (result) {
                            $scope.deviceRecommender.totalRecommendedDevices = result;

                            //gets the initial recommended devices to be displayed from recommender API
                            var x, rexTrueRecommendations = 0;
                            for (x in $scope.deviceRecommender.totalRecommendedDevices) {
                                if ($scope.deviceRecommender.totalRecommendedDevices[x].source === 'rex') {
                                    rexTrueRecommendations += 1;
                                }
                            }
                            if (rexTrueRecommendations < $scope.initDevicesLoaded / 2 || rexTrueRecommendations >= $scope.initDevicesLoaded) {
                                if ($scope.deviceRecommender.totalDevicesLoaded > $scope.deviceRecommender.totalRecommendedDevices.length) {
                                    $scope.deviceRecommender.totalDevicesLoaded = $scope.deviceRecommender.totalRecommendedDevices.length;
                                }
                                $scope.viewMoreDevices($scope.initDevicesLoaded);
                            } else {
                                $scope.deviceRecommender.totalDevicesLoaded = rexTrueRecommendations;
                                $scope.viewMoreDevices(rexTrueRecommendations);
                            }

                            // Adds sorted criteria to be displayed in the filter
                            $scope.deviceRecommender.filterOptions = exBuyflowConstants.deviceFilterOptions.map(function (option) {
                                $scope.deviceRecommender.totalRecommendedDevices.forEach(function (item) {
                                    option.values.push({value: item[option.criterion], isSelected: false});
                                });
                                option.values = exHelpUtils.uniqueByKey(option.values, function (item) {
                                    return item.value;
                                });
                                return option;
                            }).map(function (option) {
                                option.values = option.values.sort(function (a, b) {
                                    var aValue = exBuyflowConstants.deviceFilterPriority.indexOf(a.value);
                                    aValue = aValue !== -1 ? aValue : Number.MAX_VALUE;
                                    var bValue = exBuyflowConstants.deviceFilterPriority.indexOf(b.value);
                                    bValue = bValue !== -1 ? bValue : Number.MAX_VALUE;
                                    if (aValue < bValue) {
                                        return -1;
                                    } else if (aValue > bValue) {
                                        return 1;
                                    } else {
                                        return 0;
                                    }
                                });
                                return option;
                            });

                            // Calls the selected sku service with the first item
                            selectedSkuSrv.setSelectedDevice($scope.deviceRecommender.items[0].skuId);

                            // Checks for device first scenario when user add a device then choose to upgrade
                            $scope.checkDeviceFirst();
                        }));
                    });
                    profileInfoService.getProfileInfo('reload').then(function (result) {
                        favStoreService.getFavStoreId(result.ProfileInfo.uuid);
                    });


                    // Prefetch device details for all items once the recommender finishes its main load sequence
                    recommenderInstance.loaded.then(function () {
                        $scope.deviceRecommender.totalRecommendedDevices.forEach(function (item) {
                            var params = {
                                includeAssociatedProducts: true,
                                includePrices: true,
                                skuId: item.skuId,
                                groupResultsByVariants: true,
                                filterOffers: false
                            };
                            deviceConfigSrv.getDeviceDetails(item.skuId, params, true);
                        });
                    }, 0);

                    // Watches the total recommended devices. Once it is populated get device information for all of the devices.
                    var deregisterWatch = $scope.$watch(function () {
                        return $scope.deviceRecommender.totalRecommendedDevices;
                    }, function () {
                        if ($scope.deviceRecommender.totalRecommendedDevices.length > 0) {
                            // Pass comma separated skuids to getItemPriceData function
                            var skuids = $scope.deviceRecommender.totalRecommendedDevices.map(function (item) {
                                return item.skuId;
                            }).join(',');

                            $scope.filterFlairFlags($scope.deviceRecommender.totalRecommendedDevices);
                            deviceRecommenderSrv.getItemPriceData(skuids).then(function (result) {
                                var commitmentTerms = {};
                                $scope.deviceRecommender.itemPrice = result.payload;
                                angular.forEach($scope.deviceRecommender.itemPrice, function (itemValue, itemKey) {
                                    var commitmentTerm = {};
                                    commitmentTerm.name = itemValue.contractType;
                                    commitmentTerm.leaseTotalMonths = itemValue.contractLength;
                                    commitmentTerm.deviceType = itemValue.deviceType;
                                    commitmentTerms[itemKey] = commitmentTerm;
                                    $scope.imgUrl[itemKey] = imagePathService.getXpressImagePath(
                                            itemValue.brand, null, itemValue.shortDisplayName, itemValue.color, '-hero.png');
                                });
                                $scope.deviceRecommender.commitmentTerms = commitmentTerms;
                                $scope.fetchShortLegalContentForDevices($scope.deviceRecommender.commitmentTerms);

                                deregisterWatch();
                            });
                        }
                    }, true);
                }

                activate();
            }]);
})();