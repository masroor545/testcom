(function () {
    'use strict';

    angular.module('exBuyflow')

        .controller('accessoryRecommenderCtrl', ['$scope', '$rootScope', '$filter', 'accessoryRecommenderService', 'protectionPlanService', 'exCartService', 'exCommonConstants',
            'selectedSkuSrv', 'checkoutHandoffService', 'deviceRecommenderSrv', 'upgradingUserInfoSrv', 'exBuyflowConstants', 'imagePathService', 'profileInfoService',
            'upgradeLinesInfoService', 'reportingDataSrv', 'favStoreService', '$modal',
            function ($scope, $rootScope, $filter, accessoryRecommenderService, protectionPlanService, exCartService, exCommonConstants,
                selectedSkuSrv, checkoutHandoffService, deviceRecommenderSrv, upgradingUserInfoSrv, exBuyflowConstants, imagePathService, profileInfoService,
                upgradeLinesInfoService, reportingDataSrv, favStoreService, $modal) {

                $scope.accessoryRecommender = {
                    initialAccessoriesLoaded: parseInt($scope.initialAccessoriesLoaded),
                    cartData: '',
                    deviceSku: '',
                    deviceSkuInfo: '',
                    currentLOSG: '',
                    myLOSGinfo: '',
                    formattedDeviceType: '',
                    categories: JSON.parse($scope.accessoryCategories),
                    protectionPlanFlag: '',
                    itemPrice: undefined,
                    subTitle: '',
                    subTitleNoAccessory: '',
                    dataQaForAccessoryCTA: [],
                    /*RSI = Relax Store-ID indicator is the Boolean flag which indicates whether REX should
                     * consider/not consider(if store is closed or storeId is not valid) the storeId while
                     * fetching the recommended accessories.
                     */
                    RSI: $scope.relaxStoreIndicator,
                    upgradeLinesInfoDetails: '',
                    currentCtn: ''
                };

                $scope.accessoryRecommenderDetail = '';
                $scope.getRecommendedAccessories = getRecommendedAccessories;
                $scope.accessoryAddToCart = accessoryAddToCart;
                $scope.accessoryRemoveItemFromCart = accessoryRemoveItemFromCart;
                $scope.onProceedToCheckout = onProceedToCheckout;
                $scope.getCartData = getCartData;
                $scope.seeSubtotalDetails = seeSubtotalDetails;
                $scope.selectAccessory = selectAccessory;
                $scope.accFilterFlairFlags = accFilterFlairFlags;
                $scope.imgUrl = [];
                $scope.accFlairFlag = [];
                $scope.subTitleToDisplay = [];
                $scope.onContinueToUpgrade = onContinueToUpgrade;
                $scope.isAccessoryVariantsAvailable = [];
                $scope.allMultilineUpgradeComplete = false;

                $scope.sizeOf = function (obj) {
                    return Object.keys(obj).length;
                };

                //update the cartData
                $scope.$on(exCommonConstants.event.cartDataUpdated, function (event, cartData) {
                    $scope.accessoryRecommender.cartData = cartData.methodReturnValue.lobTypes.WIRELESS;
                    $scope.accessoryRecommender.currentLOSG = $scope.accessoryRecommender.cartData.currentLOSGId;
                    $scope.accessoryRecommender.myLOSGinfo = $scope.accessoryRecommender.cartData.losgs[$scope.accessoryRecommender.currentLOSG];
                    $scope.accessoryInCartItem = {};

                    // Set accessoryInCartItem object for accessories added to cart
                    angular.forEach($scope.accessoryRecommender.myLOSGinfo.cartItems.accessory, function (accessoryDetails, accessorySkuId) {
                        $scope.accessoryInCartItem[accessorySkuId] = accessoryDetails;
                    });
                });

                /**
                 * Scope function that opens the sub total details modal
                 * @public
                 */
                function seeSubtotalDetails () {
                    var modalInstance = $modal.open({
                        templateUrl: '/shop/xpress/modals/accessory-subtotal-tooltip.modal.html',
                        windowClass: 'modal-fullscreen',
                        scope: $scope
                    });

                    // Promise resolves when the modal close/dismiss functionality is triggered.
                    if (modalInstance !== undefined && modalInstance.result !== undefined) {
                        modalInstance.result.then(function () {
                            // This block is never reached. Close is acting like a dismiss due to a Zippy code change.
                        }, function () {
                            //Fire page load event when accessory recommender page loads.
                            $scope.$emit(exCommonConstants.event.DS_REPORTING_PAGELOAD_EVENT,
                                exBuyflowConstants.friendlyPageName.accessoryRecommenderDetails,
                                exBuyflowConstants.virtualUrl.accessoryRecommenderDetails
                            );
                        });
                    }

                    // Fire link click event when user clicks on the subtotals tool tip
                    $scope.$emit(exCommonConstants.event.DS_REPORTING_EVENT, {
                        eventAction: 'linkClick',
                        eventCode: 'Link_Click',
                        additionaldata: {
                            'linkName': exCommonConstants.linkName.seeSubtotalsToolTip,
                            'linkPosition': exBuyflowConstants.linkPosition,
                            'linkDestinationURL': exCommonConstants.virtualUrl.subTotalDetailsLegal
                        }
                    }, $scope);

                    // Fire page load event when accessory displayed on subtotals page as a modal. Should only be fired if getting called to show modal.
                    $scope.$emit(exCommonConstants.event.DS_REPORTING_PAGELOAD_EVENT,
                        exCommonConstants.friendlyPageName.subTotalDetailsLegal,
                        exCommonConstants.virtualUrl.subTotalDetailsLegal
                    );
                }

                /**
                 * Scope function that sets the accessory config with the currently selected sku
                 * @public
                 * @param {String} skuId - Accessory skuId for which config/details to be shown.
                 */
                function selectAccessory (skuId) {
                    selectedSkuSrv.setSelectedAccessory(skuId);
                    var modalInstance = $modal.open({
                        templateUrl: '/shop/xpress/modals/accessory-details.modal.html',
                        windowClass: 'modal-fullscreen',
                        scope: $scope
                    });

                    // Promise resolves when the modal close/dismiss functionality is triggered.
                    if (modalInstance !== undefined && modalInstance.result !== undefined) {
                        modalInstance.result.then(function () {
                            // This block is never reached. Close is acting like a dismiss due to a Zippy code change.
                        }, function () {
                            //Fire page load event when accessory recommender page loads.
                            $scope.$emit(exCommonConstants.event.DS_REPORTING_PAGELOAD_EVENT,
                                exBuyflowConstants.friendlyPageName.accessoryRecommenderDetails,
                                exBuyflowConstants.virtualUrl.accessoryRecommenderDetails
                            );
                        });
                    }

                    // Fire link click event when user clicks on choose your options link for accessories
                    $scope.$emit(exCommonConstants.event.DS_REPORTING_EVENT, {
                        eventAction: 'linkClick',
                        eventCode: 'Link_Click',
                        additionaldata: {
                            'linkName': exBuyflowConstants.linkName.chooseOptions,
                            'linkPosition': exBuyflowConstants.linkPosition,
                            'linkDestinationURL': exCommonConstants.virtualUrl.accessoryDetails
                        }
                    }, $scope);

                    // Fire page load event when accessory displayed on accessory recommender page as a modal. Should only be fired if getting called to show modal.
                    $scope.$emit(exCommonConstants.event.DS_REPORTING_PAGELOAD_EVENT,
                        exCommonConstants.friendlyPageName.accessoryDetails,
                        exCommonConstants.virtualUrl.accessoryDetails
                    );
                }

                /**
                 * gets the recommended accessories from recommender API and their respective prices
                 * @function getRecommendedAccessories
                 * @param {String} deviceSku - Device Sku for which we are looking up accessory recommendations
                 * @param {Array<String>} category - categories Array of categories that we want recommendations for. Ex: ['cases', 'screen-protectors']
                 * @param {boolean} skuExcludedFromBOPISForFlow - skuExcludedFromBOPISForFlow flag telling the selected device is availlable for BOPIS or not.
                 * @returns {object} recommended accessories in items array
                 */
                function getRecommendedAccessories (deviceSku, category, skuExcludedFromBOPISForFlow) {
                    var favStoreId = favStoreService.getFavStoreIdFromSessionStorage();

                    if (skuExcludedFromBOPISForFlow === false
                        && favStoreId !== ''
                        && favStoreId !== undefined
                        && favStoreId !== null) {

                        // Passing RSI indicator and favStoreId to REX if favStore is available
                        accessoryRecommenderService.getAccessoryRecommendations(deviceSku, category, 
                            {'favStoreId': favStoreId, 'RSI': $scope.accessoryRecommender.RSI})
                            .then(function (result) {
                                $scope.subTitleToDisplay = [];
                                getAccessoryList(result);
                            });
                    } else {
                        // Not passing RSI indicator and favStoreId to REX if favStore is not avilable
                        accessoryRecommenderService.getAccessoryRecommendations(deviceSku, category).then(function (result) {
                            $scope.subTitleToDisplay = [];
                            getAccessoryList(result);
                        });
                    }
                }

                /**
                 * Get cart data and updated few scope objects based on response
                 */
                function getCartData (action) {
                    exCartService.getCart(action).then(function (data) {
                        var selectedSku;
                        data = data.result;
                        $scope.accessoryInCartItem = [];
                        $scope.accessoryRecommender.cartData = data.methodReturnValue.lobTypes.WIRELESS;
                        $scope.accessoryRecommender.currentLOSG = $scope.accessoryRecommender.cartData.currentLOSGId;
                        $scope.accessoryRecommender.myLOSGinfo = $scope.accessoryRecommender.cartData.losgs[$scope.accessoryRecommender.currentLOSG];
                        selectedSku = Object.keys($scope.accessoryRecommender.myLOSGinfo.cartItems.device)[0];
                        $scope.accessoryRecommender.deviceSkuInfo = $scope.accessoryRecommender.myLOSGinfo.cartItems.device[selectedSku];
                        $scope.accessoryRecommender.deviceSku = $scope.accessoryRecommender.deviceSkuInfo.skuId;
                        $scope.accessoryRecommender.skuExcludedFromBOPISForFlow = $scope.accessoryRecommender.deviceSkuInfo.skuExcludedFromBOPISForFlow;
                        $scope.accessoryRecommender.formattedDeviceType = upgradingUserInfoSrv.getDeviceType($scope.accessoryRecommender.deviceSkuInfo.deviceType);
                        $scope.accessoryRecommender.subTitleNoAccessory = $scope.subTitleNoAccessory.replace('{0}', $scope.accessoryRecommender.formattedDeviceType);
                        $scope.accessoryRecommender.subTitle = $scope.subTitle.replace('{0}', $scope.accessoryRecommender.formattedDeviceType);
                        $rootScope.$broadcast(exCommonConstants.event.cartDataUpdated, data);

                        if (action === 'load') {
                            /**
                             * protectionPlan service's getInsuranceFeatures get the insurance details of the user to determine whether
                             * the protectionPlan directive is to be displayed or not.
                             * Any string except 'none' can be passed as a parameter to reload insurance options from the API.
                             */
                            protectionPlanService.getInsuranceFeatures('reload').then(function (result) {
                                if (result.payload === undefined) {
                                    $scope.accessoryRecommender.protectionPlanFlag = false;
                                } else {
                                    $scope.accessoryRecommender.protectionPlanFlag = true;
                                }

                                // get accessory hub page title and subtitle to be be shown.
                                getSubtitle();

                                // Display recommended accessories
                                $scope.getRecommendedAccessories($scope.accessoryRecommender.deviceSku, $scope.accessoryRecommender.categories,
                                    $scope.accessoryRecommender.skuExcludedFromBOPISForFlow);
                            });

                            //broadcasting the updated cart data.
                            $rootScope.$broadcast(exCommonConstants.event.cartCompletedOnAccessoryPageLoad, data);
                        }
                    });
                }

                /**
                 * Formats accessory and protection feature to be added as a cart item
                 * @returns {Object} Formatted cart item
                 */
                function formatCartItem (skuId, productId) {
                    var cartItem = {
                        items: {
                            items: [{}]
                        }
                    };

                    // Abbreviation
                    var item = cartItem.items.items[0];

                    item.quantity = 1;
                    item.catalogRefId = skuId;
                    item.productId = productId;

                    return cartItem;
                }

                /**
                 * returns whether an sku is marked as preorderable on the accessory recommender
                 * @function isPreorderAccessory
                 * @param {String} skuId - Device Sku for which we are looking up accessory recommendations
                 * @returns {boolean} returns true if sku is found and sku is preorderable else returns false
                 */
                function isPreorderAccessory (skuId) {
                    var j = 0;

                    if ($scope.accessoryRecommenderDetail && $scope.accessoryRecommenderDetail.length) {
                        for (j = 0; j < $scope.accessoryRecommenderDetail.length; j++) {
                            if ($scope.accessoryRecommenderDetail[j].skuId === skuId) {
                                return $scope.accessoryRecommenderDetail[j].preOrderable;
                            }
                        }
                    }

                    if ($scope.heroAccessory && $scope.heroAccessory.length) {
                        for (j = 0; j < $scope.heroAccessory.length; j++) {
                            if ($scope.heroAccessory[j].skuId === skuId) {
                                return $scope.heroAccessory[j].preOrderable;
                            }
                        }
                    }

                    return false;
                }

                /**
                 * Scope function to add accessory and protection feature to cart if available
                 * @param skuId sku id param of selected accessory.
                 * @param productId product id param of selected accessory
                 */
                function accessoryAddToCart (skuId, productId) {
                    var eventPayload = reportingDataSrv.getAddToCartAccessoryRecommenderPayload($scope, skuId),
                        eventCode = isPreorderAccessory(skuId) ? 'DS_Upgrade_Cart_Preorder_Submit' : 'DS_Upgrade_Cart_Add_Submit';

                    $scope.$emit(exCommonConstants.event.DS_REPORTING_EVENT, {
                        eventAction: 'formSubmit',
                        eventCode: eventCode,
                        additionaldata: eventPayload
                    }, $scope);

                    exCartService.addItemToCart({actionType: 'addItemAndGoToNextStep', skipRedirect: true}, formatCartItem(skuId, productId)).then(function (data) {
                        getCartData('reload');

                        if (data.response !== undefined && data.response !== null
                            && data.response.status === exCommonConstants.errorStatus) {
                            eventPayload = reportingDataSrv.updateEventPayloadFailure(eventPayload, data);
                        }

                        $scope.$emit(exCommonConstants.event.DS_REPORTING_EVENT, {
                            eventAction: 'formResponse',
                            eventCode: eventCode,
                            additionaldata: eventPayload
                        }, $scope);

                        //Fire page load event when Protection Plan displayed on accessory recommender page as a modal. Should only be fired if getting called to show modal.
                        $scope.$emit(exCommonConstants.event.DS_REPORTING_PAGELOAD_EVENT,
                            exBuyflowConstants.friendlyPageName.accessoryRecommenderDetails,
                            exBuyflowConstants.virtualUrl.accessoryRecommenderDetails
                        );
                    });
                }

                /**
                 * Scope function is to get the redirect url response
                 */
                function onProceedToCheckout () {
                    var eventPayload = angular.extend({},
                         reportingDataSrv.getOnProceedToCheckoutPayload($scope),
                         reportingDataSrv.getMultilineReportingPayload($scope.accessoryRecommender.upgradeLinesInfoDetails,
                            $scope.allMultilineUpgradeComplete));
                    $scope.$emit(exCommonConstants.event.DS_REPORTING_EVENT, {
                        eventAction: 'formSubmit',
                        eventCode: 'DS_Upgrade_Proceed_To_Checkout_Submit',
                        additionaldata: eventPayload
                    }, $scope);

                    checkoutHandoffService.proceedToCheckOut().then(function (data) {

                        if (data.response !== undefined && data.response !== null
                            && data.response.status === exCommonConstants.errorStatus) {
                            eventPayload = reportingDataSrv.updateEventPayloadFailure(eventPayload, data);
                        }

                        $scope.$emit(exCommonConstants.event.DS_REPORTING_EVENT, {
                            eventAction: 'formResponse',
                            eventCode: 'DS_Upgrade_Proceed_To_Checkout_Submit',
                            additionaldata: eventPayload
                        }, $scope);
                    });
                }

                /**
                 * Builds and returns the $http params object from the commerce item
                 * @param accessoryCommerceItemId selected accessory's commerce item id.
                 * @return {Object} $http param object which include commerce item.
                 */
                function createParams (accessoryCommerceItemId) {
                    var params = {removalCommerceIds: accessoryCommerceItemId};

                    return params;
                }

                /**
                 * Scope function to remove accessory from cart if already added
                 * @param accessoryCommerceItemId selected accessory's commerce item id.
                 */
                function accessoryRemoveItemFromCart (accessoryCommerceItemId) {
                    var params = createParams(accessoryCommerceItemId);
                    exCartService.removeItemFromCart(params).then(function (result) {
                        if (result && result.response && result.response.status === 'success') {
                            getCartData('reload');
                        }
                    });
                    // Reporting event that fires an add to cart event of -1 to notify a remove has been called.
                    $scope.$emit(exCommonConstants.event.DS_REPORTING_EVENT, {
                        eventAction: 'formSubmit',
                        eventCode: 'DS_Upgrade_Cart_Add_Submit',
                        additionaldata: reportingDataSrv.getRemovePayload()
                    }, $scope);
                }

                /**
                 * Function to create accessory list on the base of accessories categories.
                 * @param allAccessoriesResponse that returns from Rex api.
                 */
                function getAccessoryList (allAccessoriesResponse) {
                    $scope.casesInAccessories = [];
                    $scope.screenProtectorsInAccessories = [];
                    $scope.chargersInAccessories = [];
                    $scope.audioInAccessories = [];
                    $scope.categorizedAccessories = [];

                    angular.forEach(allAccessoriesResponse, function (accessory) {

                        // Filter out out-of-stock and end-of-life accessories
                        if (accessory.outOfStock === false && accessory.endOfLife === false) {

                            // Create accessories list based on categories
                            if (accessory.categories.indexOf(exBuyflowConstants.accessoryCategories[0]) > -1) {
                                $scope.casesInAccessories.push(accessory);
                            } else if (accessory.categories.indexOf(exBuyflowConstants.accessoryCategories[1]) > -1) {
                                $scope.screenProtectorsInAccessories.push(accessory);
                            } else if (accessory.categories.indexOf(exBuyflowConstants.accessoryCategories[2]) > -1) {
                                $scope.chargersInAccessories.push(accessory);
                            } else if (accessory.categories.indexOf(exBuyflowConstants.accessoryCategories[3]) > -1) {
                                $scope.audioInAccessories.push(accessory);
                            }
                        }
                    });

                    switch ($scope.accessoryRecommender.protectionPlanFlag) {
                    case (true):
                        if ($scope.casesInAccessories &&
                            $scope.casesInAccessories.length > 0) {
                            // enter first element if cases available
                            $scope.categorizedAccessories.push($scope.casesInAccessories[0]);
                        }
                        if ($scope.screenProtectorsInAccessories &&
                            $scope.screenProtectorsInAccessories.length > 0 &&
                            $scope.categorizedAccessories && $scope.categorizedAccessories.length < 0) {
                            //enter second element if screen-protector is available
                            $scope.categorizedAccessories.push($scope.screenProtectorsInAccessories[0]);
                        }
                        if ($scope.categorizedAccessories &&
                            $scope.categorizedAccessories.length < 3 &&
                            $scope.chargersInAccessories && $scope.chargersInAccessories.length > 0) {
                            //enter 3rd element as cases if 1 cases and 1 screen-protector is there.
                            $scope.categorizedAccessories.push($scope.chargersInAccessories[0]);
                        }
                        if ($scope.categorizedAccessories &&
                            $scope.categorizedAccessories.length < 3 &&
                            $scope.audioInAccessories && $scope.audioInAccessories.length > 0) {
                            //enter 3rd element as cases if 1 cases and 1 screen-protector is there.
                            $scope.categorizedAccessories.push($scope.audioInAccessories[0]);
                        }
                        break;
                    case (false):
                        if ($scope.casesInAccessories && $scope.casesInAccessories.length > 0) {
                            // enter first element if cases available
                            $scope.categorizedAccessories.push($scope.casesInAccessories[0]);
                        }
                        if ($scope.screenProtectorsInAccessories && $scope.screenProtectorsInAccessories.length > 0) {
                            //enter second element if screen-protector is available
                            $scope.categorizedAccessories.push($scope.screenProtectorsInAccessories[0]);
                        }
                        if ($scope.categorizedAccessories &&
                            $scope.categorizedAccessories.length < 4 &&
                            $scope.chargersInAccessories && $scope.chargersInAccessories.length > 0) {
                            //enter 3rd element as cases if 1 cases and 1 screen-protector is there.
                            $scope.categorizedAccessories.push($scope.chargersInAccessories[0]);
                        }
                        if ($scope.categorizedAccessories &&
                            $scope.categorizedAccessories.length < 4 &&
                            $scope.audioInAccessories && $scope.audioInAccessories.length > 0) {
                            //enter 3rd element as cases if 1 cases and 1 screen-protector is there.
                            $scope.categorizedAccessories.push($scope.audioInAccessories[0]);
                        }
                        break;
                    default:
                        $scope.categorizedAccessories.push('No accessories is recommended for selected device');
                    }

                    if ($scope.accessoryRecommender.protectionPlanFlag === true) {
                        $scope.accessoryRecommenderDetail = $scope.categorizedAccessories.slice(0,
                                $scope.accessoryRecommender.initialAccessoriesLoaded);
                    } else {
                        $scope.heroAccessory = $scope.categorizedAccessories.slice(0, 1);
                        $scope.accessoryRecommenderDetail = $scope.categorizedAccessories.slice(1,
                                $scope.accessoryRecommender.initialAccessoriesLoaded + 1);
                    }

                    // get additional details(iamgePath, price etc.) for each accessory
                    getItemAdditionalDetails($scope.accessoryRecommenderDetail);

                    // get flairFlag for each accessory
                    accFilterFlairFlags($scope.accessoryRecommenderDetail);

                    // get flair flag for hero accessory if hero accessory is available
                    if ($scope.heroAccessory && $scope.heroAccessory[0] !== undefined) {
                        accFilterFlairFlags($scope.heroAccessory);
                    }

                    // get accessory hub page title and subtitle to be be shown.
                    getSubtitle();
                }

                /**
                 * function to update the subtitle flag for accessory hub page on condition whether
                 * both protection plan and accessories or only protection plan or
                 * neither protection plan nor accessories are available for selected device
                 */
                function getSubtitle () {
                    if ($scope.accessoryRecommenderDetail.length > 0) {

                        // If accessory or both accessories and protection plan are available for selected device
                        $scope.subTitleToDisplay['subtitle'] = true;

                    } else if ($scope.accessoryRecommenderDetail.length === 0
                        && $scope.accessoryRecommender.protectionPlanFlag) {

                        // If only protection plan is available for selected device
                        $scope.subTitleToDisplay['subTitleNoAccessory'] = true;

                    } else if ($scope.accessoryRecommenderDetail.length === 0
                        && !$scope.accessoryRecommender.protectionPlanFlag) {

                        // If neither accessories nor protection plan are available for selected device
                        $scope.subTitleToDisplay['subTitleNoAccessoryAndProtection'] = true;
                    }
                }

                /**
                 * Scope function is to get the redirect url response in multiline selection
                 */
                function onContinueToUpgrade () {
                    var eventPayload = angular.extend({},
                         reportingDataSrv.addEventSuccessToPayload({}),
                         reportingDataSrv.getMultilineReportingPayload($scope.accessoryRecommender.upgradeLinesInfoDetails,
                            $scope.allMultilineUpgradeComplete));
                    $scope.$emit(exCommonConstants.event.DS_REPORTING_EVENT, {
                        eventAction: 'formSubmit',
                        eventCode: 'DS_Upgrade_Continue_Submit',
                        additionaldata: eventPayload
                    }, $scope);

                    checkoutHandoffService.proceedToContinue().then(function (data) {

                        if (data.response !== undefined && data.response !== null
                            && data.response.status === exCommonConstants.errorStatus) {
                            eventPayload = reportingDataSrv.updateEventPayloadFailure(eventPayload, data);
                        }

                        $scope.$emit(exCommonConstants.event.DS_REPORTING_EVENT, {
                            eventAction: 'formResponse',
                            eventCode: 'DS_Upgrade_Continue_Submit',
                            additionaldata: eventPayload
                        }, $scope);
                    });
                    //Remove selected line data from session storage so that it can be fetched again for multiple line upgrade
                    upgradingUserInfoSrv.clearUpgradingLineCache();
                }

                /**
                 *  function to get inprogress upgrade lines from profile info service
                 */
                function getProfileData () {
                    profileInfoService.getProfileInfo(true).then(function (response) {
                        if (response.ProfileInfo &&
                            response.ProfileInfo.pendingUpgradeLines &&
                            response.ProfileInfo.pendingUpgradeLines.length === 0) {
                            $scope.accessoryRecommender.upgradeLinesInfoDetails.isMultiLineInProgress = false;
                            $scope.allMultilineUpgradeComplete = true;
                            upgradeLinesInfoService.setUpgradeLinesInfo($scope.accessoryRecommender.upgradeLinesInfoDetails);
                        }
                    });
                }

                /**
                 * Filters and sorts the flairFlags against each skuId on the basis of business logic,
                 * and accordingly flair flag is displayed against each accessory on
                 * accessory-service-recommender page
                 * @function accFilterFlairFlags
                 * @param {Array} accessoriesToBeDisplayed
                 */
                function accFilterFlairFlags (accessoriesToBeDisplayed) {
                    angular.forEach(accessoriesToBeDisplayed, function (accessoryItem) {
                        var temp = [];
                        $scope.accFlairFlag[accessoryItem.skuId] = {};
                        angular.forEach(accessoryItem.displayContentItems, function (contentItem) {
                            if (contentItem.enable === true &&
                                contentItem.displayType === 'ribbon' &&
                                contentItem.contentType === 'image' &&
                                (contentItem.flowTypes).indexOf('UP') !== -1) {
                                temp.push(contentItem);
                                temp = $filter('orderBy')(temp, 'marketingPriority', false);
                            }
                        });

                        if (temp.length > 0) {
                            $scope.accFlairFlag[accessoryItem.skuId] = temp[0];
                        } else {
                            $scope.accFlairFlag[accessoryItem.skuId] = 'none';
                        }
                    });
                }

                /**
                 * It checks if any 2 or more variants are available
                 * with endOfLife as false for any accessorySku passed
                 * @function isVariantAvailableWithoutEol
                 * @param {Object} skuSiblingsMap
                 * @param {string} accessorySkuId
                 */
                function isVariantAvailableWithoutEol (skuSiblingsMap, accessorySkuId) {
                    if ((Object.keys(skuSiblingsMap).length) > 1) {
                        var count = 0,
                            continueLoop = true;
                        angular.forEach(skuSiblingsMap, function (variantItems) {
                            /*continueLoops discontiues the execution of code inside this if as soon as 2nd
                            accessory variant with mEndofLife == false is found (alternate for break function).*/
                            if (continueLoop) {
                                if (variantItems.mEndofLife === 'false') {
                                    count++;
                                }
                                if (count > 1) {
                                    $scope.isAccessoryVariantsAvailable[accessorySkuId] = true;
                                    // discontinuing the loop if hero accessories has variant and more than
                                    // one variant has life i.e mEndofLife is false.
                                    continueLoop = false;
                                }
                            }
                        });
                    }
                }

                /**
                 * Gets the additional details for returned accessoried from REX i.e. image path and accessory price.
                 * Creates comma saperated sring of accessory skuid's that are passed as param to get the accessory prices.
                 * Also gets dataQA attribute for accessory CTA.
                 * @private
                 * @function getItemAdditionalDetails
                 * @param {Array} accessoryRecommenderDetail
                 */
                function getItemAdditionalDetails (accessoryRecommenderDetail) {
                    // Create comma separated skuids to pass to deviceRecommenderSrv service's getItemPriceData function
                    var skuids = accessoryRecommenderDetail.map(function (item) {
                        return item.skuId;
                    }).join(',');

                    //Append the skuId of heroAccessory to pass to deviceRecommenderSrv service's getItemPriceData function
                    if ($scope.heroAccessory && $scope.heroAccessory.length > 0) {
                        skuids = skuids + ',' + $scope.heroAccessory[0].skuId;
                    }

                    // Call pricing service and imagePathService only in case if accessory recommendations are returned from rex.
                    if (skuids !== undefined && skuids.length > 0) {

                        // Calling deviceRecommenderSrv service's getItemPriceData funtion to get price details.
                        deviceRecommenderSrv.getItemPriceData(skuids).then(function (result) {
                            $scope.accessoryRecommender.itemPrice = result.payload;


                            // Calling method to get all accessories image path
                            // Also get datQA attribute for CTA and check EOL of sku variants
                            angular.forEach(accessoryRecommenderDetail, function (accessoryItem) {
                                $scope.imgUrl[accessoryItem.skuId] = imagePathService.getXpressImagePath(
                                    accessoryItem.brand, null,
                                    $scope.accessoryRecommender.itemPrice[accessoryItem.skuId].productDisplayName,
                                    accessoryItem.color,
                                    '-hero.png');

                                // data-qa for CTA
                                $scope.accessoryRecommender.dataQaForAccessoryCTA[accessoryItem.skuId] = accessoryItem.preOrderable ?
                                'accessoryRecommender-AccessoryRecommender-preOrder' : 'accessoryRecommender-AccessoryRecommender-addToCart';

                                // check EndofLife of sku variants
                                isVariantAvailableWithoutEol(accessoryItem.siblingsMapWithProperties, accessoryItem.skuId);
                            });

                            // Get image path for hero accessory
                            // Also get datQA attribute for CTA and check EOL of hero accessory sku variants
                            if ($scope.heroAccessory && $scope.heroAccessory[0] !== undefined) {
                                $scope.imgUrl[$scope.heroAccessory[0].skuId] = imagePathService.getXpressImagePath(
                                    $scope.heroAccessory[0].brand, null,
                                    $scope.accessoryRecommender.itemPrice[$scope.heroAccessory[0].skuId].productDisplayName,
                                    $scope.heroAccessory[0].color,
                                    '-hero.png');

                                // data-qa for CTA
                                $scope.accessoryRecommender.dataQaForAccessoryCTA[$scope.heroAccessory[0].skuId] = $scope.heroAccessory[0].preOrderable ?
                                    'accessoryRecommender-AccessoryRecommender-preOrder' : 'accessoryRecommender-AccessoryRecommender-addToCart';

                                // check EndofLife of hero accessory sku variants
                                isVariantAvailableWithoutEol($scope.heroAccessory[0].siblingsMapWithProperties, $scope.heroAccessory[0].skuId);
                            }

                        });
                    }
                }

                /**
                 * Starts up the controller
                 */
                function activate () {
                    $scope.accessoryRecommender.upgradeLinesInfoDetails = upgradeLinesInfoService.getUpgradeLinesInfo();
                    if ($scope.accessoryRecommender.upgradeLinesInfoDetails &&
                        $scope.accessoryRecommender.upgradeLinesInfoDetails.isMultiLineInProgress) {
                        getProfileData();
                    }
                    upgradingUserInfoSrv.getUpgradingDeviceDetailsData().then(function (upgradingDeviceDetails) {
                        $scope.accessoryRecommender.currentCtn = upgradingDeviceDetails.payload.ctn;
                    });
                    getCartData('load');

                    //Fire page load event when accessory recommender page loads.
                    $scope.$emit(exCommonConstants.event.DS_REPORTING_PAGELOAD_EVENT,
                        exBuyflowConstants.friendlyPageName.accessoryRecommenderDetails,
                        exBuyflowConstants.virtualUrl.accessoryRecommenderDetails
                    );
                }

                activate();
            }]);
})();
