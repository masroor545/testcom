(function () {
    'use strict';

    angular.module('exBuyflow')

        .controller('accessoryDetailsCtrl', ['$scope', '$controller', 'contentService', 'exAccessoryContentService', 'exBuyflowConstants', 'exCommonConstants', 'exCqTranslatorKeyService',
            function ($scope, $controller, contentService, exAccessoryContentService, exBuyflowConstants, exCommonConstants, exCqTranslatorKeyService) {
                var accessoryDetails = {
                    showPdpContent: exBuyflowConstants.showPdpContent,
                    showFeatureContent: false,
                    showImagesContent: false
                };
                $scope.accessoryDetails = accessoryDetails;
                $scope.selectedAccessory = {};
                //scope level broadcasts that gets set when the accessory details infomation is returned
                //returns us an object that has SkuID and accessoryPathPagePath
                $scope.$on(exCommonConstants.event.selectedSkuInFocus, function (event, data) {
                    activate(data);
                });

                /**
                 * Gets the translator keys and their content for the legalNotes array from the getDeviceProductDetails
                 *  and exCqTranslatorKey services.
                 * @function getLegalNotesTranslatorKeys
                 * @param {Array} legalNotes Legal notes array from the getDeviceProductDetails service.
                 * @returns {Array} Legal notes translator keys ready for submission to the exCqTranslatorKey service.
                 * @private
                 */
                function getLegalNotesTranslatorKeys (legalNotes) {
                    var partialHeader = 'proposition.header.lbl.';
                    var partialBody = 'proposition.content.body.';
                    var translatorKeys = [];
                    var legalNoteContent = [];

                    // catch undefined and null
                    legalNotes = legalNotes || [];

                    // step through each object in the legalNotes array and create head/body translator keys for each.
                    for (var i = 0, len = legalNotes.length; i < len; i++) {
                        translatorKeys.push(partialHeader + legalNotes[i].key);
                        translatorKeys.push(partialBody + legalNotes[i].key);
                    }

                    if (translatorKeys !== []) {
                        exCqTranslatorKeyService.getCqTranslatorKeys(translatorKeys).then(function (cqContent) {
                            // step through the translator keys, two keys at once. One for the head, another for the body.
                            for (var i = 0, len = translatorKeys.length; i < len; i += 2) {
                                legalNoteContent.push({
                                    head: cqContent[translatorKeys[i]],
                                    body: cqContent[translatorKeys[i + 1]]
                                });
                            }
                        });
                    }

                    return legalNoteContent;
                }

                /**
                 * Calls the product tabs services for each tab and outputs the result
                 * @function getRecommendedAccessories
                 * @param {object} data Object from the broadcast which returns the skuid and productDetailsPagePath
                 */
                function activate (data) {
                    var numberOnlySku = data.skuId.substring(3);
                    $scope.selectedAccessory = data;

                    //Temporarily will be the method we call till we get all accessories converted in PDP
                    if (accessoryDetails.showPdpContent === false) {
                        exAccessoryContentService.getDetailsLegacyContent(data.accessoryPageURL).then(function (overviewContent) {
                            accessoryDetails.overviewContent = overviewContent;
                        });
                    } else {
                        contentService.getProductOverviewContent(data.accessoryPageURL).then(function (overviewContent) {
                            accessoryDetails.overviewContent = overviewContent;
                        });

                        contentService.getProductFeaturesContent(data.accessoryPageURL).then(function (featureContent) {
                            accessoryDetails.featureContent = featureContent;
                            accessoryDetails.showFeatureContent = accessoryDetails.showPdpContent === true &&
                                accessoryDetails.featureContent !== undefined &&
                                accessoryDetails.featureContent.length !== 0;
                        });
                    }

                    accessoryDetails.legalNotes = getLegalNotesTranslatorKeys(data.legalNotes);

                    accessoryDetails.showOverviewDrawer = accessoryDetails.overviewContent !== undefined
                        || accessoryDetails.showFeatureContent !== false
                        || accessoryDetails.legalNotes !== undefined;

                    accessoryDetails.showOverviewContent = accessoryDetails.shopPdpContent === false
                        || accessoryDetails.overviewContent !== undefined;

                    contentService.getProduct360Images(numberOnlySku).then(function (Product360Images) {
                        accessoryDetails.imagesContent = Product360Images;
                        accessoryDetails.showImagesContent = accessoryDetails.imagesContent !== undefined &&
                            accessoryDetails.imagesContent.length !== 0;
                    });

                    contentService.getProductLegalPaths(data.accessoryPageURL).then(function (ProductLegalPaths) {
                        if (accessoryDetails.showPdpContent !== false) {
                            accessoryDetails.ProductLegalPaths = ProductLegalPaths;
                            contentService.getProductLegalContent(ProductLegalPaths).then(function (ProductLegalContent) {
                                accessoryDetails.ProductLegal = ProductLegalContent;
                            });
                        }
                    });
                }

            }]);
})();
