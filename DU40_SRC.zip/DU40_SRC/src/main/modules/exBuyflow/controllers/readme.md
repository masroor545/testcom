# exBuyflow Controllers
### <a name='deviceDetailsCtrl'></a> `deviceDetailsCtrl`

##### Description:
This controller retrieves and displays device details.

##### Functions:

---
##### ```getLegalNotesTranslatorKeys(legalNotes:array) : promise```

##### Parameters:
* legalNotes (required) - Array of legalNotes as configured in catalog and returned by the device details API.

**Returns:**
An array of objects with the translator keys and their content needed by the device details page.

```javascript
getLegalNotesTranslatorKeys(legalNotes);
```
##### Requirements:
* get content for the configured hazard warnings (Ex: Prop 65)

#### ```triggerAddToCart()```

**Description:**
Calls addToCart function when user has clicked add to cart button from device details

```javascript
triggerAddToCart();
```
#### ```reviewAccordianToBeDisplayed(renderBV, rating)```

##### Parameters:
* renderBV (required) - Boolean flag telling bazaar voice is rendered or not.
* rating (required) - Rating of the selected device.

##### Returns:
* Boolean true/false

**Description:**
Checks wheather review accordian is to be displayed or not if reviews are available/not available respectively.

```javascript
$scope.reviewAccordianToBeDisplayed(renderBV, rating);
```
---
---
### <a name='deviceRecommender'></a> `deviceRecommender`

##### Description:
This controller retrieves recommended devices from the service.

##### Functions:

---
##### ```getRecommendedDevices(devicesToBeLoaded:number)```

##### Parameters:
* devicesToBeLoaded (required) - The number of recommended devices to be displayed on initial page load.

```javascript
$scope.getRecommendedDevices($scope.initDevicesLoaded);
```
##### Requirements:
* get the recommended devices from a service.
* get devicesToBeLoaded amount of filtered devices, which could load more devices than devicesToBeLoaded.
* get prices for the devices loaded
* get short legal for the default commitment term of devices loaded

---
---
##### ```filterFlairFlags(devicesToBeDisplayed:Array)```

##### Parameters:
* devicesToBeDisplayed (required) - The array of the devices that are to be displayed.

```javascript
$scope.filterFlairFlags($scope.deviceRecommender.items);
```
##### Requirements:
* Filters the available flair flags on certain defined conditions of every device.
* Sorts the filtered flair flags orderby marketingPriority
* Displays the first available flair flag after sorting

---
---
##### ```checkDeviceFirst()```

##### Description:
Scope function checks if user has selected device first and then choosen to upgrade line.

```javascript
$scope.checkDeviceFirst();
```
##### Requirements:
* checks if the devices is already selected and then user choose to upgrade.
* open the selected device first overlay inplace of hero device.

---
---

##### ```getHeroDeviceBackgroundTheme(heroDeviceDetail:Object)```

##### Parameters:
* heroDeviceDetail (required) - hero device detail object.

```javascript
$scope.getHeroDeviceBackgroundTheme(heroDeviceDetail);
```
##### Requirements:
* Identify hero device and check source of response should be REX API.
* To apply the background color theme for hero device tile.

**Returns:**
This function will return {string} light-theme/dark-theme

---
---

##### ```fetchShortLegalContentForDevices(commitmentTerms:list)```

##### Parameters:
* commitmentTerms (required) - commitment terms for recommended devices

##### Requirements:
* Identify cms key for default price of recommended sku and call cms translator key service to get short legal content
--- 
---

##### ```filterItems()```

##### Requirements:
* Filters the listed devices with the filter options
* Sets the displayed items to the filtered items or items if there are no filtered items
--- 
---

##### ```clearFilterSelections(event:object)```

##### Requirements:
* Clears filter selections
--- 
---

##### ```viewMoreDevices(devicesToBeLoaded:number)```

##### Parameters:
* devicesToBeLoaded (required) - The number of recommended devices to be displayed when user clicks on "Show more" CTA

##### Requirements:
* Display next set of recommended devices when user clicks on 'View More Devices' button

---
---
##### ```getReportingEventCode() : String```

returns the event code for the situation in scope based on confidence and displayHeroDevice

**Returns:**
returns 'DS_System_Upgrade_Device_Details_Recommend_Display' or 'DS_System_Upgrade_Device_Recommend_Display';

```javascript
getReportingEventCode();
```
---

##### ```getReportingEventCode() : String```

returns the event code for the situation in scope based on confidence and displayHeroDevice

**Returns:**
returns 'DS_System_Upgrade_Device_Details_Recommend_Display' or 'DS_System_Upgrade_Device_Recommend_Display';

```javascript
getReportingEventCode();
```
---



#### ```selectSku(skuId:String, confidenceMet:Boolean)```

##### Parameters:
* skuId (required) - skuId of the selected device. 
* confidenceMet (optional) - let's function know if being called beause confidence met on page load. 

**Description:**
Scope function to get configuration options for the sku and fire page load event

```javascript
selectSku('sku7840239', true);
```
---
---

#### ```showDeviceLegalDetailsOverlay(deviceSkuId:String)```

##### Parameters:
* deviceSkuId (required) - skuId of the selected device. 

**Description:**
Scope function to show device legal overlay.

```javascript
showDeviceLegalDetailsOverlay('sku7840239');
```
---
---

### <a name='upsellOffer'></a> `upsellOffer`

##### Description:
This controller retrieves Bogo upsell offer details from the service.

##### Functions:

##### ```getRequiredUpsellOfferDetails(upsellDetails:object) : promise```

##### Parameters:
* upsellDetails (required) - Upsell offer details returned by the upsell offer API.

**Returns:**
The upsell offer details.

```javascript
getRequiredUpsellOfferDetails(upsellDetails);
```
##### Requirements:
* get the offer details from a service.

---

##### ```deviceImageUrl(details:object)```

##### Parameters:
* details (required) - Upsell offer details for the specific offer

**Returns:**
The image path.

```javascript
deviceImageUrl(details);
```
##### Requirements:
* get the image path with the device details from a service.

---

##### ```getRequiredUpsellOfferLegalContentDetails(offerContent:object) : promise```

##### Parameters:
* offerContent (required) - Upsell offer legal content details returned by the upsell offer API.

**Returns:**
The upsell offer legal content details.

```javascript
getRequiredUpsellOfferLegalContentDetails(offerContent);
```
##### Requirements:
* get the offer legal content details from a service.  

---
##### ```upsellOfferAddItemToCart() : Nothing```

**Description:**
Adds the item to cart.

```javascript
upsellOfferAddItemToCart();
```
##### Requirements:
* Adds offer item to the cart.

---
##### ```multiSkuUpsellOffer() : Nothing```

**Description:**
open the device config modal.

```javascript
multiSkuUpsellOffer();
```
##### Requirements:
* open the device config modal that displays device details.

---
##### ```getAddToCartOfferDetails() : Nothing```

**Description:**
Input query params that are needed.

```javascript
getAddToCartOfferDetails();
```
##### Requirements:
* get the input query params that are needed.

---
##### ```onSkipToCheckout() : nothing```

#### Description:
Makes a POST request and returns a promise of the navigation url.

```javascript
    onSkipToCheckout();
```
##### Requirements:
* get the POST response which has navigation URL in the response. 

---

#### ```openSeeOfferDetailsModal()```

**Description:**
Scope function to show see offer details legal content overlay

```javascript
$scope.openSeeOfferDetailsModal();
``` 
---
---
### <a name='protectionPlanCtrl'></a> `protectionPlanCtrl`

##### Description:
This controller retrieves recommended protection plans from the protection service.

```javascript
$scope.protectionFeature
```
##### Requirements:
* Display recommended protection plan
---

##### Functions:

---

#### ```protectionRemoveItemFromCart () : Nothing```

**Description:**
Scope function to remove protection plan from cart if already added.

```javascript
protectionRemoveItemFromCart ();
```
##### Requirements:
* Remove the added recommended protection plan from cart if already added.

---
---

#### ```atcProtectionDisabled()```

**Description:**
Scope function that disables the ATC CTA when once clicked by user, and enables Remove CTA.

```javascript
atcProtectionDisabled();
```
---
---

### <a name='accessoryRecommenderCtrl'></a> `accessoryRecommenderCtrl`

##### Description:
This controller retrieves recommended accessories from the service.

##### Functions:

---
##### ```getRecommendedAccessories(deviceSku:String, category: Array<String>, skuExcludedFromBOPISForFlow:Boolean) : promise```

##### Parameters:
* deviceSku (required) - Device Sku for which we are looking up accessory recommendations.
* category (required) - Array of categories that we want recommendations for. Ex: ['cases', 'screen-protectors'].
* skuExcludedFromBOPISForFlow (required) - Boolean flag that tells whether the deviceSku is excluded from BOPIS.

**Returns:**
recommended categorized accessories from recommender API and their respective prices

```javascript
$scope.getRecommendedAccessories($scope.accessoryRecommender.deviceSku, $scope.accessoryRecommender.categories,
$scope.accessoryRecommender.skuExcludedFromBOPISForFlow);
```
##### Requirements:
* get the recommended accessories from a service.
* get prices for the accessories loaded

#### ```selectAccessory(skuId:String)```

**Description:**
Scope function to get configuration options for the accessory.

##### Parameters:
* skuId (required) - Accessory skuId for which config/details to be shown.

```javascript
selectAccessory('sku7840239');
```
---
---

#### ```seeSubtotalDetails()```

**Description:**
Scope function that opens the sub total details modal

```javascript
seeSubtotalDetails();
```
---
---

##### ```accFilterFlairFlags(accessoriesToBeDisplayed:Array)```

##### Parameters:
* accessoriesToBeDisplayed (required) - The array of the accessories that are to be displayed.

```javascript
$scope.accFilterFlairFlags(accessoriesToBeDisplayed);
```
##### Requirements:
* Filters the available flair flags on certain defined business logic for every accessory.
* Sorts the filtered flair flags orderby marketingPriority
* Displays the first available flair flag after sorting for each accessory

---
---

##### ```createParams(featureCommerceItemId:String) : promise```

**Description:**
Builds and returns the $http params object from the commerce item.

##### Parameters:
* featureCommerceItemId (required) - The commerce item id of the protection feature.

**Returns:**
The $http params object from the commerce item.

```javascript
$scope.createParams(featureCommerceItemId);
```
##### Requirements:
* get the recommended devices from a service.
* get prices for the devices loaded

---

##### ```accessoryAddToCart(skuId:String, productId: String) : promise```

##### Parameters:
* skuId (required) - Accessory skuId which will be added to cart.
* productId (required) - productId is used to modify the cart content.

#### Description:
Makes a POST request to the cart service API and returns a promise of the added to cart results.

**Returns:**
The promise of the add to cart results.

```javascript
cartService.addItemToCart( items, params );
```
##### Requirements:
* get the recommended accessories from a service.

---
---
##### ```formatCartItem(skuId:string, productId:string)```

##### Parameters:
* skuId (required) - The sku id of the accessory
* productId (required) - The product id of the accessory

##### Returns:
* Rest service call-ready cart item

**Description:**
Formats the accessory to be added to cart.

```javascript
formatCartItem(sku)
```

##### `accessoryRemoveItemFromCart (accessoryCommerceItemId) : Promise`

##### Parameters:
* accessoryCommerceItemId (required) - AccessoryCommerceItemId is used to modify cart content to remove the accessory from cart.

#### Description:
This function will makes a POST request to the remove cart item and returns a promise.

**Returns:**
This function will returns a promise of the remove to cart results.

```javascript
    cartService.removeItemFromCart (params);
```
---
---
##### `isPreorderAccessory (skuId: String)`

##### Parameters:
* skuId (required) - String skuId that you would like to know if it's a preorder accessory

#### Description:
This function will tell you if the accessory is a preorder accesssory 

**Returns:**
This function will return true if sku is found and sku is preorderable else returns false

```javascript
    isPreorderAccessory (skuId);
```
---
---
##### `getCartData (action: String)`

##### Parameters:
* action (required) - action parameter which reloads the cart from the API and gets updated values

#### Description:
This function will cart data and updated few scope objects based on response

```javascript
    getCartData (params);
```
---
---
##### ```onProceedToCheckout() : nothing```

#### Description:
Makes a POST request and returns a promise of the navigation url.

```javascript
    onProceedToCheckout();
```
##### Requirements:
* get the POST response which has navigation URL in the response.

---
---

#### ```getSubtitle()```

**Description:**
Function to update the subtitle flag for accessory hub page on condition whether both protection plan and accessories
or only protection plan or neither protection plan nor accessories are available for selected device

```javascript
getSubtitle();
```
---
---

### <a name='protectionPlanDetailsCtrl'></a> `protectionPlanDetailsCtrl`

##### Description:
This controller adds protection plans from the protection service to cart.

##### Requirements:
* Open the protection plan overlay and add the protection plan to cart on choose button.
---

##### Functions:

---

#### ```addProtectionPlanToCart() : Nothing```

**Description:**
Scope function to add protection plan to the cart.

```javascript
addProtectionPlanToCart();
```
##### Requirements:
* should add protection plan to the cart.

#### ```getProtectionPlanLegal(protectionPlan:Object)```

##### Parameters:
* protectionPlan (required) - Protection plan object to get the legal content from service.

**Description:**
Scope function to show the protection legal content on protection details page.

```javascript
getProtectionPlanLegal(protectionPlan);
```

#### ```getProtectionPlan () : Nothing```

**Description:**
Scope function to get protection plan from the service.

```javascript
getProtectionPlan ();
```
##### Requirements:
* Should get the protection plan from the service.
---
---

#### ```resetCTAButtons()```

**Description:**
Scope function to broadcast the protectionPlanAdded event with false value as user clicked cancel CTA, and did not added the protection plan to cart

```javascript
resetCTAButtons();
```
---
---


### <a name='deviceLegalDetailCtrl'></a> `deviceLegalDetailCtrl`

##### Description:
This controller take the sku id, either from URL or through selectSkuService and fetch device legal content based on that

##### Requirements:
* Fill the long legal content in device long legal overlay modal
---

##### Functions:

---
#### ```getDeviceInformation(skuId:String)```

##### Parameters:
* skuId (required) - skuId of the selected device. 

**Description:**
function to retrieve the devicePageURL of selected sku and get the long legal content for the selected device.

```javascript
getDeviceInformation('sku7840239');

##### Parameters:
* skuId (required) - skuId of the selected device. 
```
---
---
### <a name='accessorySubtotalTooltipCtrl'></a> `accessorySubtotalTooltipCtrl`

##### Description:
This controller shows the legal content on choosing subtotal tooltip.

##### Requirements:
* Select the tool tip for subtotal section on accesory and protection hub page.
---

##### Functions:

---

#### ```fetchSubtotalTooltipDetails() : Nothing```

**Description:**
Scope function to fetch the legal content for subtotal tool tip on accesory and protection hub page.

```javascript
fetchSubtotalTooltipDetails();
```
##### Requirements:
* should fetch the legal content for subtotal tool tip on accesory and protection hub page.
---
---
