(function () {
    'use strict';

    angular.module('exBuyflow', ['exCommon', 'ngSanitize', '/templates/exBuyflow']);
})();
