# exInsuranceOptionsWidget Widget

This module contains functionality that is related to the change your insurance options based on what the customer is eligible for. This will be leveraged
for inline edits and any other various platforms that would want to allow the user to change their insurance. 

### Initialization Arguments

The following key value pairs are passed into `scope.initargs`:

* skuID - [String] unique id of insurance in cart for the widget etc...
```javascript
{
    skuID: 'Skuid Value',    // SkuID passed when calling the widget
}
```

### Event Information

Sends:

* PROTECTION_PLAN_ADDED - signals the add to cart occured after the click of the 'update insurance' button

### protectionPlanCtrl

##### Description:
This controller contains functionality that is related to the showing and chaging your insurance plan that you have inside cart. This will be leveraged
for inline edits and any other various plateforms that would want to allow the user to change the device Price.

**See:** [protectionPlanCtrl Documentation](../../../main/modules/exCommon/controllers/)

---
---