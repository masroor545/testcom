/*global window */
(function () {
    'use strict';

    // only reference .min paths starting with '/ui/' if any needed, paths are also only
    window.exDeviceConfigWidgetConfig = {
        requirejsConfig: {
            paths: {
                'express-static-excommon-tpl': '/shop/xpress/ui/express_sales_static/0.1.0/js/modules/exCommon-tpl.min',
                'express-static-exbuyflow-tpl': '/shop/xpress/ui/express_sales_static/0.1.0/js/modules/exBuyflow-tpl.min',
                'bazaar-voice': '//display.ugc.bazaarvoice.com/static/ATT/bvapi'
            },
            waitSeconds: 0
        },
        requiredFiles: ['express-static-excommon-tpl', 'express-static-exbuyflow-tpl', 'bazaar-voice'],
        requiredModules: ['exDeviceConfigWidgetModule']
    };
})();
