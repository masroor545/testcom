/*global widget */
(function () {
    'use strict';

    /**
     * This module contains functionality that is related to the change your commitment term functionality. This will be leveraged
     * for inline edits and any other various plateforms that would want to allow the user to change the device Price.
     *
     * __Initialization Arguments:__
     *
     * The specified parameters are key value pairs passed into `scope.initargs`:
     *
     * @module exDeviceConfigWidget
     *
     * @param {string} skuId - The sku ID of the device to be configured (e.g. 'sku8040300')
     * @param {string} type - The type of device config you are using (e.g. 'cart')
     *
     * @see {@link ../exCommon/controllers/#module_deviceConfigCtrl|deviceConfigCtrl}
     *
     * @fires EXDEVICECONFIGWIDGET_DEVICE_ADDED
     *
     * @example @lang html
     * <widget-view wid="exDeviceConfigWidget123456"
     *     widget-name="exDeviceConfigWidget"
     *     widget-path="/ui/express_sales_static/0.1.0"
     *     widget-library="js/modules/exDeviceConfigWidget-tpl.js"
     *     init-args="{skuId: 'sku1234567', type: 'cart'}"
     * ></widget-view>
     */
    angular.module('exDeviceConfigWidget', ['/templates/exDeviceConfigWidget']);

    angular.module('exDeviceConfigWidgetModule', ['ng', 'exDeviceConfigWidget', 'exCommon', 'exBuyflow'])

        .provider('widget', function widgetProvider () {
            this.config = {
                'exDeviceConfigWidget': {
                    'currentState': 'state1',
                    'states': {
                        'state1': {
                            'templateURL': '/templates/exdeviceconfigwidget.html',
                            'controller': 'deviceConfigCtrl'
                        }
                    },
                    'styleSource': ['/styles/deviceconfig.min.css']
                }
            };

            this.setConfig = function (config) {
                this.config = config;
            };

            this.$get = [function widgetFactory () { return new widget(this.config); }];
        });

    /**
     * Signal that a device was added to cart from the widget
     * @event EXDEVICECONFIGWIDGET_DEVICE_ADDED
     */
})();
