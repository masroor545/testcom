<a name="module_exDeviceConfigWidget"></a>

## exDeviceConfigWidget
This module contains functionality that is related to the change your commitment term functionality. This will be leveraged
for inline edits and any other various plateforms that would want to allow the user to change the device Price.

__Initialization Arguments:__

The specified parameters are key value pairs passed into `scope.initargs`:

**Emits**: [<code>EXDEVICECONFIGWIDGET_DEVICE_ADDED</code>](#event_EXDEVICECONFIGWIDGET_DEVICE_ADDED)  
**See**: [deviceConfigCtrl](../exCommon/controllers/#module_deviceConfigCtrl)  

| Param | Type | Description |
| --- | --- | --- |
| skuId | <code>string</code> | The sku ID of the device to be configured (e.g. 'sku8040300') |
| type | <code>string</code> | The type of device config you are using (e.g. 'cart') |

**Example**  
```html
<widget-view wid="exDeviceConfigWidget123456"
    widget-name="exDeviceConfigWidget"
    widget-path="/ui/express_sales_static/0.1.0"
    widget-library="js/modules/exDeviceConfigWidget-tpl.js"
    init-args="{skuId: 'sku1234567', type: 'cart'}"
></widget-view>
```

* * *

<a name="event_EXDEVICECONFIGWIDGET_DEVICE_ADDED"></a>

### "EXDEVICECONFIGWIDGET_DEVICE_ADDED"
Signal that a device was added to cart from the widget

**Kind**: event emitted by [<code>exDeviceConfigWidget</code>](#module_exDeviceConfigWidget)  

* * *

