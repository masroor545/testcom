#exStartup setup

### pathConfig

##### Description:
This config is used to handle routing config of application