(function () {
    'use strict';

    var funcDependencyLoader = function (depArr) {
        return ['$ocLazyLoad', function ($ocLazyLoad) {
            return $ocLazyLoad.load({files: depArr, serie: false});
        }];
    };

    angular.module('exStartup')

        .config(['$routeProvider', '$locationProvider', 'exStartupConstants', function ($routeProvider, $locationProvider, exStartupConstants) {
            $routeProvider

                .when('/shop/xpress/index.html', {
                    templateUrl: '/shop/xpress/index.template.html'
                })

                .when('/shop/xpress/device-recommender.html', {
                    templateUrl: '/shop/xpress/device-recommender.template.html',
                    resolve: {
                        pageDeps: funcDependencyLoader(['express-static-exbuyflow-tpl'])
                    },
                    title: exStartupConstants.titles.deviceRecommender,
                    authorize: true
                })

                .when('/shop/xpress/device-details.html', {
                    templateUrl: '/shop/xpress/device-details.template.html',
                    resolve: {
                        pageDeps: funcDependencyLoader(['express-static-exbuyflow-tpl'])
                    },
                    title: exStartupConstants.titles.deviceDetails,
                    authorize: true
                })

                .when('/shop/xpress/accessory-service-recommender.html', {
                    templateUrl: '/shop/xpress/accessory-service-recommender.template.html',
                    resolve: {
                        pageDeps: funcDependencyLoader(['express-static-exbuyflow-tpl'])
                    },
                    title: exStartupConstants.titles.accessoryServiceRecommender,
                    authorize: true
                })

                .when('/shop/xpress/upgrade-eligibility.html', {
                    templateUrl: '/shop/xpress/upgrade-eligibility.template.html',
                    resolve: {
                        pageDeps: funcDependencyLoader(['express-static-exupgrade-tpl'])
                    },
                    title: exStartupConstants.titles.upgradeEligibility,
                    friendlyPageName: exStartupConstants.friendlyPageName.upgradeEligibility,
                    authorize: true
                })

                .when('/shop/xpress/upgrade-eligibility-payment.html', {
                    templateUrl: '/shop/xpress/upgrade-eligibility-payment.template.html',
                    resolve: {
                        pageDeps: funcDependencyLoader(['express-static-exupgrade-tpl'])
                    },
                    title: exStartupConstants.titles.upgradeEligibilityPayment,
                    friendlyPageName: exStartupConstants.friendlyPageName.upgradeEligibilityPayment,
                    authorize: true
                })

                .when('/shop/xpress/upsell-offer.html', {
                    templateUrl: '/shop/xpress/upsell-offer.template.html',
                    resolve: {
                        pageDeps: funcDependencyLoader(['express-static-exbuyflow-tpl'])
                    },
                    title: exStartupConstants.titles.upsellOffer,
                    friendlyPageName: exStartupConstants.friendlyPageName.upsellOffer,
                    authorize: true
                })

                .when('/shop/xpress/upgrade-tradein-consent.html', {
                    templateUrl: '/shop/xpress/upgrade-tradein-consent.template.html',
                    resolve: {
                        pageDeps: funcDependencyLoader(['express-static-exupgrade-tpl'])
                    },
                    title: exStartupConstants.titles.upgradeTradeinConsent,
                    friendlyPageName: exStartupConstants.friendlyPageName.upgradeTradeinConsent,
                    authorize: true
                })

                .when('/shop/xpress/upgrade-payment-confirm.html', {
                    templateUrl: '/shop/xpress/upgrade-payment-confirm.template.html',
                    resolve: {
                        pageDeps: funcDependencyLoader(['express-static-exupgrade-tpl'])
                    },
                    title: exStartupConstants.titles.upgradePaymentConfirm,
                    friendlyPageName: exStartupConstants.friendlyPageName.upgradePaymentConfirm,
                    authorize: true
                })

                .otherwise({
                    redirectTo: '/shop/xpress/index.html'
                });


            $locationProvider.html5Mode({
                enabled: true,
                requireBase: true,
                rewriteLinks: 'xpress-spa'
            });
        }]);
}());
