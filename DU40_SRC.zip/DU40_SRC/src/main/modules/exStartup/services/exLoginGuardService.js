(function () {
    'use strict';

    /**
     * Gets customer's authentication state from user's profile data.
     * @module exLoginGuardService
     */
    angular.module('exStartup')

        .factory('exLoginGuardService', ['$http', '$q', '$window', '$log', '$cacheFactory', 'exStartupConstants',
            function ($http, $q, $window, $log, $cacheFactory, exStartupConstants) {
                var services = {};

                /**
                 * Gets the profile data from profile API
                 * Only called once per browser page refresh data freshness not priority from cache: true
                 *
                 * @function getProfileData
                 * @returns {object} promise object profile data
                 * @example
                 * exLoginGuardService.getProfileData();
                 *     .then(function (data) {
                 *         // do something with said data object
                 *     });
                 */
                services.getProfileData = function () {

                    return $http.get(exStartupConstants.profileServiceURL, {
                        spinner: true,
                        // prevent multiple calls, only needed once to check if user is logged in.
                        cache: true
                    }).then(function (results) {
                        // return the profile
                        return results.data;
                    });
                };

                /**
                 * Gets the current user's profile authentication state and accordingly redirects the unauthenticated
                 * user to login page. Authorized users without wireless accounts are also being redirected to the
                 * login page.
                 * @function authorize
                 * @returns {object} promise object profile data
                 * @example
                 * exLoginGuardService.authorize()
                 *     .then(function (data) {
                 *         // do something with said data object
                 *     });
                 */
                services.authorize = function () {
                    var maxAttempts = 2;

                    return $q(function (resolve, reject) {
                        profileRepeater(resolve, reject, maxAttempts);
                    });

                    function profileRepeater (resolve, reject, count) {
                        if (count > 0) {
                            services.getProfileData().then(function (data) {
                                if (data && data.ProfileInfo) { // verify service response is valid
                                    if (isCustomerAuthorized(data)) { // customer authenticated
                                        resolve(data);
                                    } else { // customer not authenticated
                                        reject(getProfileDataFailed(data));
                                        $window.location.href = exStartupConstants.shopLoginURL;
                                    }
                                } else { // invalid service response
                                    $cacheFactory.get('$http').remove(exStartupConstants.profileServiceURL);
                                    profileRepeater(resolve, reject, count -= 1);
                                }
                            }, function (data) {
                                reject(getProfileDataFailed(data)); // service failed
                                $window.location.href = exStartupConstants.shopLoginURL;
                            });
                        } else { // no valid data provided on any request
                            reject(getProfileDataFailed({
                                data: {
                                    description: 'Multiple attempts made no valid service response!!!'
                                }
                            }));
                            $window.location.href = exStartupConstants.shopLoginURL;
                        }
                    }
                };

                /**
                 * Logs an error and rejects the promise returned by the getProfileData function.
                 * @param error response error object.
                 * @return {Promise} Returns rejected promise
                 */
                function getProfileDataFailed (error) {
                    var message = 'exLoginGuardService.getProfileDataFailed authentication failed';
                    if (error && error.data && error.data.description) {
                        message += '\n' + error.data.description;
                    }
                    $log.error(message);
                    return $q.reject(error);
                }

                /**
                 * Check profile data for authentication
                 * @param profileData profile json data
                 * @return {boolean} Returns true if customer is authenticated
                 */
                function isCustomerAuthorized (profileData) {
                    if (profileData &&
                        profileData.ProfileInfo &&
                        profileData.ProfileInfo.customerState === exStartupConstants.customerAuthState &&
                        profileData.ProfileInfo.wirelessAuthenticated === true) {
                        return true;
                    }
                    return false;
                }

                return services;
            }]);
})();