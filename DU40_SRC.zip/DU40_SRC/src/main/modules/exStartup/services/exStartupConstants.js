(function () {
    'use strict';

    /**
     * Used to create constant variables related to startup module
     * @module exStartupConstants
     * @property {string} btmInfoUrl - API used to perisist Bill to Mobile (BTM) to COSC.
     * @property {boolean} btmPersistToCosc - A flag that allows us to enable/disable the persisting of BTM to COSC.
     * @property {string} btmStorageKey - Key name to save the BTM state to session storage.
     * @property {string} contextRoot - Context root of the xpress web site.
     * @property {string} customerAuthState - State at which customer is authenticated.
     * @property {object} events -
     * @property {string} events.DS_REPORTING_EVENT -
     * @property {string} events.DS_REPORTING_PAGELOAD_EVENT -
     * @property {string} events.hideGlobalNav -
     * @property {string} events.REFRESH_GLOBAL_NAV_CART -
     * @property {string} events.SESSION_STATE_EVENT -
     * @property {string} events.showGlobalNav -
     * @property {object} http - contains keys used for interceptor configuration
     * @property {string} http.postAuthReq - key for requests that are configured to depend on CSI authorization completion
     * @property {string} invokeCSICallURL - Url for CSI Call.
     * @property {number} [maxSpinRequestTime = 4000] - Maximum amount of time the spinner will be displayed without getting a response from a spinner
     * @property {number} [maxSpinStatusTime = 750]- The amount of time between checks of if the page spinner is currently being shown.
     * @property {string} profileServiceURL - Url for the profile service.
     * @property {object} url.xpress.page - contains keys for various urls within the xpress application passed by backend
     * @property {object} visualBreakpoints - width for viewedUIExperience in reporting
     * @property {number} [visualBreakpoints.desktop = 1024]
     * @property {number} [visualBreakpoints.smartphone = 768]
     * @property {string} xpressEventMappingPath - path to the location of the edd.json file for reporting.
     */
    angular.module('exStartup')
        .constant('exStartupConstants', {
            btmInfoUrl: '/apis/checkout/btmPaymentInfo/v1/btminfo/{0}',
            btmPersistToCosc: true,
            btmStorageKey: 'btmState',
            contextRoot: '/shop/xpress/',
            customerAuthState: 'authenticated',
            maxSpinRequestTime: 4000,
            maxSpinStatusTime: 750,
            profileServiceURL: '/services/shopwireless/model/att/ecom/api/ProfileServiceActor/getProfileInfo?viewType=zippy',
            profileStorageKey: 'exUpProfile',
            xpressEventMappingPath: '/shop/xpress/ui/express_sales_static/0.1.0/lib/json/edd.json',
            shopLoginURL: '/shop/login/login.html',
            invokeCSICallURL: '/services/shopwireless/model/att/ecom/api/CsiCallForPostAuthorizationServiceActor/invokeCSIService',
            http: {
                postAuthReq: 'postAuthRequired'
            },
            events: {
                hideGlobalNav: 'HIDE_GLOBALNAV',
                SESSION_STATE_EVENT: 'SESSION_STATE_CHANGED',
                showGlobalNav: 'DISPLAY_GLOBALNAV',
                DS_REPORTING_EVENT: 'DS_Reporting_Event',
                DS_REPORTING_PAGELOAD_EVENT: 'DS_Reporting_PageLoad_Event',
                REFRESH_GLOBAL_NAV_CART: 'Refresh_Global_Nav_Cart'
            },
            titles: {
                deviceRecommender: 'Pick your new device',
                deviceDetails: 'Device Details',
                accessoryServiceRecommender: 'Protection and accessories',
                upgradeEligibility: 'Upgrade Eligibility',
                upgradeEligibilityPayment: 'Upgrade Payment',
                upsellOffer: 'Device Offer',
                upgradeTradeinConsent: 'Upgrade Tradein Consent',
                upgradePaymentConfirm: 'Upgrade Payment Confirm'
            },
            friendlyPageName: {
                deviceRecommender: 'DS Upgrade Device Recommender Pg',
                deviceDetails: 'DS Upgrade Device Details Pg',
                accessoryServiceRecommender: 'DS Upgrade Protection And Accessories Pg',
                upgradeEligibility: 'DS Upgrade Eligibility And Options Pg',
                upgradeEligibilityPayment: 'DS Upgrade Payment Pg',
                upsellOffer: 'DS Upgrade Upsell Offer Pg',
                upgradeTradeinConsent: 'DS Upgrade Tradein Only Consent Pg',
                upgradePaymentConfirm: 'DS Upgrade Payment Confirmation Pg'
            },
            url: {
                xpress: {
                    page: {
                        accessoryServiceRecommender: '/shop/xpress/accessory-service-recommender.html',
                        deviceRecommender: '/shop/xpress/device-recommender.html',
                        upgradeTradeinConsent: '/shop/xpress/upgrade-tradein-consent.html',
                        upgradeEligibilityPayment: '/shop/xpress/upgrade-eligibility-payment.html',
                        upgradePaymentConfirm: '/shop/xpress/upgrade-payment-confirm.html'
                    }
                }
            },
            visualBreakpoints: {
                desktop: 1024,
                smartphone: 768
            }
        });
})();