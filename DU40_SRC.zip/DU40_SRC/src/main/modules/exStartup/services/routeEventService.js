(function () {
    'use strict';

    /**
     * Capture routing events for further processing of events
     * @module routeEventService
     */
    angular.module('exStartup')

        .run([
            '$rootScope', '$document', '$route', '$modalStack', 'exReportingSrv', 'exSessionMonitor', '$window',
            'exStartupConstants', 'exDetmManager', 'spinnerInterceptor', 'exPostAuthGlobalApi',
            function ($rootScope, $document, $route, $modalStack, exReportingSrv, exSessionMonitor, $window,
                      exStartupConstants, exDetmManager, spinnerInterceptor, exPostAuthGlobalApi) {
                $rootScope.$on('$routeChangeStart', function (evt, to) {

                    if (to.authorize === true) {
                        to.resolve = to.resolve || {};
                        if (!to.resolve.authorizationResolver) {
                            to.resolve.authorizationResolver = ['exLoginGuardService', function (exLoginGuardService) {
                                return exLoginGuardService.authorize();
                            }];
                        }
                    }
                });

                $rootScope.$on('$routeChangeSuccess', function (evt, current) {
                    if (current.authorize === true) {
                        exPostAuthGlobalApi.perform();
                    }

                    // restart session timeout on successful page load
                    exSessionMonitor.restartTimer();

                    // Dismisses any modals that are present
                    var top = $modalStack.getTop(),
                        friendlyPageName = $route.current.friendlyPageName;
                    if (top) {
                        $modalStack.dismiss(top.key);
                    }

                    // Sets page title
                    $document[0].title = $route.current.title;

                    // Notify satellite that scripts can be loaded
                    spinnerInterceptor.whenUserAccessible().then(function () {
                        notifyCorePageIntentReady();
                        exDetmManager.notifyHtmlAssetsLoaded();
                    });

                    //pageLoad event call when invokeCSI not called.
                    if (!(exPostAuthGlobalApi.postAuthCallsNeeded()) && friendlyPageName) {
                        exReportingSrv.firePageLoad(friendlyPageName);
                    }

                });

                // setup global event listener for the session timeout
                $rootScope.$on(exStartupConstants.events.SESSION_STATE_EVENT, function (evt, data) {
                    // session timeout event captured
                    if (data.type === 'expired') {
                        // timeout expired

                        $window.location.href = exStartupConstants.shopLoginURL;
                    } else if (data.type === 'warning') {
                        // timeout warning
                    }
                });

                // setup global event listener to refresh cart of global nav component
                $rootScope.$on(exStartupConstants.events.REFRESH_GLOBAL_NAV_CART, function () {
                    // GlobalNavHandler is defined globally once global nav initalizes it, defined in the globals at the top of this file
                    if ($window.GlobalNavHandler && $window.GlobalNavHandler.refreshCart) {
                        $window.GlobalNavHandler.refreshCart();
                    }
                });

                // setup global event listener for the hidding the global nav component
                $rootScope.$on(exStartupConstants.events.hideGlobalNav, function () {
                    // GlobalNavHandler is defined globally once global nav initalizes it, defined in the globals at the top of this file
                    if ($window.GlobalNavHandler) {
                        $window.GlobalNavHandler.toggleHeader(true);
                        $window.GlobalNavHandler.toggleFooter(true);
                    }

                });

                // setup global event listener for the showing the global nav component when it is hidden
                $rootScope.$on(exStartupConstants.events.showGlobalNav, function () {
                    // GlobalNavHandler is defined globally once global nav initalizes it, defined in the globals at the top of this file
                    if ($window.GlobalNavHandler) {
                        $window.GlobalNavHandler.toggleHeader(false);
                        $window.GlobalNavHandler.toggleFooter(false);
                    }

                });

                function notifyCorePageIntentReady () {
                    // send event primarily for dynatrace to know when page / url is ready
                    var evt = $document.context.createEvent('Event');
                    evt.initEvent('CriticalPathComplete', true, false);
                    $document.context.head.dispatchEvent(evt);
                }
            }]);
})();
