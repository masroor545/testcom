(function () {
    'use strict';

    /**
     *
     * Displays a spinner for any network request that is configured for it.
     * This is specifically targeted for the following situations:
     *
     * * network calls that take a significant amount of time
     * * requests that are mandatory for the function or display of the page before users
     * can interact with it.
     * * form submit type requests that need to block the UI pending navigation or response.
     *
     * The spinner will block until all spinner configured request complete or if the configured
     * amount of time passes without a response for each request.
     * @module spinnerInterceptor
     * @example
     * $http.get('/service/api/magic/profile', {
     *     cache: true,
     *     params: {
     *         value1: 'apple',
     *         value2: 'zebra'
     *     },
     *     spinner: true
     * });
     *
     * $http.post('/service/api/magic/castle', {
     *     spinner: true
     * });
     */
    angular.module('exStartup')

        .factory('spinnerInterceptor', ['$timeout', '$q', '$log', 'exStartupConstants',
            function ($timeout, $q, $log, exStartupConstants) {
                var spinnerQueue = [],
                    pageSpinnerSelector = '.fullPageLoaderIndicator'; // element selector

                return {
                    request: requestIntercept,
                    response: responseIntercept,
                    responseError: responseInterceptError,
                    whenUserAccessible: whenUserAccessible
                };

                function requestIntercept (config) {

                    if (config.spinner === true) {
                        displayPageSpinner(true);

                        spinnerQueue.push($timeout(emptySpinnerQueue, exStartupConstants.maxSpinRequestTime, false));
                    }

                    return config;
                }

                function responseIntercept (response) {

                    if (spinnerQueue.length > 0 && response.config && response.config.spinner === true) {
                        $timeout.cancel(spinnerQueue.shift()); // clear oldest timer

                        if (spinnerQueue.length === 0) { // all request complete
                            displayPageSpinner(false);
                        }
                    }

                    return response;
                }

                function responseInterceptError (response) {
                    return $q.reject(responseIntercept(response));
                }

                /**
                 * Clears all timeouts and empties queue
                 */
                function emptySpinnerQueue () {
                    var i = 0, len = spinnerQueue.length;

                    displayPageSpinner(false);
                    $log.info('spinnerInterceptor: one request exceeded timeout period');

                    for (; i <= len - 1; i += 1) {
                        $timeout.cancel(spinnerQueue.shift());
                    }
                }

                /**
                 * Performs task of displaying and hiding the full page spinner
                 * @param {boolean} display whether to show or hide the spinner
                 */
                function displayPageSpinner (display) {
                    angular.element(pageSpinnerSelector)[display ? 'show' : 'hide']();
                }

                /**
                 * Indicates when no spinners are displayed at the moment and the page is user
                 * accessible. This function is intended to only be used after $locationChangeSuccess
                 * event has occurred.
                 * Primarily this function is targeted to be used so user can identify that all page critical API calls
                 * have completed.
                 * @function whenUserAccessible
                 * @returns {Promise} resolves when page can be interacted with by users
                 * @example
                 * spinnerInterceptor.whenUserAccessible().then(function () {
                 *     // do some stuff, spinner has been closed
                 * });
                 */
                function whenUserAccessible () {
                    return spinnerStatus($q.defer());
                }

                function spinnerStatus (deferred) {
                    var originallyHidden = spinnerQueue.length === 0;

                    $timeout(function () {
                        var currentlyHidden = spinnerQueue.length === 0;

                        if (originallyHidden === true && currentlyHidden === true) {
                            deferred.resolve(); // page has been accessible for configured time period
                            $log.info('spinnerInterceptor: critical API calls complete');
                        } else {
                            deferred.notify({
                                visiblePrevious: !originallyHidden,
                                visibleCurrent: !currentlyHidden
                            });
                            spinnerStatus(deferred); // check again
                        }
                    }, exStartupConstants.maxSpinStatusTime, false);

                    return deferred.promise;
                }
            }])

        .config(['$httpProvider', function ($httpProvider) {
            // using unshift instead of push to prioritize spinner as first in request and last in response
            // this is so interceptors that delay requests can still show spinner while being blocked.
            $httpProvider.interceptors.unshift('spinnerInterceptor');
        }]);
})();
