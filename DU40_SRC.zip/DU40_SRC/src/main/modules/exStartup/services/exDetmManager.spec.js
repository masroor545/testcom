(function () {
    'use strict';

    define(['exDetmManager'], function () {
        describe('src/main/modules/exStartup/services/exDetmManager.spec.js', function () {
            describe('exDetmManager service of exStartup', function () {
                var service, $document, $window, $rootScope;

                beforeEach(function () {
                    $window = {
                        document: document
                    };

                    module('exStartup', {
                        $window: $window
                    });

                    inject(function ($injector) {
                        $document = $injector.get('$document');
                        $rootScope = $injector.get('$rootScope');
                        service = $injector.get('exDetmManager');
                    });

                    spyOn($document.context.head, 'dispatchEvent');
                });

                afterEach(function () {
                    $document.context.head.dispatchEvent.calls.reset();
                    $window.docReady = undefined;
                });

                it('should resolve as DETM ready only after loadDetmNow and docReady is called',
                    function (done) {
                        service.whenDetmReady().then(function () {
                            expect($document.context.head.dispatchEvent)
                                .toHaveBeenCalledWith(jasmine.objectContaining({
                                type: 'loadDetmNow'
                            }));

                            done();
                        });

                        $rootScope.$apply();

                        expect($document.context.head.dispatchEvent)
                            .not.toHaveBeenCalledWith(jasmine.objectContaining({
                                type: 'loadDetmNow'
                            }));

                        service.notifyHtmlAssetsLoaded();

                        $window.docReady(); // this function is called by satellite/DTM

                        $rootScope.$apply();
                    });

                it('should trigger satellite asset loaded event and DETM load now event when function called',
                    function () {

                        service.notifyHtmlAssetsLoaded();

                        expect($document.context.head.dispatchEvent)
                            .toHaveBeenCalledWith(jasmine.objectContaining({
                                type: 'loadDetmNow'
                            }));

                        expect($document.context.head.dispatchEvent)
                            .toHaveBeenCalledWith(jasmine.objectContaining({
                                type: 'HTMLAssetsLoaded'
                            }));
                    });
            });
        });
    });
})();
