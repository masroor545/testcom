(function () {
    'use strict';

    define(['exStartupConstants'], function () {
        describe('src/main/modules/exStartup/services/exStartupConstants.spec.js', function () {
            var service;

            beforeEach(function () {
                module('exStartup');

                inject(function ($injector) {
                    service = $injector.get('exStartupConstants');
                });
            });

            it('Should check the constant values to be defined', function () {
                expect(service.btmInfoUrl).toBeDefined();
                expect(service.btmPersistToCosc).toBeDefined();
                expect(service.btmStorageKey).toBeDefined();
                expect(service.contextRoot).toBeDefined();
                expect(service.customerAuthState).toBeDefined();
                expect(service.maxSpinRequestTime).toBeGreaterThan(0);
                expect(service.maxSpinStatusTime).toBeGreaterThan(0);
                expect(service.profileServiceURL).toBeDefined();
                expect(service.profileStorageKey).toBeDefined();
                expect(service.xpressEventMappingPath).toBeDefined();
                expect(service.shopLoginURL).toBeDefined();
                expect(service.events.hideGlobalNav).toBeDefined();
                expect(service.events.SESSION_STATE_EVENT).toBeDefined();
                expect(service.events.showGlobalNav).toBeDefined();
                expect(service.events.DS_REPORTING_EVENT).toBeDefined();
                expect(service.events.DS_REPORTING_PAGELOAD_EVENT).toBeDefined();
                expect(service.events.REFRESH_GLOBAL_NAV_CART).toBeDefined();
                expect(service.titles).toBeDefined();
                expect(service.friendlyPageName).toBeDefined();
                expect(service.url.xpress.page.accessoryServiceRecommender).toBeDefined();
                expect(service.url.xpress.page.deviceRecommender).toBeDefined();
                expect(service.url.xpress.page.upgradeTradeinConsent).toBeDefined();
                expect(service.url.xpress.page.upgradeEligibilityPayment).toBeDefined();
                expect(service.visualBreakpoints.desktop).toBeDefined();
                expect(service.visualBreakpoints.smartphone).toBeDefined();
                expect(service.url.xpress.page.upgradePaymentConfirm).toBeDefined();
                expect(service.invokeCSICallURL).toBeDefined();
            });
        });
    });
})();