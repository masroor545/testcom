(function () {
    'use strict';

    define(['exLoginGuardService'], function () {
        describe('src/main/modules/exStartup/services/exLoginGuardService.spec.js', function () {
            describe('exLoginGuardService service of exStartup', function () {
                var $httpBackend, service, $window, exStartupConstants, $rootScope, $log, $cache;

                beforeEach(function () {

                    $window = {
                        // now, $window.location.href will update that empty object
                        location: {'href': ''},
                        sessionStorage: jasmine.createSpyObj('sessionStorage', ['getItem', 'setItem']),
                        document: window.document
                    };

                    $window.sessionStorage.getItem.and.returnValue(undefined); // nothing in storage
                    $log = jasmine.createSpyObj('$log', ['error']);

                    module('exStartup', {
                        $window: $window,
                        $log: $log
                    });

                    inject(function ($injector) {
                        $httpBackend = $injector.get('$httpBackend');
                        $rootScope = $injector.get('$rootScope');
                        service = $injector.get('exLoginGuardService');
                        exStartupConstants = $injector.get('exStartupConstants');
                        $cache = $injector.get('$cacheFactory').get('$http');
                    });

                    spyOn($cache, 'put');
                    spyOn($cache, 'get');
                    spyOn($cache, 'remove');
                });

                afterEach(function () {
                    $httpBackend.verifyNoOutstandingExpectation();
                    $httpBackend.verifyNoOutstandingRequest();
                    $window.sessionStorage.setItem.calls.reset();
                    $window.sessionStorage.getItem.calls.reset();
                    $window.location.href = '';
                    $log.error.calls.reset();
                    $cache.put.calls.reset();
                    $cache.get.calls.reset();
                    $cache.remove.calls.reset();
                });

                describe('getProfileData function of the exLoginGuardService', function () {

                    it('should retrieve profile info and not store it when user unauthenticated', function () {
                        var endpoint = Endpoint_profileInfoApi.get_profile_info_unauth;

                        EndpointUtils.performServiceTest(service.getProfileData, undefined,
                            {
                                $httpBackend: $httpBackend,
                                endpoint: endpoint,
                                method: 'GET'
                            }, {
                                callback: function (results) {
                                    expect(results).toEqual(endpoint.result);
                                    expect($window.sessionStorage.setItem).not.toHaveBeenCalledWith(
                                        exStartupConstants.profileStorageKey, jasmine.anything());
                                }
                            });

                        EndpointUtils.verifyExpectationsComplete($httpBackend);
                    });
                });

                describe('authorize function of the exLoginGuardService', function () {
                    afterEach(function () {
                        EndpointUtils.verifyExpectationsComplete($httpBackend);
                    });

                    it('should redirect to the login page if the user is not authenticated', function () {
                        var endpoint = Endpoint_profileInfoApi.get_profile_info_unauth;

                        EndpointUtils.performServiceTest(service.authorize, undefined,
                            {
                                $httpBackend: $httpBackend,
                                endpoint: endpoint,
                                method: 'GET'
                            }, {
                                expectPromiseFail: true,
                                callback: function () {
                                    expect($window.location.href).toEqual(exStartupConstants.shopLoginURL);
                                }
                            });
                    });

                    it('should redirect to the login page if the service fails', function () {
                        var endpoint = Endpoint_profileInfoApi.service_error;

                        EndpointUtils.performServiceTest(service.authorize, undefined,
                            {
                                $httpBackend: $httpBackend,
                                endpoint: endpoint,
                                method: 'GET'
                            }, {
                                expectPromiseFail: true,
                                callback: function () {
                                    expect($window.location.href).toEqual(exStartupConstants.shopLoginURL);
                                }
                            });
                    });

                    it('should not perform a redirection if the user is authenticated', function () {
                        var endpoint = Endpoint_profileInfoApi.get_profile_info_auth;

                        EndpointUtils.performServiceTest(service.authorize, undefined,
                            {
                                $httpBackend: $httpBackend,
                                endpoint: endpoint,
                                method: 'GET'
                            }, {
                                callback: function (results) {
                                    expect(results).toEqual(endpoint.result);
                                    expect($window.location.href).toEqual('');
                                }
                            });
                    });

                    it('should make second attempt at profile and not redirect if successful',
                        function () {
                            var badEndpoint = Endpoint_profileInfoApi.get_bad_request_response,
                                goodEndpoint = Endpoint_profileInfoApi.get_profile_info_auth;

                            $httpBackend.expectGET(badEndpoint.url_match).respond(function () {
                                expect($cache.remove)
                                    .not.toHaveBeenCalledWith(exStartupConstants.profileServiceURL);
                                expect($window.location.href).toEqual('');
                                return [badEndpoint.response_code, badEndpoint.result];
                            });

                            $httpBackend.expectGET(goodEndpoint.url_match).respond(function () {
                                expect($cache.remove)
                                    .toHaveBeenCalledWith(exStartupConstants.profileServiceURL);
                                expect($window.location.href).toEqual('');
                                return [goodEndpoint.response_code, goodEndpoint.result];
                            });

                            $httpBackend.whenGET(badEndpoint.url_match).respond(function () {
                                fail('was successful final request should not be made');
                            });

                            service.authorize().then(function (result) {
                                expect($window.location.href).toEqual('');
                                expect(result.ProfileInfo.wirelessAuthenticated).toEqual(true);
                            }, function () {
                                fail('promise should resolve with success');
                            });

                            $httpBackend.flush();
                            $rootScope.$apply();
                        });

                    it('should make maximum two attempts at getting profile or else redirect',
                        function () {
                            var badEndpoint = Endpoint_profileInfoApi.get_bad_request_response;

                            $httpBackend.expectGET(badEndpoint.url_match).respond(function () {
                                expect($cache.remove)
                                    .not.toHaveBeenCalledWith(exStartupConstants.profileServiceURL);
                                expect($window.location.href).toEqual('');
                                return [badEndpoint.response_code, badEndpoint.result];
                            });

                            $httpBackend.expectGET(badEndpoint.url_match).respond(function () {
                                expect($cache.remove)
                                    .toHaveBeenCalledWith(exStartupConstants.profileServiceURL);
                                expect($window.location.href).toEqual('');
                                return [badEndpoint.response_code, badEndpoint.result];
                            });

                            $httpBackend.whenGET(badEndpoint.url_match).respond(function () {
                                fail('Call should not be made a third time');
                                return [badEndpoint.response_code, badEndpoint.result];
                            });

                            service.authorize().then(
                                function () {
                                    fail('should not resolve with success');
                                },
                                function () {
                                    expect($window.location.href).toEqual(exStartupConstants.shopLoginURL);
                                    expect($log.error).toHaveBeenCalledWith(
                                        jasmine.stringMatching(/no valid service response/));
                                });

                            $httpBackend.flush();
                            $rootScope.$apply();
                        });
                });
            });
        });
    });
})();