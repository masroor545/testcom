(function () {
    'use strict';
    /**
     * This service initiates the process of starting the session timeout timer, It also provides
     * the function needed to restart the timer and trigger session keep alive functionality. You
     * must manually specify in your application where you want to restart the timer.  Typically
     * this would be on __$locationChangeSuccess__ event.
     * @module exSessionMonitor
     * @fires SESSION_STATE_CHANGED
     * @see {@link https://codecloud.web.att.com/projects/ST_DECMS/repos/assets-combined-cart/browse/src/sales_co_combined-cart/misc/sessionmonitor?at=refs%2Fheads%2Fmaster|Session Monitor Documentation}
     * @example
     * angular.module('somemodule', ['exStartup'])
     *     .controller('somecontroller', ['exSessionMonitor', 'exStartupConstants',
     *         function (cccSessionMonitor, exStartupConstants) {
     *             $scope.someButtonClicked = function () {
     *                 cccSessionMonitor.restartTimer();
     *             };
     *
     *         $scope.$on(exStartupConstants.events.SESSION_STATE_EVENT, function (evt, data) {
     *             if (data.type === 'expired') {
     *                 // do something
     *             } else if (data.type === 'warning') {
     *                 // do something else
     *             }
     *         });
     *     }]);
     */
    angular.module('exStartup')

        .factory('exSessionMonitor', ['$window', '$document', '$rootScope', 'exStartupConstants',
            function ($window, $document, $rootScope, startupConstants) {
                var eventsToListenTo =
                    $window.sessionMonitor.SESSION_WARNING_EVENT + ' ' + $window.sessionMonitor.SESSION_EXPIRED_EVENT;

                $document.on(eventsToListenTo, broadcastAngularEvent);

                function broadcastAngularEvent (event) {
                    $rootScope.$broadcast(startupConstants.events.SESSION_STATE_EVENT, {
                        type: (event.type === $window.sessionMonitor.SESSION_WARNING_EVENT) ? 'warning' : 'expired'
                    });
                }

                return {
                    /**
                     * Restarts the session timeout timer and makes necessary calls to keep session alive.
                     * @function restartTimer
                     */
                    restartTimer: $window.sessionMonitor.restartTimer.bind($window.sessionMonitor)
                };
            }]);

    /**
     * Event fired when session state changes
     * @event SESSION_STATE_CHANGED
     * @param {object} evt - event object
     * @param {object} data - event data
     * @param {string} data.type - the type of session event that is being fired "expired" or "warning"
     */
})();
