## Modules

<table>
  <thead>
    <tr>
      <th>Module</th><th>Description</th>
    </tr>
  </thead>
  <tbody>
<tr>
    <td><a href="#module_exDetmManager">exDetmManager</a></td>
    <td><p>Service encapsulates functionality for communication with Satellite and DETM.  Specifically,
notifying it when specific scripts can be loaded on a given page.</p>
</td>
    </tr>
<tr>
    <td><a href="#module_exLoginGuardService">exLoginGuardService</a></td>
    <td><p>Gets customer&#39;s authentication state from user&#39;s profile data.</p>
</td>
    </tr>
<tr>
    <td><a href="#module_exReportingSrv">exReportingSrv</a></td>
    <td><p>Capture reporting events and create custom event notifications for DataMappingInterface</p>
</td>
    </tr>
<tr>
    <td><a href="#module_exSessionMonitor">exSessionMonitor</a></td>
    <td><p>This service initiates the process of starting the session timeout timer, It also provides
the function needed to restart the timer and trigger session keep alive functionality. You
must manually specify in your application where you want to restart the timer.  Typically
this would be on <strong>$locationChangeSuccess</strong> event.</p>
</td>
    </tr>
<tr>
    <td><a href="#module_exStartupConstants">exStartupConstants</a></td>
    <td><p>Used to create constant variables related to startup module</p>
</td>
    </tr>
<tr>
    <td><a href="#module_redirectInterceptorService">redirectInterceptorService</a></td>
    <td><p>Middleware to handle redirect responses in HTTP calls</p>
</td>
    </tr>
<tr>
    <td><a href="#module_routeEventService">routeEventService</a></td>
    <td><p>Capture routing events for further processing of events</p>
</td>
    </tr>
<tr>
    <td><a href="#module_spinnerInterceptor">spinnerInterceptor</a></td>
    <td><p>Displays a spinner for any network request that is configured for it.
This is specifically targeted for the following situations:</p>
<ul>
<li>network calls that take a significant amount of time</li>
<li>requests that are mandatory for the function or display of the page before users
can interact with it.</li>
<li>form submit type requests that need to block the UI pending navigation or response.</li>
</ul>
<p>The spinner will block until all spinner configured request complete or if the configured
amount of time passes without a response for each request.</p>
</td>
    </tr>
</tbody>
</table>

## Functions

<dl>
<dt><a href="#invokeCSIService">invokeCSIService()</a> ⇒ <code>object</code></dt>
<dd><p>Invoke CSI call from invokeCSIService api</p>
</dd>
<dt><a href="#executeCSIService">executeCSIService()</a></dt>
<dd><p>Validate local COSC cookies and execute CSI call.
Set &#39;isCSIInProgress-&#39; + shopSessionId flag value true in local session once API response is successful.
Redirect on redirectURL of API response when API resule is not successful.</p>
</dd>
</dl>

<a name="module_exDetmManager"></a>

## exDetmManager
Service encapsulates functionality for communication with Satellite and DETM.  Specifically,
notifying it when specific scripts can be loaded on a given page.


* [exDetmManager](#module_exDetmManager)
    * [~whenDetmReady()](#module_exDetmManager..whenDetmReady) ⇒ <code>Promise</code>
    * [~notifyHtmlAssetsLoaded()](#module_exDetmManager..notifyHtmlAssetsLoaded)


* * *

<a name="module_exDetmManager..whenDetmReady"></a>

### exDetmManager~whenDetmReady() ⇒ <code>Promise</code>
Get promise for completion of tag management scripts

**Kind**: inner method of [<code>exDetmManager</code>](#module_exDetmManager)  
**Returns**: <code>Promise</code> - DETM scripts have been loaded  
**Example**  
```js
exDetmManager.whenDetmReady().then(function () {
    // DataManager calls can happen here
});
```

* * *

<a name="module_exDetmManager..notifyHtmlAssetsLoaded"></a>

### exDetmManager~notifyHtmlAssetsLoaded()
Trigger custom event to notify satellite script that HTML
assets have been loaded for the page.

**Kind**: inner method of [<code>exDetmManager</code>](#module_exDetmManager)  

* * *

### exStartupConstants:
* **url** - Url keys passed by backend
    * **xpress**
        * **page**
            * **upgradeTradeinConsent** - Url for tradein consent page in exUpgrade.
            * **upgradeEligibilityPayment** - Url for payment page in exUpgrade.
* **contextRoot** - Context root of the xpress web site.
* **customerAuthState** - State at which customer is authenticated.
* **profileServiceURL** - Url for the profile service.
* **profileStorageKey** - Key used to store the profile in sessionStorage.
* **xpressEventMappingPath** - path to the location of the edd.json file for reporting.
* **shopLoginURL** - Login url to the /shop/ website.
* **invokeCSICallURL** - Url for CSI Call.
* **titles** - HTML page titles when inside of Zippy. See page_titles.json (src/main/content/page_titles.json) for accessing page titles outside of Zippy.
* **friendlyPageName** - Friendly Page Name defined by EDD.
* **events** - Broadcast events for component to component communication.
	 - **REFRESH_GLOBAL_NAV_CART** -global event listener constant to refresh cart of global nav component
     - **hideGlobalNav** -event listener for the hidding the global nav component
     - **showGlobalNav** -event listener for the showing the global nav component when it is hidden
* **maxSpinRequestTime** - Maximum amount of time the spinner will be displayed without getting a response from a spinner
* **maxSpinStatusTime** - The amount of time between checks of if the page spinner is currently being shown.
configured request.
* **visualBreakpoints** - width for viewedUIExperience in reporting
    * **desktop** - 1024
    * **smartphone** - 768
* **http**
    * **postAuthReq** - Property to signify this requests must wait for specific post authrization API calls to complete
    
----
----
<a name="module_exLoginGuardService"></a>

## exLoginGuardService

##### Description:
Gets customer's authentication state from user's profile data.


* [exLoginGuardService](#module_exLoginGuardService)
    * [~getProfileData()](#module_exLoginGuardService..getProfileData) ⇒ <code>object</code>
    * [~authorize()](#module_exLoginGuardService..authorize) ⇒ <code>object</code>


* * *

<a name="module_exLoginGuardService..getProfileData"></a>

### exLoginGuardService~getProfileData() ⇒ <code>object</code>
Gets the profile data from profile API
Only called once per browser page refresh data freshness not priority from cache: true

**Kind**: inner method of [<code>exLoginGuardService</code>](#module_exLoginGuardService)  
**Returns**: <code>object</code> - promise object profile data  
**Example**  
```js
exLoginGuardService.getProfileData();
    .then(function (data) {
        // do something with said data object
    });
```

* * *

<a name="module_exLoginGuardService..authorize"></a>

### exLoginGuardService~authorize() ⇒ <code>object</code>
Gets the current user's profile authentication state and accordingly redirects the unauthenticated
user to login page. Authorized users without wireless accounts are also being redirected to the
login page.

**Kind**: inner method of [<code>exLoginGuardService</code>](#module_exLoginGuardService)  
**Returns**: <code>object</code> - promise object profile data  
**Example**  
```js
exLoginGuardService.authorize()
    .then(function (data) {
        // do something with said data object
    });
```

* * *

<a name="module_exReportingSrv"></a>

## exReportingSrv
Capture reporting events and create custom event notifications for DataMappingInterface

**See**

- exStartupConstants.events.DS_REPORTING_EVENT
- exStartupConstants.events.DS_REPORTING_PAGELOAD_EVENT


* [exReportingSrv](#module_exReportingSrv)
    * [~init()](#module_exReportingSrv..init)
    * [~firePageLoad([friendlyPageName], [pageLocationUrl])](#module_exReportingSrv..firePageLoad) ⇒ <code>Promise</code>


* * *

<a name="module_exReportingSrv..init"></a>

### exReportingSrv~init()
Adds the necessary scope listener to pass on reporting events.

**Kind**: inner method of [<code>exReportingSrv</code>](#module_exReportingSrv)  

* * *

<a name="module_exReportingSrv..firePageLoad"></a>

### exReportingSrv~firePageLoad([friendlyPageName], [pageLocationUrl]) ⇒ <code>Promise</code>
Performs the task of sending the page load event.

**Kind**: inner method of [<code>exReportingSrv</code>](#module_exReportingSrv)  
**Returns**: <code>Promise</code> - signifies page load event has been sent and necessary data has been collected  
**Emits**: <code>DS_REPORTING_EVENT#event:pageLoad</code>  

| Param | Type | Description |
| --- | --- | --- |
| [friendlyPageName] | <code>string</code> | ??? |
| [pageLocationUrl] | <code>string</code> | ??? |


* * *

<a name="module_exSessionMonitor"></a>

## exSessionMonitor
This service initiates the process of starting the session timeout timer, It also provides
the function needed to restart the timer and trigger session keep alive functionality. You
must manually specify in your application where you want to restart the timer.  Typically
this would be on __$locationChangeSuccess__ event.

**Emits**: [<code>SESSION_STATE_CHANGED</code>](#event_SESSION_STATE_CHANGED)  
**See**: [Session Monitor Documentation](https://codecloud.web.att.com/projects/ST_DECMS/repos/assets-combined-cart/browse/src/sales_co_combined-cart/misc/sessionmonitor?at=refs%2Fheads%2Fmaster)  
**Example**  
```js
angular.module('somemodule', ['exStartup'])
    .controller('somecontroller', ['exSessionMonitor', 'exStartupConstants',
        function (cccSessionMonitor, exStartupConstants) {
            $scope.someButtonClicked = function () {
                cccSessionMonitor.restartTimer();
            };

        $scope.$on(exStartupConstants.events.SESSION_STATE_EVENT, function (evt, data) {
            if (data.type === 'expired') {
                // do something
            } else if (data.type === 'warning') {
                // do something else
            }
        });
    }]);
```

* [exSessionMonitor](#module_exSessionMonitor)
    * [~restartTimer()](#module_exSessionMonitor..restartTimer)
    * ["SESSION_STATE_CHANGED" (evt, data)](#event_SESSION_STATE_CHANGED)


* * *

<a name="module_exSessionMonitor..restartTimer"></a>

### exSessionMonitor~restartTimer()
Restarts the session timeout timer and makes necessary calls to keep session alive.

**Kind**: inner method of [<code>exSessionMonitor</code>](#module_exSessionMonitor)  

* * *

<a name="event_SESSION_STATE_CHANGED"></a>

### "SESSION_STATE_CHANGED" (evt, data)
Event fired when session state changes

**Kind**: event emitted by [<code>exSessionMonitor</code>](#module_exSessionMonitor)  

| Param | Type | Description |
| --- | --- | --- |
| evt | <code>object</code> | event object |
| data | <code>object</code> | event data |
| data.type | <code>string</code> | the type of session event that is being fired "expired" or "warning" |


* * *

<a name="module_exStartupConstants"></a>

## exStartupConstants
Used to create constant variables related to startup module

**Properties**

| Name | Type | Default | Description |
| --- | --- | --- | --- |
| contextRoot | <code>string</code> |  | Context root of the xpress web site. |
| customerAuthState | <code>string</code> |  | State at which customer is authenticated. |
| events | <code>object</code> |  | - |
| events.DS_REPORTING_EVENT | <code>string</code> |  | - |
| events.DS_REPORTING_PAGELOAD_EVENT | <code>string</code> |  | - |
| events.hideGlobalNav | <code>string</code> |  | - |
| events.REFRESH_GLOBAL_NAV_CART | <code>string</code> |  | - |
| events.SESSION_STATE_EVENT | <code>string</code> |  | - |
| events.showGlobalNav | <code>string</code> |  | - |
| http | <code>object</code> |  | contains keys used for interceptor configuration |
| http.postAuthReq | <code>string</code> |  | key for requests that are configured to depend on CSI authorization completion |
| invokeCSICallURL | <code>string</code> |  | Url for CSI Call. |
| maxSpinRequestTime | <code>number</code> | <code>4000</code> | Maximum amount of time the spinner will be displayed without getting a response from a spinner |
| maxSpinStatusTime | <code>number</code> | <code>750</code> | The amount of time between checks of if the page spinner is currently being shown. |
| profileServiceURL | <code>string</code> |  | Url for the profile service. |
| url.xpress.page | <code>object</code> |  | contains keys for various urls within the xpress application passed by backend |
| visualBreakpoints | <code>object</code> |  | width for viewedUIExperience in reporting |
| visualBreakpoints.desktop | <code>number</code> | <code>1024</code> |  |
| visualBreakpoints.smartphone | <code>number</code> | <code>768</code> |  |
| xpressEventMappingPath | <code>string</code> |  | path to the location of the edd.json file for reporting. |


* * *

<a name="module_redirectInterceptorService"></a>

## redirectInterceptorService
Middleware to handle redirect responses in HTTP calls


* * *

<a name="module_routeEventService"></a>

## routeEventService
Capture routing events for further processing of events


* * *

<a name="module_spinnerInterceptor"></a>

## spinnerInterceptor
Displays a spinner for any network request that is configured for it.
This is specifically targeted for the following situations:

* network calls that take a significant amount of time
* requests that are mandatory for the function or display of the page before users
can interact with it.
* form submit type requests that need to block the UI pending navigation or response.

The spinner will block until all spinner configured request complete or if the configured
amount of time passes without a response for each request.

**Example**  
```js
$http.get('/service/api/magic/profile', {
    cache: true,
    params: {
        value1: 'apple',
        value2: 'zebra'
    },
    spinner: true
});

$http.post('/service/api/magic/castle', {
    spinner: true
});
```

* * *

<a name="module_spinnerInterceptor..whenUserAccessible"></a>

### spinnerInterceptor~whenUserAccessible() ⇒ <code>Promise</code>
Indicates when no spinners are displayed at the moment and the page is user
accessible. This function is intended to only be used after $locationChangeSuccess
event has occurred.
Primarily this function is targeted to be used so user can identify that all page critical API calls
have completed.

**Kind**: inner method of [<code>spinnerInterceptor</code>](#module_spinnerInterceptor)  
**Returns**: <code>Promise</code> - resolves when page can be interacted with by users  
**Example**  
```js
spinnerInterceptor.whenUserAccessible().then(function () {
    // do some stuff, spinner has been closed
});
```

* * *

#### <a name='exPostAuthGlobalApi'></a>exPostAuthGlobalApi

##### Description:
This service is used to execute the various post authorization CSI calls, also
it enables the ability for configured requests to be blocked until completion.
The service also performs redirects depending on the response of the webservice.

##### Functions:

##### ```perform() : Promise```
**Returns:** Promise that is resolved when process is complete

**See:** [exPostAuthGlobalInterceptor](#exPostAuthGlobalInterceptor)

**Note:** This feature is enabled in application services with the following constant 
`exCommonConstants.http.postAuthReq` added to the `att` array in HTTP configuration.

**Usage:**
```javascript
$http.get('/someurl.json', {
    spinner: true,
    att: [exCommonConstants.http.postAuthReq]
});
```

---
---

#### <a name='exPostAuthGlobalInterceptor'></a>exPostAuthGlobalInterceptor

##### Description:
This interceptor serves to temporarily block explicitly configured requests once it has been initialized.
Once it has been completed it will allow the requests to proceed as normal.

##### Functions:

##### ```initialize()```
Resets and enables the blocking functionality, should only be called in `$routeChangeSuccess` event.

##### ```complete()```
Resolves the blocking behavior allowing configured requests to complete.

---
---

#### <a name='exStartupUtils'></a>exStartupUtils

##### Description:
Contains utility functions for use in exStartup module.

##### Functions:

##### ```isInterceptorNeeded(config: object, key: string) : Boolean```
Returns true if the requests / response is has the provided key in its configuration.

---
---
