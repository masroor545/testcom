(function () {
    'use strict';

    angular.module('exStartup')

        .factory('exPostAuthGlobalApi', [
            '$log', '$q', '$http', '$cookies', '$window', 'exStartupConstants', 'exPostAuthGlobalInterceptor', 'exReportingSrv',
            '$rootScope',
            function ($log, $q, $http, $cookies, $window, exStartupConstants, exPostAuthGlobalInterceptor, exReportingSrv,
                $rootScope) {

                return {
                    perform: perform,
                    postAuthCallsNeeded: postAuthCallsNeeded
                };

                /**
                 * Enables blocking nature of this service and makes call
                 * @returns {promise} promise resolved when processing complete
                 */
                function perform () {
                    exPostAuthGlobalInterceptor.initialize();
                    return executePostAuthCalls().then(exPostAuthGlobalInterceptor.complete);
                }

                /**
                 * Persists BTM to COSC via an API request, given that this functionality
                 * is enabled and a valid UUID cookie is found. Returns nothing.
                 * @function persistBtmToCosc
                 */
                function persistBtmToCosc () {
                    var uuid;
                    var btmUrlPlusUuid;
                    var btmState = 'persisted';
                    var storedBtmState = $window.sessionStorage.getItem('btmState');

                    if (exStartupConstants.btmPersistToCosc === true
                        && storedBtmState !== btmState) {

                        uuid = $cookies.get('UUID');

                        if (uuid) {
                            $log.info('Persisting BTM.');
                            btmUrlPlusUuid = exStartupConstants.btmInfoUrl.replace('{0}', uuid);
                            $http({
                                method: 'GET',
                                url: btmUrlPlusUuid
                            }).then(
                                function () {
                                    $window.sessionStorage.setItem(exStartupConstants.btmStorageKey, btmState);
                                    $log.info('Persisting BTM succeeded.');
                                },
                                function () {
                                    $log.info('Persisting BTM failed.');
                                }
                            );
                        }
                    }
                }

                /**
                 * Makes the necessary network calls if needed and handles response. If call is made and successful then
                 * we need to refresh globalnav cart
                 * @returns {promise} object that is resolved or rejected given when process complete
                 */
                function executePostAuthCalls () {
                    if (postAuthCallsNeeded()) {
                        return $http.get(exStartupConstants.invokeCSICallURL, {cache: true})
                            .then(
                                function (response) {
                                    var data = response.data || {};
                                    if (data.authenticationError === true) {
                                        $log.info('exPostAuthGlobalApi: performing redirect due to error');
                                        $window.location.href = response.data.redirectURL;
                                        return $q.reject();
                                    } else {
                                        persistBtmToCosc();

                                        $log.info('exPostAuthGlobalApi: process completed with success');
                                        $rootScope.$broadcast(exStartupConstants.events.REFRESH_GLOBAL_NAV_CART, null);
                                        if (data.slidAssocAccts) {
                                            $window.sessionStorage.setItem('slidAssocAccts', data.slidAssocAccts);
                                        }
                                        //pageLoad event call in case of invokeCSI called.
                                        exReportingSrv.firePageLoad(exStartupConstants.friendlyPageName.upgradeEligibility);
                                    }
                                },
                                function () {
                                    $window.location.href = exStartupConstants.shopLoginURL;
                                    return $q.reject();
                                });
                    } else {
                        persistBtmToCosc();

                        return $q.resolve();
                    }
                }

                function postAuthCallsNeeded () {
                    return ($cookies.get('v_coscGlobalSwitch')
                        && $cookies.get('v_coscSalesSwitch')
                        && !$cookies.get('v_coscPayLoadError')) ? true : false;
                }
            }]);
})();
