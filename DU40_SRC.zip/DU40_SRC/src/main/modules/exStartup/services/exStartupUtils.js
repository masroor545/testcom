(function () {
    'use strict';

    angular.module('exStartup')

        .factory('exStartupUtils', [function () {

            return {
                interceptorRequired: interceptorRequired
            };

            /**
             * Performs check to determine if the interceptor is needed on a given request.
             * @param {object} config - the HTTP configuration object for the request / response
             * @param {string} key - the name of the property to check for
             * @returns {boolean} if the interceptor is needed for the request
             */
            function interceptorRequired (config, key) {
                return (config.att instanceof Array && config.att.indexOf(key) >= 0) ? true : false;
            }
        }]);
})();
