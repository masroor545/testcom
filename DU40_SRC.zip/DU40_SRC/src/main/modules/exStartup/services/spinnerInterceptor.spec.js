(function () {
    'use strict';

    define(['spinnerInterceptor'], function () {
        describe('src/main/modules/exStartup/services/spinnerInterceptor.spec.js', function () {
            describe('the full page spinner', function () {
                var $http, $httpBackend, $timeout, spinnerInterceptor,
                    maxSpinRequestTime, maxSpinStatusTime,
                    maxSpinRequestTime90, maxSpinStatusTime90,
                    mockSpinner = jasmine.createSpyObj('angular.element', ['hide', 'show']);

                beforeEach(function () {
                    var exStartupConstants = undefined,
                        selector = '.fullPageLoaderIndicator';

                    module('exStartup');

                    inject(function ($injector) {
                        $http = $injector.get('$http');
                        $httpBackend = $injector.get('$httpBackend');
                        $timeout = $injector.get('$timeout');
                        spinnerInterceptor = $injector.get('spinnerInterceptor');
                        exStartupConstants = $injector.get('exStartupConstants');
                    });

                    // get expiration times and 90% of the same times
                    maxSpinRequestTime = exStartupConstants.maxSpinRequestTime;
                    maxSpinRequestTime90 = Math.floor(maxSpinRequestTime * .9);
                    maxSpinStatusTime = exStartupConstants.maxSpinStatusTime;
                    maxSpinStatusTime90 = Math.floor(maxSpinStatusTime * .9);

                    // provide mock spinner when requested
                    spyOn(angular, 'element').and.callFake(function (val) {
                        return val === selector ? mockSpinner : {};
                    });

                    // verify no spinner hide or show called
                    expect(mockSpinner.show).not.toHaveBeenCalled();
                    expect(mockSpinner.hide).not.toHaveBeenCalled();
                });

                afterEach(function () {
                    mockSpinner.show.calls.reset();
                    mockSpinner.hide.calls.reset();

                    $httpBackend.verifyNoOutstandingExpectation();
                });

                it('displays a spinner when a request is made with the necessary config',
                    function () {
                        var testUrl = '/abcd.json';

                        $httpBackend.expectGET(testUrl).respond(function () {
                            // request not yet complete verify spinner is currently shown
                            expect(mockSpinner.show).toHaveBeenCalled();
                            expect(mockSpinner.hide).not.toHaveBeenCalled();

                            return [200, {dada: 5000}];
                        });

                        $http.get(testUrl, {spinner: true}).then(function () {
                            expect(mockSpinner.hide).toHaveBeenCalled();
                        });

                        $httpBackend.flush();
                    });

                it('displays a spinner when a configured request is made and hide it if the request fails',
                    function () {
                        var testUrl = '/abcd.json';

                        $httpBackend.expectGET(testUrl).respond(function () {
                            // request not yet complete verify spinner is currently shown
                            expect(mockSpinner.show).toHaveBeenCalled();
                            expect(mockSpinner.hide).not.toHaveBeenCalled();

                            return [500, {dada: 5000}];
                        });

                        $http.get(testUrl, {spinner: true}).then(
                            function success () { fail('response should not be successful!'); },
                            function failure () {
                                expect(mockSpinner.hide).toHaveBeenCalled();
                            });

                        $httpBackend.flush();
                    });

                it('does not display a spinner for requests without the config',
                    function () {
                        var testUrl = '/abcd.json';

                        $httpBackend.expectGET(testUrl).respond([200, {dada: 5000}]);

                        $http.get(testUrl).then(function () {
                            // request complete spinner never shown or hidden
                            expect(mockSpinner.show).not.toHaveBeenCalled();
                            expect(mockSpinner.hide).not.toHaveBeenCalled();
                        });

                        $httpBackend.flush();
                    });

                it('hides spinner if a configured request takes longer than the maximum duration',
                    function () {
                        var testUrl = '/abcd.json';

                        $httpBackend.expectGET(testUrl).respond(function () {
                            // request not complete verify spinner shown and hidden
                            expect(mockSpinner.show).toHaveBeenCalled();
                            expect(mockSpinner.hide).not.toHaveBeenCalled();

                            // expire time and verify spinner closed
                            $timeout.flush(maxSpinRequestTime);
                            expect(mockSpinner.hide).toHaveBeenCalled();

                            return [200, {dada: 5000}];
                        });

                        $http.get(testUrl, {spinner: true});

                        $httpBackend.flush();
                    });

                it('keeps displaying the spinner until the last configured request is complete or times out',
                    function () {
                        var testUrls = [
                            {url: '/test1.json', behavior: verifySpinnerIsOpen, config: {spinner: true}},
                            {url: '/test2.json', behavior: verifySpinnerIsOpen, config: {spinner: true}},
                            {url: '/test3.json', behavior: verifySpinnerIsOpen, config: {spinner: true}},
                            {url: '/test4.json', behavior: verifySpinnerIsClosed, config: {spinner: true}}
                        ];

                        testUrls.forEach(function (val, idx) {
                            $httpBackend.expectGET(val.url).respond(function () {
                                var next = testUrls[idx + 1]; // get next request

                                $timeout.flush(maxSpinRequestTime90); // simulate request latency

                                if (next !== undefined) {
                                    // make the next request before the current one completes
                                    $http.get(next.url, next.config).then(next.behavior);
                                }

                                return [200, {}];
                            });
                        });

                        // call first request to being request chain
                        $http.get(testUrls[0].url, testUrls[0].config).then(testUrls[0].behavior);

                        $httpBackend.flush();
                    });

                describe('notification behavior', function () {
                    var maxTimeAfterLastRequest,
                        mockedPromiseFunctions = {
                            notified: jasmine.createSpy('promise.notify'),
                            resolved: jasmine.createSpy('promise.success'),
                            rejected: function () { fail('promise must always get resolved'); }
                        };

                    beforeEach(function () {
                        maxTimeAfterLastRequest = maxSpinStatusTime * 2; // most time that can pass
                    });

                    afterEach(function () {
                        mockedPromiseFunctions.notified.calls.reset();
                        mockedPromiseFunctions.resolved.calls.reset();
                        $timeout.verifyNoPendingTasks();
                    });

                    it('resolves within the first window if no spinner request is made',
                        function () {
                            spinnerInterceptor.whenUserAccessible().then(
                                mockedPromiseFunctions.resolved,
                                mockedPromiseFunctions.rejected,
                                mockedPromiseFunctions.notified
                            );

                            $timeout.flush(maxSpinStatusTime);

                            // should have resolved on first try with no notifications
                            expect(mockedPromiseFunctions.resolved).toHaveBeenCalled();
                            expect(mockedPromiseFunctions.notified).not.toHaveBeenCalled();
                        });

                    it('resolves only after post request grace period', function () {
                        var elapsedTime = 0, testUrl = '/123.json';

                        spinnerInterceptor.whenUserAccessible().then(
                            mockedPromiseFunctions.resolved,
                            mockedPromiseFunctions.rejected,
                            mockedPromiseFunctions.notified
                        );

                        $httpBackend.expectGET(testUrl).respond(function () {
                            // spinner is currently visible
                            expect(mockSpinner.show).toHaveBeenCalled();
                            expect(mockSpinner.hide).not.toHaveBeenCalled();

                            $timeout.flush(maxSpinRequestTime90); // simulate latency
                            elapsedTime += maxSpinRequestTime90;

                            // spinner closed notification not provided yet
                            expect(mockedPromiseFunctions.resolved).not.toHaveBeenCalled();

                            return [200, {}];
                        });

                        $http.get(testUrl, {spinner: true}).then(function () {
                            // spinner no longer showing
                            verifySpinnerIsClosed();

                            // notifications sent and spinner closed promise not immediately resolved
                            expect(mockedPromiseFunctions.resolved).not.toHaveBeenCalled();
                            expect(mockedPromiseFunctions.notified).toHaveBeenCalledTimes(
                                calculateNotifications(elapsedTime)
                            );
                        });

                        $httpBackend.flush();
                        $timeout.flush(maxTimeAfterLastRequest);

                        // spinner closed promise resolved
                        expect(mockedPromiseFunctions.resolved).toHaveBeenCalled();
                    });

                    it('allows for a configured gap between spinner requests without resolving',
                        function () {
                            var elapsedTime = 0;

                            function executeRequest (url) {
                                // verify no spinner shown or hidden yet
                                expect(mockSpinner.show).not.toHaveBeenCalled();
                                expect(mockSpinner.hide).not.toHaveBeenCalled();

                                $httpBackend.expectGET(url).respond(function () {
                                    // simulate request latency
                                    elapsedTime += maxSpinRequestTime90;
                                    $timeout.flush(maxSpinRequestTime90);

                                    verifySpinnerIsOpen(); // verify spinner is currently visible

                                    return [200, {}];
                                });

                                $http.get(url, {spinner: true}).then(function () {
                                    verifySpinnerIsClosed(); // verify spinner has been closed

                                    // notifications sent and spinner closed promise not immediately resolved
                                    expect(mockedPromiseFunctions.resolved).not.toHaveBeenCalled();
                                    expect(mockedPromiseFunctions.notified).toHaveBeenCalledTimes(
                                        calculateNotifications(elapsedTime)
                                    );
                                });

                                $httpBackend.flush(1);
                                elapsedTime += maxSpinStatusTime90;
                                $timeout.flush(maxSpinStatusTime90); // simulate time between requests

                                // even with small time between requests resolve does not happen
                                expect(mockedPromiseFunctions.resolved).not.toHaveBeenCalled();

                                mockSpinner.show.calls.reset();
                                mockSpinner.hide.calls.reset();
                            }

                            spinnerInterceptor.whenUserAccessible().then(
                                mockedPromiseFunctions.resolved,
                                mockedPromiseFunctions.rejected,
                                mockedPromiseFunctions.notified
                            );

                            executeRequest('/1234.json');
                            executeRequest('/5678.json');
                            executeRequest('/9101.json');

                            $timeout.flush(maxTimeAfterLastRequest);
                            expect(mockedPromiseFunctions.resolved).toHaveBeenCalled();
                        });

                    function calculateNotifications (elapsedTime) {
                        return Math.floor(elapsedTime / maxSpinStatusTime);
                    }
                });

                function verifySpinnerIsOpen () {
                    expect(mockSpinner.show).toHaveBeenCalled();
                    expect(mockSpinner.hide).not.toHaveBeenCalled();
                }

                function verifySpinnerIsClosed () {
                    expect(mockSpinner.show).toHaveBeenCalled();
                    expect(mockSpinner.hide).toHaveBeenCalledTimes(1);
                }
            });
        });
    });
})();

