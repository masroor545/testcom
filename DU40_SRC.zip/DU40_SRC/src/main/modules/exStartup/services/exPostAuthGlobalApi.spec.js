(function () {
    'use strict';

    define(['exPostAuthGlobalApi'], function () {
        describe('src/main/modules/exStartup/services/exPostAuthGlobalApi.spec.js', function () {
            describe('exPostAuthGlobalApi service of exStartup', function () {
                var service, $httpBackend, $http, cookieStore = {}, exStartupConstants,
                    $window = {
                        document: window.document, 
                        location: {href: ''}, 
                        sessionStorage: jasmine.createSpyObj(window.sessionStorage, ['getItem', 'setItem'])
                    },
                    $cookies = jasmine.createSpyObj('$cookies', ['get']),
                    mockExPostAuthGlobalInterceptor = jasmine.createSpyObj(
                        'exPostAuthGlobalInterceptor', ['complete', 'initialize']),
                    mockExReportingSrv = jasmine.createSpyObj(
                        'exReportingSrv', ['init', 'firePageLoad']);

                beforeEach(function () {
                    module('exStartup', {
                        $window: $window,
                        $cookies: $cookies,
                        exPostAuthGlobalInterceptor: mockExPostAuthGlobalInterceptor,
                        exReportingSrv: mockExReportingSrv
                    });

                    inject(function ($injector) {
                        $http = $injector.get('$http');
                        $httpBackend = $injector.get('$httpBackend');
                        exStartupConstants = $injector.get('exStartupConstants');
                        service = $injector.get('exPostAuthGlobalApi');
                    });

                    $cookies.get.and.callFake(function (key) {
                        return cookieStore[key];
                    });

                    spyOn($http, 'get').and.callThrough();
                });

                afterEach(function () {
                    $http.get.calls.reset();
                    $window.location.href = '';
                    $cookies.get.calls.reset();
                    mockExPostAuthGlobalInterceptor.complete.calls.reset();
                    mockExPostAuthGlobalInterceptor.initialize.calls.reset();
                    mockExReportingSrv.firePageLoad.calls.reset();
                    $window.sessionStorage.getItem.calls.reset();
                    $window.sessionStorage.setItem.calls.reset();
                });

                describe('no API call scenarios', function () {
                    var $rootScope;

                    beforeEach(function () {
                        inject(function ($injector) {
                            $rootScope = $injector.get('$rootScope');
                        });
                    });

                    it('should resolve blocks and not make API call if coscPayLoadError cookie exists with value',
                        function (done) {
                            cookieStore = {
                                v_coscGlobalSwitch: 'true',
                                v_coscSalesSwitch: 'true',
                                v_coscPayLoadError: 'true'
                            };

                            executeImmediateNoHttpResolutionScenarios(done);
                        });

                    it('should resolve blocks and not make API call if coscGlobalSwitch cookie is missing or empty',
                        function (done) {
                            cookieStore = {
                                v_coscGlobalSwitch: undefined,
                                v_coscSalesSwitch: 'true',
                                v_coscPayLoadError: undefined
                            };

                            executeImmediateNoHttpResolutionScenarios(done);
                        });

                    it('should resolve blocks and not make API call if coscSalesSwitch cookie is missing or empty',
                        function (done) {
                            cookieStore = {
                                v_coscGlobalSwitch: 'true',
                                v_coscSalesSwitch: undefined,
                                v_coscPayLoadError: undefined
                            };

                            executeImmediateNoHttpResolutionScenarios(done);
                        });

                    function executeImmediateNoHttpResolutionScenarios (done) {
                        // verify nothing has been called
                        expect(mockExPostAuthGlobalInterceptor.initialize).not.toHaveBeenCalled();
                        expect(mockExPostAuthGlobalInterceptor.complete).not.toHaveBeenCalled();

                        service.perform().then(function () {
                            // verify requests are currently set to be blocked for completion
                            expect(mockExPostAuthGlobalInterceptor.initialize).toHaveBeenCalled();
                            expect(mockExPostAuthGlobalInterceptor.complete).toHaveBeenCalled();

                            done();
                        });

                        $rootScope.$apply();
                    }
                });

                describe('when cookies are configured to make API calls', function () {
                    beforeEach(function () {
                        cookieStore = {
                            v_coscGlobalSwitch: 'true',
                            v_coscSalesSwitch: 'true',
                            v_coscPayLoadError: undefined
                        };

                        // verify nothing has been called
                        expect(mockExPostAuthGlobalInterceptor.initialize).not.toHaveBeenCalled();
                        expect(mockExPostAuthGlobalInterceptor.complete).not.toHaveBeenCalled();
                    });

                    afterEach(function () {
                        EndpointUtils.verifyExpectationsComplete($httpBackend);
                    });

                    it('should not resolve blocks and redirect to login if the service fails', function () {
                        var endpoint = Endpoint_invokeCSIService.csiServiceFailure;
                        $httpBackend.expectGET(endpoint.url_match).respond(endpoint.response_code, endpoint.result);

                        service.perform();
                        // verify requests are currently set to be blocked for completion
                        expect(mockExPostAuthGlobalInterceptor.initialize).toHaveBeenCalled();
                        expect(mockExPostAuthGlobalInterceptor.complete).not.toHaveBeenCalled();

                        $httpBackend.flush();

                        // verify requests are still set to be blocked and URL has redirected
                        expect(mockExPostAuthGlobalInterceptor.complete).not.toHaveBeenCalled();
                        expect($window.location.href).toEqual(exStartupConstants.shopLoginURL);
                    });

                    it('should redirect to the returned URL and not resolve blocks when service has a error response',
                        function () {
                            var endpoint = Endpoint_invokeCSIService.csiServiceAuthError;
                            $httpBackend.expectGET(endpoint.url_match).respond(endpoint.response_code, endpoint.result);

                            service.perform();
                            // verify requests are currently set to be blocked for completion
                            expect(mockExPostAuthGlobalInterceptor.initialize).toHaveBeenCalled();
                            expect(mockExPostAuthGlobalInterceptor.complete).not.toHaveBeenCalled();

                            $httpBackend.flush();

                            // verify requests are still set to be blocked and URL has redirected
                            expect(mockExPostAuthGlobalInterceptor.complete).not.toHaveBeenCalled();
                            expect($window.location.href).toEqual(endpoint.result.redirectURL);
                        });

                    it('should resolve blocks and not redirect when service is successful', function () {
                        var endpoint = Endpoint_invokeCSIService.csiServiceSuccess;
                        $httpBackend.expectGET(endpoint.url_match).respond(endpoint.response_code, endpoint.result);

                        service.perform();
                        // verify requests are currently set to be blocked for completion
                        expect(mockExPostAuthGlobalInterceptor.initialize).toHaveBeenCalled();
                        expect(mockExPostAuthGlobalInterceptor.complete).not.toHaveBeenCalled();

                        $httpBackend.flush();

                        // verify requests are no longer set to be blocked and no redirect has happened.
                        expect(mockExPostAuthGlobalInterceptor.complete).toHaveBeenCalled();
                        expect($window.location.href).toEqual('');
                    });

                    it('should have API request configured to cache', function () {
                        var endpoint = Endpoint_invokeCSIService.csiServiceSuccess;
                        $httpBackend.expectGET(endpoint.url_match).respond(endpoint.response_code, endpoint.result);

                        expect($http.get).not.toHaveBeenCalled();

                        service.perform();
                        $httpBackend.flush();

                        // verify call is setup to not get triggered multiple times within SPA flow
                        expect($http.get).toHaveBeenCalledWith(exStartupConstants.invokeCSICallURL, {cache: true});
                        expect($window.sessionStorage.setItem).toHaveBeenCalledWith('slidAssocAccts', endpoint.result.slidAssocAccts);
                        expect(mockExReportingSrv.firePageLoad).toHaveBeenCalledWith(exStartupConstants.friendlyPageName.upgradeEligibility);
                    });
                });
            });
        });
    });
})();
