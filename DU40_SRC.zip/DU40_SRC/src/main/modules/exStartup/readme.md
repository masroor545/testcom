# exStartup

This module contains code that is necessary to startup and configure the
application.  As well as to negotiate certain handshakes with backend services.

### Directory
* **setup** - pathconfig exposed in the startup module
* **services** - service used by the controllers / directives