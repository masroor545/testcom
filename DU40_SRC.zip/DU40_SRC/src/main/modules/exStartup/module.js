(function () {
    'use strict';

    angular.module('exStartup', ['ngSanitize', 'ngRoute', 'ngCookies', 'oc.lazyLoad', 'ddh.att', 'com.att.widgetframework']);

}());

