(function () {
    'use strict';

    angular.module('exCommon')

        .factory('favStoreService', ['$log', '$q', '$http', '$window', 'exCommonConstants',
            function ($log, $q, $http, $window, exCommonConstants) {
                var storageKey = exCommonConstants.favStoreStorageKey,
                    favStore = {
                        getFavStoreId: getFavStoreId,
                        getFavStoreIdFromSessionStorage: getFavStoreIdFromSessionStorage
                    };

                /**
                 * Gets the favStoreId of the user on the basis of user's UUID
                 * @function getFavStoreId
                 * @param uuid - user profile's uuid
                 * @returns {Promise} Returns a promise of the storeId returned by the FavStoreApi
                 * @namespace favStoreService
                 */
                function getFavStoreId (uuid) {
                    return $http.get(exCommonConstants.favStoreApi + '/' + uuid)
                        .then(getFavStoreIdCompleted)
                        .catch(getFavStoreIdFailed);
                }

                /**
                 * On successful callback of http GET from getFavStoreId, saves the returned favStoreId to
                 * session storage and also returns the favStoreId
                 * @function getFavStoreIdCompleted
                 * @param {object} result The data that is returned by the successful getFavStoreId function.
                 */
                function getFavStoreIdCompleted (result) {
                    $window.sessionStorage.setItem(storageKey, result.data);
                    return result.data;
                }

                /**
                 * On error callback of http GET from getFavStoreId, returns the error.
                 * @function getFavStoreIdFailed
                 * @param {object} error object returned by the failed getFavStoreId function.
                 * @returns {Promise} Returns a rejected promise.
                 */
                function getFavStoreIdFailed (error) {
                    var message = 'favStoreService.getFavStoreId call failed.';
                    if (error.data && error.data.description) {
                        message += '\n' + error.data.description;
                    }
                    $log.error(message);
                    return $q.reject(error);
                }

                /**
                 * Returns the stored favStorId from session storage.
                 * @function getFavStoreIdFromSessionStorage
                 * @returns {string} Returns favStorId.
                 */
                function getFavStoreIdFromSessionStorage () {
                    return $window.sessionStorage.getItem(storageKey);
                }

                return favStore;
            }]);
})();