(function () {
    'use strict';

    define(['contentService'], function () {
        describe('src/main/modules/exCommon/services/contentService.spec.js', function () {
            describe('contentService service of exCommon', function () {
                var $httpBackend, service, $log;

                beforeEach(function () {

                    module('exCommon');

                    inject(function ($injector) {
                        $httpBackend = $injector.get('$httpBackend');
                        $log = $injector.get('$log');
                        service = $injector.get('contentService');
                        spyOn($log, 'error');
                    });
                });

                describe('transformer related functionality', function () {
                    it('should transform XML to JSON', function () {
                        var response,
                            expectedResponse = [
                                {
                                    'path': '/shopcms/media/att/2016/shop/360s/devices/8040300/6472a-1',
                                    'suffix': '.jpg',
                                    'title_en': 'Apple iPhone 7 - 32GB - Black',
                                    'title_es': '',
                                    'url': '/shopcms/media/att/2016/shop/360s/devices/8040300/6472a-1.jpg'
                                },
                                {
                                    'path': '/shopcms/media/att/2016/shop/360s/devices/8040300/6472a-2',
                                    'suffix': '.jpg',
                                    'title_en': 'Apple iPhone 7 - 32GB - Black',
                                    'title_es': '',
                                    'url': '/shopcms/media/att/2016/shop/360s/devices/8040300/6472a-2.jpg'
                                }
                            ];

                        response = service.transformThreeSixtyXml2Json(Endpoint_device360Images.get_device_360_images.result);
                        expect(response).toBeDefined();
                        expect(response).toEqual(expectedResponse);
                    });

                    it('should return empty strings as JSON values for missing attributes', function () {
                        var response;

                        response = service.transformThreeSixtyXml2Json(Endpoint_device360Images.get_device_360_images_missing_attributes.result);
                        expect(response).toBeDefined();
                        expect(response[0].title_en).toEqual('');
                        expect(response[1].path).toEqual('');
                        expect(response[1].suffix).toEqual('');
                        expect(response[1].url).toEqual('');
                    });

                    it('should return an empty JSON array if no image data can be found', function () {
                        var response,
                            expectedResult = [];

                        response = service.transformThreeSixtyXml2Json(Endpoint_device360Images.get_device_360_images_missing_elements.result);
                        expect(response).toBeDefined();
                        expect(response).toEqual(expectedResult);
                    });
                });

                describe('network related calls', function () {
                    afterEach(function () {
                        $httpBackend.verifyNoOutstandingExpectation();
                        $httpBackend.verifyNoOutstandingRequest();
                    });

                    describe('getProduct360Images calls', function () {
                        it('should return results when called successfully', function () {
                            var mockSku = 'sku8040300';

                            $httpBackend.whenGET(Endpoint_device360Images.get_device_360_images.url_match)
                                .respond(200, Endpoint_device360Images.get_device_360_images.result);
                            service.getProduct360Images(mockSku).then(function (result) {
                                expect(result).toBeDefined();
                                expect(result[0].title_en).toEqual('Apple iPhone 7 - 32GB - Black');
                                expect(result[0].url).toEqual('/shopcms/media/att/2016/shop/360s/devices/8040300/6472a-1.jpg');
                            });

                            $httpBackend.flush();
                        });

                        it('should log console error when the request failed', function () {
                            var mockSku = 'sku8040300',
                                expectedErrorMessage = 'contentService.getProduct360Images call failed.';

                            $httpBackend.whenGET(Endpoint_device360Images.get_device_360_images.url_match)
                                .respond(404, '');
                            service.getProduct360Images(mockSku).then(function () {
                                fail('Response that should have failed, succeeded!');
                            }).catch(function () {
                                expect($log.error).toHaveBeenCalledWith(expectedErrorMessage);
                            });

                            $httpBackend.flush();
                        });
                    });

                    describe('getProductOverviewContent calls', function () {
                        it('should return results when called successfully', function () {
                            var mockProductPageUrl = '/cellphones/iphone/apple-iphone-7';

                            $httpBackend.whenGET(Endpoint_deviceContentNode.get_content_node.url_match)
                                .respond(200, Endpoint_deviceContentNode.get_content_node.result);
                            service.getProductOverviewContent(mockProductPageUrl).then(function (overviewContent) {
                                expect(Array.isArray(overviewContent)).toEqual(true);
                                expect(overviewContent[0].title).toEqual('4.7-inch display');
                                expect(overviewContent[2].icon).toEqual('cameraL_191919');
                            });

                            $httpBackend.flush();
                        });

                        it('should log console error when the request failed', function () {
                            var mockProductPageUrl = '/cellphones/iphone/apple-iphone-7',
                                expectedErrorMessage = 'contentService.getProductOverviewContent call failed.';

                            $httpBackend.whenGET(Endpoint_deviceContentNode.get_content_node.url_match)
                                .respond(404, '');
                            service.getProductOverviewContent(mockProductPageUrl).then(function () {
                                fail('Response that should have failed, succeeded!');
                            }).catch(function () {
                                expect($log.error).toHaveBeenCalledWith(expectedErrorMessage);
                            });

                            $httpBackend.flush();
                        });

                        it('should cache results when called twice', function () {
                            var mockProductPageUrl = '/cellphones/iphone/apple-iphone-7';

                            $httpBackend.whenGET(Endpoint_deviceContentNode.get_content_node.url_match)
                                .respond(200, Endpoint_deviceContentNode.get_content_node.result);
                            service.getProductOverviewContent(mockProductPageUrl).then(function (overviewContent) {
                                expect(Array.isArray(overviewContent)).toEqual(true);
                                expect(overviewContent[0].title).toEqual('4.7-inch display');
                                expect(overviewContent[2].icon).toEqual('cameraL_191919');
                            });
                            $httpBackend.flush();
                            service.getProductOverviewContent(mockProductPageUrl).then(function (overviewContent) {
                                expect(Array.isArray(overviewContent)).toEqual(true);
                                expect(overviewContent[0].title).toEqual('4.7-inch display');
                                expect(overviewContent[2].icon).toEqual('cameraL_191919');
                            });
                            expect($httpBackend.flush).toThrowError('No pending request to flush !');
                        });
                    });

                    describe('getProductFeaturesContent calls', function () {
                        it('should return results when called successfully', function () {
                            var mockProductPageUrl = '/cellphones/iphone/apple-iphone-7';

                            $httpBackend.whenGET(Endpoint_deviceContentNode.get_content_node.url_match)
                                .respond(200, Endpoint_deviceContentNode.get_content_node.result);
                            service.getProductFeaturesContent(mockProductPageUrl).then(function (featuresContent) {
                                expect(Array.isArray(featuresContent)).toEqual(true);
                                expect(featuresContent[1].title).toEqual('Display');
                                expect(featuresContent[11].title).toEqual('Messaging & email');
                                expect(featuresContent[12].entries['0'].description).toEqual('iTunes<sup>Â®<\/sup>');
                            });

                            $httpBackend.flush();
                        });

                        it('should log console error when the request failed', function () {
                            var mockProductPageUrl = '/cellphones/iphone/apple-iphone-7',
                                expectedErrorMessage = 'contentService.getProductFeaturesContent call failed.';

                            $httpBackend.whenGET(Endpoint_deviceContentNode.get_content_node.url_match)
                                .respond(404, '');
                            service.getProductFeaturesContent(mockProductPageUrl).then(function () {
                                fail('Response that should have failed, succeeded!');
                            }).catch(function () {
                                expect($log.error).toHaveBeenCalledWith(expectedErrorMessage);
                            });

                            $httpBackend.flush();
                        });

                        it('should cache results when called twice', function () {
                            var mockProductPageUrl = '/cellphones/iphone/apple-iphone-7';

                            $httpBackend.whenGET(Endpoint_deviceContentNode.get_content_node.url_match)
                                .respond(200, Endpoint_deviceContentNode.get_content_node.result);
                            service.getProductFeaturesContent(mockProductPageUrl).then(function (featuresContent) {
                                expect(Array.isArray(featuresContent)).toEqual(true);
                                expect(featuresContent[1].title).toEqual('Display');
                                expect(featuresContent[11].title).toEqual('Messaging & email');
                                expect(featuresContent[12].entries['0'].description).toEqual('iTunes<sup>Â®<\/sup>');
                            });

                            $httpBackend.flush();
                            service.getProductFeaturesContent(mockProductPageUrl).then(function (featuresContent) {
                                expect(Array.isArray(featuresContent)).toEqual(true);
                                expect(featuresContent[1].title).toEqual('Display');
                                expect(featuresContent[11].title).toEqual('Messaging & email');
                                expect(featuresContent[12].entries['0'].description).toEqual('iTunes<sup>Â®<\/sup>');
                            });
                            expect($httpBackend.flush).toThrowError('No pending request to flush !');
                        });
                    });

                    describe('getProductLegalPaths calls', function () {
                        it('should return results when called successfully', function () {
                            var mockProductPageUrl = '/cellphones/iphone/apple-iphone-7';

                            $httpBackend.whenGET(Endpoint_deviceLegalContentNode.get_content_node.url_match)
                                .respond(200, Endpoint_deviceLegalContentNode.get_content_node.result);
                            service.getProductLegalPaths(mockProductPageUrl).then(function (legalPathContent) {
                                expect(Array.isArray(legalPathContent)).toEqual(true);
                                expect(legalPathContent[0]).toEqual('/legal/details-pages/legal-id-26c/jcr:content/warrantypar/warrantyinfo_0');
                                expect(legalPathContent[1]).toEqual('/legal/details-pages/legal-id-191/jcr:content/warrantypar/warrantyinfo_2');
                                expect(legalPathContent[20]).toEqual('/legal/details-pages/made-up/jcr:content/warrantypar/warrantyinfo');
                            });

                            $httpBackend.flush();
                        });

                        it('should return results without seo cross link when called successfully', function () {
                            var mockProductPageUrl = '/cellphones/samsung/galaxy-s7-edge';

                            $httpBackend.whenGET(Endpoint_deviceLegalContentNode.get_content_node_with_seo_link.url_match)
                                .respond(200, Endpoint_deviceLegalContentNode.get_content_node_with_seo_link.result);
                            service.getProductLegalPaths(mockProductPageUrl).then(function (legalPathContent) {
                                expect(Array.isArray(legalPathContent)).toEqual(true);
                                expect(legalPathContent[0]).not.toEqual('/legal/details-pages/seo-cross-link/jcr:content/warrantypar/warrantyinfo_4');
                            });

                            $httpBackend.flush();
                        });

                        it('should log console error when the request failed', function () {
                            var mockProductPageUrl = '/cellphones/iphone/apple-iphone-7',
                                expectedErrorMessage = 'contentService.getProductLegalPaths call failed.';

                            $httpBackend.whenGET(Endpoint_deviceLegalContentNode.get_content_node.url_match)
                                .respond(404, '');
                            service.getProductLegalPaths(mockProductPageUrl).then(function () {
                                fail('Response that should have failed, succeeded!');
                            }).catch(function () {
                                expect($log.error).toHaveBeenCalledWith(expectedErrorMessage);
                            });

                            $httpBackend.flush();
                        });
                    });

                    describe('getProductLegalContent calls', function () {
                        it('should return results when called successfully', function () {
                            var mockLegalPaths = [
                                '/legal/details-pages/legal-id-26c/jcr:content/warrantypar/warrantyinfo_0',
                                '/legal/details-pages/legal-id-171/jcr:content/warrantypar/warrantyinfo_3'];
                            $httpBackend.whenGET(Endpoint_deviceLegalContentNode.get_shared_content.url_match)
                                .respond(200, Endpoint_deviceLegalContentNode.get_shared_content.result);
                            service.getProductLegalContent(mockLegalPaths).then(function (legalContent) {
                                expect(legalContent[0]).toEqual('&lt;p&gt;&lt;b&gt;Limited 4G LTE availability in select markets. LTE is a trademark of ETSI. Learn more at att.com/network.&lt;/b&gt;&lt;/p&gt;\n');
                                expect(legalContent[1]).toEqual('&lt;p&gt;TM and &copy; 2016 Apple Inc. All rights reserved.&lt;/p&gt;\n');
                            });

                            $httpBackend.flush();
                        });

                        it('should log console error when the request failed', function () {
                            var mockLegalPaths = [
                                    '/legal/details-pages/legal-id-26c/jcr:content/warrantypar/warrantyinfo_0',
                                    '/legal/details-pages/legal-id-171/jcr:content/warrantypar/warrantyinfo_3'],
                                expectedErrorMessage = 'contentService.getProductLegalContent call failed.';

                            $httpBackend.whenGET(Endpoint_deviceLegalContentNode.get_shared_content.url_match)
                                .respond(404, '');
                            service.getProductLegalContent(mockLegalPaths).then(function () {
                                fail('Response that should have failed, succeeded!');
                            }).catch(function () {
                                expect($log.error).toHaveBeenCalledWith(expectedErrorMessage);
                            });

                            $httpBackend.flush();
                        });
                    });
                    describe('getSharedContent calls', function () {
                        it('should return results when called successfully', function () {
                            var mockLegalPaths = ['/Device_Insurance_Options/sku5370279'];
                            $httpBackend.whenGET(Endpoint_deviceLegalContentNode.get_device_shared_content.url_match.params_sent)
                                .respond(200, Endpoint_deviceLegalContentNode.get_device_shared_content.result);
                            service.getSharedContent(mockLegalPaths).then(function (legalContent) {
                                expect(Object.keys(legalContent)[0]).toEqual(mockLegalPaths[0]);
                                expect(legalContent[mockLegalPaths][0]).toContain('\n&lt;li&gt;Coverage against loss, theft, damage, and out-of-warranty malfunctions for one eligible device.&lt;/li&gt;');
                            });

                            $httpBackend.flush();
                        });

                        it('should return results when getsharedcontentforInsurance is called successfully', function () {
                            var index = 0;
                            var sku = 'sku5370279';

                            $httpBackend.whenGET(Endpoint_deviceLegalContentNode.get_device_shared_content.url_match.params_sent)
                                .respond(200, Endpoint_deviceLegalContentNode.get_device_shared_content.result);
                            service.getSharedContentForInsurance(index, sku).then(function (result) {
                                expect(result).toBeDefined();
                            });


                            $httpBackend.flush();
                        });

                        it('should log console error when the request failed', function () {
                            var mockLegalPaths = [
                                    '/Device_Insurance_Options/sku5370279'],
                                expectedErrorMessage = 'contentService.getSharedContent call failed.';

                            $httpBackend.whenGET(Endpoint_deviceLegalContentNode.get_device_shared_content.url_match.params_sent)
                                .respond(404, '');
                            service.getSharedContent(mockLegalPaths).then(function () {
                                fail('Response that should have failed, succeeded!');
                            }).catch(function () {
                                expect($log.error).toHaveBeenCalledWith(expectedErrorMessage);
                            });

                            $httpBackend.flush();
                        });
                    });
                });
            });
        });
    });
})();
