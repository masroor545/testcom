(function () {
    'use strict';

    define(['profileInfoService'], function () {
        describe('src/main/modules/exCommon/services/profileInfoService.spec.js', function () {
            describe('profileInfoService service of exCommon', function () {
                var $httpBackend, service, $window, exCommonConstants;

                beforeEach(function () {
                    module('exCommon');

                    inject(function ($injector) {
                        $httpBackend = $injector.get('$httpBackend');
                        $window = $injector.get('$window');
                        service = $injector.get('profileInfoService');
                        exCommonConstants = $injector.get('exCommonConstants');
                        spyOn($window.sessionStorage, 'getItem');
                        spyOn($window.sessionStorage, 'setItem');
                    });
                });

                afterEach(function () {
                    $window.sessionStorage.setItem.calls.reset();
                    $window.sessionStorage.getItem.calls.reset();
                });


                describe('network related calls', function () {
                    afterEach(function () {
                        $httpBackend.verifyNoOutstandingExpectation();
                        $httpBackend.verifyNoOutstandingRequest();
                    });

                    it("should call the profileInfo service if the profile isn't stored", function () {
                        $httpBackend.whenGET(Endpoint_profileInfoApi.get_profile_info_auth.url_match)
                            .respond(200, Endpoint_profileInfoApi.get_profile_info_auth.result);

                        service.getProfileInfo().then(function (result) {
                            expect($window.sessionStorage.getItem).toHaveBeenCalledWith(exCommonConstants.profileStorageKey);
                            expect($window.sessionStorage.setItem).toHaveBeenCalledWith(exCommonConstants.profileStorageKey,
                                JSON.stringify(Endpoint_profileInfoApi.get_profile_info_auth.result));
                            expect(result).toBeDefined();
                            expect(result).toEqual(Endpoint_profileInfoApi.get_profile_info_auth.result);
                            expect(result.ProfileInfo.city).toEqual('BOTHELL');
                            expect(result.ProfileInfo.accountFirstName).toEqual('BEDROCK');
                            expect(result.ProfileInfo.recentServiceActivationTime).toEqual(1412121600000);
                        });

                        $httpBackend.flush();
                    });

                    it('should NOT call the profileInfo service if it is stored locally', function () {
                        var mockStoredProfile = {
                            'a': 'alpha',
                            'b': 'beta',
                            'c': 'charlie'
                        };
                        $window.sessionStorage.getItem.and.returnValue(JSON.stringify(mockStoredProfile));
                        service.getProfileInfo().then(function (result) {
                            expect($window.sessionStorage.getItem).toHaveBeenCalledWith(exCommonConstants.profileStorageKey);
                            expect(result).toBeDefined();
                            expect(result).toEqual(mockStoredProfile);
                            expect(result.a).toEqual('alpha');
                        });
                    });

                    it('should call the profileInfo service if we want to reload it', function () {
                        $httpBackend.whenGET(Endpoint_profileInfoApi.get_profile_info_auth.url_match)
                            .respond(200, Endpoint_profileInfoApi.get_profile_info_auth.result);

                        var mockStoredProfile = {
                            'a': 'alpha',
                            'b': 'beta',
                            'c': 'charlie'
                        };
                        $window.sessionStorage.getItem.and.returnValue(JSON.stringify(mockStoredProfile));
                        service.getProfileInfo('reload').then(function (result) {
                            expect($window.sessionStorage.getItem).toHaveBeenCalledWith(exCommonConstants.profileStorageKey);
                            expect($window.sessionStorage.setItem).toHaveBeenCalledWith(exCommonConstants.profileStorageKey,
                                JSON.stringify(Endpoint_profileInfoApi.get_profile_info_auth.result));
                            expect(result).toBeDefined();
                            expect(result).toEqual(Endpoint_profileInfoApi.get_profile_info_auth.result);
                            expect(result.ProfileInfo.city).toEqual('BOTHELL');
                            expect(result.ProfileInfo.accountFirstName).toEqual('BEDROCK');
                            expect(result.ProfileInfo.recentServiceActivationTime).toEqual(1412121600000);
                        });

                        $httpBackend.flush();
                    });
                });
            });
        });
    });
})();
