(function () {
    'use strict';

    define(['deviceConfigSrv'], function () {
        describe('src/main/modules/exCommon/services/deviceConfigSrv.spec.js', function () {
            describe('deviceConfigSrv service of exCommon', function () {
                var $http, $httpBackend, $cacheFactory, service, $rootScope, $log;

                beforeEach(function () {
                    module('exCommon');

                    inject(function ($injector) {
                        $httpBackend = $injector.get('$httpBackend');
                        $http = $injector.get('$http');
                        $cacheFactory = $injector.get('$cacheFactory');
                        service = $injector.get('deviceConfigSrv');
                        $rootScope = $injector.get('$rootScope');
                        $log = $injector.get('$log');
                    });
                    spyOn($log, 'error');
                    spyOn($rootScope, '$broadcast');
                    spyOn($http, 'get').and.callThrough();
                    spyOn($cacheFactory, 'get').and.callThrough();

                });

                // Network related cals
                describe('network related calls', function () {
                    afterEach(function () {
                        $httpBackend.verifyNoOutstandingExpectation();
                        $httpBackend.verifyNoOutstandingRequest();
                    });

                    describe('get device details', function () {
                        it('should get information based on the selected SKU', function () {
                            $httpBackend.whenGET(Endpoint_deviceDetailsApi.get_device_details.url_match.params_sent).respond(200, Endpoint_deviceDetailsApi.get_device_details.result);
                            service.getDeviceDetails('sku8040300', Endpoint_deviceDetailsApi.params_sent).then(function (result) {
                                expect(result.data).toBeDefined();
                                expect(result.data.methodReturnValue).toBeDefined();
                                expect(result.data.methodReturnValue.shortDisplayName).toEqual('Apple iPhone 7');
                                expect(result.data.methodReturnValue.manufacturer).toEqual('Apple');
                            });
                            $httpBackend.flush();
                        });

                        it('should flush cache results', function () {
                            $httpBackend.whenGET(Endpoint_deviceDetailsApi.get_device_details.url_match.params_sent).respond(200, Endpoint_deviceDetailsApi.get_device_details.result);
                            service.getDeviceDetails('sku8040300', Endpoint_deviceDetailsApi.params_sent, true).then(function (result) {
                                expect($cacheFactory.get).toHaveBeenCalled();
                            });
                            $httpBackend.flush();
                        });

                        it('should return a map based on size variants if multiple capacities exist', function () {
                            $httpBackend.whenGET(Endpoint_deviceDetailsApi.get_device_details.url_match.params_sent).respond(200, Endpoint_deviceDetailsApi.get_device_details.result);
                            service.getDeviceDetails('sku8040300', Endpoint_deviceDetailsApi.params_sent).then(function (result) {
                                expect(result.data).toBeDefined();
                                expect(result.data.methodReturnValue).toBeDefined();
                                expect(result.data.methodReturnValue.hasColorVariants).toBeTruthy();
                                expect(result.data.methodReturnValue.hasSizeVariants).toBeTruthy();
                                expect(result.data.methodReturnValue.sizeVariantsMap).toBeDefined();
                                expect(result.data.methodReturnValue.sizeVariantsMap['32 GB'].sku8040303.model).toEqual('iPhone 7');
                            });
                            $httpBackend.flush();
                        });

                        it('should return a map based on color variants if no capacities exist', function () {
                            $httpBackend.whenGET(Endpoint_deviceDetailsApi.get_device_details_no_size_variants.url_match.params_sent).respond(200, Endpoint_deviceDetailsApi.get_device_details_no_size_variants.result);
                            service.getDeviceDetails('sku7840239', Endpoint_deviceDetailsApi.params_sent).then(function (result) {
                                expect(result.data.methodReturnValue.hasColorVariants).toBeTruthy();
                                expect(result.data.methodReturnValue.hasSizeVariants).toBeFalsy();
                                expect(result.data).toBeDefined();
                                expect(result.data.methodReturnValue).toBeDefined();
                                expect(result.data.methodReturnValue.colorVariantsMap).toBeDefined();
                                expect(result.data.methodReturnValue.colorVariantsMap.sku7840240.model).toEqual('Galaxy S7');
                            });
                            $httpBackend.flush();
                        });

                        it('should return a map based on size variants if no capacities exist', function () {
                            $httpBackend.whenGET(Endpoint_deviceDetailsApi.get_device_details_no_variants.url_match.params_sent).respond(200, Endpoint_deviceDetailsApi.get_device_details_no_variants.result);
                            service.getDeviceDetails('sku7900638', Endpoint_deviceDetailsApi.params_sent).then(function (result) {
                                expect(result.data).toBeDefined();
                                expect(result.data.methodReturnValue).toBeDefined();
                                expect(result.data.methodReturnValue.hasColorVariants).toBeFalsy();
                                expect(result.data.methodReturnValue.hasSizeVariants).toBeFalsy();
                                expect(result.data.methodReturnValue.selectedSkuDetails).toBeTruthy();
                                expect(result.data.methodReturnValue.sizeVariantsMap).toBeDefined();
                                expect(result.data.methodReturnValue.selectedSkuDetails.model).toEqual('Galaxy J3 2016');
                            });
                            $httpBackend.flush();
                        });

                        it('should get information based on the default SKU', function () {
                            $httpBackend.whenGET(Endpoint_deviceDetailsApi.get_filtered_upsell_device_details.url_match.params_sent).respond(200, Endpoint_deviceDetailsApi.get_filtered_upsell_device_details.result);
                            service.getDeviceDetails('sku8040300', Endpoint_deviceDetailsApi.params_sent).then(function (result) {
                                expect(result.data).toBeDefined();
                                expect(result.data.methodReturnValue).toBeDefined();
                                expect(result.data.methodReturnValue.shortDisplayName).toEqual('Apple iPhone 7');
                                expect(result.data.methodReturnValue.manufacturer).toEqual('Apple');
                            });
                            $httpBackend.flush();
                        });
                    });

                    it('should get delivery promise of the devices', function () {
                        var skuList = 'sku8040303,sku8040302,sku8040301,sku8040300,sku8250255';
                        $httpBackend.whenGET(Endpoint_deviceDetailsApi.get_device_delivery_promises.url_match.params_sent).respond(200, Endpoint_deviceDetailsApi.get_device_delivery_promises.result);
                        service.getDeliveryPromiseMessage(skuList).then(function (result) {
                            expect(result.data).toBeDefined();
                            expect(result.data.payload).toBeDefined();
                            expect((result.data.payload.skuShipmentDates).length).toEqual(5);
                        });
                        $httpBackend.flush();
                    });

                });

                // Determine Color theme
                describe('color theme', function () {
                    it('should return a theme based on a hex value', function () {
                        expect(service.getColorTheme('#C14242')).toEqual('dark');
                        expect(service.getColorTheme('#c14242')).toEqual('dark');
                        expect(service.getColorTheme('#ffffff')).toEqual('light');
                    });
                });


                describe('hylaPromotionDetails function of the deviceConfigSrv', function () {

                    it('should get hyla offer content by calling endpoint rest api', function (done) {
                        $httpBackend.expectGET(Endpoint_hylaPromotion.hyla_promotion_legal_details.url_match)
                            .respond(200, Endpoint_hylaPromotion.hyla_promotion_legal_details.result);
                        service.hylaPromotionDetails().then(function (result) {
                            expect(result).toBeDefined();
                            expect(result['offercontent/hylaOffer'].subtitle[0]).toEqual('*Each req&rsquo;s $750 on installment agmt &amp; elig. svc. Req&rsquo;s a new line. Free after $750 in credits over 30 months. Credits start in 2 to 3 bills. If svc cancelled, device balance due. Taxes &amp; fees apply. For email: add at end &ldquo;See details below.&rdquo; For direct mail &ndash; (if Bottom legal is on a different page): Limited Time Offer (ends 5/31/17 in Puerto Rico).  Req&rsquo;s well-qual. credit.  Free after $750 in bill credits over 30 mos.  Credits start in 2-3 bills.  If svc cancelled, device balance due.  Taxes &amp; fees apply.  See att.com/buyonegiveone for more details.');
                            done();
                        });

                        $httpBackend.flush();
                    });

                    it('should log console error when the request failed', function (done) {
                        var expectedErrorMessage = 'deviceConfigSrv.hylaPromotionDetails call failed.';
                        $httpBackend.expectGET(Endpoint_hylaPromotion.hyla_promotion_legal_details.url_match)
                            .respond(404, '');
                        service.hylaPromotionDetails().then(function () {
                            fail('Response that should have failed, succeeded!');
                        }).catch(function () {
                            expect($log.error).toHaveBeenCalledWith(expectedErrorMessage);
                            done();
                        });
                        $httpBackend.flush();
                    });

                });

            });
        });
    });
})();
