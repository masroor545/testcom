(function () {
    'use strict';

    angular.module('exCommon')

        .factory('upgradingUserInfoSrv', ['$http', '$q', '$window', 'exCommonConstants', 'exCacheManager', '$cookies', function ($http, $q, $window, exCommonConstants, exCacheManager, $cookies) {
            var services = {};

            /**
            * gets the upgrading device detail and store it to session storage
            * @function getUpgradingDeviceDetailsData
            * @param {boolean} [action] if action is true then reload the upgrading device details from buyflowApi,
            * and if not then get the data from session.
            * @returns {object} promise object upgrading device
            */
            services.getUpgradingDeviceDetailsData = function (action) {
                var storageKey = exCommonConstants.selectedLineStorageKey;

                // grabbing the shopsessionID that is in the browser cookie to grab current sessionID
                storageKey = storageKey + '-' + $cookies.get('SHOPSESSIONID');
                var storedUpLine = $window.sessionStorage.getItem(storageKey);

                // we don't want to refresh the upgrading device details, and we got it from storage.
                if (action !== true && (storedUpLine !== null && storedUpLine !== undefined)) {
                    // yes, let's wrap it in a promise and return it
                    return $q.when(JSON.parse(storedUpLine));
                } else {
                    return $http.get(exCommonConstants.buyflowApi, {
                        params: {actionType: 'selectedupline'},
                        cache: exCacheManager.getCache()
                    }).then(function (results) {
                        // store the upgrading line result
                        $window.sessionStorage.setItem(storageKey, JSON.stringify(results.data));
                        // and return the upgrading line result
                        return results.data;
                    });
                }
            };

            /**
             * Clean session storage for selected line and cache both
             * @function clearUpgradingLineCache
             */
            services.clearUpgradingLineCache = function () {
                var param = {actionType: 'selectedupline'};
                var storageKey = exCommonConstants.selectedLineStorageKey;

                // grabbing the shopsessionID that is in the browser cookie to grab current sessionID
                storageKey = storageKey + '-' + $cookies.get('SHOPSESSIONID');
                $window.sessionStorage.removeItem(storageKey);
                exCacheManager.clearCacheItem(exCommonConstants.buyflowApi, param);
            };

            /**
             * Returns formatted upgrading device type
             * @function getDeviceType
             * @param {string} deviceType upgrading device type
             * @returns {string} upDeviceType formatted upgrading device type
             */
            services.getDeviceType = function (deviceType) {
                var upDeviceType;
                // set upgrading device type
                if (deviceType === 'handset' || deviceType === 'pda') {
                    upDeviceType = 'phone';
                } else if (deviceType === 'netbook') {
                    upDeviceType = 'tablet';
                } else if (deviceType === 'network') {
                    upDeviceType = 'device';
                } else {
                    upDeviceType = 'device';
                }
                return upDeviceType;
            };

            return services;
        }]);
})();
