(function () {
    'use strict';

    define(['upsellOfferSrv'], function () {
        describe('src/main/modules/exCommon/services/upsellOfferSrv.spec.js', function () {
            describe('upsellOfferSrv service of exCommon', function () {
                var $httpBackend, service, $window, exCommonConstants;

                beforeEach(function () {
                    module('exCommon');

                    inject(function ($injector) {
                        $httpBackend = $injector.get('$httpBackend');
                        service = $injector.get('upsellOfferSrv');
                        $window = $injector.get('$window');
                        exCommonConstants = $injector.get('exCommonConstants');
                    });
                    spyOn($window.sessionStorage, 'getItem');
                    spyOn($window.sessionStorage, 'setItem');
                });

                afterEach(function () {
                    $window.sessionStorage.setItem.calls.reset();
                    $window.sessionStorage.getItem.calls.reset();
                });

                it('should get the upsell offer details from the upsell offer API', function () {
                    $httpBackend.whenGET(Endpoint_upsellOfferDetailsApi.get_upsell_offer_details.url_match)
                        .respond(200, Endpoint_upsellOfferDetailsApi.get_upsell_offer_details.result);
                    service.getUpsellOfferDetails().then(function (result) {
                        expect(result.payload.methodReturnValue.skuItems).toBeDefined();
                        expect(result.payload.methodReturnValue.skuItems.sku8040303.model)
                            .toEqual('iPhone 7 32GB');
                    });
                    $httpBackend.flush();
                });

                it('should get the upsell offer legal content details from the upsell offer legal API', function () {
                    var mockOfferId = '200004';
                    $httpBackend.whenGET(Endpoint_upsellOfferContentNode.get_legal_content_node.url_match)
                        .respond(200, Endpoint_upsellOfferContentNode.get_legal_content_node.result);
                    service.getUpsellOfferContentDetails(mockOfferId).then(function (result) {
                        expect(result).toBeDefined();
                        expect(result['offercontent/200004'].subtitle[0]).toEqual('*Each req&rsquo;s $750 on installment agmt &amp; elig. svc. Req&rsquo;s a new line. Free after $750 in credits over 30 months. Credits start in 2 to 3 bills. If svc cancelled, device balance due. Taxes &amp; fees apply. For email: add at end &ldquo;See details below.&rdquo; For direct mail &ndash; (if Bottom legal is on a different page): Limited Time Offer (ends 5/31/17 in Puerto Rico). Req&rsquo;s well-qual. credit. Free after $750 in bill credits over 30 mos. Credits start in 2-3 bills. If svc cancelled, device balance due. Taxes &amp; fees apply. See att.com/buyonegiveone for more details.');
                    });
                    $httpBackend.flush();
                });

                it('should make a post call', function () {
                    var params = {skipToCheckout: true};
                    $httpBackend.whenPOST(Endpoint_upsellOfferSkipToCheckoutApi.skip_to_checkout.url_match)
                        .respond(200, Endpoint_upsellOfferSkipToCheckoutApi.skip_to_checkout.result);
                    service.skipToCheckout(params).then(function (result) {
                        expect(result).toBeDefined();

                    });
                    $httpBackend.flush();
                });

                describe('setRequiredOfferId function of the upsellOfferSrv', function () {
                    it('should set the shared data in into session storage', function () {
                        var offerId = {'offerId': '200004'};
                        service.setRequiredOfferId(offerId);
                        expect($window.sessionStorage.setItem)
                            .toHaveBeenCalledWith(exCommonConstants.upsellOfferId, offerId);
                    });
                });

                describe('getRequiredOfferId function of the upsellOfferSrv', function () {
                    it('should get the shared data in into session storage', function () {
                        var offerId = {'offerId': '200004'};
                        $window.sessionStorage.getItem.and.returnValue(offerId);
                        service.getRequiredOfferId();
                        expect($window.sessionStorage.getItem)
                            .toHaveBeenCalledWith(exCommonConstants.upsellOfferId);
                    });
                });

                describe('get legal content information for a specific offer', function () {
                    it('should get the see offer details legal content info', function () {
                        var offerId = {'offerId': '200004'};
                        $httpBackend.whenGET(Endpoint_upsellOfferContentNode.get_legal_content_node.url_match)
                            .respond(200, Endpoint_upsellOfferContentNode.get_legal_content_node.result);
                        service.getUpsellOfferLegalContentInfo().then(function (result) {
                            service.getUpsellOfferContentDetails(offerId).then(function (content) {
                                expect(result).toBeDefined();
                                expect(result).toEqual(content['offercontent/200004']['jcr:description'][0]);
                            });
                        });
                        $httpBackend.flush();
                    });
                });
            });
        });
    });
})();