(function () {
    'use strict';

    define(['upgradeLinesInfoService'], function () {
        describe('src/main/modules/exCommon/services/upgradeLinesInfoService.spec.js', function () {
            describe('upgradeLinesInfoService service of exCommon', function () {
                var service, $window, exCommonConstants;

                beforeEach(function () {
                    module('exCommon');

                    inject(function ($injector) {
                        service = $injector.get('upgradeLinesInfoService');
                        $window = $injector.get('$window');
                        exCommonConstants = $injector.get('exCommonConstants');
                    });
                    spyOn($window.sessionStorage, 'getItem');
                    spyOn($window.sessionStorage, 'setItem');
                });

                afterEach(function () {
                    $window.sessionStorage.setItem.calls.reset();
                    $window.sessionStorage.getItem.calls.reset();
                });

                describe('setUpgradeLinesInfo function of the upgradeLinesInfoService', function () {
                    it('should set the shared data in into session storage', function () {
                        var upgradeLinesInfo = true;
                        service.setUpgradeLinesInfo(upgradeLinesInfo);
                        expect($window.sessionStorage.setItem)
                            .toHaveBeenCalledWith(exCommonConstants.upgradeLineStorageKey, JSON.stringify(upgradeLinesInfo));
                    });
                });
                describe('getUpgradeLinesInfo function of the upgradeLinesInfoService', function () {
                    it('should get the shared data in into session storage', function () {
                        var upgradeLinesInfo = true;
                        $window.sessionStorage.getItem.and.returnValue(JSON.stringify(upgradeLinesInfo));
                        service.getUpgradeLinesInfo();
                        expect($window.sessionStorage.getItem)
                            .toHaveBeenCalledWith(exCommonConstants.upgradeLineStorageKey);
                    });
                });
            });
        });
    });
})();
