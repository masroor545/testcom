(function () {
    'use strict';

    define(['exCacheManager'], function () {
        describe('src/main/modules/exCommon/services/exCacheManager.spec.js', function () {
            describe('exCacheManager service of exCommon', function () {
                describe('when using the default cache manager', exCacheManagerTestConfig());
                describe('when configured to different cache manager', exCacheManagerTestConfig('express'));

                function exCacheManagerTestConfig (currCacheId) {
                    return function () {
                        var $httpBackend, $http, cache, exCacheManager, dataIndex = 1;

                        function getCacheConfig () {
                            return exCacheManager.getCache();
                        }

                        beforeEach(function () {
                            module('exCommon', function (exCacheManagerProvider) {
                                if (currCacheId !== undefined) {
                                    exCacheManagerProvider.setCacheId(currCacheId);
                                }
                            });

                            inject(function ($injector) {
                                $httpBackend = $injector.get('$httpBackend');
                                $http = $injector.get('$http');
                                exCacheManager = $injector.get('exCacheManager');
                            });

                            cache = exCacheManager.getCache();
                        });

                        afterEach(function () {
                            exCacheManager.getCache().removeAll();
                            $httpBackend.verifyNoOutstandingExpectation();
                            $httpBackend.verifyNoOutstandingRequest();
                        });

                        it('should remove items from cache when URL is passed for clearing (no params)', function () {
                            var requestURL = '/some/random/path';

                            $httpBackend.expectGET(requestURL)
                                .respond({apple: 'sauce'});

                            $http.get(requestURL, {cache: getCacheConfig()}).then(function () {
                                expect(cache.get(requestURL)[dataIndex])
                                    .toEqual(jasmine.objectContaining({apple: 'sauce'}));
                                exCacheManager.clearCacheItem(requestURL);
                                expect(cache.get(requestURL)).toBeUndefined();
                            });

                            $httpBackend.flush();
                        });

                        it('should remove items from cache when URL is passed for clearing (with params)', function () {
                            var requestURL = '/some/random/path/version2/',
                                requestParams = {
                                    paramTwo: 456,
                                    paramOne: 123
                                },
                                fullRequestURL = requestURL + '?paramOne=123&paramTwo=456';

                            $httpBackend.expectGET(fullRequestURL)
                                .respond({zebra: 'stripe'});

                            $http.get(requestURL, {
                                cache: getCacheConfig(),
                                params: requestParams
                            }).then(function () {
                                expect(cache.get(fullRequestURL)[dataIndex])
                                    .toEqual(jasmine.objectContaining({zebra: 'stripe'}));
                                exCacheManager.clearCacheItem(requestURL, requestParams);
                                expect(cache.get(fullRequestURL)).toBeUndefined();
                            });

                            $httpBackend.flush();
                        });

                        it('should remove items from cache when URL is passed for clearing with partial query string with params',
                            function () {
                                var requestURL = '/some/random/path/version2/?sku=1234',
                                    requestParams = {
                                        paramTwo: 456,
                                        paramOne: 123
                                    },
                                    fullRequestURL = requestURL + '&paramOne=123&paramTwo=456';

                                $httpBackend.expectGET(fullRequestURL)
                                    .respond({zebra: 'stripe'});

                                $http.get(requestURL, {
                                    cache: getCacheConfig(),
                                    params: requestParams
                                }).then(function () {
                                    expect(cache.get(fullRequestURL)[dataIndex])
                                        .toEqual(jasmine.objectContaining({zebra: 'stripe'}));
                                    exCacheManager.clearCacheItem(requestURL, requestParams);
                                    expect(cache.get(fullRequestURL)).toBeUndefined();
                                });

                                $httpBackend.flush();
                            });
                    };
                }
            });
        });
    });
})();
