(function () {
    'use strict';

    define(['exCqTranslatorKeyService'], function () {
        describe('src/main/modules/exCommon/services/exCqTranslatorKeyService.spec.js', function () {
            describe('exCqTranslatorKeyService service of exCommon', function () {
                var $httpBackend, $log, service, $window, exCommonConstants;

                beforeEach(function () {
                    module('exCommon');

                    inject(function ($injector) {
                        $httpBackend = $injector.get('$httpBackend');
                        $log = $injector.get('$log');
                        service = $injector.get('exCqTranslatorKeyService');
                        $window = $injector.get('$window');
                        exCommonConstants = $injector.get('exCommonConstants');
                        spyOn($window.sessionStorage, 'getItem');
                        spyOn($window.sessionStorage, 'setItem');
                        spyOn($log, 'error');
                    });
                });

                describe('network related calls', function () {
                    var keysParam = ['label.devicelist.viewAllDevices', 'label.defaultListPage.numberOfElement'],
                        endpointData = Endpoint_cqTranslatorKeys.get_cq_translator_keys,
                        endpointData_singular = Endpoint_cqTranslatorKeys.get_cq_translator_key_singular;

                    afterEach(function () {
                        $httpBackend.verifyNoOutstandingExpectation();
                        $httpBackend.verifyNoOutstandingRequest();
                    });

                    it('should call the service successfully', function () {
                        $httpBackend.whenGET(endpointData.url_match)
                            .respond(200, endpointData.result);

                        service.getCqTranslatorKeys(keysParam).then(function (result) {
                            expect($window.sessionStorage.getItem)
                                .toHaveBeenCalledWith(exCommonConstants.cqTranslatorStorageKey);
                            expect($window.sessionStorage.setItem)
                                .toHaveBeenCalledWith(exCommonConstants.cqTranslatorStorageKey,
                                    JSON.stringify(endpointData.result.result.methodReturnValue));
                            expect(result).toBeDefined();
                            expect(result).toEqual(endpointData.result.result.methodReturnValue);
                        });

                        $httpBackend.flush();
                    });

                    it('should log an error if the service call fails', function () {
                        var expectedErrorMessage = 'exCqTranslatorKeyService.getCqTranslatorKeys call failed.';

                        $httpBackend.whenGET(endpointData.url_match)
                            .respond(404, '');
                        service.getCqTranslatorKeys(keysParam).then(function () {
                            fail('Response that should have failed, succeeded!');
                        }).catch(function () {
                            expect($log.error).toHaveBeenCalledWith(expectedErrorMessage);
                        });

                        $httpBackend.flush();
                    });

                    it('should only make a call for the keys that don\'t exist in cache', function () {
                        var storedKey = {'label.devicelist.viewAllDevices': 'Viewing all devices compatible with: {plan name}'};

                        $window.sessionStorage.getItem.and.returnValue(JSON.stringify(storedKey));
                        $httpBackend.whenGET(endpointData_singular.url_match)
                            .respond(200, endpointData_singular.result);

                        service.getCqTranslatorKeys(keysParam).then(function (result) {
                            expect($window.sessionStorage.getItem)
                                .toHaveBeenCalledWith(exCommonConstants.cqTranslatorStorageKey);
                            expect($window.sessionStorage.setItem)
                                .toHaveBeenCalledWith(exCommonConstants.cqTranslatorStorageKey,
                                    JSON.stringify(endpointData.result.result.methodReturnValue));
                            expect(result).toBeDefined();
                            expect(result).toEqual(endpointData.result.result.methodReturnValue);
                        });

                        $httpBackend.flush();
                    });

                    it('should not make a call to the service if all keys exist in cache', function () {
                        $window.sessionStorage.getItem.and.returnValue(
                            JSON.stringify(endpointData.result.result.methodReturnValue)
                        );

                        service.getCqTranslatorKeys(keysParam).then(function (result) {
                            expect($window.sessionStorage.getItem)
                                .toHaveBeenCalledWith(exCommonConstants.cqTranslatorStorageKey);
                            expect(result).toEqual(endpointData.result.result.methodReturnValue);
                        });
                    });
                });
            });
        });
    });
})();
