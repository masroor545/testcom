(function () {
    'use strict';

    define(['exHelpUtils'], function () {
        describe('src/main/modules/exCommon/services/exHelpUtils.spec.js', function () {
            describe('exHelpUtils service of exCommon', function () {
                var exHelpUtils, structure, $modalStack, $rootScope, scope, $anchorScroll;

                beforeEach(function () {
                    // Spy object for $modalStack
                    $modalStack = jasmine.createSpyObj('$modalStack', ['getTop', 'dismiss']);
                    $anchorScroll = jasmine.createSpy('anchorScroll');

                    module('exCommon', {
                        $modalStack: $modalStack
                    });

                    inject(function ($injector) {
                        exHelpUtils = $injector.get('exHelpUtils');
                        $rootScope = $injector.get('$rootScope');
                        scope = $rootScope.$new();
                        $anchorScroll = $injector.get('$anchorScroll');
                    });

                    spyOn(scope, '$watch');

                    structure = {
                        abc: {
                            idx: 123,
                            def: {
                                idx: 456,
                                ghi: {
                                    idx: 789,
                                    jkl: {
                                        idx: 101112
                                    }
                                },
                                fox: [10, 20, 30, 40, ['uno', 'dos', 'three']],
                                skull: [
                                    {apple: 'computer'},
                                    {ibm: 'compatible'}
                                ]
                            }
                        }
                    };

                    $modalStack.getTop.and.returnValue({
                        key: 'dismiss'
                    });

                    // Reset all $modalStack calls
                    $modalStack.getTop.calls.reset();
                    $modalStack.dismiss.calls.reset();
                });

                it('should be able to return the value of an object given the string representation', function () {
                    expect(exHelpUtils.getValue('abc.def.idx', structure)).toEqual(structure.abc.def.idx);
                    expect(exHelpUtils.getValue('abc.def.ghi', structure)).toEqual(structure.abc.def.ghi);
                    expect(exHelpUtils.getValue('abc.def.fox[2]', structure)).toEqual(structure.abc.def.fox[2]);
                    expect(exHelpUtils.getValue('abc.def.fox[4][1]', structure)).toEqual(structure.abc.def.fox[4][1]);
                    expect(exHelpUtils.getValue('abc.def.skull[1].ibm', structure)).toEqual(structure.abc.def.skull[1].ibm);
                });

                it('should return undefined if the appropriate value is not found and not an error', function () {
                    expect(exHelpUtils.getValue('abc.def.lmn', structure)).toBeUndefined();
                    expect(exHelpUtils.getValue('abc.def.fox[30]', structure)).toBeUndefined();
                });

                it('should return undefined if an object does not exist', function () {
                    expect(exHelpUtils.getValue('abc.xxx.xxx', structure)).toBeUndefined();
                    expect(exHelpUtils.getValue('tpz.xxx.xxx', structure)).toBeUndefined();
                });

                it('should close an active DS2 modal', function (done) {
                    exHelpUtils.closeActiveModal();
                    // gets the active modal in DOM
                    expect($modalStack.getTop).toHaveBeenCalled();
                    // closes the active modal in DOM
                    expect($modalStack.dismiss).toHaveBeenCalled();
                    expect($modalStack.dismiss).toHaveBeenCalledWith('dismiss');
                    done();
                });

                it('should search for placeholder from input text and update with content', function () {
                    var textWithPlaceholder = 'Hi, {0}! Let&#239;&#191;½s start your upgrade.',
                        content = ['BEDROCK'];
                    expect(exHelpUtils.replacePlaceholdersWithContent(textWithPlaceholder, content))
                        .toEqual('Hi, BEDROCK! Let&#239;&#191;½s start your upgrade.');
                });

                it('should watch for whenever accordion is finished expanding and scroll to it', function () {
                    exHelpUtils.scrollToAccordion('accessory-details-container', 'overview-container', scope);
                    expect(scope.$watch).toHaveBeenCalled();
                });

                describe('Unique by key', function () {
                    it('should filter out objects that share values returned by key', function () {
                        var list = [{a: 1}, {a: 1}, {b: 1}];
                        var uniqueList = exHelpUtils.uniqueByKey(list, JSON.stringify);
                        expect(angular.equals(uniqueList, [{a: 1}, {b: 1}])).toEqual(true);
                        expect(uniqueList.length).toEqual(2);
                        expect(uniqueList).toContain({a: 1});
                        expect(uniqueList).toContain({b: 1});
                    });
                });

                describe('Memoize', function () {
                    it('should return the function results without calling the function', function () {
                        scope.func = function (val) { return val + 1; };
                        spyOn(scope, 'func').and.callThrough();
                        expect(exHelpUtils.memoize(scope.func)(1)).toEqual(2);
                        expect(scope.func).toHaveBeenCalled();
                        scope.func.calls.reset();
                        exHelpUtils.memoize(scope.func)(1);
                        expect(scope.func).not.toHaveBeenCalled();
                    });
                });
            });
        });
    });
})();
