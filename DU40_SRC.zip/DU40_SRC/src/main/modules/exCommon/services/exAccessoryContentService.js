(function () {
    'use strict';

    angular.module('exCommon')

        .factory('exAccessoryContentService', ['$log', '$q', '$http', 'exCommonConstants',
            function ($log, $q, $http, exCommonConstants) {
                var exAccessoryContentService = {
                    getDetailsLegacyContent: getDetailsLegacyContent
                };

                /**
                 * Makes a request to the accessory detail legacy content node and returns a promise.
                 *  If the promise resolves the result of the request will be returned.
                 * @function getDetailsLegacyContent
                 * @param {String} accessoryPagePath The URL path to the page of which we want to retrieve
                 * the overview content for.
                 * @returns {Promise<Object>} Returns a promise of accessory detail legacy content results.
                 * @namespace exAccessoryContentService
                 */
                function getDetailsLegacyContent (accessoryPagePath) {
                    var accessoryDetailContentNode = accessoryPagePath + exCommonConstants.accessoryDetailLegacyNode;
                    return $http.get(accessoryDetailContentNode)
                        .then(getDetailsLegacyContentCompleted)
                        .catch(getDetailsLegacyContentFailed);
                }

                /**
                 * Returns the parsed and converted data property of the
                 * accessory detail legacy content response object.
                 * @function getDetailsLegacyContentCompleted
                 * @param {Object} result accessory detail legacy content response
                 * @returns {Promise<Object>} Returns the accessory detail legacy content
                 */
                function getDetailsLegacyContentCompleted (result) {
                    return result.data;
                }

                /**
                 * Logs an error and rejects the promise returned by the
                 * getDetailsLegacyContentFailed function.
                 * @param {Error} error Cart lookup response error object.
                 * @return {Promise<Error>} Returns rejected promise
                 */
                function getDetailsLegacyContentFailed (error) {
                    var message = 'exAccessoryContentService.getDetailsLegacyContent call failed.';
                    if (error.data && error.data.description) {
                        message += '\n' + error.data.description;
                    }
                    $log.error(message);
                    return $q.reject(error);
                }

                return exAccessoryContentService;
            }]);
})();
