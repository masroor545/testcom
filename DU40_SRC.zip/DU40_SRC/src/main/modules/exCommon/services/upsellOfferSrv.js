(function () {
    'use strict';

    angular.module('exCommon')

        .factory('upsellOfferSrv', ['$http', '$window', '$location', 'exCommonConstants',
            function ($http, $window, $location, exCommonConstants) {

                var services = {
                    getUpsellOfferDetails: getUpsellOfferDetails,
                    getUpsellOfferContentDetails: getUpsellOfferContentDetails,
                    skipToCheckout: skipToCheckout,
                    setRequiredOfferId: setRequiredOfferId,
                    getRequiredOfferId: getRequiredOfferId,
                    getUpsellOfferLegalContentInfo: getUpsellOfferLegalContentInfo
                };

                /**
                * gets the upsell offer details from upsellOffer api
                * @function getUpsellOfferDetails
                * @returns {object} promise upsell offer details
                */
                function getUpsellOfferDetails () {
                    return $http.get(exCommonConstants.upsellOfferApi, {
                        params: {
                            actionType: 'getupselldetails'
                        }
                    }).then(function (response) {
                        return response.data;
                    });
                }

                /**
                * gets the upsell offer content details from sharedContentRetrievalUrl
                * @function getUpsellContentDetails
                * @param {string} offerId specific offer id
                * @returns {object} data upsell offer legal content details
                */
                function getUpsellOfferContentDetails (offerId) {
                    var paramKey = 'path=offercontent/',
                        retrievalUrl = exCommonConstants.sharedContentRetrievalUrl,
                        params = '?' + paramKey + offerId;
                    return $http.get(retrievalUrl + params).then(function (response) {
                        return response.data;
                    });
                }

                /**
                 * Set shared information into session storage.
                 * @function setRequiredOfferId
                 */
                function setRequiredOfferId (offerId) {
                    $window.sessionStorage.setItem(exCommonConstants.upsellOfferId, offerId);
                }

                /**
                 * Get shared information which is saved in into session storage.
                 * @function getRequiredOfferId
                 * @returns {object} saved information in into session storage.
                 */
                function getRequiredOfferId () {
                    return $window.sessionStorage.getItem(exCommonConstants.upsellOfferId);
                }

                /**
                 * Get the offer details legal content information.
                 * @function getUpsellOfferLegalContentInfo
                 * @returns {string} offer legal information
                 */

                function getUpsellOfferLegalContentInfo () {
                    var OfferId = getRequiredOfferId();
                    return getUpsellOfferContentDetails(OfferId).then(function (data) {
                        var legalContent = '';
                        for (var item in data) {
                            if (data.hasOwnProperty(item)) {
                                legalContent = data[item]['jcr:description'][0];
                            }
                        }
                        return legalContent;
                    });
                }

                /**
                 * Makes a post service when clicked on proceed to checkout button
                 * The param acts like a flag to let back-end know not to redirect to upsellOffer page
                 * @function skipToCheckout
                 * @return {Object} data post response
                 */
                function skipToCheckout () {
                    return $http.post(exCommonConstants.exUpHandOffToCheckoutUrl, {skipToCheckout: true, pageSource: $location.search().pageSource}).then(function (response) {
                        return response.data;
                    });
                }

                return services;
            }]);
})();