(function () {
    'use strict';

    angular.module('exCommon')

        .provider('exCacheManager', function () {
            var cacheId = '$http';

            this.setCacheId = function (id) {
                cacheId = id;
            };

            this.$get = ['$cacheFactory', '$httpParamSerializer', function ($cacheFactory, $httpParamSerializer) {
                var currentCache;

                initialize();

                return {
                    clearCacheItem: clearCacheItem,
                    getCache: getCache
                };

                /**
                 * Constructs the URL that is used as the cache key
                 * @param {string} url path being requested
                 * @param {object} [params] key value pairs of the query string parameters
                 * @returns {string} the fully generated URL value
                 */
                function constructURL (url, params) {
                    var paramString = (params !== undefined) ? $httpParamSerializer(params) : '';

                    if (paramString.length > 0) {
                        url += ((url.indexOf('?') === -1) ? '?' : '&') + paramString;
                    }

                    return url;
                }

                /**
                 * Removes a select item from the current cache
                 * @param {string} url path being requested
                 * @param {object} [params] key value pairs of the query string parameters
                 */
                function clearCacheItem (url, params) {
                    currentCache.remove(constructURL(url, params));
                }

                /**
                 * @returns {object} the current cache object
                 */
                function getCache () {
                    return currentCache;
                }

                function initialize () {
                    if ($cacheFactory.get(cacheId) === undefined) {
                        $cacheFactory(cacheId);
                    }
                    currentCache = $cacheFactory.get(cacheId);
                }
            }];
        });
})();
