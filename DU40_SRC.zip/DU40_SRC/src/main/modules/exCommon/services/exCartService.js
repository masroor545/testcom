(function () {
    'use strict';

    angular.module('exCommon')

        .factory('exCartService', ['$log', '$q', '$http', '$window', 'exCommonConstants', '$rootScope',
            function ($log, $q, $http, $window, exCommonConstants, $rootScope) {
                var storageKey = exCommonConstants.cartStorageKey,
                    exCartService = {
                        getCart: getCart,
                        addItemToCart: addItemToCart,
                        removeItemFromCart: removeItemFromCart,
                        removeItemFromPersistentCart: removeItemFromPersistentCart
                    };

                /**
                 * Makes a POST request to the cart service API and returns a promise.
                 * @function addItemToCart
                 * @param {Object} items An object with key items and an array of items
                 * @param {Object} params A header params object
                 * @return {Promise<Object>} A promise of the add to cart results
                 */
                function addItemToCart (items, params) {
                    return $http.post(exCommonConstants.cartServiceApi, items, {
                        params: params,
                        spinner: true,
                        att: [exCommonConstants.http.postAuthReq]
                    }).then(addItemToCartCompleted)
                        .catch(addItemToCartFailed);
                }

                /**
                 * Returns the data property of the add item to cart response object.
                 * @function addItemToCartCompleted
                 * @param {Object} result add item to cart response
                 * @returns {Promise<Object>} Returns the add item to cart response data
                 */
                function addItemToCartCompleted (result) {
                    $rootScope.$broadcast(exCommonConstants.event.REFRESH_GLOBAL_NAV_CART, null);
                    return result.data;
                }

                /**
                 * Logs an error and rejects the promise returned by the add to cart item function.
                 * @function addItemToCartFailed
                 * @param {Error} error in add item to cart, error object.
                 * @return {Promise<Error>} Returns rejected promise
                 */
                function addItemToCartFailed (error) {
                    var message = 'exCartService.addItemToCart call failed.';
                    if (error.data && error.data.description) {
                        message += '\n' + error.data.description;
                    }
                    $log.error(message);
                    return $q.reject(error);
                }

                /**
                 * Makes a request to the cart lookup API and returns a promise.
                 *  If the promise resolves the result of the request will be returned.
                 * @function getCart
                 * @param {String} action Optional parameter which reloads the cart from the API,
                 *  even if stored locally, if it is set to anything but 'none'.
                 * @returns {Promise<Object>} Returns a promise of cart lookup results.
                 * @namespace exCartService
                 */
                function getCart (action) {
                    var storedCart;

                    action = action || 'none';
                    storedCart = $window.sessionStorage.getItem(storageKey);

                    // we don't want to refresh the cart, and we got it from storage.
                    if (action === 'none' && (storedCart !== null && storedCart !== undefined)) {
                        return $q.when(JSON.parse(storedCart));
                    } else {
                        // cart doesn't exist in storage, or needs to be refreshed
                        return $http.get(exCommonConstants.cartLookupApi)
                            .then(getCartCompleted)
                            .catch(getCartFailed);
                    }
                }

                /**
                 * Returns the data property of the cart lookup response object.
                 * @function getCartCompleted
                 * @param {Object} result Cart lookup response
                 * @returns {Promise<Object>} Returns the cart lookup response data
                 */
                function getCartCompleted (result) {
                    $window.sessionStorage.setItem(storageKey, JSON.stringify(result.data));
                    return result.data;
                }

                /**
                 * Logs an error and rejects the promise returned by the getCart function.
                 * @param {Error} error Cart lookup response error object.
                 * @return {Promise<Error>} Returns rejected promise
                 */
                function getCartFailed (error) {
                    var message = 'exCartService.getCart call failed.';
                    if (error.data && error.data.description) {
                        message += '\n' + error.data.description;
                    }
                    $log.error(message);
                    return $q.reject(error);
                }

                /**
                 * Makes a POST request to the remove cart item and returns a promise.
                 * @function removeItemFromCart
                 * @param {Object} params $http params object for commerce item removal
                 * @return {Promise<Object>} A promise of the remove to cart results
                 */
                function removeItemFromCart (params) {
                    var removeItemApi = exCommonConstants.buyflowApi + '?actionType=removeitem';
                    return $http.post(removeItemApi, params, {spinner: true})
                        .then(removeItemFromCartCompleted)
                        .catch(removeItemFromCartFailed);
                }

                /**
                 * Returns the data property of the remove item from cart response object.
                 * @function removeItemFromCartCompleted
                 * @param {Object} result remove item from cart response
                 * @returns {Promise<Object>} Returns the remove item from cart response data
                 */
                function removeItemFromCartCompleted (result) {
                    $rootScope.$broadcast(exCommonConstants.event.REFRESH_GLOBAL_NAV_CART, null);
                    return result.data;
                }

                /**
                 * Logs an error and rejects the promise returned by the remove cart item function.
                 * @function removeItemFromCartFailed
                 * @param {Error} error in remove item to cart, error object.
                 * @return {Promise<Error>} Returns rejected promise
                 */
                function removeItemFromCartFailed (error) {
                    var message = 'exCartService.removeItemFromCart call failed.';
                    if (error.data && error.data.description) {
                        message += '\n' + error.data.description;
                    }
                    $log.error(message);
                    return $q.reject(error);
                }

                /**
                 * Empty current cart
                 * @function removeItemFromPersistentCart
                 * @param {Param} Items availabe in cart.
                 * @returns {object} success or failure response from API service
                 */
                function removeItemFromPersistentCart (param) {
                    if (param) {
                        return $http.get(exCommonConstants.buyflowApi, {
                            params: {
                                actionType: 'emptycart'
                            }
                        }).then(function (response) {
                            return response.data;
                        }).catch(removeCartFailed);
                    } else {
                        return $q.when();
                    }
                }

                /**
                 * Logs an error and rejects the promise returned by the removeItemFromPersistentCart function.
                 * @param {Error} error Empth cart response error object.
                 * @return {Promise<Error>} Returns rejected promise
                 */
                function removeCartFailed (error) {
                    var message = 'exCartService.removeItemFromPersistentCart call failed.';
                    if (error.data && error.data.description) {
                        message += '\n' + error.data.description;
                    }
                    $log.error(message);
                    // return promise event empth cart API gets failed
                    return $q.when(error);
                }
                return exCartService;

            }]);
})();