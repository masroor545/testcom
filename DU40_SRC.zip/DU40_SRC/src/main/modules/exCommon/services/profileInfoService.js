(function () {
    'use strict';

    angular.module('exCommon')

        .factory('profileInfoService', ['$log', '$q', '$http', '$window', 'exCommonConstants',
            function ($log, $q, $http, $window, exCommonConstants) {
                var storageKey = exCommonConstants.profileStorageKey,
                    profileInfo = {
                        getProfileInfo: getProfileInfo
                    };

                /**
                 * @function getProfileInfo
                 * @param action - Reloads the profile from the profileInfoApi instead of using the cached version if
                 *  action is anything different than 'none'.
                 * @returns {Promise} Returns a promise of the profileInfo data returned by the profileInfoApi
                 * @namespace profileInfoService
                 */
                function getProfileInfo (action) {
                    var storedProfile;

                    action = action || 'none';
                    storedProfile = $window.sessionStorage.getItem(storageKey);

                    // we don't want to refresh the profile, and we got it from storage.
                    if (action === 'none' && (storedProfile !== null && storedProfile !== undefined)) {
                        return $q.when(JSON.parse(storedProfile));
                    } else {
                        // load the profile, store it and then return it.
                        return $http.get(exCommonConstants.profileInfoApi, {spinner: true})
                            .then(getProfileInfoCompleted)
                            .catch(getProfileInfoFailed);
                    }
                }

                /**
                 * @function getProfileInfoCompleted
                 * @param {object} result The data that is returned by the successful getProfileInfo function.
                 */
                function getProfileInfoCompleted (result) {
                    $window.sessionStorage.setItem(storageKey, JSON.stringify(result.data));
                    return result.data;
                }

                /**
                 * @function getProfileInfoFailed
                 * @param {object} error object returned by the failed getProfileInfo function.
                 * @returns {Promise} Returns a rejected promise.
                 */
                function getProfileInfoFailed (error) {
                    var message = 'profileInfoService.getProfileInfo call failed.';
                    if (error.data && error.data.description) {
                        message += '\n' + error.data.description;
                    }
                    $log.error(message);
                    return $q.reject(error);
                }

                return profileInfo;
            }]);
})();
