(function () {
    'use strict';

    define(['exCartService'], function () {
        describe('src/main/modules/exCommon/services/exCartService.spec.js', function () {
            describe('exCartService service of exCommon', function () {
                var $httpBackend, service, $log, $window, exCommonConstants;

                beforeEach(function () {
                    module('exCommon');

                    inject(function ($injector) {
                        $httpBackend = $injector.get('$httpBackend');
                        $log = $injector.get('$log');
                        $window = $injector.get('$window');
                        service = $injector.get('exCartService');
                        exCommonConstants = $injector.get('exCommonConstants');
                        spyOn($window.sessionStorage, 'getItem');
                        spyOn($window.sessionStorage, 'setItem');
                        spyOn($log, 'error');
                    });

                });

                describe('network related calls', function () {
                    afterEach(function () {
                        $httpBackend.verifyNoOutstandingExpectation();
                        $httpBackend.verifyNoOutstandingRequest();
                    });

                    it("should call the cart lookup service if the cart isn't stored", function () {
                        $httpBackend.whenGET(Endpoint_cartLookupApi.get_cart_lookup_new.url_match)
                            .respond(200, Endpoint_cartLookupApi.get_cart_lookup_new.result);

                        service.getCart().then(function (result) {
                            expect($window.sessionStorage.getItem).toHaveBeenCalledWith(exCommonConstants.cartStorageKey);
                            expect($window.sessionStorage.setItem).toHaveBeenCalledWith(exCommonConstants.cartStorageKey,
                                JSON.stringify(Endpoint_cartLookupApi.get_cart_lookup_new.result));
                            expect(result).toBeDefined();
                            expect(result).toEqual(Endpoint_cartLookupApi.get_cart_lookup_new.result);
                            expect(result.result.methodReturnValue.lobTypes.WIRELESS.cartOneTimeAmount).toEqual(25);
                            expect(result.result.methodReturnValue.lobTypes.WIRELESS.currentLOSGId).toEqual('losg14580100');
                        });

                        $httpBackend.flush();
                    });

                    it('should NOT call the cart lookup service if it is stored locally', function () {
                        var mockStoredProfile = {
                            'a': 'alpha',
                            'b': 'beta',
                            'c': 'charlie'
                        };
                        $window.sessionStorage.getItem.and.returnValue(JSON.stringify(mockStoredProfile));
                        service.getCart().then(function (result) {
                            expect($window.sessionStorage.getItem).toHaveBeenCalledWith(exCommonConstants.cartStorageKey);
                            expect(result).toBeDefined();
                            expect(result).toEqual(mockStoredProfile);
                            expect(result.a).toEqual('alpha');
                        });
                    });

                    it('should call the cart lookup service if we want to reload it', function () {
                        $httpBackend.whenGET(Endpoint_cartLookupApi.get_cart_lookup_new.url_match)
                            .respond(200, Endpoint_cartLookupApi.get_cart_lookup_new.result);

                        var mockStoredProfile = {
                            'a': 'alpha',
                            'b': 'beta',
                            'c': 'charlie'
                        };
                        $window.sessionStorage.getItem.and.returnValue(JSON.stringify(mockStoredProfile));
                        service.getCart('reload').then(function (result) {
                            expect($window.sessionStorage.getItem).toHaveBeenCalledWith(exCommonConstants.cartStorageKey);
                            expect($window.sessionStorage.setItem).toHaveBeenCalledWith(exCommonConstants.cartStorageKey,
                                JSON.stringify(Endpoint_cartLookupApi.get_cart_lookup_new.result));
                            expect(result).toBeDefined();
                            expect(result).toEqual(Endpoint_cartLookupApi.get_cart_lookup_new.result);
                            expect(result.result.methodReturnValue.lobTypes.WIRELESS.cartOneTimeAmount).toEqual(25);
                            expect(result.result.methodReturnValue.lobTypes.WIRELESS.currentLOSGId).toEqual('losg14580100');
                        });

                        $httpBackend.flush();
                    });

                    it('should log console error when the cart request failed', function () {
                        var expectedErrorMessage = 'exCartService.getCart call failed.';

                        $httpBackend.whenGET(Endpoint_cartLookupApi.get_cart_lookup_new.url_match)
                            .respond(404, '');
                        service.getCart('reload').then(function () {
                            fail('Response that should have failed, succeeded!');
                        }).catch(function () {
                            expect($log.error).toHaveBeenCalledWith(expectedErrorMessage);
                        });
                        $httpBackend.flush();
                    });

                    it('should call the add to cart service with the params provided', function () {
                        $httpBackend.whenPOST(Endpoint_addToCart.url_match)
                            .respond(200, 'Endpoint_addToCart.add_to_cart.result');

                        var mockParam = Endpoint_addToCart.add_to_cart.params_sent;

                        var mockData = {
                            foo: 'foo',
                            bar: 'bar',
                            baz: 'baz'
                        };

                        service.addItemToCart(mockData, mockParam).then(function (result) {
                            expect(result).toBeDefined();
                        });

                        $httpBackend.flush();
                    });

                    it('should log console error when the add to cart request failed', function () {
                        var expectedErrorMessage = 'exCartService.addItemToCart call failed.';

                        $httpBackend.whenPOST(Endpoint_addToCart.url_match)
                            .respond(404, '');

                        var mockParam = Endpoint_addToCart.add_to_cart.params_sent;

                        var mockData = {
                            foo: 'foo',
                            bar: 'bar',
                            baz: 'baz'
                        };
                        service.addItemToCart(mockData, mockParam).then(function () {
                            fail('Response that should have failed, succeeded!');
                        }).catch(function () {
                            expect($log.error).toHaveBeenCalledWith(expectedErrorMessage);
                        });
                        $httpBackend.flush();
                    });

                    it('should call the remove from cart service with the params provided', function () {
                        $httpBackend.whenPOST(Endpoint_removeFromCart.url_match)
                            .respond(200, 'Endpoint_removeFromCart.remove_item_from_cart.result');

                        var mockParam = Endpoint_removeFromCart.remove_item_from_cart.params_sent;

                        service.removeItemFromCart(mockParam).then(function (result) {
                            expect(result).toBeDefined();
                        });

                        $httpBackend.flush();
                    });

                    it('should log console error when the remove from cart request failed', function () {
                        var expectedErrorMessage = 'exCartService.removeItemFromCart call failed.';

                        $httpBackend.whenPOST(Endpoint_removeFromCart.url_match)
                            .respond(404, '');
                        var mockParam = Endpoint_removeFromCart.remove_item_from_cart.params_sent;

                        service.removeItemFromCart(mockParam).then(function () {
                            fail('Response that should have failed, succeeded!');
                        }).catch(function () {
                            expect($log.error).toHaveBeenCalledWith(expectedErrorMessage);
                        });
                        $httpBackend.flush();
                    });

                    it('should call the add to cart service with the params provided', function () {
                        $httpBackend.whenPOST(Endpoint_addToCart.url_match)
                            .respond(200, 'Endpoint_upsellOfferAddToCart.add_to_cart.result');
                        var mockParam = Endpoint_addToCart.upsell_add_to_cart.params_sent;
                        var mockData = {
                            type: 'MixedCart',
                            newLine: 'true',
                            losg: 'Al'
                        };
                        service.addItemToCart(mockData, mockParam).then(function (result) {
                            expect(result).toBeDefined();
                        });
                        $httpBackend.flush();
                    });

                    it('should call the remove from persistent cart service', function () {
                        $httpBackend.whenGET(Endpoint_removeFromPersistentCart.url_match)
                            .respond(200, 'Endpoint_removeFromPersistentCart.remove_item_from_persistent_cart.result');
                        service.removeItemFromPersistentCart('param').then(function (result) {
                            expect(result).toBeDefined();
                        });
                        $httpBackend.flush();
                    });

                });
            });
        });
    });
})();