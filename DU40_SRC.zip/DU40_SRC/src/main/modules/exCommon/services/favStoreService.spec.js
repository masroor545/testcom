(function () {
    'use strict';

    define(['favStoreService'], function () {
        describe('src/main/modules/exCommon/services/favStoreService.spec.js', function () {
            describe('favStoreService service of exCommon', function () {
                var $httpBackend, service, $window, exCommonConstants;

                beforeEach(function () {
                    module('exCommon');

                    inject(function ($injector) {
                        $httpBackend = $injector.get('$httpBackend');
                        $window = $injector.get('$window');
                        service = $injector.get('favStoreService');
                        exCommonConstants = $injector.get('exCommonConstants');
                        spyOn($window.sessionStorage, 'getItem');
                        spyOn($window.sessionStorage, 'setItem');
                    });
                });

                afterEach(function () {
                    $window.sessionStorage.setItem.calls.reset();
                    $window.sessionStorage.getItem.calls.reset();
                });

                describe('network related calls', function () {
                    afterEach(function () {
                        $httpBackend.verifyNoOutstandingExpectation();
                        $httpBackend.verifyNoOutstandingRequest();
                    });

                    it('should get the favStoreId on the basis of upgrading user UUID and store it in session storage',
                        function () {
                            var uuid = Endpoint_favStoreApi.get_favStore.uuid;
                            $httpBackend.whenGET(Endpoint_favStoreApi.get_favStore.url_match)
                                .respond(200, Endpoint_favStoreApi.get_favStore.result);
                            service.getFavStoreId(uuid).then(function () {
                                expect($window.sessionStorage.setItem).toHaveBeenCalled();
                                expect($window.sessionStorage.setItem).toHaveBeenCalledWith(exCommonConstants.favStoreStorageKey,
                                    Endpoint_favStoreApi.get_favStore.result);
                            });

                            $httpBackend.flush();
                        }
                    );

                    it('should get the favStoreId from session storage', function () {
                        service.getFavStoreIdFromSessionStorage();
                        expect($window.sessionStorage.getItem).toHaveBeenCalled();
                        expect($window.sessionStorage.getItem).toHaveBeenCalledWith(exCommonConstants.favStoreStorageKey);
                    });
                });
            });
        });
    });
})();
