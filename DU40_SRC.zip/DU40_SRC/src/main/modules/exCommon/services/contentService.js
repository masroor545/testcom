(function () {
    'use strict';

    angular.module('exCommon')

        .factory('contentService', ['$log', '$q', '$http', 'exCommonConstants', 'exCacheManager',
            function ($log, $q, $http, exCommonConstants, exCacheManager) {
                var contentService = {
                    getProduct360Images: getProduct360Images,
                    getProductOverviewContent: getProductOverviewContent,
                    getProductFeaturesContent: getProductFeaturesContent,
                    getProductLegalPaths: getProductLegalPaths,
                    getProductLegalContent: getProductLegalContent,
                    transformThreeSixtyXml2Json: transformThreeSixtyXml2Json,
                    getSharedContent: getSharedContent,
                    getSharedContentForInsurance: getSharedContentForInsurance
                };

                /**
                 * Gets the insurance plan description from shared content service of CQ for each
                 * insurance sku.
                 *
                 * @function getSharedContentForInsurance
                 * @param {String[]} skuIds - An array of sku
                 * @returns {Object} contain the description of insurance
                 */
                function getSharedContentForInsurance (skuIds) {
                    var sharedContentPath = [];
                    for (var i = 0, len = skuIds.length; i < len; i++) {
                        sharedContentPath.push(exCommonConstants.insuranceOptionContentPath + skuIds[i]);
                    }
                    return getSharedContent(sharedContentPath);
                }

                /**
                 * Makes a request to a product 360 .xml file and returns a promise.
                 *  If the promise resolves the result of the request will be returned.
                 * @function getProduct360Images
                 * @param skuId SKU of the product of which we want to retrieve the image data for.
                 * @returns {Promise<Object>} Returns a promise of getProduct360Images results.
                 * @namespace contentService
                 */
                function getProduct360Images (skuId) {
                    var skuNumOnly = skuId.toLowerCase().replace('sku', ''),
                        threeSixtyPath = exCommonConstants.threeSixtyProductXmlPath.replace('{0}', skuNumOnly);
                    return $http.get(
                        threeSixtyPath,
                        {transformResponse: transformThreeSixtyXml2Json}
                    )
                        .then(getProduct360ImagesCompleted)
                        .catch(getProduct360ImagesFailed);
                }

                /**
                 * Transforms the 360 xml images data to a JSON array.
                 * @function transformThreeSixtyXml2Json
                 * @param response The response returned for the 360 .xml file request.
                 * @return {Array<Object>} JSON array that contains objects with image data.
                 */
                function transformThreeSixtyXml2Json (response) {
                    /*global DOMParser */
                    var parser = new DOMParser(),
                        doc = parser.parseFromString(response, 'application/xml'),
                        result = doc.documentElement.getElementsByTagName('image_info'),
                        images = [],
                        image = {},
                        attributes = ['path', 'suffix', 'title_en', 'title_es'],
                        imageNodeAttrValue;

                    // loop through results
                    for (var i = 0, resLen = result.length; i < resLen; i++) {
                        image = {};

                        // loop through attributes
                        for (var j = 0, attrLen = attributes.length; j < attrLen; j++) {
                            imageNodeAttrValue = result[i].attributes[attributes[j]];

                            if (imageNodeAttrValue !== null && imageNodeAttrValue !== undefined) {
                                image[attributes[j]] = imageNodeAttrValue.value || '';
                            } else {
                                image[attributes[j]] = '';
                            }
                        }

                        // add a url attribute to the JSON object that doesn't exist within the XML and which
                        // is concatenated from the path and suffix. This exists for developer convenience.
                        image['url'] = image.path + image.suffix;
                        images.push(image);
                    }

                    return images;
                }

                /**
                 * Returns the data property of the getProduct360Images response object.
                 * @function getProduct360ImagesCompleted
                 * @param {Object} result getProduct360Images response
                 * @returns {Promise<Object>} Returns the getProduct360Images response data
                 */
                function getProduct360ImagesCompleted (result) {
                    return result.data;
                }

                /**
                 * Logs an error and rejects the promise returned by the getProduct360Images function.
                 * @param {Error} error getProduct360Images response error object.
                 * @return {Promise<Error>} Returns rejected promise
                 */
                function getProduct360ImagesFailed (error) {
                    var message = 'contentService.getProduct360Images call failed.';
                    if (error.data && error.data.description) {
                        message += '\n' + error.data.description;
                    }
                    $log.error(message);
                    return $q.reject(error);
                }

                /**
                 * Makes a request to productPageUrl's product key features node, and returns a promise for it. If
                 *  the response is received it converts the response.data into a developer friendly JSON and returns
                 *  it.
                 * @function getProductOverviewContent
                 * @param productPageUrl URL of the product page of which we want to retrieve the overview content for.
                 * @return {Promise<Array>} Returns a promise of an overview content JSON object.
                 * @namespace contentService
                 */
                function getProductOverviewContent (productPageUrl) {
                    var productOverviewContentUrl = productPageUrl + exCommonConstants.productContentNodePath;

                    return $http({
                        method: 'GET',
                        url: productOverviewContentUrl,
                        cache: exCacheManager.getCache()
                    })
                        .then(getProductOverviewContentCompleted)
                        .catch(getProductOverviewContentFailed);
                }

                /**
                 * Parses and converts the getProductOverviewContent response.data object and returns a developer
                 *  friendly JSON.
                 * @function getProductOverviewContentCompleted
                 * @param {Object} result getProductOverviewContent response
                 * @returns {Array} Returns the getProductOverviewContent data as a developer friendly JSON.
                 */
                function getProductOverviewContentCompleted (result) {
                    var overviewNode,
                        subCategory = 0,
                        subCategoryName,
                        overviewContent = [],
                        overviewItem,
                        data = result.data;

                    // does a subcategory of the CQ key features exist?
                    if (data.rwdDetailsFeaturesSection &&
                        data.rwdDetailsFeaturesSection.rwddetailstopfeature &&
                        data.rwdDetailsFeaturesSection.rwddetailstopfeature.subCatagorytag) {

                        overviewNode = data.rwdDetailsFeaturesSection.rwddetailstopfeature.subCatagorytag;

                        // check if a certain subcategory exists
                        while (overviewNode[subCategory]) {
                            // and then lets create an object with all the data from that subcategory
                            overviewItem = {};
                            overviewItem['title'] = overviewNode[subCategory].subtitle;
                            overviewItem['description'] = overviewNode[subCategory].description;
                            overviewItem['icon'] = overviewNode[subCategory].iconselected;

                            // add the subcategory to the overview array
                            overviewContent.push(overviewItem);

                            // increment the subcategory index so we can process the next entry
                            subCategory += 1;
                        }
                    } else if (data.overviewpar) {

                        overviewNode = data.overviewpar;
                        //create subcategory name to check it that exist
                        subCategoryName = 'rwdoverviewsection_' + subCategory;
                        // check if a certain subcategory exists
                        while (overviewNode[subCategoryName]) {
                            // and then lets create an object with all the data from that subcategory
                            overviewItem = {};
                            overviewItem['title'] = overviewNode[subCategoryName].title;
                            overviewItem['description'] = overviewNode[subCategoryName].description;

                            // add the subcategory to the overview array
                            overviewContent.push(overviewItem);

                            // increment the subcategory index so we can process the next entry
                            subCategory += 1;
                            subCategoryName = 'rwdoverviewsection_' + subCategory;
                        }
                    }

                    return overviewContent;
                }

                /**
                 * Logs an error and rejects the promise returned by the getProductOverviewContent function.
                 * @param {Error} error getProductOverviewContent response error object.
                 * @return {Promise<Error>} Returns rejected promise
                 */
                function getProductOverviewContentFailed (error) {
                    var message = 'contentService.getProductOverviewContent call failed.';
                    if (error.data && error.data.description) {
                        message += '\n' + error.data.description;
                    }
                    $log.error(message);
                    return $q.reject(error);
                }

                /**
                 * Makes a request to productPageUrl's product specifications node and returns a Promise. If a successful
                 *  response is received it is converted into a developer friendly JSON and returned.
                 * @function getProductFeaturesContent
                 * @param productPageUrl URL of the product page of which we want to retrieve the overview content for.
                 * @return {Promise} Returns a promise of a features JSON object.
                 * @namespace contentService
                 */
                function getProductFeaturesContent (productPageUrl) {
                    var productContentUrl = productPageUrl + exCommonConstants.productContentNodePath;

                    return $http({
                        method: 'GET',
                        url: productContentUrl,
                        cache: exCacheManager.getCache()
                    })
                        .then(getProductFeaturesContentCompleted)
                        .catch(getProductFeaturesContentFailed);
                }

                /**
                 * Returns the parsed and converted JSON Array of the getProductFeaturesContent response.data object.
                 * @function getProductFeaturesContentCompleted
                 * @param {Object} result getProductFeaturesContent response
                 * @returns {Promise<Array>} Returns the getProductFeaturesContent response.data parsed and
                 *  converted to JSON.
                 */
                function getProductFeaturesContentCompleted (result) {
                    var featureNode,
                        featureKeys,
                        subCategory = 0,
                        featureContent = [],
                        featureItem,
                        entry,
                        sectionName = 'rwddetailssection',
                        data = result.data;

                    // check for cq details section
                    if (data.rwdDetailsSection) {
                        // store the section in a variable and extract the features object keys in order
                        featureNode = data.rwdDetailsSection;
                        featureKeys = Object.keys(featureNode).sort(_numSort);

                        // loop through the features object keys
                        for (var i = 0, len = featureKeys.length; i < len; i++) {
                            // does the object keys contain the section name we look for?
                            if (featureKeys[i].indexOf(sectionName) === 0) {
                                // create an empty feature object and set it's title property from the node section
                                featureItem = {};
                                featureItem.title = featureNode[featureKeys[i]].title;

                                // check if the feature node section has a subcatetegorytag node
                                if (featureNode[featureKeys[i]].subCatagorytag) {
                                    // create an entries array within the feature object
                                    featureItem.entries = [];

                                    // resetting subCategory counter, as there are multiple sub categories
                                    subCategory = 0;

                                    // check if a certain subcategory exists below the subcategorytag node
                                    while (featureNode[featureKeys[i]].subCatagorytag[subCategory]) {
                                        // create an entry object and set properties on it with node values
                                        entry = {};
                                        entry.title = featureNode[featureKeys[i]].subCatagorytag[subCategory].subtitle;
                                        entry.description = featureNode[featureKeys[i]].subCatagorytag[subCategory].description;

                                        // check if we are dealing with a checkbox
                                        if (entry.description === 'checkbox') {
                                            // create checked property for checkbox
                                            entry.checked = featureNode[featureKeys[i]].subCatagorytag[subCategory].showCheckMark;
                                        }

                                        // add the entry object to the feature entries array
                                        featureItem.entries.push(entry);

                                        // increment the subcategory index so we can process the next entry
                                        subCategory += 1;
                                    }
                                }

                                // add the feature item object to the features array
                                featureContent.push(featureItem);
                            }
                        }
                    }

                    return featureContent;
                }

                /**
                 * Logs an error and rejects the promise returned by the getProductFeaturesContent function.
                 * @param {Error} error getProductFeaturesContent response error object.
                 * @return {Promise<Error>} Returns rejected promise
                 */
                function getProductFeaturesContentFailed (error) {
                    var message = 'contentService.getProductFeaturesContent call failed.';
                    if (error.data && error.data.description) {
                        message += '\n' + error.data.description;
                    }
                    $log.error(message);
                    return $q.reject(error);
                }

                /**
                 * Special sort that sorts strings that have a number appended via an underscore.
                 *  Ex: example_10, example_0, example should return: example, example_0, example_10
                 * @param {String} a String 'a' to be sorted.
                 * @param {String} b String 'b' to be sorted.
                 * @return {number} Returns -1 if a < b, 1 if a > b, and 0 if a === b.
                 * @private
                 */
                function _numSort (a, b) {
                    var a_num = parseInt(a.split('_')[1] || '-1', 10),
                        b_num = parseInt(b.split('_')[1] || '-1', 10);

                    if (a_num < b_num) {
                        return -1;
                    }
                    if (a_num > b_num) {
                        return 1;
                    }
                    return 0;
                }

                /**
                 * Makes a request call to the products page legal content nodes returns a promise.
                 *  If the promise resolves the result of the request will be returned.
                 * @function getProductLegalPaths
                 * @param productPageUrl URL of the page we want to retrieve legal content for.
                 * @returns {Promise<Object>} Returns a promise of getProductLegalPaths results.
                 * @namespace contentService
                 */
                function getProductLegalPaths (productPageUrl) {
                    var productContentUrl = productPageUrl + exCommonConstants.productLegalContentNodePath;

                    return $http.get(productContentUrl)
                        .then(getProductLegalPathsCompleted)
                        .catch(getProductLegalPathsFailed);
                }

                /**
                 * Returns the parsed and converted JSON of the getProductLegalPaths response object.
                 * @function getProductLegalContentCompleted
                 * @param {Object} result getProductLegalPaths response
                 * @returns {Array} Returns the getProductLegalPaths response data
                 */
                function getProductLegalPathsCompleted (result) {
                    var legalPaths = [],
                        legalKeys = Object.keys(result.data),
                        sectionNames = ['legaldetailsreferenc', 'reference'],
                        sharedContentPath = '/content/sharedcontent/en',
                        legalPath;

                    for (var i = 0, len = legalKeys.length; i < len; i++) {
                        for (var j = 0, sectionLen = sectionNames.length; j < sectionLen; j++) {
                            if (legalKeys[i].indexOf(sectionNames[j]) === 0 && result.data[legalKeys[i]].path) {
                                legalPath = result.data[legalKeys[i]].path.replace(sharedContentPath, '');

                                // Only add legal path if it doesn't contains SEO link, as we don't want to display SEO content
                                if (legalPath.indexOf(exCommonConstants.seoCrossLinkLegal) === -1) {
                                    legalPaths.push(legalPath);
                                }
                            }
                        }
                    }

                    return legalPaths;
                }

                /**
                 * Logs an error and rejects the promise returned by the getProductLegalPaths function.
                 * @param {Error} error getProductLegalPaths response error object.
                 * @return {Promise<Error>} Returns rejected promise
                 */
                function getProductLegalPathsFailed (error) {
                    var message = 'contentService.getProductLegalPaths call failed.';
                    if (error.data && error.data.description) {
                        message += '\n' + error.data.description;
                    }
                    $log.error(message);
                    return $q.reject(error);
                }

                /**
                 * Makes a request call to the shared content retrieval service for the legalPaths
                 *  and returns a promise. If the promise resolves the result of the request will be returned.
                 * @function getProductLegalContent
                 * @param {Array} legalPaths that contains the paths array, returned from the getProductLegalPaths call.
                 * @returns {Promise<Array>} Returns a promise of getProductLegalContent results.
                 * @namespace contentService
                 */
                function getProductLegalContent (legalPaths) {

                    // splices the large legalPaths arrays into smaller arrays
                    function spliceArrays (bigArray, size) {
                        var smallArrays = [],
                            arrays = 0;

                        while (bigArray.length > 0) {
                            smallArrays[arrays] = bigArray.splice(0, size);
                            arrays += 1;
                        }

                        return smallArrays;
                    }

                    // creates the product legal content request urls for a set of legal path arrays
                    function createUrls (retrievalUrl, pathArrays) {
                        var urls = [],
                            paramKey = 'path=',
                            params = '';

                        for (var i = 0, pathArraysLen = pathArrays.length; i < pathArraysLen; i++) {
                            for (var j = 0, len = pathArrays[i].length; j < len; j++) {
                                if (j === 0) {
                                    params += '?' + paramKey + pathArrays[i][j];
                                } else {
                                    params += '&' + paramKey + pathArrays[i][j];
                                }
                            }
                            urls.push(retrievalUrl + params);
                            params = '';
                        }
                        return urls;
                    }

                    // TDP-279546: Need to reduce the paths per request to a maximum of 10, as the
                    // long request urls will otherwise fail in Chrome.
                    var pathsPerRequest = 10,
                        retrievalUrl = exCommonConstants.sharedContentRetrievalUrl,
                        pathsToSplice = JSON.parse(JSON.stringify(legalPaths)),
                        splicedLegalPaths = spliceArrays(pathsToSplice, pathsPerRequest),
                        legalUrls = createUrls(retrievalUrl, splicedLegalPaths),
                        promises = [];

                    // split the retrieval of the legal content over multiple calls
                    for (var i = 0, legalUrlsLen = legalUrls.length; i < legalUrlsLen; i++) {
                        promises.push($http.get(legalUrls[i]));
                    }

                    // only return the result when all calls have succeeded
                    return $q.all(promises).then(function (result) {
                        return getProductLegalContentCompleted(result, legalPaths);
                    }).catch(getProductLegalContentFailed);
                }

                /**
                 * Returns the parsed and converted JSON of the getProductLegalContent response object.
                 * @function getProductLegalContentCompleted
                 * @param {Object} results getProductLegalContent response (one or multiple)
                 * @param {Object<Array>} legalPaths getProductLegalPaths response
                 * @returns {Array} Returns the getProductLegalContent parsed and converted response as an array.
                 */
                function getProductLegalContentCompleted (results, legalPaths) {
                    // merge multiple objects into one object
                    function mergeObjects (objects) {
                        return objects.reduce(function (combined, _object) {
                            Object.keys(_object).forEach(function (_key) {
                                combined[_key] = _object[_key];
                            });
                            return combined;
                        }, {});
                    }

                    var legalContent = [];
                    var result = [];
                    var resultData = [];

                    for (var j = 0, resultsLen = results.length; j < resultsLen; j++) {
                        if (results[j].data) {
                            resultData.push(results[j].data);
                        }
                    }

                    result = mergeObjects(resultData);

                    for (var i = 0, len = legalPaths.length; i < len; i++) {

                        if (result &&
                            result[legalPaths[i]] &&
                            result[legalPaths[i]].description &&
                            result[legalPaths[i]].description[0]) {
                            legalContent.push(result[legalPaths[i]].description[0]);
                        }
                    }

                    return legalContent;
                }


                /**
                 * Logs an error and rejects the promise returned by the getProductLegalContent function.
                 * @param {Error} error getProductLegalContent response error object.
                 * @return {Promise<Error>} Returns rejected promise
                 */
                function getProductLegalContentFailed (error) {
                    var message = 'contentService.getProductLegalContent call failed.';
                    if (error.data && error.data.description) {
                        message += '\n' + error.data.description;
                    }
                    $log.error(message);
                    return $q.reject(error);
                }

                /**
                 * Makes a request call to the device shared content retrieval service for the contentPaths
                 * and returns a promise. If the promise resolves the result of the request will be returned.
                 *
                 * @function getSharedContent
                 * @param {String[]} contentPaths - contains the content paths
                 * @returns {Promise<Array>} Returns a promise of shared content results.
                 */
                function getSharedContent (contentPaths) {
                    var paramKey = 'path=',
                        retrievalUrl = exCommonConstants.sharedContentFetchUrl,
                        params = '';

                    for (var i = 0, len = contentPaths.length; i < len; i++) {
                        if (i === 0) {
                            params += '?' + paramKey + contentPaths[i];
                        } else {
                            params += '&' + paramKey + contentPaths[i];
                        }
                    }

                    return $http.get(retrievalUrl + params)
                        .then(function (data) {
                            return getSharedContentCompleted(data, contentPaths);
                        })
                        .catch(getSharedContentFailed);
                }

                /**
                 * Returns the parsed and converted JSON of the getSharedContent response object.
                 * @function getSharedContentCompleted
                 * @param {Object} result getSharedContent response
                 * @param {Object<Array>} contentPaths getSharedContent response
                 * @returns {Array} Returns the getSharedContent parsed and converted response as an array.
                 */
                function getSharedContentCompleted (result, contentPaths) {
                    var sharedContent = {},
                        descriptionLabel = 'jcr:description';

                    for (var i = 0, len = contentPaths.length; i < len; i++) {
                        if (result.data[contentPaths[i]] &&
                            result.data[contentPaths[i]][descriptionLabel]) {
                            sharedContent[contentPaths[i]] = result.data[contentPaths[i]][descriptionLabel];
                        }
                    }

                    return sharedContent;
                }


                /**
                 * Logs an error and rejects the promise returned by the getSharedContent function.
                 * @param {Error} error getSharedContent response error object.
                 * @return {Promise<Error>} Returns rejected promise
                 */
                function getSharedContentFailed (error) {
                    var message = 'contentService.getSharedContent call failed.';
                    if (error.data && error.data.description) {
                        message += '\n' + error.data.description;
                    }
                    $log.error(message);
                    return $q.reject(error);
                }

                return contentService;
            }]);
})();
