(function () {
    'use strict';

    angular.module('exCommon')

        .controller('protectionPlanDetailsCtrl', ['$scope', 'protectionPlanService', 'exCommonConstants', 'exCartService', 'exCqTranslatorKeyService', '$rootScope', 'reportingDataSrv', '$modalStack',
            function ($scope, protectionPlanService, exCommonConstants, exCartService, exCqTranslatorKeyService, $rootScope, reportingDataSrv, $modalStack) {

                var protectionPlanDetails = {
                    showProtectionPlanDetails: false,
                    legalHeader: {},
                    legalDescription: {}
                };
                //protectionPlanDetails logic is used in exprotectionplandetails.pug
                $scope.protectionPlanDetails = protectionPlanDetails;
                $scope.addProtectionPlanToCart = addProtectionPlanToCart;
                $scope.getProtectionPlanLegal = getProtectionPlanLegal;
                $scope.getProtectionPlan = getProtectionPlan;
                $scope.resetCTAButtons = resetCTAButtons;
                $scope.protectionFeature = {};

                /**
                 * Scope function to broadcast the protectionPlanAdded event with false value
                 * as user clicked cancel CTA, and did not added the protection plan to cart
                 */
                function resetCTAButtons () {
                    // Dismisses any modals that are present
                    var top = $modalStack.getTop();
                    if (top) {
                        $modalStack.dismiss(top.key);
                    }
                    $rootScope.$broadcast(exCommonConstants.event.protectionPlanAdded, false);
                }

                /**
                 * Scope function to add protection plan to cart if available
                 */
                function addProtectionPlanToCart () {
                    var eventPayload = reportingDataSrv.getAddToCartFeaturePayload($scope.protectionFeature);
                    $rootScope.$emit(exCommonConstants.event.DS_REPORTING_EVENT, {
                        eventAction: 'formSubmit',
                        eventCode: 'DS_Upgrade_Cart_Add_Submit',
                        additionaldata: eventPayload
                    }, $scope);

                    exCartService.addItemToCart({actionType: 'addItemAndGoToNextStep', skipRedirect: true}, formatCartItem()).then(function (result) {
                        if (result && result.payload && result.payload.rollupStatus === 'SUCCESS') {
                            $rootScope.$broadcast(exCommonConstants.event.protectionPlanAdded, true);
                        }

                        if (result && result.response !== undefined && result.response !== null
                            && result.response.status === exCommonConstants.errorStatus) {
                            eventPayload = reportingDataSrv.updateEventPayloadFailure(eventPayload, result);
                        }

                        $rootScope.$emit(exCommonConstants.event.DS_REPORTING_EVENT, {
                            eventAction: 'formResponse',
                            eventCode: 'DS_Upgrade_Cart_Add_Submit',
                            additionaldata: eventPayload
                        }, $scope);
                    });
                    // Dismisses any modals that are present
                    var top = $modalStack.getTop();
                    if (top) {
                        $modalStack.dismiss(top.key);
                    }
                }

                /**
                 * Scope function to get protection plan to legal if available
                 */
                function getProtectionPlanLegal (protectionFeature) {
                    var cmsKeys = [];
                    var protectionLegalHeader = exCommonConstants.insuranceCategories[protectionFeature.skuId];
                    cmsKeys.push(exCommonConstants.legalContentKeyPrefix + protectionFeature.skuId);
                    cmsKeys.push(protectionLegalHeader);
                    exCqTranslatorKeyService.getCqTranslatorKeys(cmsKeys).then(function (result) {
                        if (result) {
                            $scope.protectionPlanDetails.legalHeader = result[protectionLegalHeader];
                            $scope.protectionPlanDetails.legalDescription = result[exCommonConstants.legalContentKeyPrefix + protectionFeature.skuId];
                        }
                    });
                }

                /**
                 * Formats protection feature to be added as a cart item
                 * @returns {Object} Formatted cart item
                 */
                function formatCartItem () {
                    if ($scope.protectionFeature.skuId && $scope.protectionFeature.productId) {
                        var cartItem = {
                            items: {
                                items: [{}]
                            }
                        };

                        // Abbreviation
                        var item = cartItem.items.items[0];

                        item.quantity = 1;
                        item.catalogRefId = $scope.protectionFeature.skuId;
                        item.productId = $scope.protectionFeature.productId;

                        return cartItem;
                    }
                }

                /**
                 * Get cart data and updated few scope objects based on response
                 */
                function getCartData (action) {
                    exCartService.getCart(action).then(function (data) {
                        var currentLosg;
                        data = data.result;
                        $scope.protectionPlanInCartItem = false;
                        if (data &&
                            data.methodReturnValue &&
                            data.methodReturnValue.lobTypes &&
                            data.methodReturnValue.lobTypes.WIRELESS &&
                            data.methodReturnValue.lobTypes.WIRELESS.currentLOSGId) {
                            //broadcasting the updated cart data.
                            $rootScope.$broadcast(exCommonConstants.event.cartDataUpdated, data);
                            currentLosg = data.methodReturnValue.lobTypes.WIRELESS.losgs[data.methodReturnValue.lobTypes.WIRELESS.currentLOSGId];
                            if (currentLosg && currentLosg.cartItems && currentLosg.cartItems.feature) {
                                // Iterating all the features and finding the insurance feature.
                                angular.forEach(currentLosg.cartItems.feature, function (feature, featureKey) {
                                    if (feature.insuranceFeature === true
                                        && featureKey === $scope.protectionFeature.skuId) {
                                        $scope.protectionPlanInCartItem = true;
                                        $scope.featureCommerceItemId = feature.commerceItemId;
                                    }
                                });
                            }
                        }
                    });
                }

                /**
                 * Scope function to get the protection plan if available and initialize the protectionFeature variable
                 */
                function getProtectionPlan () {
                    protectionPlanService.getInsuranceFeatures().then(function (result) {
                        var isProtectionDetailsSet = false;
                        angular.forEach(result.payload, function (insuranceOption) {
                            if (insuranceOption.billCode === $scope.defaultInsuranceBillCode) {
                                $scope.protectionFeature = insuranceOption;
                                isProtectionDetailsSet = true;
                            }
                        });

                        if (isProtectionDetailsSet === false) {
                            // Default to the first insurance coming from API
                            $scope.protectionFeature = result.payload[Object.keys(result.payload)[0]];
                        }
                        getCartData();
                        getProtectionPlanLegal($scope.protectionFeature);
                    });
                }

                /**
                 * Starts up the controller
                 */
                function activate () {
                    getProtectionPlan();
                }

                activate();
            }]);
})();
