(function () {
    'use strict';

    define(['accessoryConfigCtrl'], function () {
        describe('src/main/modules/exCommon/controllers/accessoryConfigCtrl.spec.js', function () {
            describe('accessoryConfigCtrl controller of exCommon', function () {
                var controller, scope, $rootScope, $q, $anchorScroll, $window, exCommonConstants, reportingDataSrv,
                    imagePathService, $modalStack, exHelpUtils;

                // Endpoint abbreviation. Does not appear in tests
                var colorAndSizeAccessory = Endpoint_accessoryDetailsApi.accessory_details_size_and_color_variants;
                var colorOnlyAccessory = Endpoint_accessoryDetailsApi.accessory_details_only_color_variants;
                var noVariantsAccessory = Endpoint_accessoryDetailsApi.accessory_details_no_variants;
                var deliveryPromise = Endpoint_deviceDetailsApi.get_accessory_delivery_promises;

                var colorAndSizeAccessorySku = colorAndSizeAccessory.skuId;
                var colorOnlyAccessorySku = colorOnlyAccessory.skuId;
                var noVariantsAccessorySku = noVariantsAccessory.skuId;

                var deviceConfigSrv = {
                    getDeviceDetails: function (skuId) {
                        var deferred = $q.defer();
                        switch (skuId) {
                        case colorAndSizeAccessorySku:
                            deferred.resolve({
                                data: {
                                    result: colorAndSizeAccessory.result
                                }
                            });
                            break;
                        case colorOnlyAccessorySku:
                            deferred.resolve({
                                data: {
                                    result: colorOnlyAccessory.result
                                }
                            });
                            break;
                        case noVariantsAccessorySku:
                            deferred.resolve({
                                data: {
                                    result: noVariantsAccessory.result
                                }
                            });
                            break;
                        }
                        return deferred.promise;
                    },
                    getDeliveryPromiseMessage: function () {
                        var deferred = $q.defer();
                        deferred.resolve({
                            data: {
                                payload: deliveryPromise.result.payload
                            }
                        });
                        return deferred.promise;
                    }
                };

                $window = {
                    document: {
                        documentElement: {
                            clientWidth: 0
                        }
                    }
                };

                $anchorScroll = jasmine.createSpy('$anchorScroll');

                var exCartService = jasmine.createSpyObj('exCartService', ['addItemToCart', 'removeItemFromCart', 'getCart']);
                exCartService.addItemToCart.and.returnValue({
                    'then': function (callback) {
                        callback(true);
                    }
                });

                exCartService.removeItemFromCart.and.returnValue({
                    'then': function (callback) {
                        callback(true);
                    }
                });

                exCartService.getCart.and.returnValue({
                    'then': function (callback) {
                        callback(true);
                    }
                });

                imagePathService = jasmine.createSpyObj('imagePathService', ['getXpressImagePath']);
                imagePathService.getXpressImagePath.and.returnValue({
                    'then': function (callBackFN) {
                        callBackFN(true);
                    }
                });

                reportingDataSrv = jasmine.createSpyObj('reportingDataSrv', ['getAddToCartAccessoryDetailsPayload', 'getRemovePayload']);
                reportingDataSrv.getAddToCartAccessoryDetailsPayload.and.returnValue({
                    items: [{'itemSku': colorAndSizeAccessorySku}]
                });

                $modalStack = jasmine.createSpyObj('$modalStack', ['getTop', 'dismiss']);

                beforeEach(function () {
                    module('exCommon', {
                        exCommonConstants: exCommonConstants,
                        $modalStack: $modalStack,
                        deviceConfigSrv: deviceConfigSrv,
                        exCartService: exCartService,
                        $window: $window,
                        $anchorScroll: $anchorScroll
                    });

                    inject(function ($injector) {
                        exCommonConstants = $injector.get('exCommonConstants');
                        controller = $injector.get('$controller');
                        exHelpUtils = $injector.get('exHelpUtils');
                        $rootScope = $injector.get('$rootScope');
                        scope = $rootScope.$new();
                        $q = $injector.get('$q');
                    });

                    spyOn($rootScope, '$broadcast').and.callThrough();
                    spyOn(exHelpUtils, 'scrollToAccordion');

                    controller('accessoryConfigCtrl', {
                        $scope: scope,
                        imagePathService: imagePathService,
                        reportingDataSrv: reportingDataSrv
                    });
                });

                afterEach(function () {
                    // cleaning up the spies
                    exHelpUtils.scrollToAccordion.calls.reset();
                });

                // General functionality and skus with color + size
                describe('general functionality', function () {
                    beforeEach(function () {
                        $rootScope.$broadcast(exCommonConstants.event.accessorySelected, colorAndSizeAccessorySku);
                        $rootScope.$digest();
                    });

                    it('should get details about the selected device', function () {
                        expect(scope.accessoryConfig).toBeDefined();
                        expect(scope.accessoryConfig).not.toEqual({});
                        expect(scope.accessoryConfig.manufacturer).toEqual('Fitbit');
                        expect(scope.accessoryConfig.selectedSku.productDisplayName).toEqual('Fitbit Blaze Smart Fitness Watch');
                        expect(scope.accessoryConfig.selectedSku.rating).toEqual(4.38);
                        expect(scope.accessoryConfig.selectedSku.rating).toBeLessThan(5);
                        expect(scope.accessoryConfig.selectedSku.color).toEqual('Black');
                        expect(scope.accessoryConfig.selectedSku.hexValue).toEqual('#000001');
                        expect(scope.accessoryConfig.selectedSku.size).toEqual('L');
                        expect(scope.accessoryConfig.selectedSku.preOrderable).toEqual(false);
                        expect(scope.accessoryConfig.selectedSku.effectiveOutOfStock).toEqual(false);

                        // Color variant
                        expect(scope.accessoryConfig.selectedSku.colorVariant).toBeDefined();
                        expect(scope.accessoryConfig.selectedSku.colorVariant.id).toEqual(scope.accessoryConfig.selectedSku.color);
                        expect(scope.accessoryConfig.selectedSku.colorVariant.colorCode).toEqual(scope.accessoryConfig.selectedSku.hexValue);

                        // Size variant
                        expect(scope.accessoryConfig.selectedSku.sizeVariant).toBeDefined();
                        expect(scope.accessoryConfig.selectedSku.sizeVariant.id).toEqual(scope.accessoryConfig.selectedSku.size);

                        expect(scope.accessoryConfig.selectedSku.price).toEqual(149);
                        expect(scope.accessoryConfig.selectedSku.productId).toEqual('prod8560293');

                        // Retrieves image url to call a common imagePathSerivce function
                        expect(imagePathService.getXpressImagePath).toHaveBeenCalled();
                        expect(typeof imagePathService.getXpressImagePath.calls.mostRecent().args[1]).toEqual('object');
                        expect(imagePathService.getXpressImagePath.calls.count()).toEqual(5);
                    });

                    it('should list its size variants', function () {
                        expect(scope.accessoryConfig.sizeVariants).toBeDefined();
                        expect(scope.accessoryConfig.sizeVariants).not.toEqual([]);
                        expect(scope.accessoryConfig.selectedSku).toBeDefined();
                        expect(scope.accessoryConfig.selectedSku).not.toEqual({});
                        expect(scope.accessoryConfig.sizeVariants).toContain(scope.accessoryConfig.selectedSku);
                        scope.accessoryConfig.sizeVariants.forEach(function (sku) {
                            expect(sku.color).toEqual(scope.accessoryConfig.selectedSku.color);
                        });
                    });

                    it('should list all color variants', function () {
                        expect(scope.accessoryConfig.colorVariants).toBeDefined();
                        expect(scope.accessoryConfig.colorVariants).not.toEqual([]);
                        expect(scope.accessoryConfig.selectedSku).toBeDefined();
                        expect(scope.accessoryConfig.selectedSku).not.toEqual({});
                        expect(scope.accessoryConfig.colorVariants).toContain(scope.accessoryConfig.selectedSku);

                        var selSku = {
                            color: 'purple',
                            size: 'M'
                        };
                        var sameColorSku = {
                            color: selSku.color,
                            size: 'not ' + selSku.size
                        };
                        var nothingInCommonSku = {
                            color: 'not ' + selSku.color,
                            size: 'not ' + selSku.size
                        };

                        var mockSkuSiblings = [
                            [sameColorSku],

                            [selSku],

                            [nothingInCommonSku]
                        ];
                        var colorVariants = scope.getColorVariants(selSku, mockSkuSiblings);

                        expect(colorVariants).toContain(nothingInCommonSku);
                        expect(colorVariants).not.toContain(sameColorSku);
                    });

                    it('should update its size siblings when a new color is selected', function () {
                        var oldColorVariants = scope.accessoryConfig.colorVariants;

                        var newSku = scope.accessoryConfig.sizeVariants[0];
                        expect(newSku).not.toEqual(scope.accessoryConfig.selectedSku);

                        var newColorVariants = scope.getColorVariants(newSku, scope.accessoryConfig.skuSiblings);
                        expect(newColorVariants).not.toEqual(oldColorVariants);
                        expect(newColorVariants.length).toEqual(2);
                        expect(newColorVariants).toContain(newSku);
                    });

                    it('should update its color siblings when a new size is selected', function () {
                        var oldSizeVariants = scope.accessoryConfig.sizeVariants;

                        var newSku = scope.accessoryConfig.colorVariants[1];
                        expect(newSku).not.toEqual(scope.accessoryConfig.selectedSku);

                        var newSizeVariants = scope.getSizeVariants(newSku, scope.accessoryConfig.skuSiblings);
                        expect(newSizeVariants).not.toEqual(oldSizeVariants);
                        expect(newSizeVariants.length).toEqual(2);
                        expect(newSizeVariants).toContain(newSku);
                    });

                    it('should remove any preexisting sku information but keep user input information', function () {
                        var oldSelectedSku = scope.accessoryConfig.selectedSku;
                        var oldFocusedSku = scope.accessoryConfig.focusedSku;
                        var oldSizeVariants = scope.accessoryConfig.sizeVariants;
                        var oldColorVariants = scope.accessoryConfig.colorVariants;
                        var oldSkuSiblings = scope.accessoryConfig.skuSiblings;

                        var oldDisplayDeviceDetails = 'clearly obviously fake data';
                        var oldDisplayPricingOptions = 'clearly obviously fake data';

                        scope.accessoryConfig.displayDeviceDetails = oldDisplayDeviceDetails;
                        scope.accessoryConfig.displayPricingOptions = oldDisplayPricingOptions;

                        $rootScope.$broadcast(exCommonConstants.event.accessorySelected, colorOnlyAccessorySku);
                        $rootScope.$digest();

                        expect(scope.accessoryConfig.selectedSku).not.toEqual(oldSelectedSku);
                        expect(scope.accessoryConfig.focusedSku).not.toEqual(oldFocusedSku);
                        expect(scope.accessoryConfig.sizeVariants).not.toEqual(oldSizeVariants);
                        expect(scope.accessoryConfig.colorVariants).not.toEqual(oldColorVariants);
                        expect(scope.accessoryConfig.skuSiblings).not.toEqual(oldSkuSiblings);

                        expect(scope.accessoryConfig.displayDeviceDetails).toEqual(oldDisplayDeviceDetails);
                        expect(scope.accessoryConfig.displayPricingOptions).toEqual(oldDisplayPricingOptions);
                    });

                    it('should sort size siblings by marketing sequence', function () {
                        var sortedSiblings = scope.getColorVariants(scope.accessoryConfig.selectedSku, scope.accessoryConfig.skuSiblings);

                        // Iterates through all siblings and checks if the current
                        // marketing sequence is greater than the previous
                        sortedSiblings.reduce(function (marketingsequence, sku) {
                            if (sku.marketingsequence < marketingsequence) {
                                fail('sku siblings not sorted by marketing sequence');
                            }
                            return sku.marketingsequence;
                        }, 0);
                    });

                    it('should get the delivery promise message for the passed accessory skuIds', function () {
                        var accessorySkuidList = 'skuList=sku8040289,sku8040288,sku8040292,sku8040291,sku8040290';
                        deviceConfigSrv.getDeliveryPromiseMessage(accessorySkuidList).then(function () {
                            expect(accessoryConfig.deliveryPromiseMessage['sku8040289']).toBeDefined();
                            expect(accessoryConfig.deliveryPromiseMessage['sku8040290']).toBeDefined();
                            expect(accessoryConfig.deliveryPromiseMessage['sku8040289'].deliveryDateMessage).toEqual(
                                '!label.shipbetween.text! Jul 7, 2017 - Jul 11, 2017');
                            expect(accessoryConfig.deliveryPromiseMessage['sku8040290'].deliveryDateMessage).toEqual(
                                '!label.shipbetween.text! Jul 12, 2017 - Jul 15, 2017');
                        });
                    });

                    it('should add an item to cart', function () {
                        var cartItem,
                            params = {
                                actionType: 'addItemAndGoToNextStep',
                                skipRedirect: true
                            };
                        scope.accessoryConfigAddToCart();

                        // cart service call test
                        expect(exCartService.addItemToCart.calls.mostRecent().args.length).toEqual(2);
                        expect(typeof exCartService.addItemToCart.calls.mostRecent().args[0]).toEqual('object');
                        expect(typeof exCartService.addItemToCart.calls.mostRecent().args[1]).toEqual('object');

                        // cart item test
                        cartItem = exCartService.addItemToCart.calls.mostRecent().args[1].items;
                        expect(typeof cartItem).toEqual('object');
                        expect(cartItem).toBeDefined();
                        expect(cartItem.items[0].quantity).toEqual(1);
                        expect(cartItem.items[0].catalogRefId).toEqual(scope.accessoryConfig.selectedSku.skuId);
                        expect(typeof cartItem.items[0].productId).toEqual('string');
                        expect(exCartService.addItemToCart).toHaveBeenCalled();
                        expect(exCartService.addItemToCart).toHaveBeenCalledWith(params, {items: cartItem});

                        // update cart test
                        expect(exCartService.getCart).toHaveBeenCalledWith('reload');
                    });

                    it('Should not call getcart if addtocart gets called from the widget', function () {
                        scope.initargs = true;
                        exCartService.getCart.calls.reset();
                        scope.accessoryConfigAddToCart();
                        expect(exCartService.getCart).not.toHaveBeenCalledWith('reload');

                    });

                    describe('from widget', function () {
                        beforeEach(function () {
                            scope.initargs = {
                                type: 'cart'
                            };

                            //getting cart data for single losg in cart for one device added
                            var selectedAccessory = Endpoint_cartLookupApi.get_checkout_data_for_singleLOSG;
                            $rootScope.$broadcast.calls.reset();
                            $rootScope.$broadcast(exCommonConstants.event.accessorySelected, selectedAccessory);
                        });

                        var params = {
                            actionType: 'addItemAndGoToNextStep',
                            skipRedirect: true,
                            removalCommerceIds: '84208002789'
                        };

                        it('should remove and add to cart if the config is a widget in cart page', function () {
                            scope.accessoryConfigAddToCart();
                            expect(exCartService.addItemToCart.calls.mostRecent().args.length).toEqual(2);
                            expect(exCartService.addItemToCart.calls.mostRecent().args[0]).toEqual(params);
                        });

                        it('should set renderBV to false after addtocart from widget', function () {
                            scope.accessoryConfigAddToCart();
                            expect(scope.accessoryConfig.renderBV).toEqual(false);
                            expect(exCartService.addItemToCart.calls.mostRecent().args.length).toEqual(2);
                            expect(exCartService.addItemToCart.calls.mostRecent().args[0]).toEqual(params);
                        });
                    });

                    // remove from cart
                    it('should remove the accessory from cart and close the modal', function () {
                        var skuId = scope.accessoryConfig.selectedSku.skuId;
                        var commerceItemId = 'obviously mock data';
                        var params = {removalCommerceIds: commerceItemId};
                        scope.accessoryConfig.accessoriesInCart[skuId] = commerceItemId;

                        scope.accessoryConfigRemoveItemFromCart(skuId);

                        expect(exCartService.removeItemFromCart).toHaveBeenCalled();
                        expect(exCartService.removeItemFromCart).toHaveBeenCalledWith(params);
                        expect(exCartService.removeItemFromCart.calls.mostRecent().args[0]).toEqual(params);
                    });

                    it('should set a focused sku', function () {
                        expect(scope.accessoryConfig.focusedSku.color).toEqual(scope.accessoryConfig.selectedSku.color);
                        expect(scope.accessoryConfig.focusedSku.size).toEqual(scope.accessoryConfig.selectedSku.size);
                    });

                    it('should listen to updated sku broadcast', function () {
                        expect(scope.accessoryConfig.selectedSku.skuId).not.toEqual(colorOnlyAccessorySku);
                        $rootScope.$broadcast(exCommonConstants.event.accessorySelected, colorOnlyAccessorySku);
                        $rootScope.$digest();
                        expect(scope.accessoryConfig.selectedSku.skuId).toEqual(colorOnlyAccessorySku);
                    });

                    it('should scroll to the device details on landscape viewports', function () {
                        // Sets the client width below the breakpoint
                        $window.document.documentElement.clientWidth = 0;
                        scope.showAccessoryDetails();
                        expect(exHelpUtils.scrollToAccordion).not.toHaveBeenCalled();

                        // Sets the client width above the breakpoint
                        $window.document.documentElement.clientWidth = 10000;
                        scope.showAccessoryDetails();
                        expect(exHelpUtils.scrollToAccordion).toHaveBeenCalled();
                    });
                });

                describe('checking bv render flag', function () {
                    beforeEach(function () {
                        $rootScope.$broadcast(exCommonConstants.event.accessoryConfigWidgetBVInitiated, null);
                        $rootScope.$digest();
                    });
                    it('should set bv render flag to true', function () {
                        expect(scope.accessoryConfig.renderBV).toEqual(true);
                    });
                });

                describe('products with no size variants', function () {
                    beforeEach(function () {
                        $rootScope.$broadcast(exCommonConstants.event.accessorySelected, colorOnlyAccessorySku);
                        $rootScope.$digest();
                    });

                    it('should list its color siblings', function () {
                        expect(scope.accessoryConfig.colorVariants).toBeDefined();
                        expect(scope.accessoryConfig.colorVariants).not.toEqual([]);
                        expect(scope.accessoryConfig.selectedSku).toBeDefined();
                        expect(scope.accessoryConfig.selectedSku).not.toEqual({});
                        expect(scope.accessoryConfig.colorVariants).toContain(scope.accessoryConfig.selectedSku);
                        scope.accessoryConfig.colorVariants.forEach(function (sku) {
                            expect(sku.size).toEqual(scope.accessoryConfig.selectedSku.size);
                        });
                    });

                    it('should set a focused sku', function () {
                        expect(scope.accessoryConfig.focusedSku.color).toEqual(scope.accessoryConfig.selectedSku.color);
                        expect(scope.accessoryConfig.focusedSku.size).toEqual(scope.accessoryConfig.selectedSku.size);
                    });
                });

                describe('products with no variants', function () {
                    beforeEach(function () {
                        $rootScope.$broadcast(exCommonConstants.event.accessorySelected, noVariantsAccessorySku);
                        $rootScope.$digest();
                    });

                    it('should display the selected sku', function () {
                        expect(scope.accessoryConfig.selectedSku).toBeDefined();
                        expect(scope.accessoryConfig.selectedSku.skuId).toEqual(noVariantsAccessorySku);
                    });

                    it('should set a focused sku', function () {
                        expect(scope.accessoryConfig.focusedSku.color).toBeDefined();
                        expect(scope.accessoryConfig.focusedSku.size).toBeDefined();

                        expect(scope.accessoryConfig.focusedSku.color).toEqual(scope.accessoryConfig.selectedSku.color);
                        expect(scope.accessoryConfig.focusedSku.size).toEqual(scope.accessoryConfig.selectedSku.size);
                    });

                });

                describe('should check add to cart accessory reporting functionalities', function () {

                    beforeEach(function () {
                        spyOn(scope, '$emit').and.callThrough();
                        spyOn($rootScope, '$emit').and.callThrough();

                        $rootScope.$broadcast(exCommonConstants.event.accessorySelected, colorAndSizeAccessorySku);
                        $rootScope.$digest();
                        scope.$emit.calls.reset();
                    });

                    it('should check add to cart accessory reporting functionalities from accessory page', function () {
                        var expectedReportingObjectSubmit = jasmine.objectContaining({
                                eventAction: 'formSubmit',
                                eventCode: 'DS_Upgrade_Cart_Add_Submit',
                                additionaldata: jasmine.objectContaining({
                                    items: [jasmine.objectContaining({itemSku: colorAndSizeAccessorySku})]
                                })
                            }),
                            expectedReportingObjectResponse = jasmine.objectContaining({
                                eventAction: 'formResponse',
                                eventCode: 'DS_Upgrade_Cart_Add_Submit',
                                additionaldata: jasmine.objectContaining({
                                    items: [jasmine.objectContaining({itemSku: colorAndSizeAccessorySku})]
                                })
                            });
                        scope.accessoryConfigAddToCart();
                        expect(scope.$emit).toHaveBeenCalledWith('DS_Reporting_Event', expectedReportingObjectSubmit, jasmine.any(Object));
                        expect($rootScope.$emit).toHaveBeenCalledWith('DS_Reporting_Event', expectedReportingObjectResponse, jasmine.any(Object));
                        scope.$apply();
                    });

                    it('should check add to cart accessory reporting functionalities for preorder from accessory page', function () {
                        var expectedReportingObjectSubmit = jasmine.objectContaining({
                                eventAction: 'formSubmit',
                                eventCode: 'DS_Upgrade_Cart_Preorder_Submit',
                                additionaldata: jasmine.objectContaining({
                                    items: [jasmine.objectContaining({itemSku: colorAndSizeAccessorySku})]
                                })
                            }),
                            expectedReportingObjectResponse = jasmine.objectContaining({
                                eventAction: 'formResponse',
                                eventCode: 'DS_Upgrade_Cart_Preorder_Submit',
                                additionaldata: jasmine.objectContaining({
                                    items: [jasmine.objectContaining({itemSku: colorAndSizeAccessorySku})]
                                })
                            });
                        scope.accessoryConfig.selectedSku.preOrderable = true;
                        scope.accessoryConfigAddToCart();
                        expect(scope.$emit).toHaveBeenCalledWith('DS_Reporting_Event', expectedReportingObjectSubmit, jasmine.any(Object));
                        expect($rootScope.$emit).toHaveBeenCalledWith('DS_Reporting_Event', expectedReportingObjectResponse, jasmine.any(Object));
                        scope.$apply();
                    });
                });

            });

        });
    });

})();
