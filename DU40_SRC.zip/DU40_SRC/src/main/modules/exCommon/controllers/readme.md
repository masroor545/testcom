# exCommon Controllers

### deviceConfigCtrl

##### Description:
Exposes a sku and its configurable properties to scope. The controller looks in routing params for a sku ID and calls a service to get more information about the sku if present, otherwise it will check a service for a sku ID. If no sku ID is found the page fails to load.

##### Requirements:
* A sku ID which is used to get more information about the sku.
* A service that can provide its sku siblings as a map with the capacity as its first key. The service must also provide the make and model of the product.
* Skus returned by the service must contain a sku ID, color string, color hex, size, uom, rating and review count.

#### Functions:
#### ```formatSku(sku:Object) : Object```

##### Parameters:
* sku (required) - A sku object

##### Returns:
* A formatted (display-ready) sku object

**Description:**
Returns a sku formatted to be exposed to scope.

```javascript
formatSku(sku);
```
#### ```formatSkuPrice(term:string, priceList:object[]) : object```

##### Parameters:
* term (required) - The term the user has selected.
* priceList (required) - The sku's priceList

**Description:**
Gets the commitment term from the priceList based on term, if available. If the term is not found then the default commitment term is returned.

```javascript
formatSkuPrice(term);
```

#### ```onSkipToCheckout()```

**Description:**
Calls service to skip the deviceConfig page and redirect to onePageCheckout.

```javascript
onSkipToCheckout();
```

#### ```getDeviceInformation(skuId:string)```

##### Parameters:
* skuId (required) - A skuId

**Description:**
Calls service to get device details, creates a data structure to store the sku siblings (if any), exposes selected sku to scope, exposes sku siblings to scope.

```javascript
getDeviceInformation('sku8040300');
```
#### ```getDeliveryPromiseMessage(deviceMap:object, variantType:string)```

##### Parameters:
* deviceMap (required) - An object which has all size/color variants of a selected device.
* variantType (required) - The variant type of the device map, i.e either size, color, or no variants.

**Description:**
Calls service to get the delivery promise of all the variants(size/color) of the selected device, and puts the information in an array indexed by skuids of the selected and its variant devices.

```javascript
$scope.getDeliveryPromiseMessage(deviceMap, variantType);
```
#### ```displayDeviceDetails(visible:boolean)```

**Description:**
Scope function setter to show or hide the device details section.

```javascript
displayDeviceDetails(true)
```
or
```javascript
$scope.displayDeviceDetails(true)
```
#### ```displayEmptySmallerSpacingDiv()```

**Description:**
Scope function to display an empty smaller spacing div, allowing dynamic spacing for the price block

```javascript
displayEmptySmallerSpacingDiv()
```
or
```javascript
$scope.displayEmptySmallerSpacingDiv()
```

#### ```showDeliveryPromiseMessage(visible:boolean)```

**Description:**
Scope function setter to show or hide the delivery promise message section

```javascript
showDeliveryPromiseMessage(true)
or
$scope.showDeliveryPromiseMessage(true)
```
#### ```showPreOrderMessage(visible:boolean)```

**Description:**
Scope function setter to show or hide the pre-order message section

```javascript
showPreOrderMessage(true)
or
$scope.showPreOrderMessage(true)

#### ```showOutOfStockMessage(visible:boolean)```

**Description:**
Scope function setter to show or hide the out of stock information section

```javascript
showOutOfStockMessage(true)
or
$scope.showOutOfStockMessage(true)

```
#### ```showDeviceDetails()```

**Description:**
Scope function to show and scroll to the device details section

```javascript
showDeviceDetails();
```
or
```javascript
$scope.showDeviceDetails();
```
#### ```createCommitmentTermList(sku:Object)```

##### Parameters:
* sku (required) - The sku object that contains all the pricelist returned from the service

##### Returns:
* Display-ready pricelist with messages

**Description:**
Function that sets up the pricelist based on what the user is qualifed for. Sorts through the priceList and sets up the pricing based on the terms there.

```javascript
createCommitmentTermList(sku);
```

#### ```getPrice(commitmentTerm:Object)```

##### Parameters:
* commitmentTerm (required) - A commitment term that exists in a sku's pricelist


**Description:**
Gets price based on the commitment term

```javascript
setPrice(selectedCommitmentTerm);
```
#### ```getMonthlyPrice(commitmentTerm:Object)```

##### Parameters:
* commitmentTerm (required) - A commitment term that exists in a sku's pricelist


**Description:**
Gets monthly price based on commitment term

```javascript
setPrice(selectedCommitmentTerm);
```
#### ```getMonthlyLeasePriceRebate(selectedSku:Object)```

##### Parameters:
* selectedSku (required) - The selectedSku object that contains the selected pricelist item based off the term the user has selected from the change pricing option page.

**Description:**
Gets  monthly lease price rebate for the selected sku

```javascript
getMonthlyLeasePriceRebate(selectedSku);
```

#### ```setCommitmentTerm(selectedSku:Object)```

##### Parameters:
* selectedSku (required) - The selectedSku object that contains the selected pricelist item based off the term the user has selected from the change pricing option page.

**Description:**
Scope function to set price. Updates selected sku with the new selected price.


#### ```showReviewDetails()```

**Description:**
Scope function to scroll to the review details section and open reviews tab

```javascript
showReviewDetails();
```
or
```javascript
$scope.showReviewDetails();
```

#### ```setSelectedSku(sku:Object, variant:String)```

##### Parameters:
* sku:Object (required) - Set to the sku that is being selected
* variant:String (optional) - sets variant to identify if capacity is chosen

**Description:**
Scope function to set the selected sku and perform operations based on selected sku.

##### Requirements:
* Sets the price based on the selected contract type
* Gets short legal content for selected sku
* show/hide pre-order warning message for selected sku

```javascript
setSelectedSku(skuObject, 'capacityVariants');
```
or
```javascript
$scope.setSelectedSku(skuObject, 'capacityVariants');
```

#### ```changePricingOption()```

**Description:**
Scope function to see pricing Options modal

```javascript
changePricingOption()
```

#### ```closePricingOption()```

**Description:**
Scope function to close pricing Options modal

```javascript
closePricingOption()
```

#### ```getCapacityVariants(selSku:Object, skuSiblings:Array<Array>)```

##### Parameters:
* selSku (required) - The sku whose capacity variants you want to get
* skuSiblings (required) - a 2d array of skus in the same product family

##### Returns:
* An array of skus with matching capacities

**Description:**
Scope function to get sibling skus that share a color. Assumes color IS NOT the first key in the 2d array.

```javascript
getCapacityVariants(sku, skuItems)
```
or
```javascript
$scope.getCapacityVariants(sku, skuItems)
```

#### ```getSizeVariants(selSku:Object, skuSiblings:Array<Array>)```

##### Parameters:
* selSku (required) - The sku whose size variants you want to get
* skuSiblings (required) - a 2d array of skus in the same product family

##### Returns:
* An array of skus with matching capacities

**Description:**
Scope function to get sibling skus that share a color. Assumes color IS NOT the first key in the 2d array.

```javascript
getSizeVariants(sku, skuItems)
```
or
```javascript
$scope.getSizeVariants(sku, skuItems)
```

#### ```getColorVariants(selSku:Object, skuSiblings:Array<Array>)```

##### Parameters:
* selSku (required) - The sku whose color variants you want to get
* skuSiblings (required) - a 2d array of skus in the same product family

##### Returns:
* An array of skus with matching capacities

**Description:**
Scope function to get sibling skus that share a capacity. Assumes capacity IS the first key in the 2d array.

```javascript
getColorVariants(sku, skuItems)
```
or
```javascript
$scope.getColorVariants(sku, skuItems)
```

#### ```formatCartItem(sku:Object)```

##### Parameters:
* sku (required) - A sku object

##### Returns:
* Rest service call-ready cart item

**Description:**
Formats the sku to be added to cart.

```javascript
formatCartItem(sku)
```

#### ```addToCart( )```

**Description:**
Adds the item to cart.

```javascript
addItemToCart()
```
or
```javascript
$scope.addItemToCart()
```

#### ```close( )```

**Description:**
Closes all ds2 modals

```javascript
close()
```
or
```javascript
$scope.close()
```

#### ```showLegalAccordion()```

##### Parameters:
* none

**Description:**
Scope function to open legal accordion and scroll to legal section.

```javascript
showLegalAccordion();
```

#### ```getUpsellOfferLegalContent(deviceConfig:object)```

##### Parameters:
* deviceConfig (required) - device config object 

**Description:**
Get the see offer details legal content

```javascript
getUpsellOfferLegalContent(deviceConfig);
```

##### ```getHylaOfferInfo(sku:object)```

##### Parameters:
* sku (required) - selected sku object 

**Description:**
Hyla is a special trade in offer which deals with the existing device trade in programs and promotions. Get the hyla device trade in promo details based on eligibility. 

```javascript
getHylaOfferInfo(sku);
```

#### ```showHylaOffer(sku:object)```

##### Parameters:
* sku (required) - selected sku object

**Description:**
Scope function to show or hide the hyla offer details on view

```javascript
showHylaOffer(sku);
```

#### ```closeHylaModal()```

**Description:**
Function to close hyla promotion modal

```javascript
closeHylaModal();
```

#### ```fetchShortLegalContentForSelectedDevice(selectedSku:Object)```

##### Parameters:
* commitmentTerms (required) - commitmentTerms of selected device

**Description:**
Fetch CMS key content commitment terms of selected device and call cms translator key service to get short legal content

```javascript
fetchShortLegalContentForSelectedDevice(selectedSku);
```

#### ```getCommitmentDisclaimer(commitmentTerm:Object, disclaimer:String)```

##### Parameters:
* commitmentTerm (required) - pricing term
* disclaimer (required) - text configured in common constant for each pricing option

**Description:**
Function to return commitment term disclaimer

```javascript
getCommitmentDisclaimer(commitmentTerm, disclaimer);
```

#### ```showLongLegalOnPricingOption(visible : boolean)```

##### Parameters:
* visible (required) - boolean variable to show/hide long legal on pricing option modal.

**Description:**
Scope function to fetch long legal content from CQ using content service and then show long legal in pricing option 

```javascript
showLongLegalOnPricingOption(true);
```

#### ```isUpsellOfferInCart() : promise```

##### Parameters:
* none

**Description:**
scope function returns boolean value based on whether upsellOffer in cart or not.

```javascript
isUpsellOfferInCart(); 
``` 
or
```javascript
$scope.isUpsellOfferInCart();
```                 

#### ```getHylaPromoDetailsContent(deviceConfig:object)```

##### Parameters:
* deviceConfig (required) - device config object 

**Description:**
Get the hyla promotion details content

```javascript
getHylaPromoDetailsContent(deviceConfig);
```

#### ```getRequiredHylaPromoDetails(hylaContent:object)```

##### Parameters:
* hylaContent (required) - hyla content object 

**Description:**
Filter and get only needed hyla promotion fields

```javascript
getRequiredHylaPromoDetails(hylaContent);
```

#### ```openHylaPromoDetailsModal()```

**Description:**
open the modal/overlay to display the hyla promotion details content when link on device config page is clicked .

```javascript
openHylaPromoDetailsModal();
```

#### ```isHylaPromoLegalDetailsToggled()```

**Description:**
Toggle the flag when customer clicks on the see term and conditions

```javascript
isHylaPromoLegalDetailsToggled();
```
___
___
### accessoryConfigCtrl

##### Description:
Exposes an accessory and its configurable properties to scope. The controller looks in routing params for a sku ID and calls a service to get more information about the sku if present, otherwise it will check a service for a sku ID. If no sku ID is found the page fails to load.

##### Requirements:
* A sku ID which is used to get more information about the sku.
* A service that can provide its sku siblings as a map with the capacity as its first key.
* Skus returned by the service must contain a sku ID, color string, color hex, size, uom, rating and review count.

#### Functions:
#### ```formatSku(sku:Object) : Object```

##### Parameters:
* sku (required) - A sku object

##### Returns:
* A formatted (display-ready) sku object

**Description:**
Returns a sku formatted to be exposed to scope.

```javascript
formatSku(sku);
```
#### ```getAccessoriesInCart()```

##### Returns:
A map of skuIds to commerceItemIds e.g. 
```javascript
{
    sku1234567: '987654321',
    sku147258: '963852740'
}
```

**Description:**
Gets accessory sku ID/commerce item ID in cart. Maps commerce item IDs to sku IDs

```javascript
getAccessoriesInCart();
```
#### ```getAccessoryInformation(skuId:string)```

**Description:**
Calls service to get device details, creates a data structure to store the sku siblings (if any), exposes selected sku to scope, exposes sku siblings to scope.

##### Parameters:
* skuId (required) - A skuId

```javascript
getAccessoryInformation('sku8040300');
```
#### ```getAccDeliveryPromiseMessage(accessoryMap:object, variantType:string)```

##### Parameters:
* accessoryMap (required) - An object which has all size/color variants of a selected accessories.
* variantType (required) - The variant type of the accessories map, i.e either size, color, or no variants.

**Description:**
Calls service to get the delivery promise of all the variants(size/color) of the selected accessories, and puts the information in an array indexed by skuids of the selected and its variant accessories.

```javascript
$scope.getAccDeliveryPromiseMessage(accessoryMap, variantType);
```
#### ```displayAccessoryDetails(visible:boolean)```

**Description:**
Scope function setter to show or hide the device details section.

```javascript
displayAccessoryDetails(true)
```
or
```javascript
$scope.displayAccessoryDetails(true)
```
#### ```showDeliveryPromiseMessage(visible:boolean)```

**Description:**
Scope function setter to show or hide the delivery promise message section

```javascript
showDeliveryPromiseMessage(true)
or
$scope.showDeliveryPromiseMessage(true)
```
#### ```showPreOrderMessage(visible:boolean)```

**Description:**
Scope function setter to show or hide the pre-order message section

```javascript
showPreOrderMessage(true)
or
$scope.showPreOrderMessage(true)

#### ```showOutOfStockMessage(visible:boolean)```

**Description:**
Scope function setter to show or hide the out of stock information section

```javascript
showOutOfStockMessage(true)
or
$scope.showOutOfStockMessage(true)

```
#### ```getCartData()```

**Description:**
Get fresh cart data and broadcast results

```javascript
displayAccessoryDetails(true)
```
or
```javascript
$scope.displayAccessoryDetails(true)
```

```
```
#### ```showAccessoryDetails()```

**Description:**
Scope function to show and scroll to the accessory details section

```javascript
showAccessoryDetails();
```
or
```javascript
$scope.showAccessoryDetails();
```
#### ```setPrice(commitmentTerm:Object)```

##### Parameters:
* commitmentTerm (required) - A commitment term that exists in a sku's pricelist


**Description:**
Sets price based on the commitment term

```javascript
setPrice(selectedCommitmentTerm);
```

#### ```showReviewDetails()```

**Description:**
Scope function to scroll to the review details section

```javascript
showReviewDetails();
```
or
```javascript
$scope.showReviewDetails();
```

#### ```setSelectedSku(sku:Object)```

**Description:**
Scope function to set the selected sku and perform operations based on selected sku.

##### Requirements:
show/hide pre-order warning message for selected sku

```javascript
setSelectedSku(skuObject);
```
or
```javascript
$scope.setSelectedSku(skuObject);
```

#### ```getSizeVariants(selSku:Object, skuSiblings:Array<Array>)```

##### Parameters:
* selSku (required) - The sku whose size variants you want to get
* skuSiblings (required) - a 2d array of skus in the same product family

##### Returns:
* An array of skus with matching capacities

**Description:**
Scope function to get sibling skus that share a color. Assumes color IS NOT the first key in the 2d array.

```javascript
getCapacityVariants(sku, skuItems)
```
or
```javascript
$scope.getCapacityVariants(sku, skuItems)
```

#### ```getColorVariants(selSku:Object, skuSiblings:Array<Array>)```

##### Parameters:
* selSku (required) - The sku whose color variants you want to get
* skuSiblings (required) - a 2d array of skus in the same product family

##### Returns:
* An array of skus with sizes and varying colors sorted by marketing sequence

**Description:**
Scope function to get the color variants based on the sku. If there is a color that does not come in the selected size, that sku will be added.
E.g. red L sku will return red L, blue L, green L, purple M skus, assuming there is no purple L sku.

```javascript
getColorVariants(sku, skuItems)
```
or
```javascript
$scope.getColorVariants(sku, skuItems)
```
#### ```formatCartItem(sku:Object)```

##### Parameters:
* sku (required) - A sku object

##### Returns:
* Rest service call-ready cart item

**Description:**
Formats the sku to be added to cart.

```javascript
formatCartItem(sku)
```
#### ```accessoryConfigAddToCart( )```

**Description:**
Adds accessory to cart from accessory config modal.

```javascript
accessoryConfigAddToCart()
```
or
```javascript
$scope.accessoryConfigAddToCart()
```
##### `accessoryConfigRemoveItemFromCart (skuId: string)`

#### Description:
This function makes a POST request to the remove cart item. Looks through the items in cart and removes the item associated with skuId. Assumes there is a 1-1 mapping of skuIds to commerceItemIds.

##### Parameters:
skuId (required) - The sku ID of the item to be removed.

```javascript
    accessoryConfigRemoveItemFromCart();
```
#### ```close( )```

**Description:**
Closes all ds2 modals

```javascript
close()
```
or
```javascript
$scope.close()
```
___
___
### <a name='upgradingUserInfoCtrl'></a> `upgradingUserInfoCtrl`

##### Description:
This controller serves the purpose to get the current device of the user, which he wants to upgrade from the API.

##### Functions:

---
##### ```getUpgradingDeviceDetails() : promise```

**Returns:**
The current line/device and their complete detail.

##### Requirements:
* displays the current line of the user which he wants to upgrade
* displays the current device details of the user
___
___

### deviceCardCtrl

##### Description:
Exposes scope objects of in cart device for the current LOSG in context and its selected committment term so that this information can be used by device card  

##### Requirements:
* displays the current device details of the current LOSG in context on device card for configured time

#### Functions:

#### ```createCommitmentTermList(device:Object) : Map object of committment term```

##### Parameters:
* device (required) - A device object

##### Returns:
* A formatted (display-ready) committment term map

**Description:**
Returns a formatted map of committment term which can be used to display price etc.

```javascript
createCommitmentTermList(device);
```

#### ```showDeviceCard() : none```

**Description:**
Show device card for specific time

```javascript
showDeviceCard();
```
#### ```openInsuranceOptions()```

**Description:**
Show Insurance options modal if user wants a different insurance

```javascript
openInsuranceOptions();
```
#### ```closeInsuranceOption()```

**Description:**
Close Insurance Options Overlay

```javascript
closeInsuranceOption();
```
#### ```setSelectedInsurance(protectionPlanDetailSelected:object)```

**Description:**
Sets selected insurance from insurance options page

```javascript
setSelectedInsurance(protectionPlanDetailSelected);
```
#### ```getProtectionPlanLegal(protectionFeature:object)```

**Description:**
Gets protection plan to legal if available

```javascript
getProtectionPlanLegal(protectionFeature);
```
#### ```addProtectionPlanToCart()```

**Description:**
Adds protection plan to cart if available

```javascript
addProtectionPlanToCart();
```
___
___
