(function () {
    'use strict';

    define(['protectionPlanDetailsCtrl'], function () {
        describe('src/main/modules/exCommon/controllers/protectionPlanDetailsCtrl.spec.js', function () {
            describe('protectionPlanDetailsCtrl controller of exCommon', function () {
                var exCommonConstants, exCartService, protectionPlanService, $scope, $rootScope, $controller, $modalStack;

                beforeEach(function () {
                    module('exCommon', function ($provide) {
                        protectionPlanService = jasmine.createSpyObj('protectionPlanService', ['getInsuranceFeatures']);
                        $provide.value('protectionPlanService', protectionPlanService);
                        exCartService = jasmine.createSpyObj('exCartService', ['getCart', 'addItemToCart']);
                        $modalStack = jasmine.createSpyObj('$modalStack', ['getTop', 'dismiss']);
                        $provide.value('exCartService', exCartService);
                        $provide.value('$modalStack', $modalStack);
                        $provide.value('exCommonConstants', exCommonConstants);
                    });

                    inject(function ($injector) {
                        $controller = $injector.get('$controller');
                        $rootScope = $injector.get('$rootScope');
                        exCommonConstants = $injector.get('exCommonConstants');
                    });
                    $scope = $rootScope.$new();
                    spyOn($rootScope, '$emit').and.callThrough();

                    protectionPlanService.getInsuranceFeatures.and.returnValue({
                        'then': function (callBackFN) {
                            callBackFN(Endpoint_protectionApi.get_insurance_features.result);
                        }
                    });

                    exCartService.addItemToCart.and.returnValue({
                        'then': function (callback) {
                            callback(true);
                        }
                    });

                    exCartService.getCart.and.returnValue({
                        'then': function (callback) {
                            callback(Endpoint_cartLookupApi.get_cart_lookup_new.result);
                        }
                    });

                    $controller('protectionPlanDetailsCtrl', {
                        $scope: $scope,
                        protectionPlanService: protectionPlanService,
                        exCartService: exCartService
                    });
                });

                describe("Recommended protection feature and it's price  ", function () {

                    it('should have all the initial scope variables defined', function () {
                        expect($scope.addProtectionPlanToCart).toBeDefined();
                        expect($scope.protectionFeature).toBeDefined();
                        expect($scope.getProtectionPlan).toBeDefined();
                        expect($scope.protectionPlanDetails.showProtectionPlanDetails).toBeDefined();
                        expect($scope.protectionPlanDetails.showProtectionPlanDetails).toEqual(false);

                    });

                    it('should get the protection Plan and protection plan features variables defined', function () {
                        $scope.getProtectionPlan();
                        expect($scope.protectionFeature.skuId).toEqual('sku5370279');
                    });

                    it('should get the cart data ', function () {
                        $scope.getProtectionPlan();
                        expect(exCartService.getCart).toHaveBeenCalled();
                        expect($scope.protectionFeature.mRCDetailsBean.baseMRCPrice).toBeDefined();
                        expect($scope.protectionFeature.mRCDetailsBean.baseMRCPrice).toEqual(10.99);
                        expect(exCartService.getCart).toHaveBeenCalled();
                        exCartService.getCart().then(function () {
                            expect($scope.protectionPlanInCartItem).toEqual(true);
                            expect($scope.featureCommerceItemId).toEqual('83602000143');
                        });
                    });

                    it('should add an protection plan to cart ', function () {
                        spyOn($rootScope, '$broadcast').and.callThrough();
                        $scope.addProtectionPlanToCart();
                        expect(exCartService.addItemToCart).toHaveBeenCalled();
                        expect(exCartService.addItemToCart.calls.mostRecent().args.length).toEqual(2);
                        expect(typeof exCartService.addItemToCart.calls.mostRecent().args[0]).toEqual('object');
                        expect(exCartService.addItemToCart.calls.mostRecent().args[1].items.items[0].catalogRefId).toEqual($scope.protectionFeature.skuId);
                        expect(exCartService.addItemToCart.calls.mostRecent().args[1].items.items[0].productId).toEqual($scope.protectionFeature.productId);

                    });

                    it('should broadcast an event that protectionPlan is not added to cart by user', function () {
                        spyOn($rootScope, '$broadcast').and.callThrough();
                        $scope.resetCTAButtons();
                        expect($rootScope.$broadcast).toHaveBeenCalled();
                    });

                });

            });

        });
    });

})();