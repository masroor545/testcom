# exCommon Filters

### `tel`

##### Description:
This returns the formatted telephone number ie (425) 485-5555

##### Usage:

```html
<p>{{'4254855555' | tel}}</p>
<!-- Output: <p>(425) 485-5555</p> -->
```
___

### `selectionFilter`

##### Description:
Filters out items that do not match the criteria provided. If no criteria are provided no items are returned.

##### Usage:

```javascript
var items = [ {brand: 'Apple' } ]

var criteria = [
    {
        criterion: 'brand',
        values: [
            {
                value: 'Apple',
                count: 3,
                selected: true
            },
            {
                value: 'Samsung',
                count: 3,
                selected: false
            }
        ]
    }
]

$filter('selectionFilter')(items, criteria);
// Returns
// criteria [
//     criterion: 'brand',
//         values: [
//             {
//                 value: 'Apple',
//                 count: 3,
//                 selected: true
//             }
//         ]
// ]
```
___
