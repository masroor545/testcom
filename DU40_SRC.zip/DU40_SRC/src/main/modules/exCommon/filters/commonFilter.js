/*global document*/
(function () {
    'use strict';

    angular.module('exCommon')
        .filter('tel', function () {
            return function (ctn) {
                if (!ctn) { return ''; }

                // +1 425-485-5555 -> 14254855555
                var value = ctn.toString().trim().replace(/[+ -]+/g, '');

                // 425*485*5555 -> 425*485*5555
                if (value.match(/[^0-9]/)) {
                    return value;
                }

                var country, city, number;

                switch (value.length) {
                case 10: // 4254855555 -> (425) 485-5555
                    country = '';
                    city = value.slice(0, 3);
                    number = value.slice(3);
                    break;

                case 11: // 14254855555 -> (425) 485-5555
                    country = value[0];
                    // Don't display country code 1 while formating ctn as we don't display the country code on our web site
                    if (country === '1') {
                        country = '';
                    }
                    city = value.slice(1, 4);
                    number = value.slice(4);
                    break;

                default:
                    return value;
                }

                number = number.slice(0, 3) + '.' + number.slice(3);

                return country + city + '.' + number;
            };
        })
        .filter('selectionFilter', function () {
            return function (items, criteria) {
                if (Array.isArray(items) !== true || items.length === 0) {
                    return items;
                }

                // Checks if criteria has a selected option. If there are no selections then return no items.
                var hasSelected = false;
                var selectedCriteria = criteria.map(function (criterion) {
                    if (criterion.values.length > 0) {
                        criterion.values.filter(function (value) {
                            hasSelected = hasSelected || value.isSelected;
                            return value.isSelected;
                        });
                        return criterion;
                    }
                });

                if (hasSelected !== true) {
                    return [];
                } else {
                    // Iterates through each selection and checks if the item matches any of the criteria. If it doesn't then it is removed.
                    return items.filter(function (item) {
                        var match = false;
                        selectedCriteria.forEach(function (criterion) {
                            criterion.values.forEach(function (value) {
                                if (value.value === item[criterion.criterion]) {
                                    match = match || value.isSelected;
                                }
                            });
                        });
                        return match;
                    });
                }
            };
        })
        .filter('toTrusted', ['$sce', function ($sce) {
            //not everything is perfectly decoded to be able to sanitize
            //So we will be decoding before sanitize to make sure every character is decoded properly
            var div = document.createElement('div');
            return function (text) {
                div.innerHTML = text;
                return $sce.trustAsHtml(div.textContent);
            };
        }]);
})();
