(function () {
    'use strict';

    define(['exDeviceCard'], function () {
        describe('src/main/modules/exCommon/directives/exDeviceCard.spec.js', function () {
            describe('exDeviceCard directive of exCommon', function () {
                var element, scope, $rootScope, $compile;

                beforeEach(function () {
                    module('exCommon', function ($provide, $controllerProvider) {
                        $controllerProvider.register('deviceCardCtrl', function ($scope) {
                            $scope.deviceCard = {
                                selectedCommitmentTerm: {},
                                device: {},
                                showDeviceCard: false
                            };
                            $scope.deviceCard.showDeviceCard = true;
                            $scope.deviceCard.device = {
                                'shortDisplayName': 'Apple iPhone 7',
                                'color': 'Black',
                                'size': 32,
                                'uom': 'GB'
                            };
                            $scope.deviceCard.selectedCommitmentTerm = {
                                'commitTermName': 'NEXT Every year',
                                'type': 'lease',
                                'selectedskuPriceToDisplay': 21.67
                            };
                        });
                    });

                    inject(function ($injector) {
                        $rootScope = $injector.get('$rootScope');
                        $compile = $injector.get('$compile');
                    });

                    var html = '<div' +
                        ' ex-device-card device-card-timer="7000"' +
                        ' for-n-months-label="for {0} months"' +
                        'commitment-term-labels={"commitmentTermInstallment":"Installment"}' +
                        '></div>';

                    element = angular.element(html);
                    scope = $rootScope.$new();
                    $compile(element)(scope);
                    scope.$apply();
                    scope = element.isolateScope() || element.scope();
                });

                describe('exdevicecard template of exCommon', function () {
                    it('should display information about the selected device in cart for current losg', function () {
                        expect(element.html()).toContain(scope.deviceCard.device.shortDisplayName);
                        expect(element.html()).toContain(scope.deviceCard.device.color);
                        expect(element.html()).toContain(scope.deviceCard.device.size);
                        expect(element.html()).toContain(scope.deviceCard.device.uom);
                        expect(element.html()).toContain(scope.deviceCard.selectedCommitmentTerm.commitTermName);
                        expect(element.html()).not.toContain(scope.deviceCard.selectedCommitmentTerm.type);
                        expect(element.html()).toContain(scope.deviceCard.selectedCommitmentTerm.selectedskuPriceToDisplay);
                        expect(scope.deviceCardTimer).toBeDefined();
                        expect(scope.deviceCardTimer).toEqual('7000');
                        expect(scope.forNMonthsLabel).toBeDefined();
                        expect(scope.forNMonthsLabel).toEqual('for {0} months');
                        expect(scope.commitmentTermLabels).toBeDefined();
                        expect(scope.commitmentTermLabels.commitmentTermInstallment).toBeDefined();
                        expect(scope.commitmentTermLabels.commitmentTermInstallment).toEqual('Installment');
                    });
                });

            });
        });
    });
})();
