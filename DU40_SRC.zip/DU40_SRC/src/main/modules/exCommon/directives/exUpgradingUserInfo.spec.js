(function () {
    'use strict';

    define(['exUpgradingUserInfo'], function () {
        describe('src/main/modules/exCommon/directives/exUpgradingUserInfo.spec.js', function () {
            describe('exUpgradingUserInfo directive of exCommon', function () {
                var $scope, $rootScope, $compile, template, templateAsHtml;

                beforeEach(function () {
                    module('exCommon', function ($provide, $controllerProvider) {
                        $controllerProvider.register('upgradingUserInfoCtrl', function ($scope) {
                            // Set some values on your $scope
                            $scope.upgradingUserDescription = "You're upgrading BEDROCK's iPhone 6";
                            $scope.upgradingDeviceDescription = 'Space Gray | 16 GB | 425.295.1153';
                        });
                    });

                    inject(function ($injector) {
                        $rootScope = $injector.get('$rootScope');
                        $compile = $injector.get('$compile');
                    });

                    $scope = $rootScope.$new();
                    // $compile the template, and pass in the $scope. This will find your directive and run everything
                    template = $compile('<div ex-upgrading-user-info></div>')($scope);
                    // Now run a $digest cycle to update your template with new data
                    $scope.$digest();
                    // Render the template as a string
                    templateAsHtml = template.html();
                });

                it('should render the subscriber name and ctn as passed in by $scope', inject(function () {
                    // Verify that the $scope variables are in the template
                    expect(templateAsHtml).toContain($scope.upgradingUserDescription);
                    expect(templateAsHtml).toContain($scope.upgradingDeviceDescription);
                }));
            });
        });
    });
})();
