(function () {
    'use strict';

    angular.module('exCommon')

        .directive('exDeviceCard', [function () {
            return {
                restrict: 'EA',
                templateUrl: function (ele, attr) {
                    return attr.templateName ? attr.templateName : '/templates/exdevicecard.html';
                },
                controller: 'deviceCardCtrl',
                // This is for passing the labels and timer attribute to controller
                link: {
                    pre: function (scope, elem, $attributes) {
                        if ($attributes.commitmentTermLabels && $attributes.deviceCardTimer && $attributes.forNMonthsLabel) {
                            scope.commitmentTermLabels = JSON.parse($attributes.commitmentTermLabels);
                            scope.deviceCardTimer = $attributes.deviceCardTimer;
                            scope.forNMonthsLabel = $attributes.forNMonthsLabel;
                        }

                    }
                }
            };
        }]);
})();
