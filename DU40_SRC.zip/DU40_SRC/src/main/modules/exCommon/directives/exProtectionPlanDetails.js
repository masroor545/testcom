(function () {
    'use strict';

    angular.module('exCommon')

        .directive('exProtectionPlanDetails', [function () {
            return {
                restrict: 'EA',
                templateUrl: function (ele, attr) {
                    return attr.templateName ? attr.templateName : '/templates/exprotectionplandetails.html';
                },
                scope: {
                    defaultInsuranceBillCode: '@?'
                },
                controller: 'protectionPlanDetailsCtrl'
            };
        }]);
})();