(function () {
    'use strict';

    define(['exProtectionPlan'], function () {
        describe('src/main/modules/exCommon/directives/exProtectionPlan.spec.js', function () {
            describe('exProtectionPlan directive of exCommon', function () {
                var element, scope, $rootScope, $compile, html;

                beforeEach(function () {
                    module('exCommon', function ($controllerProvider) {
                        $controllerProvider.register('protectionPlanCtrl', function ($scope) {
                            $scope.protectionPlanDetails = {'skuId': 'sku5370279',
                                'displayName': 'Mobile Protection Pack',
                                'mrc': 11.99,
                                'productId': 'prod5280349'
                            };
                            $scope.seeProtectionPlanDetails = function () { return true; };
                            $scope.protectionRemoveItemFromCart = function () { return true; };
                        });
                        $controllerProvider.register('protectionPlanDetailsCtrl', function () {
                        });
                    });

                    inject(function ($injector) {
                        $rootScope = $injector.get('$rootScope');
                        $compile = $injector.get('$compile');
                    });
                    html = '<div ex-protection-plan></div>';
                    element = angular.element(html);
                    scope = $rootScope.$new();
                    $compile(element)(scope);
                    scope.$apply();

                });
                describe('exProtectionPlan template of exCommon', function () {
                    it('should have the scope of the controller', function () {
                        expect(scope).toBeDefined();
                    });
                    it('should render the protection plan static content', function () {
                        //Verify that the contents are in the template
                        expect(element.html()).toContain(scope.protectionPlanDetails.displayName);
                        expect(element.html()).toContain(scope.protectionPlanDetails.mrc);
                    });
                    it('should have a button to add to cart', function () {
                        scope.protectionPlanInCartItem = false;
                        scope.$digest();
                        spyOn(scope, 'seeProtectionPlanDetails');
                        element.find('.protection-add-to-cart')[0].click();
                    });
                    it('should have a button to remove item from cart', function () {
                        var updatedTemplate, removeFromCartButton;
                        scope.protectionPlanInCartItem = true;
                        scope.$digest();
                        //button's visibility before first click event
                        expect(element.find('.protection-remove-from-cart').length).toEqual(1);
                        spyOn(scope, 'protectionRemoveItemFromCart');
                        removeFromCartButton = element.find('.protection-remove-from-cart')[0];
                        removeFromCartButton.click();
                        scope.isProtectionRemoveDisabled = true;
                        scope.$digest();
                        removeFromCartButton.click();
                        expect(scope.protectionRemoveItemFromCart.calls.count()).toBe(2);
                        updatedTemplate = $compile(html)(scope);
                        //checking the updatedTemplate that the button is hidden from the page after first button click,
                        //if not visible then multiple click is not possible.
                        expect(updatedTemplate.find('.protection-remove-from-cart').length).toEqual(0);
                    });
                });
            });
        });
    });
})();