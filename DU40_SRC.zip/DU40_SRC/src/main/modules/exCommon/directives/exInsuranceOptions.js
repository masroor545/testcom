(function () {
    'use strict';

    angular.module('exCommon')

        .directive('exInsuranceOptions', [function () {
            return {
                restrict: 'E',
                templateUrl: function (ele, attr) {
                    return attr.templateName ? attr.templateName : '/templates/exinsuranceoptions.html';
                }
            };
        }]);
})();
