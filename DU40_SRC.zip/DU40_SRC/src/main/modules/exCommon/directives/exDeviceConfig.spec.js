(function () {
    'use strict';

    define(['exDeviceConfig'], function () {
        describe('src/main/modules/exCommon/directives/exDeviceConfig.spec.js', function () {
            describe('exDeviceConfig directive of exCommon', function () {
                var element, scope, $rootScope, $compile, $httpBackend;

                beforeEach(function () {
                    module('exCommon', function ($provide, $controllerProvider) {
                        $controllerProvider.register('deviceConfigCtrl', function ($scope) {
                            $scope.deviceConfig = {
                                'model': 'iPhone 7',
                                'manufacturer': 'Apple',
                                selectedSku: {
                                    'capacity': '32 GB',
                                    'color': 'Rose Gold',
                                    'rating': 4.3,
                                    'price': 25.00,
                                    'mlpRebate': 0,
                                    'imgUrl': '/path/to/iphone7.png',
                                    'priceList': [
                                        {
                                            leaseTotalMonths: '30',
                                            commitTermName: 'ATT NEXT',
                                            disclaimer: 'Upgrade every two years',
                                            selectedskuPriceToDisplay: 29.99,
                                            monthlyLeasePrice: 29.99,
                                            dueToday: 0.00,
                                            type: 'lease'
                                        },
                                        {
                                            leaseTotalMonths: '24',
                                            commitTermName: 'ATT NEXT Every year',
                                            disclaimer: 'Upgrade every years',
                                            selectedskuPriceToDisplay: 39.99,
                                            monthlyLeasePrice: 39.99,
                                            dueToday: 0.00,
                                            type: 'lease'
                                        },
                                        {
                                            leaseTotalMonths: '1',
                                            commitTermName: '2 Year',
                                            disclaimer: 'Upgrade anytime',
                                            selectedskuPriceToDisplay: 199.99,
                                            monthlyLeasePrice: 0.00,
                                            dueToday: 199.99,
                                            type: 'regular'
                                        },
                                        {
                                            leaseTotalMonths: '0',
                                            commitTermName: 'No Annual Contract',
                                            disclaimer: 'Upgrade anytime',
                                            selectedskuPriceToDisplay: 399.99,
                                            monthlyLeasePrice: 0.00,
                                            dueToday: 399.99,
                                            type: 'regular'
                                        }
                                    ]
                                }
                            };

                            $scope.close = function () {
                                return true;
                            };

                            $scope.showDeviceDetails = function () {
                                return true;
                            };

                            $scope.isUpsellOfferInCart = function () {
                                return true;
                            };
                        });
                    });

                    inject(function ($injector) {
                        $rootScope = $injector.get('$rootScope');
                        $compile = $injector.get('$compile');
                        $httpBackend = $injector.get('$httpBackend');
                    });

                    // Catches all backend calls because we have directives that make calls we don't care about
                    $httpBackend.whenGET('').respond(200, '');


                    var html = "<ex-device-config commitment-term-labels='{\"key\": \"value\"}' type='true'></ex-device-config>";

                    element = angular.element(html);
                    scope = $rootScope.$new();
                    $compile(element)(scope);
                    scope.$apply();
                    scope = element.isolateScope() || element.scope();
                });

                describe('exdeviceconfig template of exCommon', function () {
                    it('should bind its attributes to scope', function () {
                        expect(scope.commitmentTermLabels).toBeDefined();
                        expect(scope.type).toBeDefined();
                    });

                    it('should display information about the selected sku', function () {
                        expect(element.html()).toContain(scope.deviceConfig.manufacturer);
                        expect(element.html()).toContain(scope.deviceConfig.model);
                        expect(element.html()).toContain(scope.deviceConfig.selectedSku.rating);
                        expect(element.html()).toContain(scope.deviceConfig.selectedSku.price);
                        expect(element.html()).toContain(scope.deviceConfig.selectedSku.mlpRebate);
                        expect(element.html()).toContain(scope.deviceConfig.selectedSku.imgUrl);
                    });

                    describe('hero recommendation page', function () {

                        beforeEach(function () {
                            var html = '<ex-device-config type="heroDevice"></ex-device-config>';
                            element = angular.element(html);

                            $compile(element)(scope);
                            scope.$apply();
                            scope = element.isolateScope();

                            scope.$parent.$dismiss = function () {
                                return true;
                            };
                        });

                        it('should provide a see more devices button', function () {
                            spyOn(scope, 'close');
                            element.find('.config-view-more-devices')[0].click();
                            expect(scope.close).toHaveBeenCalled();
                        });

                        it('should show the upgrading user info', function () {
                            expect(element.html()).toContain('ex-upgrading-user-info');
                        });

                        it('should should provide a link to the device details section', function () {
                            var seeDetailsElement = element.find('#config-see-device-details')[0];
                            expect(seeDetailsElement).toBeDefined();
                            spyOn(scope, 'showDeviceDetails');
                            seeDetailsElement.click();
                            expect(scope.showDeviceDetails).toHaveBeenCalled();
                        });
                    });

                    describe('upsell Offer page', function () {
                        beforeEach(function () {
                            var html = '<ex-device-config type="upsellOffer"></ex-device-config>';
                            element = angular.element(html);
                            $compile(element)(scope);
                            scope.$apply();
                            scope = element.isolateScope();
                            scope.onSkipToCheckout = function () {
                                return true;
                            };
                        });

                        it('should have a button to proceed to checkout', function () {
                            spyOn(scope, 'onSkipToCheckout');
                            element.find('.config-no-thanks')[0].click();
                            expect(scope.onSkipToCheckout).toHaveBeenCalled();
                        });

                    });


                });

            });
        });
    });
})();
