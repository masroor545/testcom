(function () {
    'use strict';

    angular.module('exCommon')

        .directive('exProtectionPlan', [function () {
            return {
                restrict: 'EA',
                templateUrl: function (ele, attr) {
                    return attr.templateName ? attr.templateName : '/templates/exprotectionplan.html';
                },
                controller: 'protectionPlanCtrl'
            };
        }]);
})();