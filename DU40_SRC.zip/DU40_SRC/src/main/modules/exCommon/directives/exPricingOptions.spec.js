(function () {
    'use strict';

    define(['exPricingOptions'], function () {
        describe('src/main/modules/exCommon/directives/exPricingOptions.spec.js', function () {
            describe('exPricingOptions directive of exCommon', function () {
                var element, scope, $rootScope, $compile;

                beforeEach(function () {
                    module('exCommon');

                    inject(function ($injector) {
                        $rootScope = $injector.get('$rootScope');
                        $compile = $injector.get('$compile');
                    });

                    var html = '<ex-pricing-options></ex-pricing-options>';

                    element = angular.element(html);
                    scope = $rootScope.$new();

                    // Mock device config controller scope
                    scope.deviceConfig = {
                        'model': 'iPhone 7',
                        'manufacturer': 'Apple',
                        selectedSku: {
                            'size': 32,
                            'capacity': '32 GB',
                            'color': 'Rose Gold',
                            'reviewCount': 2758,
                            'rating': 4.3,
                            'showRating': true,
                            'price': 25.00,
                            'imgUrl': '/path/to/iphone7.png',
                            'priceList': [
                                {
                                    leaseTotalMonths: '30',
                                    commitTermName: 'ATT NEXT',
                                    disclaimer: 'Upgrade every two years',
                                    selectedskuPriceToDisplay: 29.99,
                                    monthlyLeasePrice: 29.99,
                                    dueToday: 0.00,
                                    type: 'lease',
                                    legalContent: '*Tax on full retail price is due at sale. Fees, monthly and other charges apply.',
                                    offerReqOrPriceDetailLink: 'See ATT Next details.'
                                },
                                {
                                    leaseTotalMonths: '24',
                                    commitTermName: 'ATT NEXT Every year',
                                    disclaimer: 'Upgrade every years',
                                    selectedskuPriceToDisplay: 39.99,
                                    monthlyLeasePrice: 39.99,
                                    dueToday: 0.00,
                                    type: 'lease',
                                    legalContent: '*Tax on full retail price is due at sale. Fees, monthly and other charges apply.',
                                    offerReqOrPriceDetailLink: 'See ATT Next details.'
                                },
                                {
                                    leaseTotalMonths: '1',
                                    commitTermName: '2 Year',
                                    disclaimer: 'Upgrade anytime',
                                    selectedskuPriceToDisplay: 199.99,
                                    monthlyLeasePrice: 0.00,
                                    dueToday: 199.99,
                                    type: 'regular',
                                    legalContent: 'Qualified credit, and wireless service (voice and data).',
                                    offerReqOrPriceDetailLink: 'See offer reqs.'
                                },
                                {
                                    leaseTotalMonths: '0',
                                    commitTermName: 'No Annual Contract',
                                    disclaimer: 'Upgrade anytime',
                                    selectedskuPriceToDisplay: 399.99,
                                    monthlyLeasePrice: 0.00,
                                    dueToday: 399.99,
                                    type: 'regular',
                                    legalContent: 'No-annual-contract pricing  qualified credit, and wireless service (voice and data). ',
                                    offerReqOrPriceDetailLink: 'See offer reqs.'
                                }
                            ]
                        }
                    };

                    scope.setCommitmentTerm = jasmine.createSpy('setCommitmentTerm');
                    scope.closePricingOption = jasmine.createSpy('closePricingOption');
                    scope.showLongLegalOnPricingOption = jasmine.createSpy('showLongLegalOnPricingOption');

                    $compile(element)(scope);
                    scope.$apply();
                    scope = element.isolateScope() || element.scope();

                });

                afterEach(function () {
                    scope.setCommitmentTerm.calls.reset();
                    scope.closePricingOption.calls.reset();
                    scope.showLongLegalOnPricingOption.calls.reset();
                });

                it('should display information about the selected sku', function () {
                    expect(element.html()).toContain(scope.deviceConfig.manufacturer);
                    expect(element.html()).toContain(scope.deviceConfig.model);
                    expect(element.html()).toContain(scope.deviceConfig.selectedSku.capacity);
                    expect(element.html()).toContain(scope.deviceConfig.selectedSku.color);
                });

                it('should display information about the available pricing', function () {
                    expect(element.html()).toContain(scope.deviceConfig.selectedSku.priceList[0].commitTermName);
                    expect(element.html()).toContain(scope.deviceConfig.selectedSku.priceList[0].disclaimer);
                    expect(element.html()).toContain(scope.deviceConfig.selectedSku.priceList[0].monthlyLeasePrice);
                    expect(element.html()).toContain(scope.deviceConfig.selectedSku.priceList[0].dueToday);
                });

                it('should model a price to scope', function () {
                    expect(scope.deviceConfig.selectedSku.selectedCommitmentTerm).not.toBeDefined();

                    element.find('#radiolist-0')[0].click();
                    expect(scope.deviceConfig.selectedSku.selectedCommitmentTerm).toEqual(scope.deviceConfig.selectedSku.priceList[0]);

                    element.find('#radiolist-1')[0].click();
                    expect(scope.deviceConfig.selectedSku.selectedCommitmentTerm).toEqual(scope.deviceConfig.selectedSku.priceList[1]);
                });

                it('should provide an update pricing button', function () {
                    scope.deviceConfig.selectedSku.selectedCommitmentTerm = scope.deviceConfig.selectedSku.priceList[1];
                    element.find('.upgradePricing-cta')[0].click();
                    expect(scope.setCommitmentTerm).toHaveBeenCalledWith(scope.deviceConfig.selectedSku.selectedCommitmentTerm);
                });

                it('should provide a control to close itself', function (done) {
                    element.find('.close-btn').click();
                    expect(scope.closePricingOption).toHaveBeenCalled();
                    done();
                });

                it('show pricing options legal', function () {
                    scope.deviceConfig.selectedSku.selectedCommitmentTerm = scope.deviceConfig.selectedSku.priceList[0];
                    scope.$digest();
                    expect(element.html()).toContain(scope.deviceConfig.selectedSku.selectedCommitmentTerm.legalContent);
                    expect(element.html()).toContain(scope.deviceConfig.selectedSku.selectedCommitmentTerm.offerReqOrPriceDetailLink);
                });

                it('show pricing options long legal on click of legal link', function () {
                    element.find('.offerReqOrPriceDetailLink').click();
                    expect(scope.showLongLegalOnPricingOption).toHaveBeenCalledWith(true);
                });

            });
        });
    });
})();
