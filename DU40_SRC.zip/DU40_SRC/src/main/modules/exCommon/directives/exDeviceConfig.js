(function () {
    'use strict';

    angular.module('exCommon')

        .directive('exDeviceConfig', [function () {
            return {
                restrict: 'EA',
                templateUrl: function (ele, attr) {
                    return attr.templateName ? attr.templateName : '/templates/exdeviceconfig.html';
                },
                scope: {
                    type: '@?',
                    commitmentTermLabels: '=?'
                },
                controller: 'deviceConfigCtrl'
            };
        }]);
})();
