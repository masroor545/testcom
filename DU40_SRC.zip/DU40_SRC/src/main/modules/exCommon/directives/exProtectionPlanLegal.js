(function () {
    'use strict';

    angular.module('exCommon')

        .directive('exProtectionPlanLegal', [function () {
            return {
                restrict: 'E',
                templateUrl: function (ele, attr) {
                    return attr.templateName ? attr.templateName : '/templates/exprotectionplanlegal.html';
                }
            };
        }]);
})();
