(function () {
    'use strict';

    angular.module('exCommon')

        .directive('exUpgradingUserInfo', [function () {
            return {
                restrict: 'EA',
                templateUrl: function (ele, attr) {
                    return attr.templateName ? attr.templateName : '/templates/exupgradinguserinfo.html';
                },
                controller: 'upgradingUserInfoCtrl'
            };
        }]);
})();