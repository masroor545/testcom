(function () {
    'use strict';

    angular.module('exCommon')

        .config(['exCacheManagerProvider', function (exCacheManager) {
            exCacheManager.setCacheId('xpressCache');
        }]);
}());
