(function () {
    'use strict';

    angular.module('exUpgrade', ['exCommon', 'ngSanitize', '/templates/exUpgrade']);
})();
