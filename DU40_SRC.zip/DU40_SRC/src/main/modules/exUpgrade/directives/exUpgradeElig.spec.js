(function () {
    'use strict';

    define(['exUpgradeElig'], function () {
        describe('src/main/modules/exUpgrade/directives/exUpgradeElig.spec.js', function () {
            describe('exUpgradeElig directive of exUpgrade', function () {
                var element, scope, $rootScope, $compile;


                beforeEach(function () {
                    module('exUpgrade', function ($provide, $controllerProvider) {
                        $controllerProvider.register('upgradeEligCtrl', function ($scope) {

                            $scope.user = {
                                'customerNameWithMsg': 'Hi, BEDROCK!',
                                'lines': [
                                    {
                                        'customerFirstName': 'BEDROCK',
                                        'customerDetailWithDevice': {
                                            'customerNameWithDevice': "BEDROCK's SM-T537A",
                                            'customerCTNWithDevice': 'SM-T537A | (425) 205-0545'
                                        },
                                        'tradeInOptions': {
                                            'message': 'Pay off $100.00 to upgrade early'
                                        },
                                        'subscriberNumber': '4252050545',
                                        'upgradeLinePlanType': 'mobileshare'
                                    },
                                    {
                                        'customerFirstName': 'BEDROCK',
                                        'customerDetailWithDevice': {
                                            'customerNameWithDevice': "BEDROCK's SM-T537A",
                                            'customerCTNWithDevice': 'SM-T537A | (425) 205-0545'
                                        },
                                        'tradeInOptions': {
                                            'message': 'Pay off $100.00 to upgrade early'
                                        },
                                        'subscriberNumber': '4252050545',
                                        'upgradeLinePlanType': 'mobileshare'
                                    },
                                    {
                                        'customerFirstName': 'BEDROCK',
                                        'customerDetailWithDevice': {
                                            'customerNameWithDevice': "BEDROCK's SM-T537A",
                                            'customerCTNWithDevice': 'SM-T537A | (425) 205-0545'
                                        },
                                        'tradeInOptions': {
                                            'message': 'Pay off $100.00 to upgrade early'
                                        },
                                        'subscriberNumber': '4252050545',
                                        'upgradeLinePlanType': 'mobileshare'
                                    }
                                ]
                            };
                        });
                    });

                    inject(function ($injector) {
                        $rootScope = $injector.get('$rootScope');
                        $compile = $injector.get('$compile');
                    });
                    var upgradeEligDirective = '<div' +
                        ' ex-upgrade-elig eligibility-messages="{key: value}"' +
                        ' common-message="{key: value}"' +
                        ' device-image="{key: value}" upgrade-options-messages="{key: value}"' +
                        ' display-upgrade-eligibility-heading="true"' +
                        ' information-message="{key: value}"></div>';
                    element = angular.element(upgradeEligDirective);
                    $compile(element)($rootScope.$new());
                    $rootScope.$digest();
                    scope = element.isolateScope() || element.scope();
                });

                describe('exupgradelinespage template of upgradeEligCtrl', function () {

                    it('should have the scope of the controller', function () {
                        expect(scope.user).toBeDefined();
                    });

                    it('should bind its attributes to scope', function () {
                        expect(scope.eligibilityMessages).toBeDefined();
                        expect(scope.deviceImage).toBeDefined();
                        expect(scope.informationMessage).toBeDefined();
                        expect(scope.displayUpgradeEligibilityHeading).toBeDefined();
                    });

                    it('should display/hide the account holder name based on flag', function () {
                        expect(element.html()).toContain(scope.user.customerNameWithMsg);
                        expect(element.html()).not.toContain('class="upgrade-heading ng-hide"');

                        // should not display the account holder name if displayUpgradeEligibilityHeading is false
                        var upgradeEligDirectiveNoHeading = '<div' +
                            ' ex-upgrade-elig display-upgrade-eligibility-heading="false"></div>';
                        element = angular.element(upgradeEligDirectiveNoHeading);
                        $compile(element)($rootScope.$new());
                        $rootScope.$digest();

                        expect(element.html()).toContain('class="upgrade-heading ng-hide"');
                    });

                    it('should display a list of details about the lines', function () {
                        expect(element.html()).toContain(scope.user.lines[0].customerFirstName);
                        expect(element.html()).toContain(scope.user.lines[0].customerDetailWithDevice.customerNameWithDevice);
                        expect(element.html()).toContain(scope.user.lines[0].subscriberNumber);
                    });
                });
            });
        });
    });
})();
