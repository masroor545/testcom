(function () {
    'use strict';

    /**
     * Shows the modal when user select on show more option link on upgrade eligibility page.
     * Allows the user to change upgrade options.
     *
     * __Requirements:__
     * * displays line summary
     * * displays differnt upgrade option.
     * * displays radio button to select diffrent option.
     * * displays update pricing option cta.
     *
     * @module exUpgradeOptions
     *
     * @property [template-name = exupgradeoptions.html] -
     *
     * @example @lang html
     * <ex-upgrade-options></ex-upgrade-options>
     */
    angular.module('exUpgrade')

        .directive('exUpgradeOptions', [function () {
            return {
                restrict: 'AE',
                templateUrl: function (ele, attr) {
                    return attr.templateName ? attr.templateName : '/templates/exupgradeoptions.html';
                }
            };
        }]);
})();
