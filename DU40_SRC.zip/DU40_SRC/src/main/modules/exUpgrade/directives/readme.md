## Modules

<table>
  <thead>
    <tr>
      <th>Module</th><th>Description</th>
    </tr>
  </thead>
  <tbody>
<tr>
    <td><a href="#module_exUpgrade">exUpgrade</a></td>
    <td><p>Shows the username and any devices available for upgrade.  Allows the devices to be checked and submited for upgrade. The template defaults to /templates/upgradeeligibility.html</p>
<p><strong>Requirements</strong></p>
<ul>
<li>displays user name</li>
<li>displays upgrade device description</li>
<li>displays upgrade details</li>
<li>displays device Image</li>
<li>displays link to show more options to upgrade the device</li>
<li>displays button to upgrade the device</li>
</ul>
</td>
    </tr>
<tr>
    <td><a href="#module_exUpgradeEligPayment">exUpgradeEligPayment</a></td>
    <td><p>Shows the paymnet related details which user has.  Allows the user to change the payment card which they have stored. The template defaults to /templates/exupgradeeligpayment.html</p>
<p><strong>Requirements:</strong></p>
<ul>
<li>displays payment summary</li>
<li>displays payment details</li>
<li>displays link to chnage payment card</li>
<li>displays term and condition.</li>
<li>displays submit payment cta.</li>
<li>displays cancel cta.</li>
</ul>
</td>
    </tr>
<tr>
    <td><a href="#module_exUpgradeOptions">exUpgradeOptions</a></td>
    <td><p>Shows the modal when user select on show more option link on upgrade eligibility page.
Allows the user to change upgrade options.</p>
<p><strong>Requirements:</strong></p>
<ul>
<li>displays line summary</li>
<li>displays differnt upgrade option.</li>
<li>displays radio button to select diffrent option.</li>
<li>displays update pricing option cta.</li>
</ul>
</td>
    </tr>
<tr>
    <td><a href="#module_exUpgradePaymentConfirm">exUpgradePaymentConfirm</a></td>
    <td><p>Shows the payment related details which user has.
Allows the user to change the payment card which they have stored.</p>
<p><strong>Requirements:</strong></p>
<ul>
<li>displays page header with customer name and cta.</li>
<li>displays message that payment is successful.</li>
<li>displays customer first name, device name, ctn and plan id.</li>
<li>displays payment amount, date, payment method and confirmation number.</li>
<li>displays continue upgrade cta.</li>
<li>displays return to eligibility upgrade cta.</li>
</ul>
</td>
    </tr>
<tr>
    <td><a href="#module_exUpgradeTradeinConsent">exUpgradeTradeinConsent</a></td>
    <td><p>Shows the tradein consent message for upgradeing device. Allows the user to select tradein consent.</p>
<p><strong>Requirements</strong></p>
<ul>
<li>displays checkbox to select tradein consent message.</li>
<li>displays continue cta.</li>
<li>displays cancel cta.</li>
</ul>
</td>
    </tr>
</tbody>
</table>

<a name="module_exUpgrade"></a>

## exUpgrade
Shows the username and any devices available for upgrade.  Allows the devices to be checked and submited for upgrade. The template defaults to /templates/upgradeeligibility.html

__Requirements__
* displays user name
* displays upgrade device description
* displays upgrade details
* displays device Image
* displays link to show more options to upgrade the device
* displays button to upgrade the device

**See**: [upgradeEligCtrl](../controllers/#module_upgradeEligCtrl)  
**Todo**

- [ ] Fix documentation of properties to be meaningful

**Properties**

| Name | Default | Description |
| --- | --- | --- |
| template-name | <code>&#x27;exupgradelinespage.html&#x27;</code> |  |
| eligibility-message |  | ??? |
| upgrade-options-messages |  | ??? |

**Example**  
```html
<div ex-upgrade-elig
    template-name="/templates/upgradeeligibility.html"
    eligibility-messages=upgrade_eligibility.upgradeMessages
    device-image=url.xpress.imageUrl>
</div>
```

* * *

<a name="module_exUpgradeEligPayment"></a>

## exUpgradeEligPayment
Shows the paymnet related details which user has.  Allows the user to change the payment card which they have stored. The template defaults to /templates/exupgradeeligpayment.html

__Requirements:__
* displays payment summary
* displays payment details
* displays link to chnage payment card
* displays term and condition.
* displays submit payment cta.
* displays cancel cta.

**See**: [upgradeEligPaymentCtrl](../controllers/#module_upgradeEligPaymentCtrl)  
**Properties**

| Name | Default | Description |
| --- | --- | --- |
| template-name | <code>exupgradeeligpayment.html</code> | - |
| card-declined-msg |  | Error message when card is declined. |
| pay-off-legal |  | legal terms and conditions in case of payOff. |
| pay-up-legal |  | legal terms and conditions in case of payUp. |
| upgrade-payment-payup |  | The upgrade payment payup message. |
| upgrade-payment-payoff |  | The upgrade payment payoff message. |

**Example**  
```html
<ex-upgrade-elig-payment></ex-upgrade-elig-payment>
```

* * *

<a name="module_exUpgradeOptions"></a>

## exUpgradeOptions
Shows the modal when user select on show more option link on upgrade eligibility page.
Allows the user to change upgrade options.

__Requirements:__
* displays line summary
* displays differnt upgrade option.
* displays radio button to select diffrent option.
* displays update pricing option cta.

**Properties**

| Name | Default | Description |
| --- | --- | --- |
| template-name | <code>exupgradeoptions.html</code> | - |

**Example**  
```html
<ex-upgrade-options></ex-upgrade-options>
```

* * *

<a name="module_exUpgradePaymentConfirm"></a>

## exUpgradePaymentConfirm
Shows the payment related details which user has.
Allows the user to change the payment card which they have stored.

__Requirements:__
* displays page header with customer name and cta.
* displays message that payment is successful.
* displays customer first name, device name, ctn and plan id.
* displays payment amount, date, payment method and confirmation number.
* displays continue upgrade cta.
* displays return to eligibility upgrade cta.

**See**: [upgradePaymentConfirmCtrl](../controllers/#module_upgradePaymentConfirmCtrl)  
**Todo**

- [ ] properties are not documented

**Properties**

| Name | Default | Description |
| --- | --- | --- |
| template-name | <code>exupgradepaymentconfirm.html</code> | - |
| common-apostrophe-s |  | ??? |
| common-separator |  | ??? |

**Example**  
```html
<ex-upgrade-payment-confirm></ex-upgrade-payment-confirm>
```

* * *

<a name="module_exUpgradeTradeinConsent"></a>

## exUpgradeTradeinConsent
Shows the tradein consent message for upgradeing device. Allows the user to select tradein consent.

__Requirements__
* displays checkbox to select tradein consent message.
* displays continue cta.
* displays cancel cta.

**See**: [upgradeTradeinConsentCtrl](../controllers/#module_upgradeTradeinConsentCtrl)  
**Properties**

| Name | Default | Description |
| --- | --- | --- |
| template-name | <code>&#x27;exupgradetradeinconsent.html&#x27;</code> |  |
| tradein-message |  | The upgrade eligibility messages for each device |
| tradin-avoid-charges |  | Message to avoid charges for customer if their device is not sent back. |

**Example**  
```html
<div ex-upgrade-tradein-consent
    tradein-message=""
    tradein-avoid-charges="">
</div>
```

* * *

