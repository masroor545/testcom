(function () {
    'use strict';

    /**
     * Shows the payment related details which user has.
     * Allows the user to change the payment card which they have stored.
     *
     * __Requirements:__
     * * displays page header with customer name and cta.
     * * displays message that payment is successful.
     * * displays customer first name, device name, ctn and plan id.
     * * displays payment amount, date, payment method and confirmation number.
     * * displays continue upgrade cta.
     * * displays return to eligibility upgrade cta.
     *
     * @module exUpgradePaymentConfirm
     *
     * @property [template-name = exupgradepaymentconfirm.html] -
     * @property common-apostrophe-s - ???
     * @property common-separator - ???
     *
     * @todo properties are not documented
     *
     * @see {@link ../controllers/#module_upgradePaymentConfirmCtrl|upgradePaymentConfirmCtrl}
     *
     * @example @lang html
     * <ex-upgrade-payment-confirm></ex-upgrade-payment-confirm>
     */
    angular.module('exUpgrade')

        .directive('exUpgradePaymentConfirm', [function () {
            return {
                restrict: 'AE',
                templateUrl: function (ele, attr) {
                    return attr.templateName ? attr.templateName : '/templates/exupgradepaymentconfirm.html';
                },
                scope: {
                    commonApostropheS: '@',
                    commonSeparator: '@'
                },
                controller: 'upgradePaymentConfirmCtrl'
            };
        }]);
})();
