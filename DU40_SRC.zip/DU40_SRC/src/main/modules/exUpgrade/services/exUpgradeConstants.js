(function () {
    'use strict';
    angular.module('exUpgrade')
        .constant('exUpgradeConstants', {
            classType: 'java.util.ArrayList',
            creditCard: 'creditCard',
            cvv: '111',
            customerAgreement: 'YES',
            eligibleFlag: {
                'none': 'NONE',
                'payOff': 'PAYOFF',
                'payUp': 'PAYUP',
                'payUpContract': 'CONTRACT_PAYUP',
                'replace': 'REPLACE',
                'tradeIn': 'TRADEIN',
                'tradeInContract': 'CONTRACT_TRADEIN'
            },
            errorStatus: 'error',
            errorStatusCode: {
                // Error code when card gets declined.
                'isCardDeclined': 'DETCS300007',
                'isISEFailed': 'errorCode.TI_1001',
                // Card invalid error code from AWP payment API failure response. Using this field on payment page to display the error.
                'isPaymentCardInvalid': 'DETCS3000010'
            },
            expressUpgradeApi: '/services/shopwireless/model/att/ecom/api/WirelessUpgradeSelectionActor/expressUpgrade',
            event: {
                updatePaymentInfoSubmit: 'PAYMENT_INFO_SUBMIT',
                updatePaymentInfoResponse: 'PAYMENT_INFO_SUBMIT_RESPONSE'
            },
            friendlyPageName: {
                upgradeEligibility: 'DS Upgrade Eligibility And Options Pg',
                upgradeOptionsModal: 'DS Upgrade Options Modal Pg',
                upgradeIneligibleTradein: 'DS Upgrade Device Ineligible Tradein Pg',
                changePaymentMethodModal: 'DS Upgrade Change Payment Modal Pg'
            },
            imageUrlExtension: '-100x160.jpg',
            paymentCardAmericanExpress: 'AE',
            paymentCardDiscover: 'DISC',
            paymentCardMasterCard: 'MC',
            paymentCardVisa: 'VISA',
            paymentProfile: 'paymentProfile',
            statusFailed: 'failed',
            success: 'success',
            tradeInPayUpErrorCodes: {
                // These are tradein/payup error codes. Using it on upgrade eligibility controller to handle these errors when post API got failed.
                // Do not add any other error code which are not releated to tradein/payup and not as per business requirement.
                'errorCode.TI_100': {
                    'isISCDDown': 'errorCode.TI_100'
                },
                'errorCode.TI_102': {
                    'isIDDDown': 'errorCode.TI_102'
                },
                'errorCode.TI_103': {
                    'isIREDGDown': 'errorCode.TI_103'
                },
                'errorCode.TIHS.ise': {
                    'isISEDown': 'errorCode.TIHS.ise'
                },
                'label.imei.failmsg': {
                    'isISEValidationFailed': 'label.imei.failmsg'
                },
                'errorCode.TIHS.idd_h': {
                    'isIDDHFailed': 'errorCode.TIHS.idd_h'
                }
            },
            upgradeEligibility: '/services/shopwireless/model/att/ecom/api/WirelessUpgradeSelectionActor/getUpgradeEligibility',
            upgradeEligibilityPayment: '/apis/checkout/upgradepayment/v1/upgradePaymentInfo',
            upgradedLinesInProgress: 'upgradedLinesInProgress',
            upgradeOptionsModalPath: '/shop/xpress/modals/upgrade-options.modal.html',
            UpgradeSelectionInfo: 'com.att.ecom.wireless.beans.UpgradeSelectionInfo',
            upgradeTradeinConsent: '/services/shopwireless/model/att/ecom/api/WirelessUpgradeSelectionActor/expressTradeIn',
            upgradePaymentPost: '/apis/checkout/upgradepayment/v1/postUpgradePayment',
            virtualUrl: {
                upgradeEligibility: '/shop/xpress/upgrade-eligibility.html',
                upgradeOptionsModal: '/shop/xpress/virtual/upgrade-options-modal.html',
                upgradeIneligibleTradein: '/shop/xpress/virtual/upgrade-ineligible-tradein.html',
                changePaymentMethodModal: '/shop/xpress/virtual/change-payment-method-modal.html'
            }
        });
})();