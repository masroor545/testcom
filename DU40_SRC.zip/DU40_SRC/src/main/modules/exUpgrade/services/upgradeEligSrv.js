(function () {
    'use strict';

    angular.module('exUpgrade')

        .factory('upgradeEligSrv', ['$http', 'exUpgradeConstants', 'exCommonConstants',
            function ($http, exUpgradeConstants, exCommonConstants) {
                var services = {
                    fetchUserDetails: fetchUserDetails,
                    upgradeSelectedLines: upgradeSelectedLines
                };

            /**
             * gets the upgrade eligible lines details from upgradeEligibility api
             * @function fetchUserDetails
             * @returns {object} promise upgrade eligibility lines details
             */
                function fetchUserDetails () {
                    return $http.get(exUpgradeConstants.upgradeEligibility).then(function (response) {
                        return response.data;
                    });
                }

            /**
             * Makes POST request to the express upgrade api
             * @function upgradeSelectedLines
             * @param {object} params A header params object
             * @returns {object} promise of the express upgrade results
             */
                function upgradeSelectedLines (params) {
                    return $http.post(exUpgradeConstants.expressUpgradeApi,
                    params, {
                        spinner: true,
                        att: [exCommonConstants.http.postAuthReq]
                    }).then(function (resp) {
                        return resp.data;
                    });
                }

                return services;
            }]);
})();
