(function () {
    'use strict';

    angular.module('exUpgrade')

        .factory('upgradeEligPaymentSrv', ['$log', '$q', '$http', 'exUpgradeConstants', 'exCommonConstants',
            function ($log, $q, $http, exUpgradeConstants, exCommonConstants) {
                var services = {
                    fetchPaymentDetails: fetchPaymentDetails,
                    getUpgradingDevicePaymentData: getUpgradingDevicePaymentData,
                    upgradePaymentContinue: upgradePaymentContinue,
                    updateUpgradeEligibility: updateUpgradeEligibility
                };
                var paymentRequestToken = '';

                /**
                 * fetchs the user payment profile information from upgradeEligibilityPayment api.
                 * @function fetchPaymentDetails
                 * @returns {object} promise object user payment profile information.
                 */
                function fetchPaymentDetails (userUUID) {
                    return $http.get(exUpgradeConstants.upgradeEligibilityPayment + '/' + userUUID, {spinner: true}).then(function (response) {
                        paymentRequestToken = response.headers('X-CCC-AWP-ACCESS-TOKEN');
                        return response.data;
                    });
                }
                /**
                 * gets the upgrading device payment details.
                 * @function getUpgradingDevicePaymentData
                 * @returns {object} promise object upgrading device payment data.
                 */
                function getUpgradingDevicePaymentData () {
                    return $http.get(exCommonConstants.buyflowApi, {
                        params: {
                            actionType: 'getupoptions'
                        }
                    }).then(function (response) {
                        return response.data;
                    });
                }


                /**
                 * Makes POST request to the upgrade payment POST api
                 * @function upgradePaymentContinue
                 * @param {string} UUID of user
                 * @param {object} payment details object for $http post request
                 * @returns {object} promise of the upgrade payment POST results
                 */
                function upgradePaymentContinue (userUUID, params) {
                    return $http.post(exUpgradeConstants.upgradePaymentPost + '/' + userUUID, params, {
                        spinner: true,
                        headers: {
                            'X-CCC-AWP-ACCESS-TOKEN': paymentRequestToken
                        }
                    }).then(upgradePaymentComplete)
                        .catch(upgradePaymentFailed);
                }

                /**
                 * Returns the data property of the upgrade payment api response object.
                 * @function upgradePaymentComplete
                 * @param {object} response - upgrade payment response
                 * @returns {Promise<object>} promise of the upgrade payment POST results
                 */
                function upgradePaymentComplete (response) {
                    return response.data;
                }

                /**
                 * Logs an error and rejects the promise returned by the upgrade payment continue function.
                 * @function upgradePaymentFailed
                 * @param {Error} error in upgrade payment, error object.
                 * @returns {Promise<Error>} Returns rejected promise.
                 */
                function upgradePaymentFailed (error) {
                    var message = 'upgradeEligPaymentSrv.upgradePaymentContinue call failed.';
                    if (error.data && error.data.description) {
                        message += '\n' + error.data.description;
                    }
                    $log.error(message);
                    return $q.reject(error);
                }

                 /**
                 * Make a call to IUE call getUpgradeEligibility api.
                 * @function updateUpgradeEligibility.
                 * @returns {object} promise object refreshed upgrade eligible device.
                 */
                function updateUpgradeEligibility () {
                    return $http.get(exUpgradeConstants.upgradeEligibility, {
                        params: {
                            refreshEligibility: true
                        }
                    }).then(function (response) {
                        return response.data;
                    });
                }


                return services;
            }]);
})();
