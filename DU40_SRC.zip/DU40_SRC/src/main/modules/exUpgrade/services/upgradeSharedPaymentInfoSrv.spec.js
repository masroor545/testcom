(function () {
    'use strict';

    define(['upgradeSharedPaymentInfoSrv'], function () {
        describe('src/main/modules/exUpgrade/services/upgradeSharedPaymentInfoSrv.spec.js', function () {
            describe('upgradeSharedPaymentInfoSrv service of exUpgrade', function () {
                var service, $window, exCommonConstants;

                beforeEach(function () {
                    module('exUpgrade');

                    inject(function ($injector) {
                        service = $injector.get('upgradeSharedPaymentInfoSrv');
                        $window = $injector.get('$window');
                        exCommonConstants = $injector.get('exCommonConstants');
                    });
                    spyOn($window.sessionStorage, 'getItem');
                    spyOn($window.sessionStorage, 'setItem');
                });

                describe('setSharedPaymentInfo function of the upgradeSharedPaymentInfoSrv', function () {
                    it('should set the shared data in into session storage', function () {
                        var sharedData = {'ctn': '158625565'};
                        service.setSharedPaymentInfo(sharedData);
                        expect($window.sessionStorage.setItem)
                            .toHaveBeenCalledWith(exCommonConstants.paymentSummaryStorageKey, JSON.stringify(sharedData));
                    });
                });
                describe('getSharedPaymentInfo function of the upgradeSharedPaymentInfoSrv', function () {
                    it('should get the shared data in into session storage', function () {
                        var sharedData = {'ctn': '158625565'};
                        $window.sessionStorage.getItem.and.returnValue(JSON.stringify(sharedData));
                        service.getSharedPaymentInfo();
                        expect($window.sessionStorage.getItem)
                            .toHaveBeenCalledWith(exCommonConstants.paymentSummaryStorageKey);
                    });
                });

            });
        });
    });
})();