(function () {
    'use strict';

    define(['upgradeTradeinConsentSrv'], function () {
        describe('src/main/modules/exUpgrade/services/upgradeTradeinConsentSrv.spec.js', function () {
            describe('upgradeTradeinConsentSrv service of exUpgrade', function () {
                var $httpBackend, service;

                beforeEach(function () {
                    module('exUpgrade');

                    inject(function ($injector) {
                        $httpBackend = $injector.get('$httpBackend');
                        service = $injector.get('upgradeTradeinConsentSrv');
                    });
                });
                describe('tradeinConsentContinue function of the upgradeTradeinConsentSrv in exUpgrade', function () {

                    it('should call the expressTradein service with the params provided', function () {
                        $httpBackend.whenPOST(Endpoint_expressTradeinConsent.express_tradein_consent.url_match)
                            .respond(200, Endpoint_expressTradeinConsent.express_tradein_consent.result);

                        var inputParams = {
                            foo: 'foo',
                            bar: 'bar',
                            baz: 'baz'
                        };
                        service.tradeinConsentContinue(inputParams).then(function (result) {
                            expect(result).toBeDefined();
                        });
                        $httpBackend.flush();
                    });
                });


            });
        });
    });
})();
