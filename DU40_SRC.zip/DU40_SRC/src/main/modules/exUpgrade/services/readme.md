# exUpgrade Services

### <a name='upgradeEligSrv'></a> `upgradeEligSrv`

##### Description:
This service serves the purpose of getting the list of upgrade elibible device from the rest api endpoint of upgrade eligibility.

##### Functions:

---
##### ```fetchUserDetails( ) : Promise```

It makes a call to get list of lines from rest api endpoint of upgrade eligibility.

**Parameters:**
* *NONE* 

**Returns:**
It returns data for lines which shows all upgrade related information for that line.

```javascript
upgradeEligSrv.fetchUserDetails()
    .then(function (data) {
        // do something with said data object
    });
```
---

##### ```upgradeSelectedLines(params:object) : Promise```

It makes POST service call to get result from the express upgrade api.

**Parameters:**
* params (required) - A header params object.

**Returns:**
It returns success or failure result for the selected device to upgrade along with redirection url.

```javascript
upgradeEligSrv.upgradeSelectedLines(params)
    .then(function (data) {
        // do something with said data object
    });
```
---

### <a name='upgradeEligPaymentSrv'></a> `upgradeEligPaymentSrv`

##### Description:
This service serves the purpose of getting the payment details from the rest api endpoint of upgrade payment.

##### Functions:

---
##### ```fetchPaymentDetails( ) : Promise```

It makes a call to get list of lines from rest api endpoint of upgrade eligibility.

**Parameters:**
* params (string) - A UUID nummber.

**Returns:**
It returns data for payment which shows all payment related information for that user.

```javascript
upgradeEligPaymentSrv.fetchPaymentDetails(userUUID)
    .then(function (data) {
        // do something with said data object
    });
```
---
##### ```getUpgradingDevicePaymentData( ) : Promise```

It makes a call to get upgrading device payment and upgrading type information.

**Parameters:**
* *NONE* 

**Returns:**
It returns data for payment amount and upgrading type of upgrading line.

```javascript
upgradeEligPaymentSrv.getUpgradingDevicePaymentData()
    .then(function (data) {
        // do something with said data object
    });
```
---
##### ```upgradePaymentContinue(params:string, params:object) : Promise```

It makes POST service call to get result from the upgrade paymentPost api.

**Parameters:**
* params (string) - A UUID nummber.
* param {object} - payment details object for $http post request

**Returns:**
It returns success or failure result for the payment made for upgarding device.

```javascript
upgradeEligPaymentSrv.upgradePaymentContinue(userUUID, params)
    .then(function (data) {
        // do something with said data object
    });
```
---
##### ```upgradePaymentComplete(response:object)```

Returns the data property of the upgrade payment api response object.

**Parameters:**
* response {object} - upgrade payment response

**Returns:**
It returns result for the payment made for upgarding device.

```javascript
upgradePaymentComplete(response);
```
---
##### ```upgradePaymentFailed(error)```

Logs an error and rejects the promise returned by the upgrade payment continue function.

**Parameters:**
* error {Error} - error in upgrade payment, error object.

**Returns:**
Returns rejected promise.

```javascript
upgradePaymentFailed(error);
```
---
##### ```updateUpgradeEligibility( ) : Promise```

It makes get IUE service call to get refreshed upgrade eligible device.

**Returns:**
It returns success or failure result for inquire upgrade eligibility service.

```javascript
upgradeEligPaymentSrv.updateUpgradeEligibility()
    .then(function (data) {
        // do something with said data object
    });
```
---

### <a name='upgradeTradeinConsentSrv'></a> `upgradeTradeinConsentSrv`

##### Description:
This service serves the purpose of getting the trade in consent details from the rest api endpoint of upgrade tradein.

##### Functions:

---
##### ```tradeinConsentContinue( ) : Promise```

It makes POST service call to get result from the express tradein api.

**Parameters:**
* params (required) - A header params object.

**Returns:**
It returns success or failure result for the traedin consent along with redirection url.

```javascript
upgradeTradeinConsentSrv.tradeinConsentContinue(params)
    .then(function (data) {
        // do something with said data object
    });
```
---
### <a name='upgradeSharedPaymentInfoSrv'></a> `upgradeSharedPaymentInfoSrv`

##### Description:
This service serves the purpose of saving and retrieving the payment information which being shared. 

##### Functions:

---
##### ```setSharedPaymentInfo(sharedData:object)```

This function saves shared information to sharedPaymentInfo object.

**Parameters:**
* sharedData (required) - A information which is going to be saved.

```javascript
upgradeSharedPaymentInfoSrv.setSharedPaymentInfo(sharedData)
        // do something with said data object
    });
```
---
##### ```getSharedPaymentInfo( )```

This function retrives shared information which is saved in sharedPaymentInfo object.

**Returns:**
It returns saved information from sharedPaymentInfo object.

```javascript
upgradeSharedPaymentInfoSrv.getSharedPaymentInfo()
        // do something with said data object
    });
```
---

# exUpgradeConstants

### <a name='exUpgradeConstants'></a> `exUpgradeConstants`

##### Description:
This file is used to store constants for exUpgrade module .

##### Constants:
* **classType** -  ATG rest service attribute to pass input parameter as an array to express upgrade api.
* **eligibleFlag** - upgrade option flag passed as an input to express upgrade api.
* **errorStatus** - it is the status to check if there is an error from express upgrade api response.
* **errorStatusCode** - it is to check the message in case of error from express upgrade api response.
     - **isCardDeclined** - Error code when card gets declined.
* **expressUpgradeApi** - express upgrade api url.
* **imageUrlExtension** - Catalog image path extension.
* **invokeCSICall** - invokeCSI service api url.
* **upgradeEligibility** - url for getting upgrade eligible lines.
* **upgradeEligibilityPayment** - url for getting payment details to upgrade the device.
* **upgradedLinesInProgress** - upgraded lines in progress tag.
* **upgradeOptionsModalPath** - upgraded options modal path.
* **UpgradeSelectionInfo** - it is a java class name passed as an input to express upgrade api.
* **upgradeTradeinConsent** - express tradeIn api url.
* **upgradePaymentPost** - upgrade payment POST call api.
* **paymentCardMasterCard** - payment card master card.
* **paymentCardVisa** - payment card visa card.
* **paymentCardDiscover** - payment card discover card.
* **paymentCardAmericanExpress** - payment card american express card.
* **creditCard** - credit card.
* **paymentProfile** - payment profile.
* **friendlyPageName** - Friendly Page Name defined by EDD.
* **virtualUrl** - Virtual URL defined by EDD.
* **event.updatePaymentInfoSubmit** - event from CCC for Update Payment Info Submit
* **event.updatePaymentInfoResponse** - event from CCC for Update Payment Info Response
* **customerAgreement** - Customer agreement flag to pass AWP call 
* **tradeInPayUpErrorCodes** - tradein and payup failure error codes object 
---
---