(function () {
    'use strict';

    /**
     * This controller retrieves the tradein consent message from service
     *
     * __Requirements:__
     * * gets tradein consent message.
     *
     * @module upgradeTradeinConsentCtrl
     *
     * @property {object} upgradeTradein - ???
     * @property {boolean} [upgradeTradein.consentCheckbox = false] - ???
     * @property {object} upgradeTradein.avoidChargesDesc - ???
     * @property {string} upgradeTradein.upgradeEligUrl - {@link ../../exCommon/#module_exCommonConstants|exCommonConstants.upgradeEligibility}
     *
     * @todo update documentation to be more informative and accurate
     *
     * @see {@link ../services/#module_upgradeLinesInfoService..getUpgradeLinesInfo|upgradeLinesInfoService} this is the
     * primary source of data for this controller.
     */
    angular.module('exUpgrade')

        .controller('upgradeTradeinConsentCtrl', ['$scope', 'exCqTranslatorKeyService', 'upgradeTradeinConsentSrv',
            'exCommonConstants', 'reportingDataSrv', 'upgradeLinesInfoService', 'exHelpUtils',
            function ($scope, exCqTranslatorKeyService, upgradeTradeinConsentSrv, exCommonConstants, reportingDataSrv, upgradeLinesInfoService, exHelpUtils) {

                $scope.upgradeTradein = {};
                $scope.agreeTradeinConsent = agreeTradeinConsent;

                $scope.upgradeTradein.consentCheckbox = false;
                $scope.upgradeTradein.upgradeEligUrl = exCommonConstants.upgradeEligibility;
                $scope.upgradeTradein.avoidChargesDesc;

                activate();
                /**
                 * Controller startup logic
                 */
                function activate () {
                    exCqTranslatorKeyService.getCqTranslatorKeys([$scope.tradeinMessage]).then(function (result) {
                        $scope.upgradeTradein.terms = result[$scope.tradeinMessage];
                    });

                    var upgradeLinesInfo = upgradeLinesInfoService.getUpgradeLinesInfo();
                    if (upgradeLinesInfo.contractDeviceDetails) {
                        $scope.upgradeTradein.avoidChargesDesc = exHelpUtils.replacePlaceholdersWithContent(
                            $scope.contractAvoidCharges, [upgradeLinesInfo.contractDeviceDetails.deviceName, '']);
                    } else if (upgradeLinesInfo.networkDeviceDetails) {
                        $scope.upgradeTradein.avoidChargesDesc = exHelpUtils.replacePlaceholdersWithContent(
                            $scope.contractAvoidCharges, [upgradeLinesInfo.networkDeviceDetails.networkDeviceName, '']);
                    } else {
                        $scope.upgradeTradein.avoidChargesDesc = $scope.tradeinAvoidCharges;
                    }
                }

                /**
                 * Pass scope variables to the post service.
                 * @function agreeTradeinConsent
                 * @todo add meaningful documentation
                 * @emits DS_Upgrade_Tradein_Submit
                 * @see {@link ../services/module_upgradeTradeinConsentSrv..tradeinConsentContinue|upgradeTradeinConsentSrv}
                 */
                function agreeTradeinConsent () {
                    var serviceInput = {
                        'tradeInTerms': $scope.upgradeTradein.terms,
                        'agreeToTradeInTerms': $scope.upgradeTradein.consentCheckbox
                    };

                    var eventPayload = reportingDataSrv.getTradeinConsentEventPayload($scope.upgradeTradein.consentCheckbox);
                    $scope.$emit(exCommonConstants.event.DS_REPORTING_EVENT, {
                        eventAction: 'formSubmit',
                        eventCode: 'DS_Upgrade_Tradein_Submit',
                        additionaldata: eventPayload
                    }, $scope);

                    upgradeTradeinConsentSrv.tradeinConsentContinue(serviceInput).then(function (data) {
                        if (data.response !== undefined && data.response !== null
                            && data.response.status === exCommonConstants.errorStatus) {
                            eventPayload = reportingDataSrv.updateEventPayloadFailure(eventPayload, data);
                        }

                        $scope.$emit(exCommonConstants.event.DS_REPORTING_EVENT, {
                            eventAction: 'formResponse',
                            eventCode: 'DS_Upgrade_Tradein_Submit',
                            additionaldata: eventPayload
                        }, $scope);
                    });
                }
            }]);
})();
