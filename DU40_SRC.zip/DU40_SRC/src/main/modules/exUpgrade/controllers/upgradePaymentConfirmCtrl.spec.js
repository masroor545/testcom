(function () {
    'use strict';

    define(['upgradePaymentConfirmCtrl'], function () {
        describe('src/main/modules/exUpgrade/controllers/upgradePaymentConfirmCtrl.spec.js', function () {
            describe('upgradePaymentConfirmCtrl controller of exUpgrade', function () {
                var controller, $rootScope, scope, $filter, $q, upgradingUserInfoSrv, getUpDeviceDetails,
                    getDeviceTypeInfo, $location, upgradeSharedPaymentInfoSrv, exCommonConstants, upgradeEligPaymentSrv;

                getUpDeviceDetails = Endpoint_deviceRecommenderApi.getUpgradingDeviceDetailsData;
                getDeviceTypeInfo = Endpoint_deviceRecommenderApi.getUpgradingDetails_Phone;

                beforeEach(function () {
                    module('exUpgrade');
                    inject(function ($injector) {
                        controller = $injector.get('$controller');
                        $rootScope = $injector.get('$rootScope');
                        scope = $rootScope.$new();
                        $filter = $injector.get('$filter');
                        exCommonConstants = $injector.get('exCommonConstants');
                        $location = $injector.get('$location');
                        $q = $injector.get('$q');
                        spyOn($location, 'path');
                        upgradingUserInfoSrv = {
                            getUpgradingDeviceDetailsData: function () {
                                return $q.when(getUpDeviceDetails.result);
                            },
                            getDeviceType: function () {
                                return $q.when(getDeviceTypeInfo.result);
                            }
                        };
                        upgradeSharedPaymentInfoSrv = jasmine.createSpyObj('upgradeSharedPaymentInfoSrv', ['getSharedPaymentInfo']);
                        upgradeEligPaymentSrv = jasmine.createSpyObj('upgradeEligPaymentSrv', ['updateUpgradeEligibility']);
                        upgradeSharedPaymentInfoSrv.getSharedPaymentInfo.and.returnValue({
                            'paymentDate': 'payment data',
                            'amount': 363,
                            'referenceInformation': '15493202558',
                            'last4digitCC': '4525',
                            'paymentType': 'PayOff',
                            'planId': '4525842525'
                        });
                        jasmine.createSpyObj('upgradingUserInfoSrv', ['getUpgradingDeviceDetailsData', 'getDeviceType']);
                        controller('upgradePaymentConfirmCtrl', {
                            $scope: scope,
                            upgradingUserInfoSrv: upgradingUserInfoSrv,
                            upgradeSharedPaymentInfoSrv: upgradeSharedPaymentInfoSrv,
                            upgradeEligPaymentSrv: upgradeEligPaymentSrv
                        });
                        scope.commonSeparator = ' | ';
                        scope.commonApostrophes = "'s";
                    });
                    $rootScope.$digest();
                });

                it('should provide scope for the upgrading device', function () {
                    expect(scope.paymentConfirmation.upgradingDevice).toBeDefined();
                    expect(scope.paymentConfirmation.customerDetailWithDevice).toBeDefined();
                });

                it('should check IRU call is made', function () {
                    upgradingUserInfoSrv.getUpgradingDeviceDetailsData().then(function () {
                        expect(upgradeEligPaymentSrv.updateUpgradeEligibility).toHaveBeenCalled();
                    });
                });

                it('should provide user, device and line information', function () {
                    expect(scope.paymentConfirmation.upgradingDevice.subscriberName).toEqual('BEDROCK');
                    expect(scope.paymentConfirmation.upgradingDevice.deviceModel).toEqual('iPhone 6');
                    expect(scope.paymentConfirmation.upgradingDevice.ctn).toEqual('4252951153');
                    expect(scope.paymentConfirmation.paymentDetails.amount).toEqual(363);
                    expect(scope.paymentConfirmation.paymentDetails.referenceInformation).toEqual('15493202558');
                    expect(scope.paymentConfirmation.paymentDetails.planId).toEqual('4525842525');
                });

                describe('should check updateHeaderDetails function ', function () {
                    it('should provide customer name and device name', function () {
                        scope.commonApostrophes = "'s";
                        var upgradingDevice = {
                            'deviceMake': 'APPLE',
                            'ctn': '4252951153',
                            'deviceSkuId': 'sku7380579',
                            'sharedDataGroupSocCode': 'SDGUNLTV',
                            'uom': 'GB',
                            'color': 'Space Gray',
                            'deviceType': 'pda',
                            'subscriberName': 'BEDROCK',
                            'deviceModel': 'iPhone 6',
                            'subscriberStatus': 'A',
                            'planSocCode': 'SDDVRP',
                            'size': 16
                        };
                        expect(scope.paymentConfirmation.customerDetailWithDevice.customerCTNWithDevice)
                            .toEqual(upgradingDevice.deviceModel + ' ' + scope.commonSeparator + ' ' +
                                $filter('tel')(scope.paymentConfirmation.upgradingDevice.ctn));
                    });
                });

                describe('should check paymentConfirmRedirect function', function () {
                    it('should redirect page to a new location', function () {
                        scope.paymentConfirmRedirect();
                        expect($location.path).toHaveBeenCalled();
                    });
                });

                describe('should check disableUpgradePaymentConfirmCta function', function () {
                    it('disableUpgradePaymentConfirmCta should be enabled', function () {
                        expect(scope.disableUpgradePaymentConfirmCta()).toBe(false);
                    });

                    it('disableUpgradePaymentConfirmCta should be disabled', function () {
                        scope.paymentConfirmation = {
                            paymentDetails: {}
                        };
                        expect(scope.disableUpgradePaymentConfirmCta()).toBe(true);
                    });

                });

                it('should check redirection when cancel button click', function () {
                    scope.redirectToUpgradeElig();
                    expect($location.path).toHaveBeenCalledWith(exCommonConstants.upgradeEligibility);
                });

            });
        });
    });
})();
