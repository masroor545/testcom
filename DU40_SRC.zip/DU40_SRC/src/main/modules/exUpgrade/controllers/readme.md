## Modules

<table>
  <thead>
    <tr>
      <th>Module</th><th>Description</th>
    </tr>
  </thead>
  <tbody>
<tr>
    <td><a href="#module_upgradeEligCtrl">upgradeEligCtrl</a></td>
    <td><p>This controller retrieves the details of the devices the user has from the service</p>
<p><strong>Requirements:</strong></p>
<ul>
<li>gets devices that the user has.</li>
<li>gets message informing user whether their device is eligible for upgrade or not.</li>
</ul>
</td>
    </tr>
<tr>
    <td><a href="#module_upgradeEligPaymentCtrl">upgradeEligPaymentCtrl</a></td>
    <td><p>This controller retrieves the payment related details which user has from the service</p>
<p><strong>Requirements:</strong></p>
<ul>
<li>gets payment details which user has.</li>
</ul>
</td>
    </tr>
<tr>
    <td><a href="#module_upgradePaymentConfirmCtrl">upgradePaymentConfirmCtrl</a></td>
    <td><p>This controller retrieves payment confirmation details</p>
<p><strong>Requirements:</strong></p>
<ul>
<li>gets customer profile information.</li>
<li>gets customer plan ID</li>
<li>gets customer payment information</li>
</ul>
</td>
    </tr>
<tr>
    <td><a href="#module_upgradeTradeinConsentCtrl">upgradeTradeinConsentCtrl</a></td>
    <td><p>This controller retrieves the tradein consent message from service</p>
<p><strong>Requirements:</strong></p>
<ul>
<li>gets tradein consent message.</li>
</ul>
</td>
    </tr>
</tbody>
</table>

<a name="module_upgradeEligCtrl"></a>

## upgradeEligCtrl
This controller retrieves the details of the devices the user has from the service

__Requirements:__
* gets devices that the user has.
* gets message informing user whether their device is eligible for upgrade or not.

**Todo**

- [ ] Update this content to be complete and meaningful
- [ ] missing properties etc...
- [ ] function docs need updated
- [ ] other information etc...

**Properties**

| Name | Type | Description |
| --- | --- | --- |
| user | <code>object</code> | ??? |
| user.selectedLines | <code>object</code> | ??? |


* [upgradeEligCtrl](#module_upgradeEligCtrl)
    * [~updateLineSelection(lineObject)](#module_upgradeEligCtrl..updateLineSelection)
    * [~upgradeLines()](#module_upgradeEligCtrl..upgradeLines)
    * [~disableTradeInPayUpOption(selectedSubscriber, selectNextEligibileOption)](#module_upgradeEligCtrl..disableTradeInPayUpOption)


* * *

<a name="module_upgradeEligCtrl..updateLineSelection"></a>

### upgradeEligCtrl~updateLineSelection(lineObject)
Enables the selected line and disables the other lines.

**Kind**: inner method of [<code>upgradeEligCtrl</code>](#module_upgradeEligCtrl)  

| Param | Type | Description |
| --- | --- | --- |
| lineObject | <code>Object</code> | Subscriber line |


* * *

<a name="module_upgradeEligCtrl..upgradeLines"></a>

### upgradeEligCtrl~upgradeLines()
If any upgradeing line is in progress then redirect it to cart summary page.

**Kind**: inner method of [<code>upgradeEligCtrl</code>](#module_upgradeEligCtrl)  
**Todo**

- [ ] needs updated


* * *

<a name="module_upgradeEligCtrl..disableTradeInPayUpOption"></a>

### upgradeEligCtrl~disableTradeInPayUpOption(selectedSubscriber, selectNextEligibileOption)
Disable Trade in option radio button on tradein option page and select another available option.

**Kind**: inner method of [<code>upgradeEligCtrl</code>](#module_upgradeEligCtrl)  

| Param | Type | Description |
| --- | --- | --- |
| selectedSubscriber | <code>Object</code> | Subscriber number |
| selectNextEligibileOption | <code>String</code> | Select next eligibile flag option. |


* * *

<a name="module_upgradeEligPaymentCtrl"></a>

## upgradeEligPaymentCtrl
This controller retrieves the payment related details which user has from the service

__Requirements:__
* gets payment details which user has.

**Emits**: <code>event:DS_Upgrade_Update_Payment_Info_Submit</code>  
**Todo**

- [ ] update information and make it accurate

**Properties**

| Name | Type | Default | Description |
| --- | --- | --- | --- |
| upgradePayment | <code>object</code> |  | ??? |
| upgradePayment.terms | <code>string</code> |  | ??? |
| upgradePayment.errorMessage | <code>string</code> |  | ??? |
| upgradePayment.consentCheckbox | <code>boolean</code> | <code>false</code> | ??? |
| upgradePayment.displayPaymentOptions | <code>boolean</code> | <code>false</code> | ??? |
| upgradePayment.cvv | <code>string</code> |  | ??? |


* [upgradeEligPaymentCtrl](#module_upgradeEligPaymentCtrl)
    * [~continueToPayment()](#module_upgradeEligPaymentCtrl..continueToPayment)
    * [~changePaymentMethod(visible)](#module_upgradeEligPaymentCtrl..changePaymentMethod)
    * [~redirectToUpgradeElig()](#module_upgradeEligPaymentCtrl..redirectToUpgradeElig)


* * *

<a name="module_upgradeEligPaymentCtrl..continueToPayment"></a>

### upgradeEligPaymentCtrl~continueToPayment()
Passes serviceInput and userId to upgradePaymentContinue services.

**Kind**: inner method of [<code>upgradeEligPaymentCtrl</code>](#module_upgradeEligPaymentCtrl)  
**See**: [upgradeEligPaymentSrv.upgradePaymentContinue](../services/#module_upgradeEligPaymentSrv..upgradePaymentContinue)  
**Todo**

- [ ] provide meaningful information


* * *

<a name="module_upgradeEligPaymentCtrl..changePaymentMethod"></a>

### upgradeEligPaymentCtrl~changePaymentMethod(visible)
function to see ccc payment modal and broadcast customer information to modal

**Kind**: inner method of [<code>upgradeEligPaymentCtrl</code>](#module_upgradeEligPaymentCtrl)  
**Emits**: <code>event:DS_REPORTING_PAGELOAD_EVENT</code>  
**See**: [DS_REPORTING_PAGELOAD_EVENT](../../exCommon/#module_exCommonConstants.event.DS_REPORTING_PAGELOAD_EVENT)  
**Todo**

- [ ] meaningful information is needed


| Param | Type | Description |
| --- | --- | --- |
| visible | <code>boolean</code> | ??? |


* * *

<a name="module_upgradeEligPaymentCtrl..redirectToUpgradeElig"></a>

### upgradeEligPaymentCtrl~redirectToUpgradeElig()
redirect to upgrade eligibility page.

**Kind**: inner method of [<code>upgradeEligPaymentCtrl</code>](#module_upgradeEligPaymentCtrl)  

* * *

<a name="module_upgradePaymentConfirmCtrl"></a>

## upgradePaymentConfirmCtrl
This controller retrieves payment confirmation details

__Requirements:__
* gets customer profile information.
* gets customer plan ID
* gets customer payment information

**See**: [upgradeUserInfoSrv.getUpgradingDeviceDetailsData](../services/#module_upgradeUserInfoSrv..getUpgradingDeviceDetailsData)
this is the primary source of data in controller.  
**Todo**

- [ ] update documentation so that it is complete and accurate

**Properties**

| Name | Type | Description |
| --- | --- | --- |
| paymentConfirmation | <code>object</code> | parent data store object |
| paymentConfirmation.paymentDetails | <code>object</code> | ??? |
| paymentConfirmation.customerDetailWithDevice | <code>object</code> | ??? |
| paymentConfirmation.upgradingDevice | <code>object</code> | ??? |


* [upgradePaymentConfirmCtrl](#module_upgradePaymentConfirmCtrl)
    * [~paymentConfirmRedirect()](#module_upgradePaymentConfirmCtrl..paymentConfirmRedirect)
    * [~disableUpgradePaymentConfirmCta()](#module_upgradePaymentConfirmCtrl..disableUpgradePaymentConfirmCta) ⇒ <code>Boolean</code>
    * [~redirectToUpgradeElig()](#module_upgradePaymentConfirmCtrl..redirectToUpgradeElig)


* * *

<a name="module_upgradePaymentConfirmCtrl..paymentConfirmRedirect"></a>

### upgradePaymentConfirmCtrl~paymentConfirmRedirect()
Redirect to next page based on payment type.

**Kind**: inner method of [<code>upgradePaymentConfirmCtrl</code>](#module_upgradePaymentConfirmCtrl)  

* * *

<a name="module_upgradePaymentConfirmCtrl..disableUpgradePaymentConfirmCta"></a>

### upgradePaymentConfirmCtrl~disableUpgradePaymentConfirmCta() ⇒ <code>Boolean</code>
Disable the CTA if payment details are not available

**Kind**: inner method of [<code>upgradePaymentConfirmCtrl</code>](#module_upgradePaymentConfirmCtrl)  
**Returns**: <code>Boolean</code> - based if payment details are available  

* * *

<a name="module_upgradePaymentConfirmCtrl..redirectToUpgradeElig"></a>

### upgradePaymentConfirmCtrl~redirectToUpgradeElig()
redirect to upgrade eligibility page.

**Kind**: inner method of [<code>upgradePaymentConfirmCtrl</code>](#module_upgradePaymentConfirmCtrl)  

* * *

<a name="module_upgradeTradeinConsentCtrl"></a>

## upgradeTradeinConsentCtrl
This controller retrieves the tradein consent message from service

__Requirements:__
* gets tradein consent message.

**See**: [upgradeLinesInfoService](../services/#module_upgradeLinesInfoService..getUpgradeLinesInfo) this is the
primary source of data for this controller.  
**Todo**

- [ ] update documentation to be more informative and accurate

**Properties**

| Name | Type | Default | Description |
| --- | --- | --- | --- |
| upgradeTradein | <code>object</code> |  | ??? |
| upgradeTradein.consentCheckbox | <code>boolean</code> | <code>false</code> | ??? |
| upgradeTradein.avoidChargesDesc | <code>object</code> |  | ??? |
| upgradeTradein.upgradeEligUrl | <code>string</code> |  | [exCommonConstants.upgradeEligibility](../../exCommon/#module_exCommonConstants) |


* * *

<a name="module_upgradeTradeinConsentCtrl..agreeTradeinConsent"></a>

### upgradeTradeinConsentCtrl~agreeTradeinConsent()
Pass scope variables to the post service.

**Kind**: inner method of [<code>upgradeTradeinConsentCtrl</code>](#module_upgradeTradeinConsentCtrl)  
**Emits**: <code>event:DS_Upgrade_Tradein_Submit</code>  
**See**: [upgradeTradeinConsentSrv](../services/module_upgradeTradeinConsentSrv..tradeinConsentContinue)  
**Todo**

- [ ] add meaningful documentation


* * *

