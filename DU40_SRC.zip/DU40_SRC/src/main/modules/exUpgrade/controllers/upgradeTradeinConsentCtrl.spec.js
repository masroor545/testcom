(function () {
    'use strict';

    define(['upgradeTradeinConsentCtrl'], function () {
        describe('src/main/modules/exUpgrade/controllers/upgradeTradeinConsentCtrl.spec.js', function () {
            describe('upgradeTradeinConsentCtrl of exUpgrade', function () {
                var controller, scope, $rootScope, exCqTranslatorKeyService, expressTradeinResponse,
                    upgradeTradeinConsentSrv, reportingDataSrv, exHelpUtils, upgradeLinesInfoService;

                expressTradeinResponse = Endpoint_expressTradeinConsent.express_tradein_consent;

                beforeEach(function () {
                    reportingDataSrv = jasmine.createSpyObj('reportingDataSrv', ['getTradeinConsentEventPayload']);
                    reportingDataSrv.getTradeinConsentEventPayload.and.returnValue({
                        userResp: 'Trade In Consent Selected'
                    });
                });

                beforeEach(function () {
                    module('exUpgrade');
                    inject(function ($injector) {
                        controller = $injector.get('$controller');
                        $rootScope = $injector.get('$rootScope');
                        scope = $rootScope.$new();
                        scope.tradeinMessage = 'label.tradinoptions.agreement';
                        exCqTranslatorKeyService = jasmine.createSpyObj('exCqTranslatorKeyService', ['getCqTranslatorKeys']);
                        upgradeLinesInfoService = jasmine.createSpyObj('upgradeLinesInfoService', ['getUpgradeLinesInfo']);

                        exHelpUtils = jasmine.createSpyObj('exHelpUtils', ['replacePlaceholdersWithContent']);
                        exCqTranslatorKeyService.getCqTranslatorKeys.and.returnValue({
                            'then': function (callback) {
                                callback({'label.tradinoptions.agreement':
                                    'Trade in consent: Trade in consent message'});
                            }
                        });
                        exHelpUtils.replacePlaceholdersWithContent.and.returnValue({
                            customerNameAndMsg: 'Hi, BEDROCK! Which device would you like to upgrade?',
                            payUp: 'Pay $50.00 and trade in your device to upgrade early',
                            payOff: 'Pay off $70.00 to upgrade early',
                            contractTerm: 'Two-year contract ends Nov.',
                            installmentPlan: '24-month installment plan ends Nov.'
                        });

                        upgradeTradeinConsentSrv = jasmine.createSpyObj('upgradeTradeinConsentSrv', ['tradeinConsentContinue']);
                        upgradeTradeinConsentSrv.tradeinConsentContinue.and.returnValue({
                            'then': function (callback) {
                                callback(expressTradeinResponse.result);
                            }
                        });

                        upgradeLinesInfoService.getUpgradeLinesInfo.and.returnValue({
                            'then': function (callback) {
                                callBackFN(true);
                            }
                        });
                        // Instantiates controller
                        controller('upgradeTradeinConsentCtrl', {
                            $scope: scope,
                            exCqTranslatorKeyService: exCqTranslatorKeyService,
                            upgradeTradeinConsentSrv: upgradeTradeinConsentSrv,
                            reportingDataSrv: reportingDataSrv,
                            exHelpUtils: exHelpUtils,
                            upgradeLinesInfoService: upgradeLinesInfoService
                        });
                    });

                    $rootScope.$digest();
                });
                describe('Basic functionality', function () {
                    it('should provide cq translator key value to view', function () {
                        expect(scope.upgradeTradein.terms).toBeDefined();
                        expect(scope.upgradeTradein.terms).toEqual('Trade in consent: Trade in consent message');
                    });
                });
                describe('should check cta functionalities', function () {
                    it('should pass tradein consent details to expressTradein api', function () {
                        scope.agreeTradeinConsent();
                        expect(upgradeTradeinConsentSrv.tradeinConsentContinue.calls.mostRecent().args[0]).toBeDefined();
                        expect(upgradeTradeinConsentSrv.tradeinConsentContinue.calls.mostRecent()
                            .args[0]).toBeDefined();
                        expect(upgradeTradeinConsentSrv.tradeinConsentContinue.calls.mostRecent()
                            .args[0].tradeInTerms).toEqual('Trade in consent: Trade in consent message');
                        expect(upgradeTradeinConsentSrv.tradeinConsentContinue.calls.mostRecent()
                            .args[0].agreeToTradeInTerms).toEqual(scope.upgradeTradein.consentCheckbox);
                    });
                });

                describe('should check reporting functionalities', function () {

                    beforeEach(function () {
                        spyOn(scope, '$emit').and.callThrough();
                        scope.$emit.calls.reset();
                    });

                    it('should check that Trade in consent is selected', function () {
                        var expectedReportingObjectSubmit = jasmine.objectContaining({
                                eventAction: 'formSubmit',
                                eventCode: 'DS_Upgrade_Tradein_Submit',
                                additionaldata: {
                                    userResp: 'Trade In Consent Selected'
                                }
                            }),
                            expectedReportingObjectResponse = jasmine.objectContaining({
                                eventAction: 'formResponse',
                                eventCode: 'DS_Upgrade_Tradein_Submit',
                                additionaldata: {
                                    userResp: 'Trade In Consent Selected'
                                }
                            });
                        scope.upgradeTradein.consentCheckbox = true;
                        scope.agreeTradeinConsent();
                        expect(scope.$emit).toHaveBeenCalledWith('DS_Reporting_Event', expectedReportingObjectSubmit, jasmine.any(Object));
                        expect(scope.$emit).toHaveBeenCalledWith('DS_Reporting_Event', expectedReportingObjectResponse, jasmine.any(Object));
                        scope.$apply();
                    });
                });
            });
        });
    });
})();
