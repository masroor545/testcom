(function () {
    'use strict';

    /**
     * This controller retrieves the details of the devices the user has from the service
     *
     * __Requirements:__
     * * gets devices that the user has.
     * * gets message informing user whether their device is eligible for upgrade or not.
     *
     * @property {object} user - ???
     * @property {object} user.selectedLines - ???
     *
     * @todo Update this content to be complete and meaningful
     * @todo missing properties etc...
     * @todo function docs need updated
     * @todo other information etc...
     *
     * @module upgradeEligCtrl
     */
    angular.module('exUpgrade')

        .controller('upgradeEligCtrl', ['$scope', 'upgradeEligSrv', '$filter', 'profileInfoService', 'exUpgradeConstants', 'reportingDataSrv',
            'upgradingUserInfoSrv', 'exCommonConstants', '$window', '$modal', '$modalStack', 'imagePathService', 'upgradeLinesInfoService', 'exHelpUtils',
            '$cookies', 'exCartService',
            function ($scope, upgradeEligSrv, $filter, profileInfoService, exUpgradeConstants, reportingDataSrv,
                upgradingUserInfoSrv, exCommonConstants, $window, $modal, $modalStack, imagePathService, upgradeLinesInfoService, exHelpUtils,
                $cookies, exCartService) {

                $scope.user = {
                    selectedLines: {},
                    displayUpgradeEligMessage: true,
                    isMessageAvailable: true
                };
                $scope.updateLineSelection = updateLineSelection;
                $scope.upgradeLines = upgradeLines;
                $scope.disableUpgradeLineCta = disableUpgradeLineCta;
                $scope.user.showOptionModal = showModal;
                $scope.user.hideOptionModal = hideModal;
                $scope.user.updateTradeInSelection = updateTradeInSelection;
                $scope.showUpgradeEligMessage = showUpgradeEligMessage;
                $scope.eligibilityLineCheckboxState = eligibilityLineCheckboxState;
                $scope.continueButtonClicked = false;

                $scope.user.ModalData = {};
                $scope.user.isUpdateCTAEnabled = false;
                $scope.user.upgradedLinesInProgress = '';
                $scope.upgradeEligibilityNoImage = exCommonConstants.upgradeEligibilityNoImage;
                $scope.user.upgradeLinesInfoDetails = {
                    isMultiLineInProgress: false,
                    hideTradeInPayUpHeader: false
                };
                $scope.user.cartItemCounts = 0;
                var modalInstance;
                var shopSessionId = $cookies.get('SHOPSESSIONID');
                //Getting errorKey information that is returned when ISE error throws an error for contract tradein/payup device
                var errorKeyForContractDevice = $window.sessionStorage.getItem(exCommonConstants.contractDeviceErrorKey) || null;
                errorKeyForContractDevice = JSON.parse(errorKeyForContractDevice);
                activate();

                /**
                 * Controller startup logic
                 */
                function activate () {

                    var userFirstName = undefined;
                    //Clear upgrading line api cache
                    upgradingUserInfoSrv.clearUpgradingLineCache();
                    //Fetch user details
                    isMessageAvailabe($scope.informationMessage);
                    upgradeEligSrv.fetchUserDetails().then(function (data) {
                        profileInfoService.getProfileInfo().then(function (response) {

                            $scope.user.multiLineEnabledFlag =
                                response.ProfileInfo.multiLineUpgradeEnabled;
                            $scope.user.lines = getRequiredLines(data);

                            if (response.ProfileInfo && response.ProfileInfo.accountFirstName) {
                                userFirstName = response.ProfileInfo.accountFirstName;
                            }

                            //Upgrade eligibility page header message with account holder name.
                            if ($scope.user.lines.length > 1 &&
                                $scope.user.multiLineEnabledFlag === true &&
                                userFirstName) {
                                $scope.user.customerNameWithMsg = exHelpUtils.replacePlaceholdersWithContent(
                                    $scope.eligibilityMessages.accountHolderWhenMultipleLineIsTrue,
                                    [userFirstName]);
                            } else if ($scope.user.lines.length > 1 &&
                                $scope.user.multiLineEnabledFlag === false &&
                                userFirstName) {
                                $scope.user.customerNameWithMsg = exHelpUtils.replacePlaceholdersWithContent(
                                    $scope.eligibilityMessages.accountHolderforMultipleLine,
                                    [userFirstName]);
                            } else if (userFirstName) {
                                $scope.user.customerNameWithMsg = exHelpUtils.replacePlaceholdersWithContent(
                                    $scope.eligibilityMessages.accountHolderforSingleLine,
                                    [userFirstName]);
                            } else {
                                $scope.user.customerNameWithMsg = $scope.eligibilityMessages.accountHolderMessageWithoutFirstName;
                            }

                            /** reporting DS_System_Upgrade_Eligibility_Displayed event */
                            var eventPayload = reportingDataSrv.getUpgradeEligibilityExistingItemsPayload($scope.user);

                            $scope.$emit(exCommonConstants.event.DS_REPORTING_EVENT, {
                                eventAction: 'systemEvent',
                                eventCode: 'DS_System_Upgrade_Eligibility_Displayed',
                                additionaldata: eventPayload
                            }, $scope);

                            autoSubmitFullyEligible(response.ProfileInfo);
                        });
                    });
                }

                /**
                 * Gets details about each device
                 * @param {Array<Object>} data User account subscriber lines information
                 * @return {Array<Object>} device details, plan type and upgrade eligibility details
                 */
                function getRequiredLines (data) {
                    var lineDetails = [], lineDetail, singleLine, islineUpdateInProgress;
                    if (data.payload !== undefined && data.payload !== null) {
                        $scope.user.upgradedLinesInProgress = data.payload[exUpgradeConstants.upgradedLinesInProgress].toString();
                        $scope.user.cartItemCounts = data.payload[exUpgradeConstants.upgradedLinesInProgress].length;
                        Object.keys(data.payload).forEach(function (key) {
                            if (key !== exUpgradeConstants.upgradedLinesInProgress) {
                                singleLine = data.payload[key];
                                singleLine.forEach(function (line) {
                                    islineUpdateInProgress = ($scope.user.upgradedLinesInProgress.indexOf(
                                        line.subscriberNumber) >= 0) ? true : false;
                                    lineDetail = {
                                        customerFirstName: line.customerFirstName,
                                        device: {
                                            color: line.device.color,
                                            make: line.device.make,
                                            manufacturerForImage: line.device.manufacturerForImage,
                                            model: line.device.model,
                                            skuId: line.device.skuId,
                                            modelForImage: line.device.modelForImage,
                                            size: line.device.size,
                                            shortDisplayName: line.device.shortDisplayName
                                        },
                                        deviceURL: deviceImageUrl(line),
                                        eligibilityInfo: line.eligibilityInfo,
                                        enableLine: ($scope.user.upgradedLinesInProgress === '' || $scope.user.multiLineEnabledFlag === false) ? false : !islineUpdateInProgress,
                                        isLineSelected: $scope.user.multiLineEnabledFlag ? islineUpdateInProgress : false,
                                        islineUpdateInProgress: islineUpdateInProgress,
                                        groupId: line.groupId,
                                        noCommitUpgradeEligible: line.noCommitUpgradeEligible,
                                        planChangeRequired: line.planChangeRequired,
                                        planTypeGroupId: key,
                                        subscriberNumber: line.subscriberNumber,
                                        tradeInOptions: filterTradeinOption(line),
                                        upgradeLinePlanType: line.upgradeLinePlanType,
                                        customerDetailWithDevice: updateHeaderDetails(line),
                                        contractType: updateContractType(line),
                                        contractTypeWithoutDate: line.contractType,
                                        contractLength: line.term
                                    };

                                    // Set tool tip message for ineligibile and disabled lines
                                    setToolTipMessage(lineDetail);
                                    lineDetails.push(lineDetail);
                                });
                            }
                        });

                        return lineDetails;
                    }
                }

                /**
                 * Gets the device image from imagePathService.
                 * @param {Object} line A subscriber line
                 * @return {string} catalog image url
                 */
                function deviceImageUrl (line) {
                    return imagePathService.getCatalogImagePath(exCommonConstants.deviceCatalogUrlRoot,
                        line.device.manufacturerForImage, line.device.modelForImage,
                        line.device.color, exUpgradeConstants.imageUrlExtension).toLowerCase();
                }

                /**
                 * Gets the trade-in options with price, message,
                 * and displays value to show upgrade options link
                 * @param {Object} line A subscriber line
                 * @return {Object} Price options to Upgrade device
                 */
                function filterTradeinOption (line) {
                    var priceOption = {};

                    // checking line is eligible for pay up
                    var isPayUpEligible = line.eligibilityInfo.payUpAmount > 0;

                    // checking line is eligible for pay off
                    var isPayOffEligible = line.eligibilityInfo.payOffAmount > 0;

                    // checking line is eligible for upgrade
                    var isUpgradeEligible = (line.eligibilityInfo.eligibility === 'ELIGIBLE' ||
                        line.eligibilityInfo.eligibility === 'DISCOUNT_ELIGIBLE' ||
                        line.eligibilityInfo.eligibility === 'TABLET_INSTALLMENT_ELIGIBLE' ||
                        line.eligibilityInfo.eligibility === 'ATT_NEXT_ELIGIBLE' ||
                        line.eligibilityInfo.eligibility === 'INSTALLMENT_ELIGIBLE' ||
                        line.eligibilityInfo.earlyUpgrade) &&
                        (line.eligibilityInfo.payUpAmount === 0 &&
                            line.eligibilityInfo.payOffAmount === 0);

                    // checking line is ineligible
                    var isUpgradeIneligible = line.planChangeRequired === true ||
                        line.IRUSplitLiability === true;

                    // checking line is eligible for buy at full price
                    var isBuyAtFullPrice = isUpgradeIneligible === false &&
                        line.noCommitUpgradeEligible === true;

                    //Checking for in-eligible line first, do not change the execution sequence as execution order of logic
                    //is important and part of the business rules.
                    if (line !== undefined) {
                        if (isUpgradeIneligible === true) {
                            priceOption = {
                                disableTile: true,
                                displayUpgradeOptionLink: false,
                                eligibleFlag: '',
                                message: line.IRUSplitLiability === true ?
                                    $scope.eligibilityMessages.upgradeMessages.splitLiability : '',
                                showInfoIcon: line.IRUSplitLiability === true ? false : true,
                                tradeInEligible: line.eligibilityInfo.tradeInEligible
                            };
                        } else if (isPayUpEligible === true) {
                            priceOption = {
                                disableTile: false,
                                displayUpgradeOptionLink: true,
                                eligibleFlag: exUpgradeConstants.eligibleFlag.payUp,
                                message: exHelpUtils.replacePlaceholdersWithContent(
                                    $scope.eligibilityMessages.upgradeMessages.tradeInUp,
                                    [$filter('currency')(line.eligibilityInfo.payUpAmount)]),
                                showInfoIcon: false,
                                tradeInEligible: line.eligibilityInfo.tradeInEligible
                            };
                        } else if (line.eligibilityInfo.tradeInEligible === true) {
                            priceOption = {
                                disableTile: false,
                                displayUpgradeOptionLink: true,
                                eligibleFlag: exUpgradeConstants.eligibleFlag.tradeIn,
                                message: $scope.eligibilityMessages.upgradeMessages.tradeIn,
                                showInfoIcon: false,
                                tradeInEligible: line.eligibilityInfo.tradeInEligible
                            };
                        } else if (isPayOffEligible === true) {
                            priceOption = {
                                disableTile: false,
                                displayUpgradeOptionLink: true,
                                eligibleFlag: exUpgradeConstants.eligibleFlag.payOff,
                                message: exHelpUtils.replacePlaceholdersWithContent(
                                    $scope.eligibilityMessages.upgradeMessages.tradeInOff,
                                    [$filter('currency')(line.eligibilityInfo.payOffAmount)]),
                                showInfoIcon: false,
                                tradeInEligible: line.eligibilityInfo.tradeInEligible
                            };
                        } else if (isUpgradeEligible === true) {
                            priceOption = {
                                disableTile: false,
                                displayUpgradeOptionLink: false,
                                eligibleFlag: exUpgradeConstants.eligibleFlag.none,
                                message: $scope.eligibilityMessages.upgradeMessages.fullEligible,
                                showInfoIcon: false,
                                tradeInEligible: line.eligibilityInfo.tradeInEligible
                            };
                        } else if (isBuyAtFullPrice === true) {
                            priceOption = {
                                disableTile: false,
                                displayUpgradeOptionLink: false,
                                eligibleFlag: exUpgradeConstants.eligibleFlag.replace,
                                message: $scope.eligibilityMessages.upgradeMessages.buyAtFullPrice,
                                showInfoIcon: false,
                                tradeInEligible: line.eligibilityInfo.tradeInEligible
                            };
                        } else if (line.noCommitUpgradeEligible === false) {
                            priceOption = {
                                disableTile: true,
                                displayUpgradeOptionLink: false,
                                eligibleFlag: '',
                                message: line.IRUSplitLiability === true ?
                                    $scope.eligibilityMessages.upgradeMessages.splitLiability : '',
                                showInfoIcon: line.IRUSplitLiability === true ? false : true,
                                tradeInEligible: line.eligibilityInfo.tradeInEligible
                            };
                        }
                        return priceOption;
                    }
                }

                /**
                 * Enables the selected line and disables the other lines.
                 * @function updateLineSelection
                 * @param {Object} lineObject Subscriber line
                 */
                function updateLineSelection (lineObject) {
                    if ($scope.user.cartItemCounts > 0 &&
                        $scope.user.multiLineEnabledFlag === true) {
                        lineObject.isLineSelected = true;
                    } else {
                        if (lineObject.isLineSelected === false) {
                            delete $scope.user.selectedLines[lineObject.subscriberNumber];
                        }

                        $scope.user.lines.forEach(function (line) {
                            if (Object.keys($scope.user.selectedLines).length === 0) {
                                var multiFlagDisabledAndDiffSubscriberNumber =
                                    ($scope.user.multiLineEnabledFlag === false &&
                                    lineObject.subscriberNumber !== line.subscriberNumber);

                                var diffPlanIdAndNoSelectedLines =
                                    (lineObject.planTypeGroupId !== line.planTypeGroupId &&
                                    Object.keys($scope.user.selectedLines).length === 0);

                                var islineObjectFullEligible = (lineObject.tradeInOptions.eligibleFlag ===
                                    exUpgradeConstants.eligibleFlag.none) ? true : false;

                                var islineFullyEligible = (line.tradeInOptions.eligibleFlag ===
                                    exUpgradeConstants.eligibleFlag.none) ? true : false;

                                var diffPlanIdAndDiffSubscriberNumberAndTradeInEligible =
                                    (lineObject.planTypeGroupId === line.planTypeGroupId &&
                                    lineObject.subscriberNumber !== line.subscriberNumber &&
                                    !(islineFullyEligible === true && islineObjectFullEligible === true));

                                if (multiFlagDisabledAndDiffSubscriberNumber ||
                                    diffPlanIdAndNoSelectedLines ||
                                    diffPlanIdAndDiffSubscriberNumberAndTradeInEligible) {
                                    line.enableLine = !line.enableLine;
                                }

                                // Set tool tip eligibility message for ineligibile and disabled lines.
                                setToolTipMessage(line);
                            }
                        });
                        if (lineObject.isLineSelected === true) {
                            $scope.user.selectedLines[lineObject.subscriberNumber] =
                                lineObject;
                        }
                    }
                }

                /**
                 * Fires the Trade In Ineligible event
                 * @param {Object} eventPayload event payload from upgrade selected Lines
                 * @param {Object} data data response from upgrade selected Lines
                 */
                function reportTradeinIneligible (eventPayload, data) {
                    var eventPayloadIneligible = reportingDataSrv.getTradeinIneligibleEventPayload(eventPayload, data);

                    $scope.$emit(exCommonConstants.event.DS_REPORTING_EVENT, {
                        eventAction: 'systemEvent',
                        eventCode: 'DS_System_Upgrade_Tradein_Ineligible_Displayed',
                        additionaldata: eventPayloadIneligible
                    }, $scope);
                }

                /**
                 * Pass input parameters to expressUpgrade post service.
                 */
                function updateSelectedLinesData () {
                    $scope.user.isUpdateCTAEnabled = true;
                    if (validateSelectedLines() === true) {
                        /**
                         * If user selected more than one line then set multi line flag true in session,
                         * we will use this flag to execute get profile service on accessory recommender page.
                         */
                        if (Object.keys($scope.user.selectedLines).length > 1) {
                            $scope.user.upgradeLinesInfoDetails.isMultiLineInProgress = true;
                        }

                        var serviceInput = {
                            upgradingLineCount: Object.keys($scope.user.selectedLines).length,
                            selectedUpgradeLines: {
                                'atg-rest-class-type': exUpgradeConstants.classType,
                                'atg-rest-values': selectedLineData()
                            }
                        };

                        var eventPayload = reportingDataSrv.getUpgradeSubmitPayload($scope),
                            eventCode = reportingDataSrv.getUpgradeSubmitEvent($scope);

                        $scope.$emit(exCommonConstants.event.DS_REPORTING_EVENT, {
                            eventAction: 'formSubmit',
                            eventCode: eventCode,
                            additionaldata: eventPayload
                        }, $scope);

                        /**
                         * If user selected network/ contract tradein/payup, hide gloabl header  and set network details in session,
                         * we will use this flag to hide tradein consent page gloabl blue header and show network  device details on tradein consent page
                         */
                        var tradeInPayUpFlow =
                            ($scope.selectedDataValue.tradeInOptions.eligibleFlag === exUpgradeConstants.eligibleFlag.payUp ||
                            $scope.selectedDataValue.tradeInOptions.eligibleFlag === exUpgradeConstants.eligibleFlag.tradeIn ||
                            $scope.selectedDataValue.tradeInOptions.eligibleFlag === exUpgradeConstants.eligibleFlag.payUpContract ||
                            $scope.selectedDataValue.tradeInOptions.eligibleFlag === exUpgradeConstants.eligibleFlag.tradeInContract);
                        if (tradeInPayUpFlow === true) {
                            $scope.user.upgradeLinesInfoDetails.hideTradeInPayUpHeader = true;
                            $scope.user.upgradeLinesInfoDetails.networkDeviceDetails = {
                                networkDeviceName: $scope.selectedDataValue.device.shortDisplayName ? $scope.selectedDataValue.device.shortDisplayName : '',
                                networkDeviceCapicity: $scope.selectedDataValue.device.size ? '(' + $scope.selectedDataValue.device.size + ')' : ''
                            };
                        }

                        upgradeLinesInfoService.setUpgradeLinesInfo($scope.user.upgradeLinesInfoDetails);

                        //remove item from cart if persistent cart item count is equal to 1
                        var isRemoveCartItem = $scope.user.cartItemCounts === 1 ? true : false;
                        var errorKey = (Object.keys($scope.user.selectedLines)[0] + shopSessionId);
                        exCartService.removeItemFromPersistentCart(isRemoveCartItem).then(function () {
                            upgradeEligSrv.upgradeSelectedLines(serviceInput).then(function (data) {

                                if (data.response !== undefined && data.response !== null
                                && data.response.status === exUpgradeConstants.errorStatus) {
                                    if (data.response.errors[0].field === exUpgradeConstants.errorStatusCode.isISEFailed) {
                                        // Creating the errorKey info obejct so we can save it in session storage to check for if user ever navigates back
                                        var contractDeviceErrorKey = {};
                                        contractDeviceErrorKey.errorKeyValue = errorKey;
                                        contractDeviceErrorKey.errorData = data;
                                        $window.sessionStorage.setItem(exCommonConstants.contractDeviceErrorKey, JSON.stringify(contractDeviceErrorKey));
                                        displayTradinContractOption(data);
                                        reportTradeinIneligible(eventPayload, data);
                                    } else if (exUpgradeConstants.tradeInPayUpErrorCodes[data.response.errors[0].field]) {
                                        // Adding safety check in case line is a contract device and backend by mistake throws an error when you navigate back to the page
                                        // Checking if the error key information is in session storage actually matches the subscriber number and session id
                                        if (errorKeyForContractDevice &&
                                            (Object.keys($scope.user.selectedLines)[0] + shopSessionId).indexOf(errorKeyForContractDevice.errorKeyValue) !== -1) {
                                            displayTradinContractOption(errorKeyForContractDevice.errorData);
                                        } else {
                                            disableTradeInPayUpOption(data.optionsBean.selectedSubscriber,
                                                exUpgradeConstants.eligibleFlag.payOff);
                                        }

                                        reportTradeinIneligible(eventPayload, data);
                                    }
                                    eventPayload = reportingDataSrv.updateEventPayloadFailure(eventPayload, data);
                                } else {
                                    var top = $modalStack.getTop();
                                    if (top) {
                                        $modalStack.close(top.key);
                                    }
                                }

                                $scope.$emit(exCommonConstants.event.DS_REPORTING_EVENT, {
                                    eventAction: 'formResponse',
                                    eventCode: eventCode,
                                    additionaldata: eventPayload
                                }, $scope);

                            });
                        });

                    }
                }

                /**
                 *  If any upgradeing line is in progress then redirect it to cart summary page.
                 *  @function upgradeLines
                 *  @todo needs updated
                 */
                function upgradeLines () {
                    $scope.continueButtonClicked = true;
                    var firstSelectedLine = getFirstSelectedLine();
                    var isRedirect = ($scope.user.upgradedLinesInProgress !== '' &&
                        $scope.user.multiLineEnabledFlag) || (firstSelectedLine &&
                        firstSelectedLine.islineUpdateInProgress);

                    if (isRedirect) {
                        $window.location.href = exCommonConstants.cartSummaryPageUrl;
                    } else {
                        updateSelectedLinesData();
                    }
                }

                /**
                 * Create array of input parameters
                 * @return {Array} linesData SubscriberNumber, eligibleFlag
                 */
                function selectedLineData () {
                    var linesData = [];
                    angular.forEach($scope.user.selectedLines, function (
                        SubscriberDetails, SubscriberNumber) {
                        linesData.push({
                            subscriberNumber: SubscriberNumber,
                            selectedUpgradeOption: SubscriberDetails.tradeInOptions.eligibleFlag,
                            'atg-rest-class-type': exUpgradeConstants.UpgradeSelectionInfo
                        });
                        $scope.selectedDataValue = SubscriberDetails;
                    });

                    return linesData;
                }

                /**
                 * Validate Selected Lines data before CTA click.
                 * @return {Boolean} based on multiLineEnabledFlag and selectedLines
                 */
                function validateSelectedLines () {
                    var multiFlagDisabledAndMoreThanOneSelectedLine =
                        ($scope.user.multiLineEnabledFlag === false &&
                            Object.keys($scope.user.selectedLines).length > 1);

                    if (!$scope.user.selectedLines ||
                        Object.keys($scope.user.selectedLines).length === 0 ||
                        multiFlagDisabledAndMoreThanOneSelectedLine) {
                        $scope.user.isUpdateCTAEnabled = false;
                        return false;
                    }
                    return true;
                }

                /**
                 * Disable the CTA on page load and enable it on line selection.
                 * @return {Boolean} based on number of selectedLines
                 */
                function disableUpgradeLineCta () {
                    if ($scope.user.cartItemCounts > 0 &&
                        $scope.user.multiLineEnabledFlag) {
                        return false;
                    } else if ((Object.keys($scope.user.selectedLines).length > 0) &&
                        $scope.user.isUpdateCTAEnabled === false) {
                        return false;
                    } else {
                        return true;
                    }
                }

                /**
                 * Opens the option modal.
                 * @param {Object} lineObject Subscriber line
                 * @param {Boolean} tradeInIneligibleModal whether or not this is the Trade in Ineligible Modal
                 */
                function showModal (lineObject, tradeInIneligibleModal) {

                    //Check if option modal is already opened if not then open the modal
                    if (!modalInstance) {
                        modalInstance = $modal.open({
                            templateUrl: exUpgradeConstants.upgradeOptionsModalPath,
                            windowClass: 'modal-fullscreen',
                            scope: $scope
                        });
                    }

                    // Promise resolves when the modal close functionality is triggered.
                    if (modalInstance !== undefined && modalInstance.result !== undefined) {
                        modalInstance.result.then(function () {
                        }, function () {
                            hideModal();
                            modalInstance = undefined;
                        });
                    }
                    if (lineObject.optionPageSelection === undefined) {
                        setOptionPageData(lineObject);
                    }

                    lineObject.isLineAlreadySelected = lineObject.isLineSelected;
                    $scope.user.modalData = lineObject;
                    $scope.user.modalData.isLineOptionClicked = false;
                    if (lineObject.isLineSelected === false) {
                        lineObject.isLineSelected = true;
                        updateLineSelection(lineObject);
                    }

                    // Checking if the error key information is in session storage actually matches the subscriber number and session id
                    if (errorKeyForContractDevice &&
                        (Object.keys($scope.user.selectedLines)[0] + shopSessionId).indexOf(errorKeyForContractDevice.errorKeyValue) !== -1 &&
                            $scope.continueButtonClicked === false) {
                        // if so then disable the trade in and pay up radio button
                        displayTradinContractOption(errorKeyForContractDevice.errorData);
                    }

                    if (!tradeInIneligibleModal) {
                        var eventPayload = reportingDataSrv.getUpgradeEligibilityExistingItemsPayload($scope.user);
                        $scope.$emit(exCommonConstants.event.DS_REPORTING_EVENT, {
                            eventAction: 'systemEvent',
                            eventCode: 'DS_System_Upgrade_Options_Displayed',
                            additionaldata: eventPayload
                        }, $scope);
                    }

                    $scope.$emit(exCommonConstants.event.DS_REPORTING_PAGELOAD_EVENT);
                }
                /**
                 * Disable Trade in option radio button on tradein option page and select another available option.
                 * @function disableTradeInPayUpOption
                 * @param {Object} selectedSubscriber - Subscriber number
                 * @param {String} selectNextEligibileOption - Select next eligibile flag option.
                 */
                function disableTradeInPayUpOption (selectedSubscriber, selectNextEligibileOption) {
                    // Checking if the error key information is in session storage actually matches the subscriber number and session id
                    if ($scope.continueButtonClicked === true) {
                        // if it is not then reload the modal
                        showModal($scope.user.selectedLines[selectedSubscriber], true);
                    }
                    angular.forEach($scope.user.selectedLines[selectedSubscriber].optionPageSelection, function (tradeInOptionDetail) {
                        // Checking if the error key information is in session storage actually matches the subscriber number and session id
                        if (errorKeyForContractDevice &&
                            (Object.keys($scope.user.selectedLines)[0] + shopSessionId).indexOf(errorKeyForContractDevice.errorKeyValue) !== -1) {
                            // if so then check if there is a trade in or pay up radio button, if so disable it since contract device doesn't allow it.
                            if (exUpgradeConstants.eligibleFlag.tradeIn === tradeInOptionDetail.eligibleFlag) {
                                tradeInOptionDetail.isDisabled = true;
                                tradeInOptionDetail.eligibleFlagMsg = $scope.upgradeOptionsMessages.tradeInIneligible;
                                $scope.user.isUpdateCTAEnabled = false;
                            } else if (exUpgradeConstants.eligibleFlag.payUp === tradeInOptionDetail.eligibleFlag) {
                                tradeInOptionDetail.isDisabled = true;
                                $scope.user.isUpdateCTAEnabled = false;
                                $scope.user.selectedLines[selectedSubscriber]
                                .tradeInOptions.priceToUpgrade = tradeInOptionDetail.priceToUpgrade;
                                $scope.user.selectedLines[selectedSubscriber]
                                .tradeInOptions.message = tradeInOptionDetail.message;
                            }
                        } else {
                            if ($scope.user.selectedLines[selectedSubscriber]
                                .tradeInOptions.eligibleFlag === tradeInOptionDetail.eligibleFlag) {
                                tradeInOptionDetail.isDisabled = true;
                                tradeInOptionDetail.eligibleFlagMsg = $scope.upgradeOptionsMessages.tradeInIneligible;
                                $scope.user.isUpdateCTAEnabled = false;
                            }
                            if (selectNextEligibileOption === tradeInOptionDetail.eligibleFlag) {
                                $scope.user.selectedLines[selectedSubscriber]
                                .tradeInOptions.eligibleFlag = tradeInOptionDetail.eligibleFlag;
                                $scope.user.selectedLines[selectedSubscriber]
                                .tradeInOptions.priceToUpgrade = tradeInOptionDetail.priceToUpgrade;
                                $scope.user.selectedLines[selectedSubscriber]
                                .tradeInOptions.message = tradeInOptionDetail.message;
                            }
                        }
                    });
                }

                /**
                 * Close the option modal.
                 */
                function hideModal () {
                    if ($scope.user.modalData.isLineOptionClicked === false &&
                        $scope.user.modalData.isLineAlreadySelected === false) {
                        delete $scope.user.selectedLines[$scope.user.modalData.subscriberNumber];
                        $scope.user.modalData.isLineSelected = false;
                        updateLineSelection($scope.user.modalData);
                    }

                    $scope.$emit(exCommonConstants.event.DS_REPORTING_PAGELOAD_EVENT,
                        exUpgradeConstants.friendlyPageName.upgradeEligibility,
                        exUpgradeConstants.virtualUrl.upgradeEligibility);

                    var eventPayload = reportingDataSrv.getUpgradeEligibilityExistingItemsPayload($scope.user);

                    $scope.$emit(exCommonConstants.event.DS_REPORTING_EVENT, {
                        eventAction: 'systemEvent',
                        eventCode: 'DS_System_Upgrade_Eligibility_Displayed',
                        additionaldata: eventPayload
                    }, $scope);
                }

                /**
                 * set option modal page data .
                 * @param {Object} lineObject Subscriber line
                 */
                function setOptionPageData (lineObject) {
                    var priceOption = {};
                    var selectedLineOptions = {};
                    //Do not change below this sequence. Discuss with business team before making change in sequence
                    if (lineObject !== undefined) {
                        if (lineObject.tradeInOptions.eligibleFlag === exUpgradeConstants.eligibleFlag.none) {
                            priceOption = {
                                upgradeMessageWithPrice: $scope.eligibilityMessages.upgradeMessages.fullEligible,
                                eligibleFlag: exUpgradeConstants.eligibleFlag.none,
                                eligibleFlagMsg: $scope.upgradeOptionsMessages.upgradeDevice,
                                isDisplay: false,
                                message: $scope.eligibilityMessages.upgradeMessages.fullEligible
                            };
                            selectedLineOptions[exUpgradeConstants.eligibleFlag.none] = priceOption;
                        } else {
                            if (lineObject.eligibilityInfo.payUpAmount > 0) {
                                priceOption = {
                                    upgradeMessageWithPrice: exHelpUtils.replacePlaceholdersWithContent(
                                    $scope.upgradeOptionsMessages.tradeInEarly,
                                    [$filter('currency')(lineObject.eligibilityInfo.payUpAmount)]),

                                    eligibleFlag: exUpgradeConstants.eligibleFlag.payUp,
                                    eligibleFlagMsg: $scope.upgradeOptionsMessages.tradeInWithPrice,
                                    isDisplay: true,
                                    message: exHelpUtils.replacePlaceholdersWithContent(
                                    $scope.eligibilityMessages.upgradeMessages.tradeInUp,
                                    [$filter('currency')(lineObject.eligibilityInfo.payUpAmount)])
                                };
                                selectedLineOptions[exUpgradeConstants.eligibleFlag.payUp] = priceOption;
                            }
                            if (lineObject.eligibilityInfo.tradeInEligible === true) {
                                priceOption = {
                                    upgradeMessageWithPrice: $scope.upgradeOptionsMessages.tradeIn,
                                    eligibleFlag: exUpgradeConstants.eligibleFlag.tradeIn,
                                    eligibleFlagMsg: $scope.upgradeOptionsMessages.tradeInCurrent,
                                    isDisplay: true,
                                    message: $scope.eligibilityMessages.upgradeMessages.tradeIn
                                };
                                selectedLineOptions[exUpgradeConstants.eligibleFlag.tradeIn] = priceOption;
                            }
                            if (lineObject.eligibilityInfo.payOffAmount > 0) {
                                priceOption = {
                                    upgradeMessageWithPrice: exHelpUtils.replacePlaceholdersWithContent(
                                    $scope.upgradeOptionsMessages.payOff,
                                    [$filter('currency')(lineObject.eligibilityInfo.payOffAmount)]),

                                    eligibleFlag: exUpgradeConstants.eligibleFlag.payOff,
                                    eligibleFlagMsg: $scope.upgradeOptionsMessages.payOffWithPrice,
                                    isDisplay: true,
                                    message: exHelpUtils.replacePlaceholdersWithContent(
                                    $scope.eligibilityMessages.upgradeMessages.tradeInOff,
                                    [$filter('currency')(lineObject.eligibilityInfo.payOffAmount)])
                                };
                                selectedLineOptions[exUpgradeConstants.eligibleFlag.payOff] = priceOption;
                            }
                            if (lineObject.tradeInOptions.eligibleFlag === exUpgradeConstants.eligibleFlag.none) {
                                priceOption = {
                                    upgradeMessageWithPrice: $scope.eligibilityMessages.upgradeMessages.fullEligible,
                                    eligibleFlag: exUpgradeConstants.eligibleFlag.none,
                                    eligibleFlagMsg: $scope.upgradeOptionsMessages.upgradeDevice,
                                    isDisplay: false,
                                    message: $scope.eligibilityMessages.upgradeMessages.fullEligible
                                };
                                selectedLineOptions[exUpgradeConstants.eligibleFlag.none] = priceOption;
                            }
                        }
                        priceOption = {
                            upgradeMessageWithPrice: $scope.upgradeOptionsMessages.buyAtFullPrice,
                            eligibleFlag: exUpgradeConstants.eligibleFlag.replace,
                            eligibleFlagMsg: $scope.upgradeOptionsMessages.replaceYourDevice,
                            isDisplay: true,
                            message: $scope.eligibilityMessages.upgradeMessages.buyAtFullPrice
                        };
                        selectedLineOptions[exUpgradeConstants.eligibleFlag.replace] = priceOption;
                        lineObject.optionPageSelection = selectedLineOptions;
                    }
                }

                /**
                 * Update tradeIn option selection.
                 * @param {Object} lineObject Subscriber line
                 * @param {Object} lineOptionObject Selected Tradein option of a Subscriber line
                 */
                function updateTradeInSelection (lineObject, lineOptionObject) {
                    lineObject.tradeInOptions.eligibleFlag = lineOptionObject.eligibleFlag;
                    lineObject.tradeInOptions.message = lineOptionObject.message;
                    $scope.user.modalData.isLineOptionClicked = true;
                    if (lineObject.isLineSelected === false) {
                        lineObject.isLineSelected = true;
                        updateLineSelection(lineObject);
                    }

                }
                /**
                 * Set customer name with device modal and with CTN based on condition
                 * @param {Object} lineInfo Subscriber line
                 *
                 */
                function updateHeaderDetails (lineInfo) {
                    var customerDetailWithDevice = {};

                    customerDetailWithDevice.customerNameWithDevice = lineInfo.customerFirstName ?
                        lineInfo.customerFirstName + $scope.commonApostrophes : '';
                    customerDetailWithDevice.customerNameWithDevice = customerDetailWithDevice.customerNameWithDevice ?
                        customerDetailWithDevice.customerNameWithDevice + ' ' + upgradingUserInfoSrv.getDeviceType(lineInfo.device.deviceType) : '';

                    // Determing the device name by first checking if the device is in the att catalog by checking if shortDisplayName exists
                    // if it doesn't exist then we go with the next best option of getting the device make and model and use that to show the name
                    customerDetailWithDevice.customerCTNWithDevice = '';
                    if (lineInfo.device.shortDisplayName) {
                        customerDetailWithDevice.customerCTNWithDevice = lineInfo.device.shortDisplayName + ' ' + $scope.commonSeparator;
                    } else if (lineInfo.device.model && lineInfo.device.make) {
                        customerDetailWithDevice.customerCTNWithDevice = lineInfo.device.make + ' ' + lineInfo.device.model + ' ' + $scope.commonSeparator;
                    }
                    customerDetailWithDevice.customerCTNWithDevice = customerDetailWithDevice.customerCTNWithDevice + ' ' + $filter('tel')(lineInfo.subscriberNumber);

                    return customerDetailWithDevice;
                }

                /**
                * select and submit fully eligible CTN from upgrade handoff from service side.
                * @param {Object} user profile object.
                */
                function autoSubmitFullyEligible (profileInfo) {
                    if (profileInfo !== undefined && profileInfo !== null &&
                        profileInfo.selectedCTNforUpgrade !== undefined && profileInfo.selectedCTNforUpgrade !== null) {
                        var selectedCTNs = profileInfo.selectedCTNforUpgrade.split(',');
                        // will remove selectedCTNs.length === 1 check in 1708
                        if (selectedCTNs !== undefined && selectedCTNs.length > 0 && selectedCTNs.length === 1) {
                            var autoSelectedCTN = {
                                subscriberNumber: '',
                                tradeInOptions: {
                                    eligibleFlag: exUpgradeConstants.eligibleFlag.none
                                }
                            };
                            if (selectedCTNs.length > 1) {
                                profileInfo.multiLineEnabledFlag = true;
                            }
                            autoSelectedCTN.subscriberNumber = selectedCTNs[0];
                            $scope.user.selectedLines[selectedCTNs[0]] = autoSelectedCTN;
                            upgradeLines();
                        }
                    }
                }

                /**
                * Set subscriber line contract type dynamically with date based on condition
                * @param {Object} lineInfo Subscriber line
                * returns {string} contractTypeWithDate- A string that contains contract type of subscriber line with date
                */
                function updateContractType (lineInfo) {
                    var contractTypeWithDate = {};
                    if (lineInfo.contractType === 'regular' && lineInfo.term === 24) {
                        contractTypeWithDate = exHelpUtils.replacePlaceholdersWithContent(
                            $scope.upgradeOptionsMessages.twoYearContract,
                            (lineInfo.contractEndDate !== null && lineInfo.contractEndDate.time !== null) ?
                                [$filter('date')(lineInfo.contractEndDate.time, 'MMM. d, yyyy')] : '');
                    } else {
                        contractTypeWithDate = exHelpUtils.replacePlaceholdersWithContent(
                            $scope.upgradeOptionsMessages.monthInstallment,
                            (lineInfo.contractEndDate !== null && lineInfo.contractEndDate.time !== null) ?
                                [lineInfo.term, $filter('date')(lineInfo.contractEndDate.time, 'MMM. d, yyyy')] : '');
                    }
                    return contractTypeWithDate;
                }

                /**
                 * Function used to show or hide the upgrade eligibility alert message section
                 * @param {boolean} visible
                 */
                function showUpgradeEligMessage (visible) {
                    $scope.user.displayUpgradeEligMessage = visible;
                }

                /**
                 * Function used to check alert message description is available or not
                 * @param {String} message
                 */
                function isMessageAvailabe (message) {
                    if (message) {
                        $scope.user.isMessageAvailable = true;
                    } else {
                        $scope.user.isMessageAvailable = false;
                    }
                }

                /**
                 * Set tool tip message for ineligibile and disabled lines.
                 * @param {Object} lineObject - Subscriber line
                 */
                function setToolTipMessage (lineObject) {
                    var toolTipMessage = {};
                    if (lineObject.tradeInOptions.disableTile === true) {
                        toolTipMessage.lineDisableMessage = $scope.eligibilityMessages.ineligibleErrorMsg;
                        toolTipMessage.position = 'ineligibleMsg';
                    } else if (lineObject.enableLine === true &&
                        lineObject.tradeInOptions.disableTile === false &&
                        $scope.user.multiLineEnabledFlag === false) {
                        toolTipMessage.lineDisableMessage = $scope.eligibilityMessages.singleLineDisableErrorMsg;
                        toolTipMessage.position = 'singleLineDisableMsg';
                    } else if (lineObject.enableLine === true &&
                        lineObject.tradeInOptions.disableTile === false &&
                        $scope.user.multiLineEnabledFlag === true) {
                        toolTipMessage.lineDisableMessage = $scope.eligibilityMessages.multiLineDisableErrorMsg;
                        toolTipMessage.position = '';
                    }
                    lineObject.toolTipMessage = toolTipMessage;
                }

                /**
                 * Function used to enable or disable checkbox of upgrade elibility tile.
                 * @param {Object} line - A subscriber line
                 * @returns {Boolean} based on selection and disableTile flag.
                 */
                function eligibilityLineCheckboxState (line) {
                    return (line.enableLine ||
                        line.tradeInOptions.disableTile) === true ? true : false;
                }

                /**
                 * Function used to display new contract device tradeIn or payUp option when ISE call fail and both IREDD, IREDG calls success.
                 * @param {Object} failureResponseData - A failure response from API
                 */

                function displayTradinContractOption (failureResponseData) {
                    disableTradeInPayUpOption(failureResponseData.optionsBean.selectedSubscriber, exUpgradeConstants.eligibleFlag.payOff);
                    setNewDeviceContractOption(failureResponseData.optionsBean);
                }

                /**
                 * Function used to set new contract device tradeIn or payUp option
                 * @param {Object} responseData - A failure response from API
                 */
                function setNewDeviceContractOption (responseData) {

                    var contractDeviceCapacity = responseData.skuSize ? '(' + responseData.skuSize + ')' : ' ',
                        contractDeviceName = '',
                        tradeInPayUpOption = {},
                        tradeInPayUpOptions = {},
                        selectedOption = '';

                    contractDeviceName = $scope.user.selectedLines[responseData.selectedSubscriber].customerDetailWithDevice.customerCTNWithDevice.split('| ')[0];
                    $scope.user.selectedLines[responseData.selectedSubscriber].customerDetailWithDevice.customerCTNWithDevice = $scope.user.selectedLines[responseData.selectedSubscriber].customerDetailWithDevice.customerCTNWithDevice.replace(contractDeviceName, responseData.shortDisplayName + ' ');

                    if ($scope.user.selectedLines[responseData.selectedSubscriber].optionPageSelection[exUpgradeConstants.eligibleFlag.tradeIn]) {
                        tradeInPayUpOption = {
                            upgradeMessageWithPrice: exHelpUtils.replacePlaceholdersWithContent($scope.upgradeOptionsMessages.tradInContract, [responseData.shortDisplayName, contractDeviceCapacity]),
                            eligibleFlag: exUpgradeConstants.eligibleFlag.tradeInContract,
                            eligibleFlagMsg: $scope.upgradeOptionsMessages.tradInContractDetails,
                            message: exHelpUtils.replacePlaceholdersWithContent($scope.upgradeOptionsMessages.tradInContract, [responseData.shortDisplayName, contractDeviceCapacity]),
                            isDisplay: true
                        };
                        selectedOption = exUpgradeConstants.eligibleFlag.tradeIn;
                    } else if ($scope.user.selectedLines[responseData.selectedSubscriber].optionPageSelection[exUpgradeConstants.eligibleFlag.payUp]) {
                        tradeInPayUpOption = {
                            upgradeMessageWithPrice: exHelpUtils.replacePlaceholdersWithContent($scope.upgradeOptionsMessages.payUpContract, [$filter('currency')(responseData.payUpAmount), responseData.shortDisplayName, contractDeviceCapacity]),
                            eligibleFlag: exUpgradeConstants.eligibleFlag.payUpContract,
                            eligibleFlagMsg: $scope.upgradeOptionsMessages.payUpContractDetails,
                            message: exHelpUtils.replacePlaceholdersWithContent($scope.upgradeOptionsMessages.payUpContract, [$filter('currency')(responseData.payUpAmount), responseData.shortDisplayName, contractDeviceCapacity]),
                            isDisplay: true
                        };
                        selectedOption = exUpgradeConstants.eligibleFlag.payUp;
                    }

                    // Add new options for 'Contract type TradeIn' and 'Contract type PayUp' with exisitng options to display on modal option and upgrade
                    tradeInPayUpOptions = addDeviceContractOption($scope.user.selectedLines[responseData.selectedSubscriber].optionPageSelection, tradeInPayUpOption, selectedOption);
                    $scope.user.selectedLines[responseData.selectedSubscriber].optionPageSelection = tradeInPayUpOptions;
                    $scope.user.selectedLines[responseData.selectedSubscriber].tradeInOptions.eligibleFlag = tradeInPayUpOption.eligibleFlag;
                    $scope.user.selectedLines[responseData.selectedSubscriber].tradeInOptions.message = tradeInPayUpOption.message;

                    $scope.user.upgradeLinesInfoDetails.contractDeviceDetails = {
                        deviceName: responseData.shortDisplayName,
                        deviceCapicity: contractDeviceCapacity
                    };
                }

                /**
                 * Function used to set new contract device tradeIn or payUp option in exisitng device options .
                 * @param {Object} lineOptionsData - line options to upgrade contract device
                 * @param {Object} contractDeviceOption - new contract device option
                 * @param {string} contractType - pre selected contract option type
                 * @return {Object} tradeIn Option Details to Upgrade contract device
                 */

                function addDeviceContractOption (lineOptionsData, contractDeviceOption, contractType) {
                    var tradeInOptionDetails = {};
                    angular.forEach(lineOptionsData, function (contractOptionData, contractOptionType) {
                        tradeInOptionDetails[contractOptionType] = contractOptionData;
                        if (contractOptionType === contractType) {
                            tradeInOptionDetails[contractDeviceOption.eligibleFlag] = contractDeviceOption;
                            tradeInOptionDetails[contractType].eligibleFlagMsg = $scope.upgradeOptionsMessages.tradeInOrPayUpIneligible;
                        }
                    });
                    return tradeInOptionDetails;
                }

                /**
                * get first line from selected lines
                */
                function getFirstSelectedLine () {
                    var selectedLine = undefined;
                    if (Object.keys($scope.user.selectedLines).length === 1) {
                        var subscriberNumber = Object.keys($scope.user.selectedLines)[0];
                        selectedLine = $scope.user.selectedLines[subscriberNumber];
                    }
                    return selectedLine;
                }
            }]);
})();