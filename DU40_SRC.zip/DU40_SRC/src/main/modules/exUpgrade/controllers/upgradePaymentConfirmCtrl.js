(function () {
    'use strict';

    /**
     * This controller retrieves payment confirmation details
     *
     * __Requirements:__
     * * gets customer profile information.
     * * gets customer plan ID
     * * gets customer payment information
     *
     * @module upgradePaymentConfirmCtrl
     *
     * @property {object} paymentConfirmation - parent data store object
     * @property {object} paymentConfirmation.paymentDetails - ???
     * @property {object} [paymentConfirmation.customerDetailWithDevice] - ???
     * @property {object} [paymentConfirmation.upgradingDevice - ???
     *
     * @todo update documentation so that it is complete and accurate
     *
     * @see {@link ../services/#module_upgradeUserInfoSrv..getUpgradingDeviceDetailsData|upgradeUserInfoSrv.getUpgradingDeviceDetailsData}
     * this is the primary source of data in controller.
     */
    angular.module('exUpgrade')

        .controller('upgradePaymentConfirmCtrl', ['$scope', '$filter', 'upgradeSharedPaymentInfoSrv', 'upgradingUserInfoSrv', 'exUpgradeConstants', 'exCommonConstants', '$location', 'upgradeEligPaymentSrv',
            function ($scope, $filter, upgradeSharedPaymentInfoSrv, upgradingUserInfoSrv, exUpgradeConstants, exCommonConstants, $location, upgradeEligPaymentSrv) {
                $scope.paymentConfirmation = {
                    paymentDetails: {}
                };
                $scope.redirectToUpgradeElig = redirectToUpgradeElig;
                $scope.paymentConfirmRedirect = paymentConfirmRedirect;
                $scope.disableUpgradePaymentConfirmCta = disableUpgradePaymentConfirmCta;

                activate();
                /**
                * Controller startup logic
                */
                function activate () {
                    upgradingUserInfoSrv.getUpgradingDeviceDetailsData().then(function (userInfo) {
                        $scope.paymentConfirmation.upgradingDevice = paymentConfirmationProfile(userInfo);
                        $scope.paymentConfirmation.customerDetailWithDevice = updateHeaderDetails(userInfo.payload);
                        $scope.paymentConfirmation.paymentDetails = updatePaymentDetails();

                        //call IUE api.
                        upgradeEligPaymentSrv.updateUpgradeEligibility();

                    });
                }

                /**
                 * Gets subscriber profile information
                 * @param {Object} userInfo User account information
                 * @return {Object} Subscriber name, device model and ctn
                 */
                function paymentConfirmationProfile (userInfo) {
                    return {
                        subscriberName: userInfo.payload.subscriberName,
                        deviceModel: userInfo.payload.deviceModel,
                        ctn: userInfo.payload.ctn
                    };
                }

                /**
                 * Set customer name with device modal and with CTN based on condition
                 * @param {Object} upgradeLineProfileDetail Subscriber line
                 * @return {Object} Correctly formatted object containing user name, device and ctn
                 */
                function updateHeaderDetails (upgradeLineProfileDetail) {
                    var customerDetailWithDevice = {};

                    customerDetailWithDevice.customerNameWithDevice = upgradeLineProfileDetail.subscriberName !== '' ?
                        upgradeLineProfileDetail.subscriberName + $scope.commonApostropheS : '';
                    customerDetailWithDevice.customerNameWithDevice = customerDetailWithDevice.customerNameWithDevice !== '' ?
                        customerDetailWithDevice.customerNameWithDevice + ' ' + upgradingUserInfoSrv.getDeviceType(upgradeLineProfileDetail.deviceType) : '';
                    customerDetailWithDevice.customerCTNWithDevice = (upgradeLineProfileDetail.deviceModel !== '' ?
                        upgradeLineProfileDetail.deviceModel + ' ' + $scope.commonSeparator : '') + ' ' + $filter('tel')(upgradeLineProfileDetail.ctn);
                    return customerDetailWithDevice;
                }

                /**
                 * Redirect to next page based on payment type.
                 * @function paymentConfirmRedirect
                 */
                function paymentConfirmRedirect () {
                    var paymentType = $filter('uppercase')($scope.paymentConfirmation.paymentDetails.paymentType);
                    if (paymentType === exUpgradeConstants.eligibleFlag.payOff) {
                        $location.path(exCommonConstants.deviceRecommender);
                    } else if (paymentType === exUpgradeConstants.eligibleFlag.payUp || paymentType === exUpgradeConstants.eligibleFlag.payUpContract) {
                        $location.path(exCommonConstants.tradeinConsent);
                    }
                }

                /**
                * Update payment summary from upgradeSharedPaymentInfoSrv service
                * @return {Object} Payment details
                */
                function updatePaymentDetails () {
                    var paymentSummary = upgradeSharedPaymentInfoSrv.getSharedPaymentInfo();
                    var paymentDetail = {
                        'amount': paymentSummary.amount,
                        'cardDetails': paymentSummary.cardType,
                        'paymentDate': new Date(paymentSummary.paymentDate),
                        'paymentType': paymentSummary.paymentType,
                        'planId': paymentSummary.planId,
                        'referenceInformation': paymentSummary.referenceInformation
                    };
                    return paymentDetail;
                }

                /**
                 * Disable the CTA if payment details are not available
                 * @function disableUpgradePaymentConfirmCta
                 * @return {Boolean} based if payment details are available
                 */
                function disableUpgradePaymentConfirmCta () {
                    return Object.keys($scope.paymentConfirmation.paymentDetails).length === 0 ? true : false;
                }

                /**
                 * redirect to upgrade eligibility page.
                 * @function redirectToUpgradeElig
                 */
                function redirectToUpgradeElig () {
                    $location.path(exCommonConstants.upgradeEligibility);
                }
            }]);
})();