(function () {
    'use strict';

    define(['upgradeEligPaymentCtrl'], function () {
        describe('src/main/modules/exUpgrade/controllers/upgradeEligPaymentCtrl.spec.js', function () {
            describe('upgradeEligPaymentCtrl of exUpgrade', function () {
                var controller, scope, upgradeEligPaymentSrv, $rootScope, $q,
                    $location, profileInfoService, exCqTranslatorKeyService, exCommonConstants, reportingDataSrv, exReportingSrv;
                beforeEach(function () {
                    reportingDataSrv = jasmine.createSpyObj('reportingDataSrv',
                        ['getUpgradePaymentFailurePayload',
                            'addEventSuccessToPayload',
                            'getUpgradePaymentPayload',
                            'updateEventPayloadFailure',
                            'updateEventPayloadPaymentFailure']);

                    exReportingSrv = jasmine.createSpyObj('exReportingSrv', ['firePageLoad']);

                    reportingDataSrv.getUpgradePaymentFailurePayload.and.returnValue({
                        successFlag: '0',
                        statusCode: '-2',
                        statusMessage: '',
                        errorType: 'Failure_BusinessRule',
                        linkName: 'Submit Payment'
                    });

                    reportingDataSrv.getUpgradePaymentPayload.and.returnValue({
                        successFlag: '1',
                        statusCode: '0'
                    });

                    reportingDataSrv.addEventSuccessToPayload.and.returnValue({
                        successFlag: '1',
                        statusCode: '0'
                    });

                    reportingDataSrv.updateEventPayloadFailure.and.returnValue({
                        errorType: 'Failure_Data',
                        successFlag: '0'
                    });

                    reportingDataSrv.updateEventPayloadPaymentFailure.and.returnValue({
                        successFlag: '0',
                        statusCode: 'DETCS3000010,DETCS300007',
                        errorType: 'Failure_Data',
                        statusMessage: 'FAILED'
                    });
                });

                beforeEach(function () {
                    module('exUpgrade');
                    inject(function ($injector) {
                        controller = $injector.get('$controller');
                        $rootScope = $injector.get('$rootScope');
                        $location = $injector.get('$location');
                        exCommonConstants = $injector.get('exCommonConstants');
                        scope = $rootScope.$new();
                        $q = $injector.get('$q');
                        spyOn($location, 'path');
                        exCqTranslatorKeyService = jasmine.createSpyObj('exCqTranslatorKeyService', ['getCqTranslatorKeys']);
                        exCqTranslatorKeyService.getCqTranslatorKeys.and.returnValue({
                            'then': function (callback) {
                                callback({'label.contractpay.agreepayoff':
                                    'Terms and conditions for payOff'});
                            }
                        });
                        profileInfoService = {
                            getProfileInfo: function () {
                                return $q.when(Endpoint_profileInfoApi.get_profile_info_auth.result);
                            }
                        };

                        upgradeEligPaymentSrv = jasmine.createSpyObj('upgradeEligPaymentSrv', ['fetchPaymentDetails',
                            'getUpgradingDevicePaymentData', 'upgradePaymentContinue']);
                        upgradeEligPaymentSrv.fetchPaymentDetails.and.returnValue({
                            'then': function (callback) {
                                callback(Endpoint_upgradeEligibilityPayment.get_upgrade_payment_details.result);
                            }
                        });
                        upgradeEligPaymentSrv.getUpgradingDevicePaymentData.and.returnValue({
                            'then': function (callback) {
                                callback(Endpoint_upgradeDevicePayment.getUpgradingDevicePaymentData.result);
                            }
                        });
                        upgradeEligPaymentSrv.upgradePaymentContinue.and.returnValue({
                            'then': function (callback) {
                                callback(Endpoint_upgradePaymentPost.upgrade_payment_post.result);
                            }
                        });

                        scope.payOffLegal = 'label.contractpay.agreepayoff';

                        controller('upgradeEligPaymentCtrl', {
                            $scope: scope,
                            exCqTranslatorKeyService: exCqTranslatorKeyService,
                            upgradeEligPaymentSrv: upgradeEligPaymentSrv,
                            profileInfoService: profileInfoService,
                            reportingDataSrv: reportingDataSrv,
                            exReportingSrv: exReportingSrv
                        });
                    });
                    $rootScope.$digest();
                });

                it('should provide an payment details to view', function () {
                    expect(scope.upgradePayment).toBeDefined();
                    expect(scope.upgradePayment.userId).toEqual('976b99d3-9220-0054-61f3-a745c98d6bd2');
                    expect(scope.upgradePayment.paymentInfo.cardType).toEqual('MC');
                    expect(scope.upgradePayment.upgradeTypeInfo.upgradeType).toEqual('PAYOFF');
                    expect(scope.upgradePayment.upgradeTypeInfo.paymentAmount).toEqual('100.00');
                    expect(scope.upgradePayment.upgradeTypeInfo.invoiceNumber).toEqual('IP300000000020410');
                    expect(scope.upgradePayment.paymentInfo.isPaymentProfile).toEqual(false);
                });

                it('should provide cq translator key value to view', function () {
                    expect(scope.upgradePayment.terms).toBeDefined();
                    expect(scope.upgradePayment.terms).toEqual('Terms and conditions for payOff');
                });

                it('should make sure the broadcast sent from the widget works as expected', function () {
                    var isPaymentValidated = true;
                    $rootScope.$broadcast(exCommonConstants.event.paymentInfoValidated, isPaymentValidated);
                    expect(upgradeEligPaymentSrv.fetchPaymentDetails).toBeDefined();
                    expect(scope.upgradePayment.paymentInfo).toBeDefined();
                });

                it('should check checkCard is defined', function () {
                    expect(scope.upgradePayment.checkCard).not.toBe(null);
                    expect(angular.isFunction(scope.upgradePayment.paymentInfo.checkCard)).toBe(true);
                });

                it('should call and check checkCard function', function () {
                    var upgradePaymentObj = {'paymentInfo': {cardType: 'MC'}};
                    var cardClass = scope.upgradePayment.paymentInfo.checkCard(upgradePaymentObj);
                    expect(cardClass).toBe('cards-mastercard');
                });

                it('should check parseDisplayName function', function () {
                    expect(scope.upgradePayment.paymentInfo.displayName).toBe('MasterCard ending With 2200');
                });


                it('should pass payment details to upgradePaymentContinue service', function () {
                    scope.upgradePayment.paymentInfo.paymentType = 'PayOff';
                    scope.continueToPayment();
                    expect(upgradeEligPaymentSrv.upgradePaymentContinue.calls.mostRecent()
                        .args[0]).toBeDefined();
                    expect(upgradeEligPaymentSrv.upgradePaymentContinue.calls.mostRecent()
                        .args[0]).toEqual(scope.upgradePayment.userId);
                    expect(upgradeEligPaymentSrv.upgradePaymentContinue.calls.mostRecent()
                        .args[1]).toBeDefined();
                    expect(upgradeEligPaymentSrv.upgradePaymentContinue.calls.mostRecent()
                        .args[1].subscriberNumber).toEqual(scope.upgradePayment.upgradeTypeInfo.customerCtn);
                    expect(upgradeEligPaymentSrv.upgradePaymentContinue.calls.mostRecent()
                        .args[1].systemDivision).toEqual(scope.upgradePayment.systemDivision);
                    expect(upgradeEligPaymentSrv.upgradePaymentContinue.calls.mostRecent()
                        .args[1].paymentInfo.amount).toEqual(scope.upgradePayment.upgradeTypeInfo.paymentAmount);
                });

                it('Should check redirection on continue button click when payment is successful', function () {
                    scope.continueToPayment();
                    upgradeEligPaymentSrv.upgradePaymentContinue().then(function (data) {
                        expect(data.response.status).toEqual('SUCCESS');
                        expect($location.path).toHaveBeenCalledWith('/shop/xpress/upgrade-payment-confirm.html');
                    });
                });

                it('should not allow to call upgradePaymentContinue service', function () {
                    scope.upgradePayment.paymentInfo.paymentType = false;
                    scope.continueToPayment();
                    expect(upgradeEligPaymentSrv.upgradePaymentContinue).not.toHaveBeenCalled();

                });

                it('should check redirection when cancel button click', function () {
                    scope.redirectToUpgradeElig();
                    expect($location.path).toHaveBeenCalledWith(exCommonConstants.upgradeEligibility);
                });

                it('should report success when payment accepted', function () {
                    var expectedReportingObjectSubmit = jasmine.objectContaining({
                            eventAction: 'formSubmit',
                            eventCode: 'DS_Upgrade_Payment_Submit',
                            additionaldata: jasmine.objectContaining({
                                successFlag: '1',
                                statusCode: '0'
                            })
                        }),
                        expectedReportingObjectResponse = jasmine.objectContaining({
                            eventAction: 'formResponse',
                            eventCode: 'DS_Upgrade_Payment_Submit',
                            additionaldata: jasmine.objectContaining({
                                successFlag: '1',
                                statusCode: '0'
                            })
                        });
                    spyOn(scope, '$emit').and.callThrough();
                    scope.$emit.calls.reset();
                    scope.continueToPayment();
                    expect(scope.$emit).toHaveBeenCalledWith(exCommonConstants.event.DS_REPORTING_EVENT, expectedReportingObjectSubmit, jasmine.any(Object));
                    expect(scope.$emit).toHaveBeenCalledWith(exCommonConstants.event.DS_REPORTING_EVENT, expectedReportingObjectResponse, jasmine.any(Object));
                });

                it('should report failure response with required params when payment not accepted', function () {
                    upgradeEligPaymentSrv.upgradePaymentContinue.and.returnValue({
                        'then': function (callback) {
                            callback(Endpoint_upgradePaymentPost.upgrade_payment_post_failure.result);
                        }
                    });
                    var expectedReportingObjectSubmit = jasmine.objectContaining({
                            eventAction: 'formSubmit',
                            eventCode: 'DS_Upgrade_Payment_Submit',
                            additionaldata: jasmine.objectContaining({
                                successFlag: '1',
                                statusCode: '0'
                            })
                        }),
                        expectedReportingObjectResponse = jasmine.objectContaining({
                            eventAction: 'formResponse',
                            eventCode: 'DS_Upgrade_Payment_Submit',
                            additionaldata: jasmine.objectContaining({
                                successFlag: '0',
                                statusCode: 'DETCS3000010,DETCS300007',
                                errorType: 'Failure_Data',
                                statusMessage: 'FAILED'
                            })
                        });
                    spyOn(scope, '$emit').and.callThrough();
                    scope.$emit.calls.reset();
                    scope.continueToPayment();
                    expect(scope.$emit).toHaveBeenCalledWith(exCommonConstants.event.DS_REPORTING_EVENT, expectedReportingObjectSubmit, jasmine.any(Object));
                    expect(scope.$emit).toHaveBeenCalledWith(exCommonConstants.event.DS_REPORTING_EVENT, expectedReportingObjectResponse, jasmine.any(Object));
                });

                it('should report page load with correct name and url', function () {
                    spyOn(scope, '$emit').and.callThrough();
                    scope.$emit.calls.reset();
                    scope.changePaymentMethod(true);
                    expect(scope.$emit).toHaveBeenCalledWith(exCommonConstants.event.DS_REPORTING_PAGELOAD_EVENT,
                            'DS Upgrade Change Payment Modal Pg',
                             '/shop/xpress/virtual/change-payment-method-modal.html');
                });

                it('should report upgrade update payment info form submit', function () {
                    var expectedReportingObjectSubmit = jasmine.objectContaining({
                        eventAction: 'formSubmit',
                        eventCode: 'DS_Upgrade_Update_Payment_Info_Submit',
                        additionaldata: jasmine.objectContaining({
                            successFlag: '1',
                            statusCode: '0'
                        })
                    });
                    spyOn(scope, '$emit').and.callThrough();
                    scope.$emit.calls.reset();
                    scope.$broadcast('PAYMENT_INFO_SUBMIT', 'creditCard');
                    expect(scope.$emit).toHaveBeenCalledWith(exCommonConstants.event.DS_REPORTING_EVENT, expectedReportingObjectSubmit, jasmine.any(Object));
                    scope.$apply();
                });

                it('should report upgrade update payment info form reponse', function () {
                    var expectedReportingObjectResponse = jasmine.objectContaining({
                        eventAction: 'formResponse',
                        eventCode: 'DS_Upgrade_Update_Payment_Info_Submit',
                        additionaldata: jasmine.objectContaining({
                            successFlag: '1',
                            statusCode: '0'
                        })
                    });
                    spyOn(scope, '$emit').and.callThrough();
                    scope.$emit.calls.reset();
                    scope.$broadcast('PAYMENT_INFO_SUBMIT_RESPONSE', 'creditCard');
                    expect(scope.$emit).toHaveBeenCalledWith(exCommonConstants.event.DS_REPORTING_EVENT, expectedReportingObjectResponse, jasmine.any(Object));
                    scope.$apply();
                });
            });
        });
    });
})();