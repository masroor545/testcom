# Prefetch

The `prefetch` folder contains all the scripts that are provided to third parties to prefetch Zippy (and other) assets.

## `services_prefetch`
### Script that is provided to myAT&T services to include into their website, so that Zippy files are prefetched when a user logs into myAT&T services, and then continues to myAT&T Sales through a handoff.

### Script include with cache breaker:
```
<script>
(function () {
    var path = '/shop/xpress/ui/express_sales_static/prefetch/prefetchZippy.min.js';
    var head = document.head;
    var script = document.createElement('script');

    script.src = path + '?_=' + Date.now().toString();
    head.appendChild(script);
})();
</script>
```
