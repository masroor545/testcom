// contents must remain in alphabetical order and grouped by module
requirejs.config({
    paths: {
        'angular': '../../bower_components/angular/angular',
        'uiRouter': '../../bower_components/angular-ui-router/release/angular-ui-router.min',

        // exBuyflow root
        'exBuyflowModule': 'modules/exBuyflow/module',
        'exBuyflowTemplates': 'modules/exBuyflow/templates',

        // exBuyflow controllers
        'accessoryDetailsCtrl': 'modules/exBuyflow/controllers/accessoryDetailsCtrl',
        'accessoryRecommenderCtrl': 'modules/exBuyflow/controllers/accessoryRecommenderCtrl',
        'accessorySubtotalTooltipCtrl': 'modules/exBuyflow/controllers/accessorySubtotalTooltipCtrl',
        'deviceDetailsCtrl': 'modules/exBuyflow/controllers/deviceDetailsCtrl',
        'deviceLegalDetailCtrl': 'modules/exBuyflow/controllers/deviceLegalDetailCtrl',
        'deviceRecommenderCtrl': 'modules/exBuyflow/controllers/deviceRecommenderCtrl',
        'upsellOfferCtrl': 'modules/exBuyflow/controllers/upsellOfferCtrl',

        // exBuyflow directives
        'exAccessoryDetails': 'modules/exBuyflow/directives/exAccessoryDetails',
        'exAccessoryRecommender': 'modules/exBuyflow/directives/exAccessoryRecommender',
        'exAccessorySubtotalTooltip': 'modules/exBuyflow/directives/exAccessorySubtotalTooltip',
        'exBvQa': 'modules/exBuyflow/directives/exBvQa',
        'exBvReviews': 'modules/exBuyflow/directives/exBvReviews',
        'exDeviceDetails': 'modules/exBuyflow/directives/exDeviceDetails',
        'exDeviceLegalDetails': 'modules/exBuyflow/directives/exDeviceLegalDetails',
        'exDeviceRecommender': 'modules/exBuyflow/directives/exDeviceRecommender',
        'exProtectionPlanFooter': 'modules/exBuyflow/directives/exProtectionPlanFooter',
        'exSubtotal': 'modules/exBuyflow/directives/exSubtotal',
        'upsellOffer': 'modules/exBuyflow/directives/upsellOffer',

        // exBuyflow services
        'accessoryRecommenderService': 'modules/exBuyflow/services/accessoryRecommenderService',
        'checkoutHandoffService': 'modules/exBuyflow/services/checkoutHandoffService',
        'deviceRecommenderSrv': 'modules/exBuyflow/services/deviceRecommenderSrv',
        'exBuyflowConstants': 'modules/exBuyflow/services/exBuyflowConstants',

        // exCommon root
        'exCommonModule': 'modules/exCommon/module',
        'exCommonTemplates': 'modules/exCommon/templates',

        // exCommon controllers
        'accessoryConfigCtrl': 'modules/exCommon/controllers/accessoryConfigCtrl',
        'addLineUserInfoCtrl': 'modules/exCommon/controllers/addLineUserInfoCtrl',
        'deviceCardCtrl': 'modules/exCommon/controllers/deviceCardCtrl',
        'deviceConfigCtrl': 'modules/exCommon/controllers/deviceConfigCtrl',
        'protectionPlanCtrl': 'modules/exCommon/controllers/protectionPlanCtrl',
        'protectionPlanDetailsCtrl': 'modules/exCommon/controllers/protectionPlanDetailsCtrl',
        'upgradingUserInfoCtrl': 'modules/exCommon/controllers/upgradingUserInfoCtrl',

        // exCommon directives
        'exAccessoryConfig': 'modules/exCommon/directives/exAccessoryConfig',
        'exDeviceCard': 'modules/exCommon/directives/exDeviceCard',
        'exDeviceConfig': 'modules/exCommon/directives/exDeviceConfig',
        'exInsuranceOptions': 'modules/exCommon/directives/exInsuranceOptions',
        'exPricingOptions': 'modules/exCommon/directives/exPricingOptions',
        'exProtectionPlan': 'modules/exCommon/directives/exProtectionPlan',
        'exProtectionPlanDetails': 'modules/exCommon/directives/exProtectionPlanDetails',
        'exProtectionPlanLegal': 'modules/exCommon/directives/exProtectionPlanLegal',
        'exAddLineUserInfo': 'modules/exCommon/directives/exAddLineUserInfo',
        'exUpgradingUserInfo': 'modules/exCommon/directives/exUpgradingUserInfo',

        // exCommon filters
        'commonFilter': 'modules/exCommon/filters/commonFilter',

        // exCommon services
        'contentService': 'modules/exCommon/services/contentService',
        'deviceConfigSrv': 'modules/exCommon/services/deviceConfigSrv',
        'exAccessoryContentService': 'modules/exCommon/services/exAccessoryContentService',
        'exCacheManager': 'modules/exCommon/services/exCacheManager',
        'exCartService': 'modules/exCommon/services/exCartService',
        'exCommonConstants': 'modules/exCommon/services/exCommonConstants',
        'exCqTranslatorKeyService': 'modules/exCommon/services/exCqTranslatorKeyService',
        'exHelpUtils': 'modules/exCommon/services/exHelpUtils',
        'favStoreService': 'modules/exCommon/services/favStoreService',
        'imagePathService': 'modules/exCommon/services/imagePathService',
        'profileInfoService': 'modules/exCommon/services/profileInfoService',
        'protectionPlanService': 'modules/exCommon/services/protectionPlanService',
        'reportingDataSrv': 'modules/exCommon/services/reportingDataSrv',
        'selectedSkuSrv': 'modules/exCommon/services/selectedSkuSrv',
        'upgradeLinesInfoService': 'modules/exCommon/services/upgradeLinesInfoService',
        'upgradingUserInfoSrv': 'modules/exCommon/services/upgradingUserInfoSrv',
        'upsellOfferSrv': 'modules/exCommon/services/upsellOfferSrv',

        // exStartup root
        'exStartupModule': 'modules/exStartup/module',

        // exStartup services
        'exDetmManager': 'modules/exStartup/services/exDetmManager',
        'exLoginGuardService': 'modules/exStartup/services/exLoginGuardService',
        'exPostAuthGlobalApi': 'modules/exStartup/services/exPostAuthGlobalApi',
        'exPostAuthGlobalInterceptor': 'modules/exStartup/services/exPostAuthGlobalInterceptor',
        'exReportingSrv': 'modules/exStartup/services/exReportingSrv',
        'exSessionMonitor': 'modules/exStartup/services/exSessionMonitor',
        'exStartupConstants': 'modules/exStartup/services/exStartupConstants',
        'exStartupUtils': 'modules/exStartup/services/exStartupUtils',
        'redirectInterceptorService': 'modules/exStartup/services/redirectInterceptorService',
        'validateBuyflowInterceptor': 'modules/exStartup/services/validateBuyflowInterceptor',
        'profileServiceInterceptor': 'modules/exStartup/services/profileServiceInterceptor',
        'routeEventService': 'modules/exStartup/services/routeEventService',
        'spinnerInterceptor': 'modules/exStartup/services/spinnerInterceptor',

        // exStartup setup
        'pathConfig': 'modules/exStartup/setup/pathConfig',

        // exUpgrade root
        'exUpgradeModule': 'modules/exUpgrade/module',
        'exUpgradeTemplates': 'modules/exUpgrade/templates',

        // exUpgrade controllers
        'upgradeEligCtrl': 'modules/exUpgrade/controllers/upgradeEligCtrl',
        'upgradeEligPaymentCtrl': 'modules/exUpgrade/controllers/upgradeEligPaymentCtrl',
        'upgradePaymentConfirmCtrl': 'modules/exUpgrade/controllers/upgradePaymentConfirmCtrl',
        'upgradeTradeinConsentCtrl': 'modules/exUpgrade/controllers/upgradeTradeinConsentCtrl',

        // exUpgrade directives
        'exUpgradeElig': 'modules/exUpgrade/directives/exUpgradeElig',
        'exUpgradeEligPayment': 'modules/exUpgrade/directives/exUpgradeEligPayment',
        'exUpgradeOptions': 'modules/exUpgrade/directives/exUpgradeOptions',
        'exUpgradePaymentConfirm': 'modules/exUpgrade/directives/exUpgradePaymentConfirm',
        'exUpgradeTradeinConsent': 'modules/exUpgrade/directives/exUpgradeTradeinConsent',

        // exUpgrade services
        'exUpgradeConstants': 'modules/exUpgrade/services/exUpgradeConstants',
        'upgradeEligPaymentSrv': 'modules/exUpgrade/services/upgradeEligPaymentSrv',
        'upgradeEligSrv': 'modules/exUpgrade/services/upgradeEligSrv',
        'upgradeSharedPaymentInfoSrv': 'modules/exUpgrade/services/upgradeSharedPaymentInfoSrv',
        'upgradeTradeinConsentSrv': 'modules/exUpgrade/services/upgradeTradeinConsentSrv'
    },

    shim: {
        // exBuyflow root
        'exBuyflowModule': {
            deps: ['exBuyflowTemplates', 'exCommonModule']
        },


        // exBuyflow controllers
        'accessoryDetailsCtrl': {
            deps: ['exBuyflowModule', 'exCommonConstants']
        },

        'accessoryRecommenderCtrl': {
            deps: ['exBuyflowModule', 'exCommonConstants']
        },

        'accessorySubtotalTooltipCtrl': {
            deps: ['exBuyflowModule']
        },

        'deviceDetailsCtrl': {
            deps: ['exBuyflowModule', 'exCommonConstants']
        },

        'deviceLegalDetailCtrl': {
            deps: ['exBuyflowModule']
        },

        'deviceRecommenderCtrl': {
            deps: ['exBuyflowModule', 'exCommonConstants']
        },

        'upsellOfferCtrl': {
            deps: ['exBuyflowModule']
        },


        // exBuyflow directives
        'exAccessoryDetails': {
            deps: ['exBuyflowModule']
        },

        'exAccessoryRecommender': {
            deps: ['exBuyflowModule']
        },

        'exAccessorySubtotalTooltip': {
            deps: ['exBuyflowModule']
        },

        'exBvQa': {
            deps: ['exBuyflowModule', 'exCommonConstants']
        },

        'exBvReviews': {
            deps: ['exBuyflowModule', 'exCommonConstants']
        },

        'exDeviceDetails': {
            deps: ['exBuyflowModule']
        },

        'exDeviceLegalDetails': {
            deps: ['exBuyflowModule']
        },

        'exDeviceRecommender': {
            deps: ['exBuyflowModule']
        },

        'exProtectionPlanFooter': {
            deps: ['exBuyflowModule']
        },

        'exSubtotal': {
            deps: ['exBuyflowModule']
        },

        'upsellOffer': {
            deps: ['exBuyflowModule']
        },


        // exBuyflow services
        'accessoryRecommenderService': {
            deps: ['exBuyflowModule', 'exBuyflowConstants']
        },

        'checkoutHandoffService': {
            deps: ['exBuyflowModule', 'exBuyflowConstants']
        },

        'deviceRecommenderSrv': {
            deps: ['exBuyflowModule', 'exBuyflowConstants']
        },

        'exBuyflowConstants': {
            deps: ['exBuyflowModule']
        },


        // exCommon root
        'exCommonModule': {
            deps: ['exCommonTemplates']
        },


        // exCommon controllers
        'accessoryConfigCtrl': {
            deps: ['exCommonModule']
        },

        'addLineUserInfoCtrl': {
            deps: ['exCommonModule']
        },

        'deviceCardCtrl': {
            deps: ['exCommonModule']
        },

        'deviceConfigCtrl': {
            deps: ['exCommonModule']
        },

        'protectionPlanCtrl': {
            deps: ['exCommonModule']
        },

        'protectionPlanDetailsCtrl': {
            deps: ['exCommonModule']
        },

        'upgradingUserInfoCtrl': {
            deps: ['exCommonModule']
        },


        // exCommon directives
        'exAccessoryConfig': {
            deps: ['exCommonModule']
        },

        'exDeviceCard': {
            deps: ['exCommonModule']
        },

        'exDeviceConfig': {
            deps: ['exCommonModule']
        },

        'exInsuranceOptions': {
            deps: ['exCommonModule']
        },

        'exPricingOptions': {
            deps: ['exCommonModule']
        },

        'exProtectionPlan': {
            deps: ['exCommonModule']
        },

        'exProtectionPlanDetails': {
            deps: ['exCommonModule']
        },

        'exProtectionPlanLegal': {
            deps: ['exCommonModule']
        },

        'exAddLineUserInfo': {
            deps: ['exCommonModule']
        },

        'exUpgradingUserInfo': {
            deps: ['exCommonModule']
        },


        // exCommon filters
        'commonFilter': {
            deps: ['exCommonModule']
        },

        // exCommon services
        'contentService': {
            deps: ['exCommonModule']
        },

        'deviceConfigSrv': {
            deps: ['exCommonModule']
        },

        'exAccessoryContentService': {
            deps: ['exCommonModule']
        },

        'exCacheManager': {
            deps: ['exCommonModule']
        },

        'exCartService': {
            deps: ['exCommonModule']
        },

        'exCommonConstants': {
            deps: ['exCommonModule']
        },

        'exCqTranslatorKeyService': {
            deps: ['exCommonModule']
        },

        'exHelpUtils': {
            deps: ['exCommonModule']
        },

        'favStoreService': {
            deps: ['exCommonModule']
        },

        'imagePathService': {
            deps: ['exCommonModule']
        },

        'profileInfoService': {
            deps: ['exCommonModule']
        },

        'protectionPlanService': {
            deps: ['exCommonModule']
        },

        'reportingDataSrv': {
            deps: ['exCommonModule']
        },

        'selectedSkuSrv': {
            deps: ['exCommonModule']
        },

        'upgradeLinesInfoService': {
            deps: ['exCommonModule']
        },

        'upgradingUserInfoSrv': {
            deps: ['exCommonModule', 'exCommonConstants']
        },

        'upsellOfferSrv': {
            deps: ['exCommonModule']
        },

        // exStartup services
        'exDetmManager': {
            deps: ['exStartupModule']
        },

        'exLoginGuardService': {
            deps: ['exStartupModule', 'exStartupConstants']
        },

        'exPostAuthGlobalApi': {
            deps: ['exStartupModule', 'exStartupConstants']
        },

        'exPostAuthGlobalInterceptor': {
            deps: ['exStartupModule', 'exStartupConstants', 'exStartupUtils']
        },

        'exReportingSrv': {
            // exDetmManager needed because of the run block in this file
            deps: ['exStartupModule', 'exStartupConstants', 'exDetmManager']
        },

        'exSessionMonitor': {
            deps: ['exStartupModule', 'exStartupConstants']
        },

        'exStartupConstants': {
            deps: ['exStartupModule']
        },

        'exStartupUtils': {
            deps: ['exStartupModule']
        },

        'redirectInterceptorService': {
            deps: ['exStartupModule', 'exStartupConstants']
        },

        'routeEventService': {
            deps: ['exStartupModule', 'exStartupConstants']
        },

        'spinnerInterceptor': {
            deps: ['exStartupModule', 'exStartupConstants']
        },

        'validateBuyflowInterceptor': {
            deps: ['exStartupModule', 'exStartupConstants']
        },

        'profileServiceInterceptor': {
            deps: ['exStartupModule', 'exStartupConstants']
        },

        // exStartup setup
        'pathConfig': {
            deps: ['exStartupModule', 'exStartupConstants']
        },

        // exStartup root
        'exStartupModule': {
            deps: ['uiRouter']
        },

        'uiRouter': {
            deps: ['angular'],
            exports: 'angular'
        },


        // exUpgrade root
        'exUpgradeModule': {
            deps: ['exUpgradeTemplates', 'exCommonModule']
        },

        // exUpgrade controllers
        'upgradeEligCtrl': {
            deps: ['exUpgradeModule']
        },

        'upgradeEligPaymentCtrl': {
            deps: [
                'exUpgradeModule',
                'exCommonConstants',
                'exUpgradeConstants',
                'upgradeSharedPaymentInfoSrv'
            ]
        },

        'upgradePaymentConfirmCtrl': {
            deps: ['exUpgradeModule']
        },

        'upgradeTradeinConsentCtrl': {
            deps: ['exUpgradeModule']
        },

        // exUpgrade directives
        'exUpgradeElig': {
            deps: ['exUpgradeModule']
        },

        'exUpgradeEligPayment': {
            deps: ['exUpgradeModule']
        },

        'exUpgradeOptions': {
            deps: ['exUpgradeModule']
        },

        'exUpgradePaymentConfirm': {
            deps: ['exUpgradeModule']
        },

        'exUpgradeTradeinConsent': {
            deps: ['exUpgradeModule']
        },


        // exUpgrade services
        'exUpgradeConstants': {
            deps: ['exUpgradeModule']
        },

        'upgradeEligPaymentSrv': {
            deps: ['exUpgradeModule']
        },

        'upgradeEligSrv': {
            deps: ['exUpgradeModule', 'exCommonConstants', 'exUpgradeConstants']
        },

        'upgradeSharedPaymentInfoSrv': {
            deps: ['exUpgradeModule']
        },

        'upgradeTradeinConsentSrv': {
            deps: ['exUpgradeModule']
        }
    }
});