/*global require, console, __dirname */
(function () {
    'use strict';

    var packageJson = require('./package'),
        cleanCSS = require('gulp-clean-css'),
        concat = require('gulp-concat'),
        del = require('del'),
        eslint = require('gulp-eslint'),
        fs = require('fs'),
        gulp = require('gulp-help')(require('gulp')),
        gulpUtil = require('gulp-util'),
        karma = require('karma'),
        lazypipe = require('lazypipe'),
        less = require('gulp-less'),
        merge = require('merge-stream'),
        order = require('gulp-order'),
        pug = require('gulp-pug'),
        pugBeautify = require('gulp-pug-beautify'),
        path = require('path'),
        recursive = require('recursive-readdir'),
        remoteSrc = require('gulp-remote-src'),
        rename = require('gulp-rename'),
        requireDir = require('require-dir'),
        sourcemaps = require('gulp-sourcemaps'),
        template = require('gulp-template'),
        templatecache = require('gulp-angular-templatecache'),
        uglify = require('gulp-uglify');

    var moduleDirs = packageJson.attconfig.moduleDirs,
        outputDir = packageJson.attconfig.outputDir + packageJson.version + '/',
        moduleFiles = ['module.js', '**/*.js', '!templates.js', '!**/*.spec.js', '!GruntFile.js'];

    /**
     * Performs task of uglifying all javascript files in the stream and generating minified files with maps.
     */
    var func_uglifyWithMaps = lazypipe()
        .pipe(sourcemaps.init)
        .pipe(uglify)
        .pipe(rename, {suffix: '.min'})
        .pipe(sourcemaps.write, '.');

    /**
     * Performs task of executing lint against all javascript files in the stream and failing on errors.
     */
    var func_performLint = lazypipe()
        .pipe(eslint)
        .pipe(eslint.format)
        .pipe(eslint.failAfterError);

    var func_performCSSLint = lazypipe()
        .pipe(require('gulp-stylelint'), {
            reporters: [
                {formatter: 'string', console: true}
            ]
        });

    /**
     * Performs task of uglifying all CSS files in stream and generating minified files with maps.
     */
    var func_uglifyCssWithMaps = lazypipe()
        .pipe(sourcemaps.init)
        .pipe(cleanCSS, {restructuring: false})
        .pipe(rename, {suffix: '.min'})
        .pipe(sourcemaps.write, '.');

    /**
     * Listing of child directories when provided a parent directory
     * @param {string} dir a source directory
     * @returns [string] array of directory names contained in provided directory
     */
    function getFolders(dir) {
        return fs.readdirSync(dir)
            .filter(function (file) {
                return fs.statSync(path.join(dir, file)).isDirectory();
            });
    }

    /**
     * executes the karma tests in a single run scenario and fails on error.
     * also generates coverage etc...
     * @param {function} done called to indicate completion of gulp task.
     */
    function executeTests(done) {
        new karma.Server({
            configFile: __dirname + '/karma.conf.js',
            singleRun: true,
            reporters: ['coverage', 'spec', 'sonarqubeUnit'],
            preprocessors: {
                'src/**/!(*.spec|*.endpoint)*.js': 'coverage'
            },
            specReporter: {
                maxLogLines: 5,
                showSpecTiming: true
            },
            sonarQubeUnitReporter: {
                outputFile: 'coverage/TESTS.xml',
                useBrowserName: false
            },
            coverageReporter: {
                subdir: '.',
                type: 'lcov',
                dir: 'coverage/'
            },
            failOnEmptyTestSuite: false
        }, done).start();
    }

    /**
     * Cycles through all module directories configured in package.json and executes build functionality
     * returning the resulting stream.
     * @param {function} func execute and returns a stream when passed a configured module directory
     * @returns [stream] collection of streams returned by the provided function
     */
    function processModules(func) {
        var i, streams = [];
        for (i = 0; i < moduleDirs.length; i += 1) {
            streams = streams.concat(func(moduleDirs[i]));
        }
        return streams;
    }

    /**
     * Delete generated files that could potentially be confused with updated upon new build.
     */
    gulp.task('clean', 'deletes generated files and dist folder', function () {
        return del(['dist', 'src/**/templates.js', 'src/**/html/*.html', 'coverage']);
    });

    /**
     * Generates the template.js files from the HTML source files included in the configured module directories
     */
    gulp.task('process-html', false, ['clean', 'process-pug-files'], function () {
        var streams = processModules(function (moduleConfig) {
            return getFolders(moduleConfig.in).map(function (module) {
                return gulp.src(['**/*.html'], {cwd: moduleConfig.in + module})
                    .pipe(templatecache({
                        module: '/templates/' + module,
                        standalone: true,
                        transformUrl: function (url) {
                            return '/templates/' + url.split(path.sep).pop();
                        }
                    }))
                    .pipe(gulp.dest(moduleConfig.in + module));
            });
        });

        return (streams.length > 0) ? merge(streams) : undefined;
    });

    gulp.task('process-pug-files', false, ['clean', 'get-remote-content'], function () {
        var streams, content, contentDir = packageJson.attconfig.staticContentDir;

        if (contentDir !== undefined) {
            content = requireDir(contentDir, {recurse: true});

            streams = processModules(function (moduleConfig) {
                return getFolders(moduleConfig.in).reduce(function (accum, module) {
                    var contentSource = './' + moduleConfig.in + module + '/html/',
                        moduleFolder = moduleConfig.in + module;

                    if (fs.existsSync(contentSource)) {
                        accum.push(
                            gulp.src(['**/*.pug', '!**/_*.pug'], {cwd: moduleFolder})
                                .pipe(pug({data: content, doctype: 'html'}))
                                .pipe(gulp.dest(moduleFolder))
                        );
                    }

                    return accum;
                }, []);
            });
        }

        return (streams.length > 0) ? merge(streams) : undefined;
    });

    /**
     * Go through the configured module input directories and generate combined file for each modules.
     * This includes the step of generating initial module javascript file and then generating a second
     * version that includes the HTML templates and a template specific extension i.e. "-tpl.js".
     * Finally deposit the files in the configured output directory for each module folder.
     */
    gulp.task('compile-module-dir', false, ['clean', 'test-in-build'], function () {
        var streams = processModules(function (moduleConfig) {
            return getFolders(moduleConfig.in).map(function (module) {
                var moduleOutDir = outputDir + moduleConfig.out;
                var scriptstream = gulp.src(moduleFiles, {cwd: moduleConfig.in + module})
                    .pipe(concat(module + '.js'))
                    .pipe(uglify({compress: false, mangle: false, output: {beautify: true}})) // security: strip comments
                    .pipe(gulp.dest(moduleOutDir));

                var htmlstream = gulp.src(['templates.js'], {cwd: moduleConfig.in + module});

                return merge(scriptstream, htmlstream)
                    .pipe(order(moduleFiles))
                    .pipe(concat(module + '-tpl.js'))
                    .pipe(gulp.dest(moduleOutDir));
            });

            return merge(streams);
        });

        return (streams.length > 0) ? merge(streams) : undefined;
    });

    /**
     * Go through the configured module output directories and generate minified files along with appropriate
     * map files and write the results to the same modules output directory.
     */
    gulp.task('uglify-modules', false, ['compile-module-dir'], function () {
        var streams = processModules(function (moduleConfig) {
            var moduleOutputDir = outputDir + moduleConfig.out;
            return gulp.src(['**/*.js', '!**/*.min.js', '!**/*.map'], {cwd: moduleOutputDir})
                .pipe(func_uglifyWithMaps())
                .pipe(gulp.dest(moduleOutputDir));
        });

        return (streams.length > 0) ? merge(streams) : undefined;
    });

    /**
     * General processing of other file types, primarily moving each type to the configured output directory.
     */
    gulp.task('process-other-files', false, ['clean', 'bower-move', 'test-in-build', 'get-remote-content'], function () {
        var streams = [], confobj;

        // grab generic configured file mappings and place in configured output directory.
        if (packageJson.attconfig.move['other'] !== undefined) {
            confobj = packageJson.attconfig.move['other'];
            streams.push(
                gulp.src(confobj.sources, {cwd: packageJson.attconfig.sourceDir})
                    .pipe(gulp.dest(outputDir))
            );
        }

        // move css files based on configured mapping to configured output directory and perform minification / map.
        if (packageJson.attconfig.move['css'] !== undefined) {
            confobj = packageJson.attconfig.move['css'];
            streams.push(
                gulp.src(confobj.sources, {cwd: packageJson.attconfig.sourceDir})
                    .pipe(gulp.dest(outputDir + confobj.outputDir))
                    .pipe(func_uglifyCssWithMaps())
                    .pipe(gulp.dest(outputDir + confobj.outputDir))
            )
        }

        // move js files based on configured mapping to configured output directory and perform minification / map.
        if (packageJson.attconfig.move['js'] !== undefined) {
            confobj = packageJson.attconfig.move['js'];
            streams.push(
                gulp.src(confobj.sources, {cwd: packageJson.attconfig.sourceDir})
                    .pipe(uglify({compress: false, mangle: false, output: {beautify: true}})) // security: strip comments
                    .pipe(gulp.dest(outputDir + confobj.outputDir))
                    .pipe(func_uglifyWithMaps())
                    .pipe(gulp.dest(outputDir + confobj.outputDir))
            )
        }

        // compile less files as configured and move to configured output directory and perform minification / map.
        if (packageJson.attconfig.move['less'] !== undefined) {
            confobj = packageJson.attconfig.move['less'];
            streams.push(
                gulp.src(confobj.sources, {cwd: packageJson.attconfig.sourceDir})
                    .pipe(less())
                    .pipe(gulp.dest(outputDir + confobj.outputDir))
                    .pipe(func_uglifyCssWithMaps())
                    .pipe(gulp.dest(outputDir + confobj.outputDir))
            );
        }

        if (packageJson.attconfig.move['pug'] !== undefined) {
            var contentDir = packageJson.attconfig.staticContentDir,
                content = contentDir !== undefined ? requireDir(contentDir) : {};

            confobj = packageJson.attconfig.move['pug'];
            streams.push(
                gulp.src(confobj.sources, {cwd: confobj.sourceDir})
                    .pipe(pug({data: content, doctype: 'html'}))
                    .pipe(gulp.dest(outputDir + confobj.outputDir))
            );
        }

        return (streams.length > 0) ? merge(streams) : undefined;
    });

    /**
     * Go through combined file configuration, grab mapped files from dist directory to create combined files and
     * generate map and minfied versions of the combined file.  Deposit file in configured output directory.
     */
    gulp.task('create-combined', false, ['process-other-files', 'uglify-modules'], function () {
        var genfile, streams = [], combined = packageJson.attconfig.combined;
        for (genfile in combined) {
            streams.push(
                gulp.src(combined[genfile].sources, {cwd: outputDir})
                    .pipe(concat(genfile + '.js'))
                    .pipe(gulp.dest(outputDir + combined[genfile].outputDir))
                    .pipe(func_uglifyWithMaps())
                    .pipe(gulp.dest(outputDir + combined[genfile].outputDir))
            );
        }

        return (streams.length > 0) ? merge(streams) : undefined;
    });

    /**
     * Generate requireJS path configuration file.
     * Upon completion of other build steps collect all listing of all minfied files from dist directory with certain
     * folder / file exceptions.  Generate a listing of all the file names, paths and types.  Pass this listing to the
     * configured main template file.  Write results to dist.
     */
    gulp.task('process-templates', false, ['create-combined', 'generate-prefetch-json'], function (done) {
        var ignoreFiles = /(-app|-bootstrap|-main)\.min\.js$/,
            engageFiles = /\.min\.(js|css)$/;
        recursive(outputDir, [function (file, stat) {
            var basename = path.basename(file);
            return (stat.isDirectory() && basename === 'lib') ||
                (stat.isFile() && ignoreFiles.test(basename)) ||
                (stat.isFile() && !engageFiles.test(basename));
        }], function (err, files) {
            var data = files.map(function (filename) {
                var indexes = filename.endsWith('min.js') ? [-7, -3, ''] : [-8, -4, '-css'];
                return {
                    name: path.basename(filename).slice(0, indexes[0]) + indexes[2], // strip extensions .min.js or css
                    path: filename.slice(8, indexes[1]).replace(/\\/g, '/'), // strip prefix dist/us and extension .js or css
                    ext: indexes[2]
                }
            });

            gulp.src(packageJson.attconfig.maintemplate)
                .pipe(template({ files: data, version: packageJson.version }))
                .pipe(gulp.dest(outputDir + 'js'))
                .pipe(func_uglifyWithMaps())
                .pipe(gulp.dest(outputDir + 'js'));
            done();
        });
    });

    /**
     * Move some files into lib directory
     */
    gulp.task('bower-move', false, ['clean'], function () {
        return gulp.src(packageJson.attconfig.bowerFiles, {cwd: "bower_components"})
            .pipe(gulp.dest(outputDir + 'js/lib/'));
    });

    gulp.task('fix-script-style', 'updates the spacing used in code files to be in line with general styleguide', ['fix-javascript-style', 'fix-pug-style']);

    gulp.task('fix-javascript-style', false, function () {
        return gulp.src(['**/*.js', '!**/*.min.js', '!**/*.spec.js', '!**/templates.js', '!**/*-main.js'], {cwd: packageJson.attconfig.sourceDir})
            .pipe(eslint({fix: true}))
            .pipe(eslint.format())
            .pipe(gulp.dest(packageJson.attconfig.sourceDir));
    });

    gulp.task('fix-pug-style', false, function () {
        return gulp.src(['**/*.pug'])
            .pipe(pugBeautify({
                fill_tab: true, omit_div: true, tab_size: 4
            }))
            .pipe(gulp.dest('.'));
    });

    gulp.task('lint-css', function () {
        return gulp.src(['**/*.css', '**/*.less'], {cwd: packageJson.attconfig.sourceDir})
            .pipe(func_performCSSLint());
    });

    gulp.task('lint', 'execute lint tests', ['lint-css'], function () {
        return gulp.src(['**/*.js', '!**/*.min.js', '!**/*.spec.js', '!**/templates.js', '!**/*-main.js'], {cwd: packageJson.attconfig.sourceDir})
            .pipe(func_performLint());
    });

    gulp.task('lint-tests', 'runs lint and style rules against unit test files', function () {
        return gulp.src(['**/*.spec.js'], {cwd: packageJson.attconfig.sourceDir})
            .pipe(eslint({
                fix: true,
                configFile: '.eslintrc-test.json'
            }))
            .pipe(eslint.format())
            .pipe(gulp.dest(packageJson.attconfig.sourceDir));
    });

    gulp.task('watch-lint', 'watches javascript files for changes and performs lint task', function () {
        return gulp.watch(['**/*.js', '!**/*.spec.js', '!**/templates.js', '!**/*-main.js'], {cwd: 'src'}, ['lint']);
    });

    gulp.task('get-remote-content', 'fetches content from remote source', function () {
        var remoteContent = require(packageJson.attconfig.remoteContent),
            remoteTimeout = packageJson.attconfig.remoteTimeout;

        if (remoteContent.base !== undefined) {
            return remoteSrc(remoteContent.paths, {
                base: remoteContent.base,
                requestOptions: {
                    followRedirect: false,
                    timeout: remoteTimeout
                }})
                .on('error', function (error) {
                    gulpUtil.log(
                        'Remote Content:',
                        gulpUtil.colors.magenta(error.message));
                    this.emit('end');
                })
                .pipe(rename(function (path) {
                    path.extname = '.json';
                    path.dirname = path.dirname.toLowerCase();
                    path.basename = path.basename.toLowerCase();
                }))
                .pipe(gulp.dest(packageJson.attconfig.staticContentDir));
        } else {
           return undefined;
        }
    });

    /**
     * General build task with dependency, equivalent to default task just named.
     */
    gulp.task('build-all', false, ['process-templates']);

    gulp.task('default', 'execute complete build and test process', ['build-all']);

    /**
     * Version of test task that requires lint to pass first, intended for build environment sequencing purposes.
     * Previously the two task happened simultaneously resulting in combined output in logs.
     */
    gulp.task('test-in-build', false, ['process-html', 'lint'], executeTests);

    gulp.task('test', 'execute unit tests once', ['process-html'], executeTests);

    gulp.task('test-tdd', 'execute continuous unit tests', ['process-html'], function (done) {
        gulp.watch(['**/*.html'], {cwd: 'src'}, ['process-html']);

        new karma.Server({
            configFile: __dirname + '/karma.conf.js',
        }, done).start();
    });

    gulp.task('generate-prefetch-json', ['process-other-files'], function () {
        return gulp.src(['prefetch.json', 'legacy_prefetch.json'], {cwd: packageJson.attconfig.staticContentDir})
            .pipe(template({version: packageJson.version}))
            .pipe(gulp.dest(packageJson.attconfig.outputDir + '/prefetch/'));
    });

    gulp.task('generate-docs', 'generate documentation readme files', function () {
        var jsdoc2md = require('jsdoc-to-markdown');

        // generate documentation for modules
        processModules(function (moduleConfig) {
            getFolders(moduleConfig.in).map(function (module) {
                getFolders(moduleConfig.in + module).map(function (dir) {
                    if (packageJson.attconfig.generateDocModuleDirs.indexOf(dir) >= 0) {
                        generateDocs(moduleConfig.in + module + '/' + dir);
                    }
                });
            });
        });

        // generate documentation for other folders
        if (packageJson.attconfig.generateDocOtherDirs instanceof Array) {
            packageJson.attconfig.generateDocOtherDirs.forEach(function (dir) {
                generateDocs(dir);
            });
        }

        function generateDocs (docDir) {
            fs.writeFileSync(docDir + '/readme.md', jsdoc2md.renderSync({
                'module-index-format': 'table',
                'separators': true,
                'files': docDir + '/*.js'
            }));
        }
    });
})();

