/**
 * Various test responses for the device legal content service
 *
 * @example
 * $httpBackend.whenGET(Endpoint_deviceLegalContentNode.get_content_node.url_match)
 *      .respond(200, Endpoint_deviceLegalContentNode.get_content_node.result);
 */
var Endpoint_deviceLegalContentNode = (function () {
    'use strict';

    return {
        "get_content_node": {
            url_match: /\/cellphones\/iphone\/apple-iphone-7\/jcr:content\/details\/legalpar.eternity.json/,
            response_code: 200,
            params_sent: '',
            result: {
                "sling:resourceType": "foundation/components/parsys",
                "jcr:primaryType": "nt:unstructured",
                "legaldetailsreferenc": {
                    "jcr:lastModifiedBy": "mm7471",
                    "sling:resourceType": "att/mobile/wireless/components/legal/legaldetailsreference",
                    "jcr:createdBy": "mm7471",
                    "path": "/content/sharedcontent/en/legal/details-pages/legal-id-26c/jcr:content/warrantypar/warrantyinfo_0",
                    "jcr:created": "Wed Jan 11 2017 16:45:07 GMT-0800",
                    "jcr:lastModified": "Wed Jan 11 2017 16:46:07 GMT-0800",
                    "jcr:primaryType": "nt:unstructured"
                },
                "legaldetailsreferenc_0": {
                    "jcr:lastModifiedBy": "mm7471",
                    "sling:resourceType": "att/mobile/wireless/components/legal/legaldetailsreference",
                    "jcr:createdBy": "mm7471",
                    "path": "/content/sharedcontent/en/legal/details-pages/legal-id-191/jcr:content/warrantypar/warrantyinfo_2",
                    "jcr:created": "Wed Jan 11 2017 16:45:11 GMT-0800",
                    "jcr:lastModified": "Thu Jan 12 2017 14:50:22 GMT-0800",
                    "jcr:primaryType": "nt:unstructured"
                },
                "legaldetailsreferenc_1": {
                    "jcr:lastModifiedBy": "mm7471",
                    "sling:resourceType": "att/mobile/wireless/components/legal/legaldetailsreference",
                    "jcr:createdBy": "mm7471",
                    "path": "/content/sharedcontent/en/legal/details-pages/legal-id-99/jcr:content/warrantypar/warrantyinfo_0",
                    "jcr:created": "Wed Jan 11 2017 16:45:15 GMT-0800",
                    "jcr:lastModified": "Wed Jan 11 2017 16:46:29 GMT-0800",
                    "jcr:primaryType": "nt:unstructured"
                },
                "legaldetailsreferenc_2": {
                    "jcr:lastModifiedBy": "mm7471",
                    "sling:resourceType": "att/mobile/wireless/components/legal/legaldetailsreference",
                    "jcr:createdBy": "mm7471",
                    "path": "/content/sharedcontent/en/legal/details-pages/legal-id-242/jcr:content/warrantypar/warrantyinfo_0",
                    "jcr:created": "Wed Jan 11 2017 16:45:18 GMT-0800",
                    "jcr:lastModified": "Wed Jan 11 2017 16:46:44 GMT-0800",
                    "jcr:primaryType": "nt:unstructured"
                },
                "legaldetailsreferenc_4": {
                    "jcr:lastModifiedBy": "mm7471",
                    "sling:resourceType": "att/mobile/wireless/components/legal/legaldetailsreference",
                    "jcr:createdBy": "mm7471",
                    "path": "/content/sharedcontent/en/legal/details-pages/legal-id-247/jcr:content/warrantypar/warrantyinfo_1",
                    "jcr:created": "Wed Jan 11 2017 16:45:28 GMT-0800",
                    "jcr:lastModified": "Thu Jan 12 2017 14:50:42 GMT-0800",
                    "jcr:primaryType": "nt:unstructured"
                },
                "legaldetailsreferenc_5": {
                    "jcr:lastModifiedBy": "mm7471",
                    "sling:resourceType": "att/mobile/wireless/components/legal/legaldetailsreference",
                    "jcr:createdBy": "mm7471",
                    "path": "/content/sharedcontent/en/legal/details-pages/legal-id-214/jcr:content/warrantypar/warrantyinfo_7",
                    "jcr:created": "Wed Jan 11 2017 16:45:29 GMT-0800",
                    "jcr:lastModified": "Wed Jan 11 2017 16:47:25 GMT-0800",
                    "jcr:primaryType": "nt:unstructured"
                },
                "legaldetailsreferenc_6": {
                    "jcr:lastModifiedBy": "mm7471",
                    "sling:resourceType": "att/mobile/wireless/components/legal/legaldetailsreference",
                    "jcr:createdBy": "mm7471",
                    "path": "/content/sharedcontent/en/legal/details-pages/legal-id-214/jcr:content/warrantypar/warrantyinfo_10",
                    "jcr:created": "Wed Jan 11 2017 16:45:29 GMT-0800",
                    "jcr:lastModified": "Wed Jan 11 2017 16:47:40 GMT-0800",
                    "jcr:primaryType": "nt:unstructured"
                },
                "legaldetailsreferenc_7": {
                    "jcr:lastModifiedBy": "mm7471",
                    "sling:resourceType": "att/mobile/wireless/components/legal/legaldetailsreference",
                    "jcr:createdBy": "mm7471",
                    "path": "/content/sharedcontent/en/legal/details-pages/legal-id-94/jcr:content/warrantypar/warrantyinfo_6",
                    "jcr:created": "Wed Jan 11 2017 16:45:30 GMT-0800",
                    "jcr:lastModified": "Wed Jan 11 2017 16:47:51 GMT-0800",
                    "jcr:primaryType": "nt:unstructured"
                },
                "legaldetailsreferenc_8": {
                    "jcr:lastModifiedBy": "mm7471",
                    "sling:resourceType": "att/mobile/wireless/components/legal/legaldetailsreference",
                    "jcr:createdBy": "mm7471",
                    "path": "/content/sharedcontent/en/legal/details-pages/legal-id-30/jcr:content/warrantypar/warrantyinfo_1",
                    "jcr:created": "Wed Jan 11 2017 16:45:30 GMT-0800",
                    "jcr:lastModified": "Wed Jan 11 2017 16:48:00 GMT-0800",
                    "jcr:primaryType": "nt:unstructured"
                },
                "legaldetailsreferenc_9": {
                    "jcr:lastModifiedBy": "mm7471",
                    "sling:resourceType": "att/mobile/wireless/components/legal/legaldetailsreference",
                    "jcr:createdBy": "mm7471",
                    "path": "/content/sharedcontent/en/legal/details-pages/legal-id-401/jcr:content/warrantypar/warrantyinfo_16",
                    "jcr:created": "Wed Jan 11 2017 16:45:34 GMT-0800",
                    "jcr:lastModified": "Wed Jan 11 2017 16:48:24 GMT-0800",
                    "jcr:primaryType": "nt:unstructured"
                },
                "legaldetailsreferenc_10": {
                    "jcr:lastModifiedBy": "mm7471",
                    "sling:resourceType": "att/mobile/wireless/components/legal/legaldetailsreference",
                    "jcr:createdBy": "mm7471",
                    "path": "/content/sharedcontent/en/legal/details-pages/legal-id-401/jcr:content/warrantypar/warrantyinfo_0",
                    "jcr:created": "Wed Jan 11 2017 16:45:35 GMT-0800",
                    "jcr:lastModified": "Wed Jan 11 2017 16:48:13 GMT-0800",
                    "jcr:primaryType": "nt:unstructured"
                },
                "legaldetailsreferenc_11": {
                    "jcr:lastModifiedBy": "mm7471",
                    "sling:resourceType": "att/mobile/wireless/components/legal/legaldetailsreference",
                    "jcr:createdBy": "mm7471",
                    "path": "/content/sharedcontent/en/legal/details-pages/legal-id-40/jcr:content/warrantypar/warrantyinfo_2",
                    "jcr:created": "Wed Jan 11 2017 16:45:36 GMT-0800",
                    "jcr:lastModified": "Wed Jan 11 2017 16:48:36 GMT-0800",
                    "jcr:primaryType": "nt:unstructured"
                },
                "legaldetailsreferenc_12": {
                    "jcr:lastModifiedBy": "mm7471",
                    "sling:resourceType": "att/mobile/wireless/components/legal/legaldetailsreference",
                    "jcr:createdBy": "mm7471",
                    "path": "/content/sharedcontent/en/legal/details-pages/legal-id-41/jcr:content/warrantypar/warrantyinfo_5",
                    "jcr:created": "Wed Jan 11 2017 16:45:36 GMT-0800",
                    "jcr:lastModified": "Wed Jan 11 2017 16:48:47 GMT-0800",
                    "jcr:primaryType": "nt:unstructured"
                },
                "legaldetailsreferenc_13": {
                    "jcr:lastModifiedBy": "mm7471",
                    "sling:resourceType": "att/mobile/wireless/components/legal/legaldetailsreference",
                    "jcr:createdBy": "mm7471",
                    "path": "/content/sharedcontent/en/legal/details-pages/legal-id-214/jcr:content/warrantypar/warrantyinfo_8",
                    "jcr:created": "Wed Jan 11 2017 16:45:37 GMT-0800",
                    "jcr:lastModified": "Wed Jan 11 2017 16:48:58 GMT-0800",
                    "jcr:primaryType": "nt:unstructured"
                },
                "legaldetailsreferenc_14": {
                    "jcr:lastModifiedBy": "mm7471",
                    "sling:resourceType": "att/mobile/wireless/components/legal/legaldetailsreference",
                    "jcr:createdBy": "mm7471",
                    "path": "/content/sharedcontent/en/legal/details-pages/legal-id-401/jcr:content/warrantypar/warrantyinfo_17",
                    "jcr:created": "Wed Jan 11 2017 16:45:41 GMT-0800",
                    "jcr:lastModified": "Wed Jan 11 2017 16:49:08 GMT-0800",
                    "jcr:primaryType": "nt:unstructured"
                },
                "legaldetailsreferenc_3": {
                    "jcr:lastModifiedBy": "mb3601",
                    "sling:resourceType": "att/mobile/wireless/components/legal/legaldetailsreference",
                    "jcr:createdBy": "mb3601",
                    "path": "/content/sharedcontent/en/legal/details-pages/legal-id-302/jcr:content/warrantypar/warrantyinfo",
                    "jcr:created": "Wed Jan 25 2017 09:25:00 GMT-0800",
                    "jcr:lastModified": "Wed Jan 25 2017 09:25:10 GMT-0800",
                    "jcr:primaryType": "nt:unstructured"
                },
                "legaldetailsreferenc_15": {
                    "jcr:lastModifiedBy": "mm7471",
                    "sling:resourceType": "att/mobile/wireless/components/legal/legaldetailsreference",
                    "jcr:createdBy": "mm7471",
                    "path": "/content/sharedcontent/en/legal/details-pages/legal-id-6/jcr:content/warrantypar/warrantyinfo",
                    "jcr:created": "Wed Jan 11 2017 16:45:41 GMT-0800",
                    "jcr:lastModified": "Wed Jan 11 2017 16:49:20 GMT-0800",
                    "jcr:primaryType": "nt:unstructured"
                },
                "legaldetailsreferenc_16": {
                    "jcr:lastModifiedBy": "mm7471",
                    "sling:resourceType": "att/mobile/wireless/components/legal/legaldetailsreference",
                    "jcr:createdBy": "mm7471",
                    "path": "/content/sharedcontent/en/legal/details-pages/legal-id-2411/jcr:content/warrantypar/warrantyinfo",
                    "jcr:created": "Wed Jan 11 2017 16:45:42 GMT-0800",
                    "jcr:lastModified": "Wed Jan 11 2017 16:49:32 GMT-0800",
                    "jcr:primaryType": "nt:unstructured"
                },
                "legaldetailsreferenc_17": {
                    "jcr:lastModifiedBy": "mm7471",
                    "sling:resourceType": "att/mobile/wireless/components/legal/legaldetailsreference",
                    "jcr:createdBy": "mm7471",
                    "path": "/content/sharedcontent/en/legal/details-pages/legal-id-171/jcr:content/warrantypar/warrantyinfo_3",
                    "jcr:created": "Wed Jan 11 2017 16:45:42 GMT-0800",
                    "jcr:lastModified": "Wed Jan 11 2017 16:49:45 GMT-0800",
                    "jcr:primaryType": "nt:unstructured"
                },
                "legaldetailsreferenc_18": {
                    "jcr:lastModifiedBy": "mm7471",
                    "sling:resourceType": "att/mobile/wireless/components/legal/legaldetailsreference",
                    "jcr:createdBy": "mm7471",
                    "path": "/content/sharedcontent/en/legal/details-pages/legal-id-4/jcr:content/warrantypar/warrantyinfo",
                    "jcr:created": "Wed Jan 11 2017 16:45:43 GMT-0800",
                    "jcr:lastModified": "Wed Jan 11 2017 16:49:57 GMT-0800",
                    "jcr:primaryType": "nt:unstructured"
                },
                "reference_18": {
                    "jcr:lastModifiedBy": "mm7471",
                    "sling:resourceType": "att/mobile/wireless/components/legal/legaldetailsreference",
                    "jcr:createdBy": "mm7471",
                    "path": "/content/sharedcontent/en/legal/details-pages/made-up/jcr:content/warrantypar/warrantyinfo",
                    "jcr:created": "Wed Jan 11 2017 16:45:43 GMT-0800",
                    "jcr:lastModified": "Wed Jan 11 2017 16:49:57 GMT-0800",
                    "jcr:primaryType": "nt:unstructured"
                }
            }
        },
        "get_shared_content": {
            url_match: /\/shop\/wireless\/legal.sharedcontentdetailsasjson.html/,
            response_code: 200,
            params_sent: '?path=/legal/details-pages/legal-id-26c/jcr:content/warrantypar/warrantyinfo_0&path=/legal/details-pages/legal-id-191/jcr:content/warrantypar/warrantyinfo_2',
            result: {
                "/legal/details-pages/legal-id-171/jcr:content/warrantypar/warrantyinfo_3": {
                    "description": ["&lt;p&gt;TM and &copy; 2016 Apple Inc. All rights reserved.&lt;/p&gt;\n"],
                    "jcr:lastModifiedBy": ["mm7471"],
                    "sling:resourceType": ["att/wireless/components/warrantyinfo"],
                    "jcr:createdBy": ["mm7471"],
                    "resourcepath": ["/content/sharedcontent/en/legal/details-pages/legal-id-171/jcr:content/warrantypar/warrantyinfo_3"],
                    "jcr:created": ["2015-09-10T13:26:35.767-07:00"],
                    "jcr:lastModified": ["2016-03-22T22:56:13.850-07:00"],
                    "jcr:primaryType": ["nt:unstructured"]
                },
                "/legal/details-pages/legal-id-26c/jcr:content/warrantypar/warrantyinfo_0": {
                    "description": ["&lt;p&gt;&lt;b&gt;Limited 4G LTE availability in select markets. LTE is a trademark of ETSI. Learn more at att.com/network.&lt;/b&gt;&lt;/p&gt;\n"],
                    "jcr:lastModifiedBy": ["rp1240"],
                    "sling:resourceType": ["att/wireless/components/warrantyinfo"],
                    "jcr:createdBy": ["rp1240"],
                    "jcr:created": ["2013-02-13T10:20:39.408-08:00"],
                    "jcr:lastModified": ["2013-02-20T14:32:33.018-08:00"],
                    "jcr:primaryType": ["nt:unstructured"]
                }
            }
        },
        "get_device_shared_content": {
            url_match: /\/shop\/wireless\/legal.sharedcontentdetailsasjson.html/,
            response_code: 200,
            params_sent: '?path=/Device_Insurance_Options/sku5370279',
            result: {
                "/Device_Insurance_Options/sku5370279": {
                    "jcr:description": ["&lt;ul&gt;\n&lt;li&gt;Coverage against loss, theft, damage, and out-of-warranty malfunctions for one eligible device.&lt;/li&gt;\n&lt;li&gt;Personalized device help from our ProTech support experts.&lt;/li&gt;\n&lt;li&gt;50GB of storage to back up and restore content, and locate and alarm capabilities with the Protect Plus app.&lt;/li&gt;\n&lt;/ul&gt;"],
                    "sling:resourceType": ["att/wireless/components/page/sharedcontent/devices/warrantyinfo"],
                    "jcr:uuid": ["80a18eec-3c5b-4187-826e-36c3bbb3ba25"],
                    "jcr:mixinTypes": ["mix:lockable"],
                    "jcr:title": ["sku5370279"],
                    "attcms:currentProject": ["BFOPT_SHOP"],
                    "jcr:created": ["2015-06-12T17:55:57.568+05:30"],
                    "cq:lastReplicationAction": ["Activate"],
                    "jcr:baseVersion": ["ba4f892a-8cdf-4953-abfe-5524fb67f600"],
                    "jcr:primaryType": ["cq:PageContent"],
                    "cq:lastModifiedBy": ["je650v"],
                    "jcr:isCheckedOut": ["true"],
                    "cq:template": ["/apps/att/wireless/templates/sharedcontent/devices/warrantyinfo"],
                    "pageTitle": ["AT&amp;T Mobile Protection Pack"],
                    "jcr:predecessors": ["ba4f892a-8cdf-4953-abfe-5524fb67f600"],
                    "jcr:createdBy": ["admin"],
                    "jcr:versionHistory": ["f31472bc-eed2-43fc-9915-2967c82ce749"],
                    "cq:lastReplicatedBy": ["ak277p"],
                    "cq:lastModified": ["2016-02-24T19:46:00.768-08:00"],
                    "cq:lastReplicated": ["2015-09-25T16:09:08.230-07:00"],
                    "commonLegalFooter": ["/content/sharedcontent/en/legal/commonLegalFooter/commonLegalFooter"]
                }
            }
        },
        "get_content_node_with_seo_link": {
            url_match: /\/cellphones\/samsung\/galaxy-s7-edge\/jcr:content\/details\/legalpar.eternity.json/,
            response_code: 200,
            params_sent: '',
            result: {
            	"sling:resourceType": "foundation/components/parsys",
            	"jcr:primaryType": "nt:unstructured",
            	"legaldetailsreferenc_13": {
            		"jcr:lastModifiedBy": "mm7471",
            		"sling:resourceType": "att/mobile/wireless/components/legal/legaldetailsreference",
            		"jcr:createdBy": "mm7471",
            		"path": "/content/sharedcontent/en/legal/details-pages/seo-cross-link/jcr:content/warrantypar/warrantyinfo_4",
            		"jcr:created": "Fri Dec 09 2016 10:55:31 GMT-0800",
            		"jcr:lastModified": "Fri Dec 09 2016 11:02:25 GMT-0800",
            		"jcr:primaryType": "nt:unstructured"
            	},
            	"warrantyreference": {
            		"jcr:lastModifiedBy": "je650v",
            		"sling:resourceType": "att/mobile/wireless/components/legal/legaldetailsreference",
            		"path": "/content/sharedcontent/en/legal/details-pages/legal-id-17/jcr:content/warrantypar/warrantyinfo_4",
            		"jcr:lastModified": "Mon Feb 15 2016 13:24:40 GMT-0800",
            		"jcr:primaryType": "nt:unstructured"
            	},
            	"legaldetailsreferenc_8": {
            		"jcr:lastModifiedBy": "je650v",
            		"sling:resourceType": "att/mobile/wireless/components/legal/legaldetailsreference",
            		"jcr:createdBy": "je650v",
            		"path": "/content/sharedcontent/en/legal/details-pages/legal-id-18/jcr:content/warrantypar/warrantyinfo_8",
            		"jcr:created": "Fri Feb 19 2016 12:25:08 GMT-0800",
            		"jcr:lastModified": "Fri Feb 19 2016 12:25:15 GMT-0800",
            		"jcr:primaryType": "nt:unstructured"
            	},
            	"legaldetailsreferenc_9": {
            		"jcr:lastModifiedBy": "je650v",
            		"sling:resourceType": "att/mobile/wireless/components/legal/legaldetailsreference",
            		"jcr:createdBy": "je650v",
            		"path": "/content/sharedcontent/en/legal/details-pages/legal-id-18/jcr:content/warrantypar/warrantyinfo_9",
            		"jcr:created": "Mon Feb 15 2016 13:24:49 GMT-0800",
            		"jcr:lastModified": "Fri Feb 19 2016 12:24:43 GMT-0800",
            		"jcr:primaryType": "nt:unstructured"
            	},
            	"reference_2": {
            		"jcr:lastModifiedBy": "je650v",
            		"sling:resourceType": "att/mobile/wireless/components/legal/legaldetailsreference",
            		"path": "/content/sharedcontent/en/legal/details-pages/legal-id-18/jcr:content/warrantypar/warrantyinfo_10",
            		"jcr:lastModified": "Fri Feb 19 2016 12:24:51 GMT-0800",
            		"jcr:primaryType": "nt:unstructured"
            	},
            	"legaldetailsreferenc_6": {
            		"jcr:lastModifiedBy": "je650v",
            		"sling:resourceType": "att/mobile/wireless/components/legal/legaldetailsreference",
            		"jcr:createdBy": "mm7471",
            		"path": "/content/sharedcontent/en/legal/details-pages/legal-id-213/jcr:content/warrantypar/warrantyinfo_2",
            		"jcr:created": "Tue Jan 26 2016 11:25:38 GMT-0800",
            		"jcr:lastModified": "Fri Feb 19 2016 12:25:27 GMT-0800",
            		"jcr:primaryType": "nt:unstructured"
            	},
            	"legaldetailsreferenc_3": {
            		"jcr:lastModifiedBy": "mb3601",
            		"sling:resourceType": "att/mobile/wireless/components/legal/legaldetailsreference",
            		"jcr:createdBy": "mb3601",
            		"path": "/content/sharedcontent/en/legal/details-pages/legal-id-302/jcr:content/warrantypar/warrantyinfo_1",
            		"jcr:created": "Wed Jan 25 2017 09:34:10 GMT-0800",
            		"jcr:lastModified": "Tue Jan 31 2017 12:29:50 GMT-0800",
            		"jcr:primaryType": "nt:unstructured"
            	},
            	"legaldetailsreferenc": {
            		"jcr:lastModifiedBy": "je650v",
            		"sling:resourceType": "att/mobile/wireless/components/legal/legaldetailsreference",
            		"jcr:createdBy": "je650v",
            		"path": "/content/sharedcontent/en/legal/details-pages/legal-id-99/jcr:content/warrantypar/warrantyinfo_3",
            		"jcr:created": "Fri Feb 19 2016 12:27:39 GMT-0800",
            		"jcr:lastModified": "Fri Feb 19 2016 12:28:38 GMT-0800",
            		"jcr:primaryType": "nt:unstructured"
            	},
            	"legaldetailsreferenc_0": {
            		"jcr:lastModifiedBy": "mb3601",
            		"sling:resourceType": "att/mobile/wireless/components/legal/legaldetailsreference",
            		"jcr:createdBy": "mb3601",
            		"path": "/content/sharedcontent/en/legal/details-pages/legal-id-300/jcr:content/warrantypar/warrantyinfo",
            		"jcr:created": "Wed Jan 18 2017 10:59:55 GMT-0800",
            		"jcr:lastModified": "Wed Jan 18 2017 11:00:59 GMT-0800",
            		"jcr:primaryType": "nt:unstructured"
            	},
            	"legaldetailsreferenc_10": {
            		"jcr:lastModifiedBy": "mb3601",
            		"sling:resourceType": "att/mobile/wireless/components/legal/legaldetailsreference",
            		"jcr:createdBy": "mb3601",
            		"path": "/content/sharedcontent/en/legal/details-pages/legal-id-300/jcr:content/warrantypar/warrantyinfo_2",
            		"jcr:created": "Mon Jun 05 2017 12:35:35 GMT-0700",
            		"jcr:lastModified": "Mon Jun 05 2017 12:35:42 GMT-0700",
            		"jcr:primaryType": "nt:unstructured"
            	},
            	"legaldetailsreferenc_11": {
            		"jcr:lastModifiedBy": "je650v",
            		"sling:resourceType": "att/mobile/wireless/components/legal/legaldetailsreference",
            		"jcr:createdBy": "je650v",
            		"path": "/content/sharedcontent/en/legal/details-pages/legal-id-157/jcr:content/warrantypar/warrantyinfo",
            		"jcr:created": "Fri Mar 04 2016 09:43:14 GMT-0800",
            		"jcr:lastModified": "Fri Mar 04 2016 09:43:26 GMT-0800",
            		"jcr:primaryType": "nt:unstructured"
            	},
            	"legaldetailsreferenc_7": {
            		"jcr:lastModifiedBy": "je650v",
            		"sling:resourceType": "att/mobile/wireless/components/legal/legaldetailsreference",
            		"jcr:createdBy": "mm7471",
            		"path": "/content/sharedcontent/en/legal/details-pages/legal-id-12/jcr:content/warrantypar/warrantyinfo_8",
            		"jcr:created": "Sun Feb 14 2016 23:14:08 GMT-0800",
            		"jcr:lastModified": "Fri Feb 19 2016 12:25:59 GMT-0800",
            		"jcr:primaryType": "nt:unstructured"
            	},
            	"legaldetailsreferenc_1": {
            		"jcr:lastModifiedBy": "je650v",
            		"sling:resourceType": "att/mobile/wireless/components/legal/legaldetailsreference",
            		"jcr:createdBy": "je650v",
            		"path": "/content/sharedcontent/en/legal/details-pages/legal-id-6/jcr:content/warrantypar/warrantyinfo",
            		"jcr:created": "Mon Jan 04 2016 16:24:03 GMT-0800",
            		"jcr:lastModified": "Fri Feb 19 2016 12:26:36 GMT-0800",
            		"jcr:primaryType": "nt:unstructured"
            	},
            	"legaldetailsreferenc_5": {
            		"jcr:lastModifiedBy": "je650v",
            		"sling:resourceType": "att/mobile/wireless/components/legal/legaldetailsreference",
            		"jcr:createdBy": "je650v",
            		"path": "/content/sharedcontent/en/legal/details-pages/legal-id-2411/jcr:content/warrantypar/warrantyinfo",
            		"jcr:created": "Mon Jan 04 2016 19:41:49 GMT-0800",
            		"jcr:lastModified": "Fri Feb 19 2016 12:26:45 GMT-0800",
            		"jcr:primaryType": "nt:unstructured"
            	},
            	"legaldetailsreferenc_2": {
            		"jcr:lastModifiedBy": "je650v",
            		"sling:resourceType": "att/mobile/wireless/components/legal/legaldetailsreference",
            		"jcr:createdBy": "js1652",
            		"path": "/content/sharedcontent/en/legal/details-pages/legal-id-4/jcr:content/warrantypar/warrantyinfo",
            		"jcr:created": "Wed Jul 08 2015 10:39:52 GMT-0700",
            		"jcr:lastModified": "Fri Feb 19 2016 12:26:54 GMT-0800",
            		"jcr:primaryType": "nt:unstructured"
            	},
            	"legaldetailsreferenc_4": {
            		"jcr:lastModifiedBy": "cw251a",
            		"sling:resourceType": "att/mobile/wireless/components/legal/legaldetailsreference",
            		"jcr:createdBy": "cw251a",
            		"path": "/content/sharedcontent/en/legal/details-pages/legal-id-157/jcr:content/warrantypar/warrantyinfo_14",
            		"jcr:created": "Mon May 01 2017 11:58:01 GMT-0700",
            		"jcr:lastModified": "Mon May 01 2017 11:58:09 GMT-0700",
            		"jcr:primaryType": "nt:unstructured"
            	}
            }
        }
    }
})();