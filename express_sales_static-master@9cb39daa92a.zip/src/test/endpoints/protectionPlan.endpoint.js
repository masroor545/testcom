/**
 * Test responses for the protection feature service.
 *
 * @example
 * $httpBackend.whenGET(Endpoint_protectionApi.get_insurance_features.url_match)
 *      .respond(200, Endpoint_protectionApi.get_insurance_features.result);
 */
var Endpoint_protectionApi = (function () {
    'use strict';

    return {
        /**
         * Get the recommended protection plan for the in cart items and account items.
         */
        'get_insurance_features': {
            url_match: /\/services\/shopwireless\/model\/att\/ecom\/api\/CatalogServiceController\/catalogService/,
            response_code: 200,
            params_sent: '?actionType=getexupinsurancefeatures',
            result: {
            	  "response": {
            		    "redirectKey": null,
            		    "errors": null,
            		    "status": "success",
            		    "subStatus": null,
            		    "redirectURL": null,
            		    "redirect": false
            		  },
            		  "payload": {"sku5370279": {
            		    "mRCDetailsBean": {
            		      "promotionDetailsBean": null,
            		      "finalMRCPrice": 10.99,
            		      "MRCPriceAdjustments": {},
            		      "baseMRCPriceAfterPromo": 0,
            		      "mrcModifierPromo": false,
            		      "baseMRCPrice": 10.99
            		    },
            		    "adminDisplayName": "Active- AT&T Mobile Protection Pack - QSBNDLMRC",
            		    "isAccountLevelFeature": false,
            		    "description": "Get the benefits of Mobile Insurance, plus personalized support from ProTech experts, and the Protect Plus app with 50GB of backup storage.\nEffective April 21, 2017, the monthly charge is $11.99 for each mobile number enrolled.",
            		    "skuId": "sku5370279",
            		    "displayName": "AT&T Mobile Protection Pack",
            		    "mrc": 10.99,
            		    "variableDiscountSkuEligible": false,
            		    "productId": "prod5280349"
            		  }}
            }
        },
        'insurance_features_not_available': {
            url_match: /\/services\/shopwireless\/model\/att\/ecom\/api\/CatalogServiceController\/catalogService/,
            response_code: 200,
            params_sent: '?actionType=getexupinsurancefeatures',
            result: {
                    "response": {
                        "redirectKey": null,
                        "errors": null,
                        "status": "success",
                        "subStatus": null,
                        "redirectURL": null,
                        "redirect": false
                    }
            }
        }

    };
})();
