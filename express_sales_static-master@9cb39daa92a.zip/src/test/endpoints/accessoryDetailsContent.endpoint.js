/**
 * Various test responses for the accessory detail legacy service
 *
 * @example
 * $httpBackend.whenGET(Endpoint_accessoryDetailLegacyNode.get_legacy_content.url_match)
 *      .respond(200, Endpoint_accessoryDetailLegacyNode.get_legacy_content.result);
 */
var Endpoint_accessoryDetailLegacyNode = (function () {
    'use strict';

    return {
        "get_legacy_content": {
            url_match: /\/cases\/otterbox-defender-series-way-case-and-holster-iphone-7-plus\/jcr:content\/accessorytabs\/detailsoverviewpar\/text.json/,
            response_code: 200,
            params_sent: '',
            result: '<p>Worry less while you’re on the job. Defender Series combines three ultra-tough layers to guard your device against serious drops, dirt, scrapes, and bumps. The built-in screen film stops display scratches, plus the included holster gives you the quick draw on calls and texts. Defender Series works hard to protect your device.<br> ' +
                '<br> ' +
                'Built tough like you, Defender Series isn’t some sissy case. Three ultra-rugged and tough layers combine to guard against the roughest drops, scrapes, bumps, dust, and grime. Defender Series clips on your belt are ready to do anything with you — from GPS navigation to the call home for dinner. Rugged protection gives you what you need.<br> ' +
                '<br> ' +
                'You don’t have time to worry about your case doing its job while you do yours. That’s why Defender Series inner and outer layers work together to keep your phone safe. Plus, the built-in touchscreen protector keeps your display clean from scratches, scrapes, and dirt all day long.<br> ' +
                '<br> ' +
                'Features:<br> ' +
                'Defend your device from drops, dirt, and daily adventures.<br> ' +
                '</p> ' +
                '<ul style="list-style-type: disc; margin-left: 20px;"> ' +
                '<li>Triple-layer defense: Inner shell, outer cover, and touchscreen protector.</li> ' +
                '<li>Screen protection: Built in to keep your brilliant display flawless.</li> ' +
                '<li>Port covers: Stop dirt, dust, and lint from getting into jacks and ports.</li> ' +
                '<li>Holster: Works as a belt clip and a hands-free kickstand.</li> ' +
                '</ul> ' +
                '<p>&nbsp;</p> ' +
                '<div class="dottedDivider onepix">&nbsp;</div> ' +
                '<p style="font-weight: bold; text-align: center; font-size: 20px;">Compatible Devices</p> ' +
                '<table class="table margin-top-0 margin-bottom-0"> ' +
                '<tbody><tr><td style="text-align: center;"><a href="https://www.att.com/cellphones/iphone/iphone-7-plus.html" target="_blank" data-cqpath="18860169722222105608779781310003265193;2016322"><img src="/catalog/en/skus/images/apple-iphone%207%20plus%20128gb-rose%20gold-160x160.jpg"></a></td> ' +
                '</tr><tr><td class="center"><a style="font-size: 14px;" href="https://www.att.com/cellphones/iphone/iphone-7-plus.html" target="_blank" data-cqpath="18860169722222105608779781310003265193;2016322">Apple iPhone 7 Plus</a></td> ' +
                '</tr></tbody></table> ' +
                '<div class="dottedDivider onepix">&nbsp;</div> '
        }
    }
})();