/**
 * Various test responses for the recommended accessories content service
 *
 * @example
 * $httpBackend.whenGET(Endpoint_recommendedAccessoriesContentNode.get_content_node.url_match)
 *      .respond(200, Endpoint_recommendedAccessoriesContentNode.get_content_node.result);
 */
var Endpoint_recommendedAccessoriesContentNode = (function () {
    'use strict';

    return {
        "get_content_node": {
            url_match: /\/cellphones\/iphone\/apple-iphone-7\/jcr:content\/recommendedAccessories.eternity.json/,
            response_code: 200,
            params_sent: '',
            result: {
                "bundleTitle": "Frequently Purchased Together<br><p style='font-size: 13px;'>Add accessories to the cart prior to adding the device, and the accessories will display at checkout.</p>",
                "title": "Recommended Accessories<br><p style='font-size: 13px;'>Add accessories to the cart prior to adding the device, and the accessories will display at checkout.</p>",
                "jcr:lastModifiedBy": "wd7979",
                "sling:resourceType": "att/wireless/components/accessories/accessorycarousel",
                "skuList": "sku8140322,sku8030508,sku8030526,sku8030505,sku7880415,sku8030539,sku8030521,sku8030506,sku8040246,sku8030548,sku8000354,sku8030507,sku8030479,sku8040248,sku8030488,sku8030515,sku7900275,sku7700371,sku7750821,sku7880417,sku7880418, sku8040292, sku8040290, sku8040288, sku8040291, sku8040289, sku8040300, sku8040301, sku8040303, sku8040302, sku8500247",
                "showCatSelDetail": "true",
                "jcr:lastModified": "Mon Jan 29 2018 08:38:38 GMT-0800",
                "jcr:primaryType": "nt:unstructured",
                "allowPromotion": "CCSBA"
            }
        }
    }
})();