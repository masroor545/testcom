var Endpoint_validateBuyflowDataApi = (function () {
    'use strict';

    return {

        'validate_buyflow_data': {
            url_match: /services\/shopwireless\/model\/att\/ecom\/api\/BuyFlowController\/service/,
            response_code: 200,
            result: {
                'response': {
                    'redirectKey': null,
                    'errors': null,
                    'status': 'success',
                    'subStatus': null,
                    'redirectURL': null,
                    'redirect': true
                }
            }
        }
    };
})();
