var Endpoint_upgradePaymentPost = (function () {
    'use strict';

    return {

        /**
         * Gets response to redirect to next page from tradein consent page.
         */

        'upgrade_payment_post': {
            url_match: /\/apis\/checkout\/upgradepayment\/v1\/postUpgradePayment\/976b99d3-9220-0054-61f3-a745c98d6bd2.*/,
            response_code: 200,
            params_sent: '?',
            result: {
                'response': {
                    "status": "SUCCESS",
                    "redirect": false
                },
                "payload": {
                    "ReferenceInformation": "1013075606"
                }
            }
            // End result
        },

        /**
         * Gets postUpgradePayment failure response on submit payment.
         */

        'upgrade_payment_post_failure': {
            url_match: /\/apis\/checkout\/upgradepayment\/v1\/postUpgradePayment\/976b99d3-9220-0054-61f3-a745c98d6bd2.*/,
            response_code: 200,
            params_sent: '?',
            result: {
                "response": {
                    "status": "FAILED",
                    "redirect": false,
                    "errors": [
                        {
                            "code": "DETCS3000010",
                            "message": "Card Number is Not Valid.",
                            "field": null,
                            "rootCauseInfo": ""
                        },
                        {
                            "code": "DETCS300007",
                            "message": "USLE_DATA_ERROR:Data Error (Caused by: CSIE_300203836002:invoiceNumber Is Invalid):CSI Conversation Id: buyonline~CNG-CSI~a9f14d56-5d9c-46d2-81bd-f1c7f437c0ba",
                            "field": null,
                            "rootCauseInfo": null
                        }
                    ]
                }
            }
            // End result
        }
    };
})();