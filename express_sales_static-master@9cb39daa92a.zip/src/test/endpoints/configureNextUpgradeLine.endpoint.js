var Endpoint_configureNextUpgradeLine = (function () {
    'use strict';

    return {
        /**
         * Test response for configureNextUpgradeLine api.
         */
        'proceed_to_continue': {
            url_match: /services\/shopwireless\/model\/att\/ecom\/api\/WirelessUpgradeSelectionActor\/configureNextUpgradeLine/,
            response_code: 200,
            result: {
                'response': {
                    'redirectKey': null,
                    'errors': null,
                    'status': 'success',
                    'subStatus': null,
                    'redirectURL': '/shop/xpress/device-recommender.html',
                    'redirect': true
                }
            }
        }
    };
})();