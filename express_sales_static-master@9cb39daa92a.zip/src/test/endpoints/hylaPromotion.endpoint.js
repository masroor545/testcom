/**
 * Responses for the hyla promotion offer service.
 */
var Endpoint_hylaPromotion = (function () {
    'use strict';

    return {
        /**
         * Get the hyla promotion offer, it returns same response for every device and every user.
         */
        'hyla_promotion_legal_details': {
            url_match: /\/shop\/wireless\/legal.sharedcontentdetailsasjson.html/,
            response_code: 200,
            params_sent: '?path=offercontent/hylaOffer',
            result: {
                "offercontent/hylaOffer": {
                    "jcr:description": [
                        "&lt;p style=&quot;font-weight: 400; font-size: 14px; margin-bottom: 0px&quot;&gt;&lt;strong&gt;SAMSUNG GALAXY S8 INTEGRATED BOGO: Limited Time Offer (ends 5/31/17 in Puerto Rico).&lt;/strong&gt; &amp;nbsp;Select locations. &amp;nbsp;&lt;strong&gt;Elig. Devices:&lt;/strong&gt; Samsung Galaxy S8, S8+, Galaxy S7, Galaxy S7 Active, and Galaxy S7 Edge on 0% APR AT&amp;amp;T Next (30-mo. at $25) or AT&amp;amp;T Next Every Year (24-mo. at $31.25) installment agmts. $0 down for well-qualified credit or down payment may be req&rsquo;d. Retail price is divided into monthly installments. &lt;strong&gt;Tax on full retail price due at sale.&lt;/strong&gt; &amp;nbsp;After all credits, get S8 up to $750 (credits are $25/mo. or $31.25/mo.) for free. &amp;nbsp;May apply max credit towards S8+ devices priced up to $850, which will be discounted but not free. &amp;nbsp;May also apply credit towards Galaxy S7 (priced at $595, credits are 30-mo. at $19.84 or 24-mo. at $24.80) or to Galaxy S7 Edge or S7 Active (priced at $695, credits are 30-mo. at $23.17 or 24-mo. at $28.96). &amp;nbsp;&lt;strong&gt;Wireless:&lt;/strong&gt; Monthly postpaid voice &amp;amp; data plan req&rsquo;d on both (existing customers can add to elig. current plans). &lt;strong&gt;If you cancel service you will owe device balance of up to $850. &amp;nbsp;DIRECTV:&lt;/strong&gt; Excludes streaming only svcs. If new customer, 24-month agmt req&rsquo;d. Must be installed w/in 30 days of device activation to receive credits; if svc cannot be installed must return device w/in 14 days of notification from AT&amp;amp;T or will owe device balance of up to $850. &amp;nbsp;&lt;strong&gt;Bill Credit:&lt;/strong&gt; &amp;nbsp;Applied in equal amounts based on lower priced device over entire agmt term &amp;amp; will not exceed $750 for S8 or S8+ and will not exceed $695 for Samsung Galaxy S7, S7 Edge, and S7 Active. Addresses for TV and wireless accounts must match and both wireless lines must be on same acct, be active &amp;amp; in good standing for 30 days to qualify. &amp;nbsp;To get all credits (up to max bill credit of lower priced device), free/discounted wireless line and TV service must remain active and on agmts for entire term. If upgrade or pay up/off agmts early your credits may cease. &lt;strong&gt;Offer Limits:&lt;/strong&gt; May not be combinable w/ other offers, discounts or credits. Participation in this offer may make your wireless account ineligible for select other offers (including select bill credit offers) for a 12 month period. &amp;nbsp;&lt;strong&gt;Return:&lt;/strong&gt; Restocking fee up to $45 may apply. See store or &lt;a href=&quot;att.com/buyonegiveone&quot; target=&quot;_blank&quot; rel=&quot;noopener&quot;&gt;att.com/buyonegiveone&lt;/a&gt; for offer details.&lt;/p&gt;\n        \n&lt;p style=&quot;font-weight: 400; font-size: 14px;margin-top:30px; margin-bottom: 0px&quot;&gt;&lt;strong&gt;GEN. WIRELESS SVC: &lt;a href=&quot;att.com/wca&quot; target=&quot;_blank&quot; rel=&quot;noopener&quot;&gt;Subj. to Wireless Customer Agmt&lt;/a&gt;&lt;/strong&gt;. &lt;strong&gt;Deposit:&lt;/strong&gt; may apply. &lt;strong&gt;Limits:&lt;/strong&gt; Purch. limits apply. &lt;strong&gt;Activation:&lt;/strong&gt; $25 Fee. Credit approval, taxes, fees, monthly, other charges, usage, speed, coverage &amp;amp; other restrs apply. See &lt;a href=&quot;att.com/additionalcharges&quot; target=&quot;_blank&quot; rel=&quot;noopener&quot;&gt;att.com/additionalcharges&lt;/a&gt; for details on fees &amp;amp; charges. &lt;strong&gt;Promotion, terms, &amp;amp; restr&rsquo;s subject to change &amp;amp; may be modified or terminated at any time without notice.&lt;/strong&gt; &amp;nbsp;AT&amp;amp;T service is subject to AT&amp;amp;T network management policies. See &lt;a href=&quot;att.com/broadbandinfo&quot; target=&quot;_blank&quot; rel=&quot;noopener&quot;&gt;att.com/broadbandinfo&lt;/a&gt; for details.&lt;/p&gt;\n        \n&lt;p style=&quot;font-weight: 400; font-size: 14px;margin-top:30px; margin-bottom: 0px&quot;&gt;&lt;strong&gt;DIRECTV: &amp;nbsp;&lt;a href=&quot;directv.com/legal&quot; target=&quot;_blank&quot; rel=&quot;noopener&quot;&gt;Subj. to Equip. Lease &amp;amp; Customer Agreements&lt;/a&gt;&lt;/strong&gt;. Residential customers only. Hardware and programming avail. separately. Early termination fee of $20/mo. for each mo. remaining on agmt., $35 activation, equipment non-return &amp;amp; add&rsquo;l fees apply. Programming, pricing, terms &amp;amp; conditions subject to change at any time.&lt;/p&gt;"
                    ],
                    "sling:resourceType": [
                        "att/wireless/components/page/sharedcontent/devices/warrantyinfo"
                    ],
                    "jcr:uuid": [
                        "f1619451-16fe-4d59-bb3e-53c8a1dfb35d"
                    ],
                    "jcr:title": [
                        "hylaOffer"
                    ],
                    "jcr:mixinTypes": [
                        "mix:versionable"
                    ],
                    "subtitle": [
                        "*Each req&rsquo;s $750 on installment agmt &amp; elig. svc. Req&rsquo;s a new line. Free after $750 in credits over 30 months. Credits start in 2 to 3 bills. If svc cancelled, device balance due. Taxes &amp; fees apply. For email: add at end &ldquo;See details below.&rdquo; For direct mail &ndash; (if Bottom legal is on a different page): Limited Time Offer (ends 5/31/17 in Puerto Rico).  Req&rsquo;s well-qual. credit.  Free after $750 in bill credits over 30 mos.  Credits start in 2-3 bills.  If svc cancelled, device balance due.  Taxes &amp; fees apply.  See att.com/buyonegiveone for more details."
                    ],
                    "jcr:created": [
                        "2017-07-21T17:24:32.982-07:00"
                    ],
                    "jcr:baseVersion": [
                        "a819c94d-4e1c-4ab3-bd69-9923d0046b20"
                    ],
                    "navTitle": [
                        "Buy a Samsung Galaxy S8, and get one free when you buy both on AT&amp;amp;T Next&lt;sup&gt;&amp;reg;&lt;/sup&gt; with monthly eligible wireless (min. 1&lt;sup&gt;st&lt;/sup&gt; line $50; 2&lt;sup&gt;nd&lt;/sup&gt; line $20) and DIRECTV service (min. $29.99/mo.)."
                    ],
                    "cq:lastModifiedBy": [
                        "gk1204"
                    ],
                    "jcr:primaryType": [
                        "cq:PageContent"
                    ],
                    "jcr:isCheckedOut": [
                        "true"
                    ],
                    "cq:template": [
                        "/apps/att/wireless/templates/sharedcontent/devices/warrantyinfo"
                    ],
                    "pageTitle": [
                        "Get an Iphone 7 32 GB on NEXT for FREE"
                    ],
                    "jcr:predecessors": [
                        "a819c94d-4e1c-4ab3-bd69-9923d0046b20"
                    ],
                    "jcr:createdBy": [
                        "admin"
                    ],
                    "jcr:versionHistory": [
                        "35db25d6-0caa-4616-8eb3-90767fd03d32"
                    ],
                    "cq:lastModified": [
                        "2017-07-21T17:10:22.922-07:00"
                    ],
                    "commonLegalFooter": [
                        "/content/sharedcontent/en/legal/commonLegalFooter/commonLegalFooter"
                    ]
                }
            }
        }
    };

})();