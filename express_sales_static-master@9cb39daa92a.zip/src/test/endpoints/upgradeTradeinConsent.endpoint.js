var Endpoint_expressTradeinConsent = (function () {
    'use strict';

    return {

        /**
         * Gets response to redirect to next page from tradein consent page.
         */

        'express_tradein_consent': {
            url_match: /\/services\/shopwireless\/model\/att\/ecom\/api\/WirelessUpgradeSelectionActor\/expressTradeIn.*/,
            response_code: 200,
            params_sent: '?',
            result: {
                'response': {
                    'redirectKey': 'url.xpress.page.deviceRecommender',
                    'errors': null,
                    'status': 'success',
                    'subStatus': null,
                    'redirect': true
                }
            }
            // End result
        }
    };
})();