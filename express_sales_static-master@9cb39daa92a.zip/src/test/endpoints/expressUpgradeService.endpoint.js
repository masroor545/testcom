var Endpoint_expressUpgradeApi = (function () {
    'use strict';

    return {

        /**
         * Gets response to redirect to next page from upgrade eligibility page
         */

        'express_upgrade': {
            url_match: /\/services\/shopwireless\/model\/att\/ecom\/api\/WirelessUpgradeSelectionActor\/expressUpgrade.*/,
            response_code: 200,
            params_sent: '?',
            result: {
                'response': {
                    'redirectKey': 'url.xpress.page.deviceRecommender',
                    "errors": [
                        {
                          "message": null,
                          "field": "errorCode.TI_102",
                          "rootCauseInfo": null,
                          "code": "atg.droplet.DropletException"
                        },
                        {
                          "message": null,
                          "field": "errorCode.TI_103",
                          "rootCauseInfo": null,
                          "code": "atg.droplet.DropletException"
                        }
                    ],
                    'status': 'success',
                    'redirectURL': null,
                    'subStatus': null,
                    'redirect': true,
                    'optionsBean': {
                    'selectedSubscriber': '4252050541',
                    'isISEFailed': 'errorCode.TI_1001'
                }
                }
            }
        },
        'express_upgrade_error': {
            url_match: /\/services\/shopwireless\/model\/att\/ecom\/api\/WirelessUpgradeSelectionActor\/expressUpgrade.*/,
            response_code: 200,
            params_sent: '?',
            result: {
                'response': {
                    'redirectKey': null,
                    'errors': [{
                        'message': null,
                        'field': 'errorCode.TI_100',
                        'rootCauseInfo': null,
                        'code': 'atg.droplet.DropletException'
                    }],
                    'status': 'error',
                    'subStatus': null,
                    'redirectURL': null,
                    'redirect': false
                },
                'optionsBean': {
                    'selectedSubscriber': '4252050541',
                    'errorCodeDetails': ['errorCode.TI_100']
                }
            }
        }
    };
})();