/**
 * Test responses for the upsell offer service
 *
 * @example
 * $httpBackend.whenGET(Endpoint_favStoreApi.get_favStore.url_match)
 *      .respond(200, Endpoint_favStoreApi.get_favStore.result);
 */
var Endpoint_favStoreApi = (function () {
    'use strict';

    return {
        'get_favStore': {
            url_match: /\/apis\/personalization\/favoriteStore\/get\/d573b967-9150-0340-4b07-6e707ca18d7c/,
            response_code: 200,
            params_sent: '',
            result: 311,
            uuid: 'd573b967-9150-0340-4b07-6e707ca18d7c'
        }
    };

})();