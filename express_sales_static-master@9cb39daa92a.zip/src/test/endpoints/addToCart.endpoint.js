/**
 * Various test responses for the add to cart service
 *
 * @example
 * $httpBackend.whenGET(addToCart.url_match)
 *      .respond(200, Endpoint_addToCart.add_to_cart.result);
 */
var Endpoint_addToCart = (function () {
    'use strict';

    return {
        'url_match': /services\/shopwireless\/model\/att\/ecom\/api\/CartServiceController\/cartService/,
        'add_to_cart': {
            'params_sent': {
                'actionType': 'addItemAndGoToNextStep'
            },
            'result': {
                'response': {
                    'redirectKey': 'url.xpress.page.accessoryServiceRecommender',
                    'errors': null,
                    'status': 'success',
                    'redirectURL': null,
                    'redirect': false
                },
                'payload': {
                    'redirectionURL': 'url.plan.planlist.planconfigurator',
                    'resultAddItems': [],
                    'originalNextStepURL': null,
                    'rollupStatus': 'SUCCESS',
                    'resultCount': 0,
                    'removeResultIncompatibleAccountItems': [],
                    'failed': false,
                    'errorResultIncompatibleCartItems': [],
                    'replaceResultIncompatibleCartItems': [],
                    'results': [],
                    'resultErrorCodes': [],
                    'removeResultIncompatibleCartItems': [],
                    'storePickUpCompatibilityError': false,
                    'redirectionURLValue': '/shop/wireless/plans/planconfigurator.html',
                    'replaceResultIncompatibleAccountItems': [],
                    'resultIncompatibleCartItemsIds': [],
                    'errorResultRequiredItems': [],
                    'promtionSKUs': null,
                    'isPromotionAvailable': false,
                    'resultIncompatibleAccountItems': [],
                    'rollUpErrorCodeValue': null,
                    'rollUpErrorCode': '',
                    'replace': false,
                    'errorResultIncompatibleAccountItems': [],
                    'successful': true,
                    'originalNextStepURLValue': null,
                    'nextStep': null,
                    'allSuccessful': true,
                    'removeConfirm': null
                }
            }
        },
        'add_to_cart_skip_redirect': {
            'params_sent': {
                'actionType': 'addItemAndGoToNextStep'
            },
            'result': {
                'response': {
                    'redirectKey': null,
                    'errors': null,
                    'status': 'success',
                    'redirectURL': null,
                    'redirect': false
                },
                'payload': {
                    'redirectionURL': 'url.plan.planlist.planconfigurator',
                    'resultAddItems': [],
                    'originalNextStepURL': null,
                    'rollupStatus': 'SUCCESS',
                    'resultCount': 0,
                    'removeResultIncompatibleAccountItems': [],
                    'failed': false,
                    'errorResultIncompatibleCartItems': [],
                    'replaceResultIncompatibleCartItems': [],
                    'results': [],
                    'resultErrorCodes': [],
                    'removeResultIncompatibleCartItems': [],
                    'storePickUpCompatibilityError': false,
                    'redirectionURLValue': '/shop/wireless/plans/planconfigurator.html',
                    'replaceResultIncompatibleAccountItems': [],
                    'resultIncompatibleCartItemsIds': [],
                    'errorResultRequiredItems': [],
                    'promtionSKUs': null,
                    'isPromotionAvailable': false,
                    'resultIncompatibleAccountItems': [],
                    'rollUpErrorCodeValue': null,
                    'rollUpErrorCode': '',
                    'replace': false,
                    'errorResultIncompatibleAccountItems': [],
                    'successful': true,
                    'originalNextStepURLValue': null,
                    'nextStep': null,
                    'allSuccessful': true,
                    'removeConfirm': null
                }
            }
        },
        'add_to_cart_fail': {
            'params_sent': {
                'actionType': 'addItemAndGoToNextStep'
            },
            'result': {
                'response': {
                    'redirectKey': null,
                    'errors': null,
                    'status': 'error',
                    'redirectURL': null,
                    'redirect': false
                },
                'payload': {
                    'redirectionURL': 'url.plan.planlist.planconfigurator',
                    'resultAddItems': [],
                    'originalNextStepURL': null,
                    'rollupStatus': 'SUCCESS',
                    'resultCount': 0,
                    'removeResultIncompatibleAccountItems': [],
                    'failed': false,
                    'errorResultIncompatibleCartItems': [],
                    'replaceResultIncompatibleCartItems': [],
                    'results': [],
                    'resultErrorCodes': [],
                    'removeResultIncompatibleCartItems': [],
                    'storePickUpCompatibilityError': false,
                    'redirectionURLValue': '/shop/wireless/plans/planconfigurator.html',
                    'replaceResultIncompatibleAccountItems': [],
                    'resultIncompatibleCartItemsIds': [],
                    'errorResultRequiredItems': [],
                    'promtionSKUs': null,
                    'isPromotionAvailable': false,
                    'resultIncompatibleAccountItems': [],
                    'rollUpErrorCodeValue': null,
                    'rollUpErrorCode': '',
                    'replace': false,
                    'errorResultIncompatibleAccountItems': [],
                    'successful': true,
                    'originalNextStepURLValue': null,
                    'nextStep': null,
                    'allSuccessful': true,
                    'removeConfirm': null
                }
            }
        },
        'upsell_add_to_cart': {
            'params_sent': {
                'actionType': 'addItemAndGoToNextStep',
                'addNewLine': 'true',
                'losgBuyFlowType': 'AL',
                'wirelessBuyFlowType': 'MIXEDCART'
            },
            'result': {
                'response': {
                    'redirectKey': 'url.device.devicelist',
                    'errors': null,
                    'status': 'success',
                    'subStatus': null,
                    'redirectURL': '/shop/xpress/accessory-service-recommender.html',
                    'redirect': true
                },
                'payload': {
                    'redirectionURL': 'url.device.devicelist',
                    'resultAddItems': [],
                    'originalNextStepURL': null,
                    'rollupStatus': 'SUCCESS',
                    'resultCount': 0,
                    'removeResultIncompatibleAccountItems': [],
                    'failed': false,
                    'errorResultIncompatibleCartItems': [],
                    'replaceResultIncompatibleCartItems': [],
                    'results': [],
                    'resultErrorCodes': [],
                    'removeResultIncompatibleCartItems': [],
                    'storePickUpCompatibilityError': false,
                    'redirectionURLValue': '/shop/wireless/devices/cellphones.allDevices.html',
                    'replaceResultIncompatibleAccountItems': [],
                    'resultIncompatibleCartItemsIds': [],
                    'errorResultRequiredItems': [],
                    'promtionSKUs': null,
                    'isPromotionAvailable': false,
                    'resultIncompatibleAccountItems': [],
                    'rollUpErrorCodeValue': null,
                    'rollUpErrorCode': '',
                    'replace': false,
                    'errorResultIncompatibleAccountItems': [],
                    'successful': true,
                    'originalNextStepURLValue': null,
                    'nextStep': null,
                    'allSuccessful': true,
                    'removeConfirm': null
                }
            }
        }
    };


})();