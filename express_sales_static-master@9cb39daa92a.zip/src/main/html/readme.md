# html

These folders contains the html files in .pug format.

* **fragments** - files that represent reusable components in a page.

* **templates** - files that define a layout for a page.

_All fragments and templates must begin with "\_" to prevent them from being processed into HTML and placed in dist_