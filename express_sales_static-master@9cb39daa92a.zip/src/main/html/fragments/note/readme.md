# _note.pug

### mixin block 'whitespace'

##### Description
Used to add whitespace between two elements in pug file.

```use
+whitespace
```

### mixin block 'warningMessage'

##### Description:
Contains reusable warning message/information section across different pages

##### Parameters:
* name (required) - Type of message to be shown
* message (required) - Dynamic message to be shown

```use
+warningMessage('deliverypromise', 'deviceConfig.selectedSku.deliveryPromiseMessage')
```
