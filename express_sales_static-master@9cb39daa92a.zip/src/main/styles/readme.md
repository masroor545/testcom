# styles

This folder contains the various application specific CSS file that may be produced.

* **main** - this is the primary CSS file that is produced for application specific css.
This file is not specialized for a single purpose.