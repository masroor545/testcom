# styles

This folder contains the various component specific CSS files.

* **common.less** - Custom CSS for common generic alignment css which can be used in multiple placed based on requirement if only none of the DS2 css is suitable.
* **device-recommender.less** - CSS for device recommender page
* **legal-details.less** - CSS for legal overlay