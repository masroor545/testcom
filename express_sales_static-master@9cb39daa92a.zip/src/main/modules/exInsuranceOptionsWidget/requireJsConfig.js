/*global window */
(function () {
    'use strict';

    // only reference .min paths starting with '/ui/' if any needed. Also paths must be javascript files only.
    window.exInsuranceOptionsWidgetConfig = {
        requirejsConfig: {
            paths: {
                'express-static-excommon-tpl': '/shop/xpress/ui/express_sales_static/0.1.0/js/modules/exCommon-tpl.min'
            },
            waitSeconds: 0
        },
        requiredFiles: ['express-static-excommon-tpl'],
        requiredModules: ['exInsuranceOptionsWidgetModule']
    };
})();
