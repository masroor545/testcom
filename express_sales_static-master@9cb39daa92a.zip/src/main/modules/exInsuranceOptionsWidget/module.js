/*global widget */
(function () {
    'use strict';

    angular.module('exInsuranceOptionsWidget', []);

    angular.module('exInsuranceOptionsWidgetModule', ['ng', 'exInsuranceOptionsWidget', 'exCommon'])

        .provider('widget', function widgetProvider () {
            this.config = {
                'exInsuranceOptionsWidget': {
                    'currentState': 'state1',
                    'states': {
                        'state1': {
                            'templateURL': '/templates/exinsuranceoptions.html',
                            'controller': 'protectionPlanCtrl'
                        }
                    },
                    'styleSource': ['/styles/insuranceoptions.min.css']
                }
            };

            this.setConfig = function (config) {
                this.config = config;
            };

            this.$get = [function widgetFactory () { return new widget(this.config); }]; // what does this do?
        });
})();
