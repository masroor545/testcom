/*global widget*/
(function () {
    'use strict';

    angular.module('exAccessoryConfigWidget', ['/templates/exAccessoryConfigWidget']);

    angular.module('exAccessoryConfigWidgetModule', ['ng', 'exAccessoryConfigWidget', 'exCommon', 'exBuyflow'])

        .provider('widget', function widgetProvider () {
            this.config = {
                'exAccessoryConfigWidget': {
                    'currentState': 'state1',
                    'states': {
                        'state1': {
                            'templateURL': '/templates/exaccessoryconfigwidget.html',
                            'controller': 'accessoryConfigCtrl'
                        }
                    },
                    'styleSource': ['/styles/accessoryconfig.min.css']
                }
            };

            this.setConfig = function (config) {
                this.config = config;
            };

            this.$get = [function widgetFactory () { return new widget(this.config); }];
        });


})();