# exAccessoryConfigWidgetModule Widget

This module contains functionality that is related to the change your accessory config functionality. This will be leveraged
for inline edits and any other various plateforms that would want to allow the user to change the accessory configurations. 

### Initialization Arguments

The following key value pairs are passed into `scope.initargs`:

* type:string - The type of accessory config you are using (e.g. 'cart')

### Event Information

Sends:

* EXACCESSORYCONFIGWIDGET\_ACCESSORY\_ADDED - signal that a ACCESSORY was added to cart from the widget

### accessoryConfigCtrl

##### Description:
This controller contains functionality that is related to the change your accessory config functionality. This will be leveraged
for inline edits and any other various plateforms that would want to allow the user to change the accessory configurations.

**See:** [accessoryConfigCtrl Documentation](../../../main/modules/exCommon/controllers/)

---
---