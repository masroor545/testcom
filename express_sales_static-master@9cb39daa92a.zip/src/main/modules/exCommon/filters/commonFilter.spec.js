(function () {
    'use strict';

    define(['commonFilter'], function () {
        describe('src/main/modules/exCommon/filters/commonFilter.spec.js', function () {
            describe('commonFilter of exCommon', function () {
                var $filter;

                beforeEach(function () {
                    module('exCommon');

                    inject(function ($injector) {
                        $filter = $injector.get('$filter');
                    });
                });

                it('it should define all the filters that are set', inject(function ($filter) {
                    expect($filter('tel')).not.toBeNull();
                    expect($filter('toTrusted')).not.toBeNull();
                }));

                it('toTrusted should escape unsafe html', inject(function ($filter) {
                    expect('' + $filter('toTrusted')('&amp;') + '').toEqual('&');
                    expect('' + $filter('toTrusted')('&lt;') + '').toEqual('<');
                    expect('' + $filter('toTrusted')('&gt;') + '').toEqual('>');
                    expect('' + $filter('toTrusted')('&#034;') + '').toEqual('"');
                    expect('' + $filter('toTrusted')('&#039;') + '').toEqual("'");
                }));

                it('should remove space, plus, hyphen from telephone number', inject(function (telFilter) {
                    expect(telFilter('+1 425-485-5555')).toEqual('425.485.5555');
                }));

                it('should return telephone number as it is, if it is non-numeric', inject(function (telFilter) {
                    expect(telFilter('425*485*5555')).toEqual('425*485*5555');
                }));

                it('should return telephone number as it is, if its length is less than 10 or greater than 11', inject(function (telFilter) {
                    expect(telFilter('425-485-555')).toEqual('425485555');
                    expect(telFilter('425-485-5555-5555')).toEqual('42548555555555');
                }));

                it('should return formatted telephone number', inject(function (telFilter) {
                    expect(telFilter('')).toBeFalsy();
                    expect(telFilter('4254855555')).toEqual('425.485.5555');
                    expect(telFilter('14254855555')).toEqual('425.485.5555');
                }));

                describe('Selection Filter', function () {
                    it('should remove items that do not match the selected criteria', function () {
                        var matchingItem = {brand: 'Apple'};
                        var items = [
                            matchingItem,
                            {
                                brand: 'Samsung'
                            }
                        ];
                        var criteria = [
                            {
                                criterion: 'brand',
                                values: [
                                    {
                                        value: 'Apple',
                                        count: 3,
                                        isSelected: true
                                    },
                                    {
                                        value: 'Samsung',
                                        count: 3,
                                        isSelected: false
                                    }
                                ]
                            }
                        ];
                        var filteredItems = $filter('selectionFilter')(items, criteria);
                        expect(filteredItems.length).toEqual(1);
                        expect(filteredItems[0].brand).toEqual(matchingItem.brand);
                    });
                });

            });
        });
    });
})();