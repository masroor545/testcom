(function () {
    'use strict';

    angular.module('exCommon')

        .factory('selectedSkuSrv', ['$rootScope', 'exCommonConstants',
            function ($rootScope, exCommonConstants) {
                var services = {
                    getSelectedDevice: getSelectedDevice,
                    setSelectedDevice: setSelectedDevice,

                    getSelectedAccessory: getSelectedAccessory,
                    setSelectedAccessory: setSelectedAccessory
                };
                var selectedDevice = null;
                var selectedAccessory = null;

                /**
                 * Getter for selected device
                 * @return {String} The selected device skuId
                 */
                function getSelectedDevice () {
                    return selectedDevice;
                }

                /**
                 * Setter for the selected device.
                 * Broadcasts when the selected sku is updated.
                 * @param {String} skuId the skuId of the selected device
                 */
                function setSelectedDevice (skuId) {
                    if (skuId === undefined) {
                        throw new SyntaxError('No argument passed');
                    }

                    // Sets selected device sku only if the new sku is different
                    if (skuId !== selectedDevice) {
                        selectedDevice = skuId;
                        $rootScope.$broadcast(exCommonConstants.event.deviceSelected, selectedDevice);
                    }
                }


                /**
                 * Getter for selected accessory
                 * @return {String} The selected accessory skuId
                 */
                function getSelectedAccessory () {
                    return selectedAccessory;
                }

                /**
                 * Setter for the selected accessory.
                 * Broadcasts when the selected sku is updated.
                 * @param {String} skuId - skuId of the selected accessory
                 * @param {String} cartItem - in cart accessory object
                 */
                function setSelectedAccessory (skuId) {
                    if (skuId === undefined) {
                        throw new SyntaxError('No argument passed');
                    }

                    // Sets selected accessory sku only if the new sku is different
                    if (skuId !== selectedAccessory) {
                        selectedAccessory = skuId;
                        $rootScope.$broadcast(exCommonConstants.event.accessorySelected, selectedAccessory);
                    }
                }

                return services;
            }]);
})();
