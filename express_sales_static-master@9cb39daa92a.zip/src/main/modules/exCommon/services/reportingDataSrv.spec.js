(function () {
    'use strict';

    define(['reportingDataSrv'], function () {
        describe('src/main/modules/exCommon/services/reportingDataSrv.spec.js', function () {
            var service, reportingData, user, deviceItem, accessoryDetailItem, accessoryRecommenderItem, featureItem, cartData, $window, existingItems;

            beforeEach(module('exCommon'));

            beforeEach(function () {
                inject(function ($injector) {
                    $window = $injector.get('$window');
                    spyOn($window.sessionStorage, 'getItem');
                    spyOn($window.sessionStorage, 'setItem');
                    service = $injector.get('reportingDataSrv');
                });

                cartData = Endpoint_cartLookupApi.get_cart_lookup_new.result.result.methodReturnValue.lobTypes.WIRELESS;

                deviceItem = {
                    selectedSku: {
                        skuId: 'sku8040300',
                        selectedCommitmentTerm: {
                            listPrice: 200.00,
                            monthlyLeasePrice: 5.00,
                            MREDiscount: 1.00,
                            type: 'regular',
                            name: 0
                        }
                    },
                    shortDisplayName: 'iPhone 7'
                };

                accessoryDetailItem = {
                    selectedSku: {
                        skuId: 'sku12345678',
                        selectedCommitmentTerm: {
                            listPrice: 200.00,
                            dueToday: 195.00
                        }
                    },
                    productDisplayName: 'Fitbit Blaze Smart Fitness Watch'
                };

                accessoryRecommenderItem = {
                    heroAccessory: [
                        {
                            skuId: 'sku8140322',
                            name: 'accessory1',
                            type: 'case'
                        },
                        {
                            skuId: 'sku2',
                            name: 'accessory2',
                            type: 'audio'
                        },
                        {
                            skuId: 'sku3',
                            name: 'accessory3',
                            type: 'screen protector'
                        }
                    ],
                    accessoryRecommenderDetail: [
                        {
                            skuId: 'sku8030508',
                            name: 'accessory4',
                            type: 'case'
                        },
                        {
                            skuId: 'sku5',
                            name: 'accessory5',
                            type: 'audio'
                        },
                        {
                            skuId: 'sku6',
                            name: 'accessory6',
                            type: 'screen protector'
                        }
                    ],
                    accessoryRecommender: {
                        cartData: cartData,
                        myLOSGinfo: cartData.losgs['losg14580100'],
                        itemPrice: {
                            sku8140322: {
                                originalPrice: 10,
                                defaultPrice: 5
                            },
                            sku2: {
                                originalPrice: 100,
                                defaultPrice: 50
                            },
                            sku3: {
                                originalPrice: 1000,
                                defaultPrice: 500
                            },
                            sku8030508: {
                                originalPrice: 105,
                                defaultPrice: 51
                            },
                            sku5: {
                                originalPrice: 103,
                                defaultPrice: 56
                            },
                            sku6: {
                                originalPrice: 1078,
                                defaultPrice: 55
                            }
                        },
                        currentCtn: '12345'
                    }
                };

                featureItem = {
                    skuId: 'sku5370279',
                    displayName: 'Fitbit Blaze Smart Fitness Watch',
                    mrc: 11.99
                };

                existingItems = {};
                existingItems['12345'] = {
                    itemQty: '1',
                    itemsName: 'iPhone6sPlus',
                    itemSku: 'sku12345',
                    itemMreCodes: 'LTV999_Lease',
                    itemUpgradeTypeRecommended: 'Pay Up'
                };

                user = Endpoint_upgradeEligibility.lines_data_for_reporting_params.result;
            });


            afterEach(function () {
                $window.sessionStorage.setItem.calls.reset();
                $window.sessionStorage.getItem.calls.reset();
            });

            it('should return device data in the correct reporting format', function () {
                reportingData = service.getAddToCartDevicePayload(deviceItem);
                expect(reportingData).not.toBeNull();
                expect(reportingData.items).not.toBeNull();
                expect(reportingData.items[0].itemSku).toEqual('sku8040300');
                expect(reportingData.items[0].itemRecurringPrice).toEqual(5.00);
            });

            it('should return Accessory data in the correct reporting format', function () {
                reportingData = service.getAddToCartAccessoryDetailsPayload(accessoryDetailItem);
                expect(reportingData).not.toBeNull();
                expect(reportingData.items).not.toBeNull();
                expect(reportingData.items[0].itemSku).toEqual('sku12345678');
                expect(reportingData.items[0].itemDiscount).toEqual('5.00');
            });

            it('should return Accessory data from Accessory Recommender page in the correct reporting format', function () {
                reportingData = service.getAddToCartAccessoryRecommenderPayload(accessoryRecommenderItem, 'sku2');
                expect(reportingData).not.toBeNull();
                expect(reportingData.items).not.toBeNull();
                expect(reportingData.items[0].itemSku).toEqual('sku2');
                expect(reportingData.items[0].itemDiscount).toEqual('50.00');
                reportingData = service.getAddToCartAccessoryRecommenderPayload(accessoryRecommenderItem, 'sku6');
                expect(reportingData).not.toBeNull();
                expect(reportingData.items).not.toBeNull();
                expect(reportingData.items[0].itemSku).toEqual('sku6');
                expect(reportingData.items[0].itemOneTimePrice).toEqual('55.00');
            });

            it('should return Feature data in the correct reporting format', function () {
                reportingData = service.getAddToCartFeaturePayload(featureItem);
                expect(reportingData).not.toBeNull();
                expect(reportingData.items).not.toBeNull();
                expect(reportingData.items[0].itemSku).toEqual('sku5370279');
                expect(reportingData.items[0].itemRecurringPrice).toEqual(11.99);
            });

            it('should return Cart data from Accessory Recommender page in the correct reporting format', function () {
                reportingData = service.getOnProceedToCheckoutPayload(accessoryRecommenderItem);
                expect(reportingData).not.toBeNull();
                expect(reportingData.contractLength).toEqual('30');
                expect(reportingData.items.length).toEqual(4);
                expect(reportingData.cartOneTimeAmt).toEqual(25);
                expect(reportingData.cartContents).toEqual('Wireless (postpaid)|1|0|0');
            });

            it('should return existing items data from session storage in the correct reporting format', function () {
                $window.sessionStorage.getItem.and.returnValue(JSON.stringify(existingItems));
                reportingData = service.getOnProceedToCheckoutPayload(accessoryRecommenderItem);
                expect(reportingData.existingItems).not.toBeNull();
                expect(reportingData.existingItems[0].itemSku).toEqual('sku12345');
                expect(reportingData.existingItems[0].itemsName).toEqual('iPhone6sPlus');
                expect(reportingData.existingItems[0].itemUpgradeTypeRecommended).toEqual('Pay Up');
            });

            it('should return device data in the correct reporting format', function () {
                $window.sessionStorage.getItem.and.returnValue(JSON.stringify(existingItems));
                reportingData = service.getDeviceRecommenderDevicePayload(Endpoint_deviceRecommenderApi.get_Recommended_Devices.data[0], -1, '12345');
                expect(reportingData).not.toBeNull();
                expect(reportingData.items).not.toBeNull();
                expect(reportingData.items[0].itemSku).toEqual('sku7840239');
                expect(reportingData.items[0].itemRecurringPrice).toEqual('19.84');
                expect(reportingData.items[0].itemAnnualPrice).toEqual(0);
                expect(reportingData.items[0].itemRackRatePrice).toEqual(594.99);
                expect(reportingData.existingItems).not.toBeNull();
                expect(reportingData.existingItems[0].itemSku).toEqual('sku12345');
                expect(reportingData.existingItems[0].itemsName).toEqual('iPhone6sPlus');
                expect(reportingData.existingItems[0].itemUpgradeTypeRecommended).toEqual('Pay Up');
                expect(reportingData['page.location.url']).toEqual('/shop/xpress/device-recommender.html');
                expect(reportingData['page.pageInfo.friendlyPageName']).toEqual('DS Upgrade Device Recommender Pg');
            });

            it('should return device data in the correct reporting format on subsequent calls', function () {
                $window.sessionStorage.getItem.and.returnValue(JSON.stringify(existingItems));
                reportingData = service.getDeviceRecommenderDevicePayload(Endpoint_deviceRecommenderApi.get_Recommended_Devices.data[0], 0, '12345');
                expect(reportingData).not.toBeNull();
                expect(reportingData.items).not.toBeNull();
                expect(reportingData.items[0].itemSku).toEqual('sku7840239');
                expect(reportingData.items[0].itemRecurringPrice).toEqual('19.84');
                expect(reportingData.existingItems).not.toBeNull();
                expect(reportingData.existingItems[0].itemSku).toEqual('sku12345');
                expect(reportingData.existingItems[0].itemsName).toEqual('iPhone6sPlus');
                expect(reportingData.existingItems[0].itemUpgradeTypeRecommended).toEqual('Pay Up');
                expect(reportingData['page.location.url']).toEqual('/shop/xpress/virtual/device-details.html+HeroDevice');
                expect(reportingData['page.pageInfo.friendlyPageName']).toEqual('DS Upgrade Hero Device Details Pg');
            });

            it('should return device data in the correct reporting format for url param on device details page', function () {
                $window.sessionStorage.getItem.and.returnValue(JSON.stringify(existingItems));
                reportingData = service.getDeviceRecommenderDevicePayload(Endpoint_deviceRecommenderApi.get_Recommended_Devices.data[1], 1, '12345');
                expect(reportingData).not.toBeNull();
                expect(reportingData.items).not.toBeNull();
                expect(reportingData.items[0].itemSku).toEqual('sku7870569');
                expect(reportingData.items[0].itemRecurringPrice).toEqual('13.34');
                expect(reportingData.existingItems).not.toBeNull();
                expect(reportingData.existingItems[0].itemSku).toEqual('sku12345');
                expect(reportingData.existingItems[0].itemsName).toEqual('iPhone6sPlus');
                expect(reportingData.existingItems[0].itemUpgradeTypeRecommended).toEqual('Pay Up');
                expect(reportingData['page.location.url']).toEqual('/shop/xpress/virtual/device-details.html');
                expect(reportingData['page.pageInfo.friendlyPageName']).toEqual('DS Upgrade Device Details Pg');
            });

            it('should return info for the selected lines in the correct reporting format', function () {
                reportingData = service.getUpgradeEligibilitySelectedItemsPayload(user);
                expect(reportingData).not.toBeNull();
                expect(reportingData.items).not.toBeNull();
                expect(reportingData.items[0].itemSku).toEqual('sku12345');
                expect(reportingData.items[1].itemsName).toEqual('iPhone 7');
                expect(reportingData.items[2].itemUpgradeTypeSelected).toEqual('Full Price');
                expect(reportingData.items[0].itemFullPrice).toEqual(50);
                expect(reportingData.items[0].itemOneTimePrice).toEqual(50);
            });

            it('should return info for the existing lines in the correct reporting format and store a copy in sessionStorage', function () {
                reportingData = service.getUpgradeEligibilityExistingItemsPayload(user);
                expect(reportingData).not.toBeNull();
                expect(reportingData.existingItems).not.toBeNull();
                expect(reportingData.existingItems[0].itemSku).toEqual('sku12345');
                expect(reportingData.existingItems[0].itemsName).toEqual('iPhone6sPlus');
                expect(reportingData.existingItems[0].itemUpgradeTypeRecommended).toEqual('Pay Up');
                expect(reportingData.existingItems[0].networkSku).toEqual('sku12345');
                expect(reportingData.contractLength).toEqual('24|0|24|24|24|24');
                expect(reportingData.contractType).toEqual('regular|regular|regular|regular|regular|regular');
                expect($window.sessionStorage.setItem).toHaveBeenCalledWith('reportingExistingItems', jasmine.any(String));
                expect($window.sessionStorage.setItem).toHaveBeenCalledWith('reportingContractLength', reportingData.contractLength);
                expect($window.sessionStorage.setItem).toHaveBeenCalledWith('reportingContractType', reportingData.contractType);
            });

            it('should return info for the existing lines in the correct reporting format from Session Storage', function () {
                $window.sessionStorage.getItem.and.returnValue(JSON.stringify(existingItems));
                reportingData = service.getUpgradeEligibilityExistingItemsPayload('12345');
                expect($window.sessionStorage.getItem).toHaveBeenCalledWith('reportingExistingItems');
                expect(reportingData).not.toBeNull();
                expect(reportingData.existingItems).not.toBeNull();
                expect(reportingData.existingItems[0].itemSku).toEqual('sku12345');
                expect(reportingData.existingItems[0].itemsName).toEqual('iPhone6sPlus');
                expect(reportingData.existingItems[0].itemUpgradeTypeRecommended).toEqual('Pay Up');
            });

            it('should return event code DS_Upgrade_Submit based on data ', function () {
                var scope = {user: user,
                    selectedDataValue: {subscriberNumber: '12345'}
                };
                reportingData = service.getUpgradeSubmitEvent(scope);
                expect(reportingData).not.toBeNull();
                expect(reportingData).toEqual('DS_Upgrade_Submit');
            });

            it('should return info for the upgrade submit event in the correct reporting format', function () {
                var scope = {user: user,
                    selectedDataValue: {subscriberNumber: '12345'}
                };
                $window.sessionStorage.getItem.and.returnValue(JSON.stringify(existingItems));
                reportingData = service.getUpgradeSubmitPayload(scope);
                expect(reportingData).not.toBeNull();
                expect(reportingData.existingItems).not.toBeNull();
                expect(reportingData.existingItems[0].itemSku).toEqual('sku12345');
                expect(reportingData.existingItems[0].itemsName).toEqual('iPhone6sPlus');
                expect(reportingData.existingItems[0].itemUpgradeTypeRecommended).toEqual('Pay Up');
                expect(reportingData.items[0].itemSku).toEqual('sku12345');
                expect(reportingData.items[1].itemsName).toEqual('iPhone 7');
                expect(reportingData.items[2].itemUpgradeTypeSelected).toEqual('Full Price');
            });

            it('should return info for a failed event in the correct reporting format', function () {
                var scope = {user: user,
                        selectedDataValue: {subscriberNumber: '12345'}
                    },
                    data = Endpoint_expressUpgradeApi.express_upgrade_error.result;
                reportingData = service.getUpgradeSubmitPayload(scope);
                reportingData = service.updateEventPayloadFailure(reportingData, data);
                expect(reportingData.errorType).toEqual('Failure_Data');
                expect(reportingData.successFlag).toEqual('0');
                expect(reportingData.statusCode[0]).toEqual('errorCode.TI_100');
            });

            it('should return trade in consent message based on checkbox', function () {
                reportingData = service.getTradeinConsentEventPayload(true);
                expect(reportingData.userResp).toEqual('Trade In Consent Selected');

                reportingData = service.getTradeinConsentEventPayload(false);
                expect(reportingData.userResp).toEqual('Trade in Consent Unselected');
            });

            it('should return default multiline parameters', function () {
                var eventPayload = {};
                eventPayload = service.getMultilineReportingPayload({isMultiLineInProgress: true}, false);
                expect(eventPayload.isMultilineUpgrade).toEqual('1');
                expect(eventPayload.allMultilineUpgradeComplete).toEqual('0');

                eventPayload = service.getMultilineReportingPayload({isMultiLineInProgress: true}, true);
                expect(eventPayload.isMultilineUpgrade).toEqual('1');
                expect(eventPayload.allMultilineUpgradeComplete).toEqual('1');

                eventPayload = service.getMultilineReportingPayload(false, false);
                expect(eventPayload.isMultilineUpgrade).toEqual('0');
                expect(eventPayload.allMultilineUpgradeComplete).toEqual('0');
                expect($window.sessionStorage.getItem).toHaveBeenCalledWith('reportingMultilineEligible');
            });

            it('should return default event success parameters', function () {
                var eventPayload = {};
                eventPayload = service.addEventSuccessToPayload(eventPayload);
                expect(eventPayload.successFlag).toEqual('1');
                expect(eventPayload.statusCode).toEqual('0');
                expect(eventPayload.statusMessage).toEqual('SUCCESS');
                expect(eventPayload.errorType).toEqual('Success_Admit');
            });

            it('should return default event success parameters', function () {
                var upsellDetails = Endpoint_upsellOfferDetailsApi.get_upsell_offer_details.result,
                    upsellOfferDetails = [],
                    count = 0;

                var upsellOfferId = upsellDetails.payload.methodReturnValue.offerId,
                    isMultiSku = upsellDetails.payload.methodReturnValue.multiSkuOffer,
                    dueTodayTotal = upsellDetails.payload.methodReturnValue.cartTotalAmount,
                    dueMonthlyTotal = upsellDetails.payload.methodReturnValue.cartMonthlyAmount;

                Object.keys(upsellDetails.payload.methodReturnValue.wirelessProductDetailsBeans[0].skuItems).forEach(function (key) {
                    var details = upsellDetails.payload.methodReturnValue.wirelessProductDetailsBeans[0].skuItems[key];
                    count++;
                    upsellOfferDetails.push({
                        redirectURL: upsellDetails.payload.redirectURL,
                        skuId: details.skuId,
                        offerId: upsellOfferId,
                        productId: details.productId,
                        displayName: details.displayName,
                        model: details.model,
                        priceList: details.priceList,
                        multiSkuOffer: isMultiSku,
                        defaultSku: upsellDetails.payload.methodReturnValue.defaultSkuId,
                        offerDueTodayTotal: dueTodayTotal,
                        offerDueMonthlyTotal: dueMonthlyTotal
                    });
                });
                var eventPayload = service.getUpsellPayload(upsellOfferDetails);
                expect(eventPayload.successFlag).toEqual('1');
                expect(eventPayload.statusCode).toEqual('0');
                expect(eventPayload.statusMessage).toEqual('SUCCESS');
                expect(eventPayload.errorType).toEqual('Success_Admit');
                expect(eventPayload.upSellOfferSelectedFlag).toEqual('0');
                expect(eventPayload.items.length).toEqual(count);

            });

            it('should return default remove  parameters', function () {
                var eventPayload = {};
                eventPayload = service.getRemovePayload();
                expect(eventPayload.linkName).toEqual('Remove');
                expect(eventPayload.response).toEqual('-1');
            });

            it('should return event  parameters for getUpgradePaymentPayload', function () {
                $window.sessionStorage.getItem.and.returnValue(JSON.stringify(existingItems));
                var upgradePayment = {
                        paymentInfo: {
                            isPaymentProfile: true
                        },
                        upgradeTypeInfo: {
                            customerCtn: '12345',
                            paymentAmount: '100',
                            upgradeType: 'payoff'
                        }
                    },
                    eventPayload = service.getUpgradePaymentPayload(upgradePayment.paymentInfo, upgradePayment.upgradeTypeInfo);
                expect(eventPayload.successFlag).toEqual('1');
                expect(eventPayload.statusCode).toEqual('0');
                expect(eventPayload.statusMessage).toEqual('SUCCESS');
                expect(eventPayload.errorType).toEqual('Success_Admit');
                expect(eventPayload.paymentMethod).toEqual('Payment Profile');
                expect(eventPayload.items.length).toEqual(1);
                expect(eventPayload.existingItems).not.toBeDefined();
            });

            it('should return event  parameters for getUpgradePaymentPayload when payment type is credit card', function () {
                var upgradePayment = {
                        paymentInfo: {
                            paymentType: 'creditCard'
                        },
                        upgradeTypeInfo: {
                            customerCtn: '12345',
                            paymentAmount: '100',
                            upgradeType: 'payoff'
                        }
                    },
                    eventPayload = service.getUpgradePaymentPayload(upgradePayment.paymentInfo, upgradePayment.upgradeTypeInfo);
                expect(eventPayload.paymentMethod).toEqual('New CC');
            });

            it('should return info for a payment failure event in the correct reporting format', function () {
                var scope = {
                        user: user,
                        selectedDataValue: {subscriberNumber: '12345'}
                    },
                    data = Endpoint_upgradePaymentPost.upgrade_payment_post_failure.result;
                reportingData = service.getUpgradeSubmitPayload(scope);
                reportingData = service.updateEventPayloadPaymentFailure(reportingData, data);
                expect(reportingData.errorType).toEqual('Failure_Data');
                expect(reportingData.successFlag).toEqual('0');
                expect(reportingData.statusCode).toEqual('DETCS3000010,DETCS300007');
            });

        });
    });
})();
