(function () {
    'use strict';

    angular.module('exCommon')

        .factory('protectionPlanService', ['$log', '$q', '$http', '$window', 'exCommonConstants',
            function ($log, $q, $http, $window, exCommonConstants) {
                var protectionPlanStorageKey = exCommonConstants.protectionPlanStorageKey,
                    protectionPlanSrv = {
                        getInsuranceFeatures: getInsuranceFeatures
                    };

                /**
                 * Makes a request to the protection plan recommendations API to get the recommended protection features in context and
                 *  returns a promise. If the promise resolves the result of the request will be returned.
                 * @function getInsuranceFeatures
                 * @param {String} action Optional parameter which reloads the insurance features from the API,
                 *  even if stored locally, if it is set to anything but 'none'.
                 * @returns {Promise<Object>} Returns a promise of insurance features results.
                 */
                function getInsuranceFeatures (action) {
                    var storedProtectionPlans;

                    action = action || 'none';
                    storedProtectionPlans = $window.sessionStorage.getItem(protectionPlanStorageKey);

                    // we don't want to refresh the insurance features, and we got it from storage.
                    if (action === 'none' && (storedProtectionPlans !== null && storedProtectionPlans !== undefined)) {
                        return $q.when(JSON.parse(storedProtectionPlans));
                    } else {
                        // insurance features don't exist in storage, or needs to be refreshed
                        return $http.get(exCommonConstants.catalogApi, {
                            params:
                            {
                                actionType: 'getexupinsurancefeatures'
                            },
                            spinner: false
                        }).then(getInsuranceFeaturesDetails)
                            .catch(getInsuranceFeaturesFailed);
                    }
                }

                /**
                 * Returns the data property of the protection plan recommendation response object.
                 * @function getInsuranceFeaturesDetails
                 * @param {Object} result Protection plan recommendations response
                 * @returns {Promise<Object>} Returns the protection plan recommendation response data
                 */
                function getInsuranceFeaturesDetails (result) {
                    $window.sessionStorage.setItem(protectionPlanStorageKey, JSON.stringify(result.data));
                    return result.data;
                }

                /**
                 * Logs an error and rejects the promise returned by the getInsuranceFeatures function.
                 * @param {Error} error Protection plan recommendation response error object.
                 * @return {Promise<Error>} Returns rejected promise
                 */
                function getInsuranceFeaturesFailed (error) {
                    var message = 'protectionPlanService.getInsuranceFeatures call failed.';
                    if (error && error.data && error.data.description) {
                        message += '\n' + error.data.description;
                    }
                    $log.error(message);
                    return $q.reject(error);
                }

                return protectionPlanSrv;
            }]);
})();
