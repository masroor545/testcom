(function () {
    'use strict';

    angular.module('exCommon')

        .factory('reportingDataSrv', ['exCommonConstants', '$window',
            function (exCommonConstants, $window) {
                var deviceRecommenderDevicePayload = {};

                return {
                    addEventSuccessToPayload: addEventSuccessToPayload,
                    getAddToCartDevicePayload: getAddToCartDevicePayload,
                    getAddToCartAccessoryDetailsPayload: getAddToCartAccessoryDetailsPayload,
                    getAddToCartAccessoryRecommenderPayload: getAddToCartAccessoryRecommenderPayload,
                    getAddToCartFeaturePayload: getAddToCartFeaturePayload,
                    getDeviceRecommenderDevicePayload: getDeviceRecommenderDevicePayload,
                    getUpgradeEligibilitySelectedItemsPayload: getUpgradeEligibilitySelectedItemsPayload,
                    getUpgradeEligibilityExistingItemsPayload: getUpgradeEligibilityExistingItemsPayload,
                    getMultilineReportingPayload: getMultilineReportingPayload,
                    getRemovePayload: getRemovePayload,
                    getUpgradeSubmitPayload: getUpgradeSubmitPayload,
                    updateEventPayloadFailure: updateEventPayloadFailure,
                    updateEventPayloadPaymentFailure: updateEventPayloadPaymentFailure,
                    getUpgradeSubmitEvent: getUpgradeSubmitEvent,
                    getOnProceedToCheckoutPayload: getOnProceedToCheckoutPayload,
                    getUpsellPayload: getUpsellPayload,
                    getAddToCartUpsellPayload: getAddToCartUpsellPayload,
                    getTradeinConsentEventPayload: getTradeinConsentEventPayload,
                    getTradeinIneligibleEventPayload: getTradeinIneligibleEventPayload,
                    getUpgradePaymentFailurePayload: getUpgradePaymentFailurePayload,
                    getUpgradePaymentPayload: getUpgradePaymentPayload
                };

                /**
                 * event fired when Item is removed
                 * @return {Object} eventPayload object with remove payload
                 */
                function getRemovePayload () {
                    var eventPayload = {
                        linkName: 'Remove',
                        response: '-1'
                    };
                    return eventPayload;
                }

                function addEventSuccessToPayload (eventPayload) {
                    if (eventPayload) {
                        eventPayload['successFlag'] = '1',
                        eventPayload['statusCode'] = '0',
                        eventPayload['statusMessage'] = 'SUCCESS',
                        eventPayload['errorType'] = 'Success_Admit';
                    }
                    return eventPayload;
                }

                 /**
                 * Returns object with reporting data formatted for device object on device recommender page
                 * @param {Object} deviceItem
                 * @return {Object} eventPayload object
                 */
                function getAddToCartDevicePayload (deviceItem) {
                    var eventPayload = {};

                    if (deviceItem && deviceItem.selectedSku) {
                        eventPayload = {
                            'items': [
                                {
                                    'itemSku': deviceItem.selectedSku.skuId,
                                    'itemName': deviceItem.shortDisplayName,
                                    'itemQty': '1',
                                    'itemOneTimePrice': deviceItem.selectedSku.selectedCommitmentTerm.listPrice,
                                    'itemRecurringPrice': deviceItem.selectedSku.selectedCommitmentTerm.monthlyLeasePrice,
                                    'itemDiscount': deviceItem.selectedSku.selectedCommitmentTerm.MREDiscount,
                                    'itemCategory': 'Device'
                                }
                            ],
                            'contractLength': deviceItem.selectedSku.selectedCommitmentTerm.type === 'regular' ? deviceItem.selectedSku.selectedCommitmentTerm.name.toString() : deviceItem.selectedSku.selectedCommitmentTerm.leaseTotalMonths.toString(),
                            'contractType': deviceItem.selectedSku.selectedCommitmentTerm.type
                        };
                    }
                    eventPayload = addEventSuccessToPayload(eventPayload);
                    return eventPayload;
                }

                 /**
                 * Returns object with reporting data formatted for accessory object on accessory details page
                 * @param {Object} accessoryItem
                 * @return {Object} eventPayload object
                 */
                function getAddToCartAccessoryDetailsPayload (accessoryItem) {
                    var eventPayload = {};

                    if (accessoryItem && accessoryItem.selectedSku) {
                        eventPayload = {
                            'items': [
                                {
                                    'itemSku': accessoryItem.selectedSku.skuId,
                                    'itemName': accessoryItem.productDisplayName,
                                    'itemOneTimePrice': (accessoryItem.selectedSku.selectedCommitmentTerm.dueToday).toFixed(2),
                                    'itemDiscount': (accessoryItem.selectedSku.selectedCommitmentTerm.listPrice - accessoryItem.selectedSku.selectedCommitmentTerm.dueToday).toFixed(2),
                                    'itemCategory': 'Accessory'
                                }
                            ]};
                    }
                    eventPayload = addEventSuccessToPayload(eventPayload);
                    return eventPayload;
                }

                 /**
                 * Returns object with reporting data formatted for accessory object on accessory details page
                 * @param {Object} scope
				 * @param {String} skuId
                 * @return {Object} eventPayload object
                 */
                function getAddToCartAccessoryRecommenderPayload (scope, skuId) {
                    var eventPayload = {},
                        accessoryItem = {},
                        accessories = scope.accessoryRecommenderDetail;

                    for (var i = 0; i < accessories.length; i++) {
                        if (accessories[i].skuId === skuId) {
                            accessoryItem = accessories[i];
                            break;
                        }
                    }

                    if (scope.heroAccessory && scope.heroAccessory.length) {
                        for (var j = 0; j < scope.heroAccessory.length; j++) {
                            if (scope.heroAccessory[j].skuId === skuId) {
                                accessoryItem = scope.heroAccessory[j];
                                break;
                            }
                        }
                    }

                    if (accessoryItem && accessoryItem.skuId === skuId) {
                        var accessoryItemPrice = scope.accessoryRecommender.itemPrice[skuId],
                            originalPrice = (parseFloat(accessoryItemPrice.originalPrice)) ? parseFloat(accessoryItemPrice.originalPrice).toFixed(2) : 0,
                            defaultPrice = (parseFloat(accessoryItemPrice.defaultPrice)) ? parseFloat(accessoryItemPrice.defaultPrice).toFixed(2) : 0;
                        eventPayload = {
                            'items': [
                                {
                                    'itemSku': accessoryItem.skuId,
                                    'itemName': accessoryItem.name,
                                    'itemQty': '1',
                                    'itemOneTimePrice': defaultPrice,
                                    'itemDiscount': (originalPrice - defaultPrice).toFixed(2),
                                    'itemCategory': accessoryItem.type
                                }
                            ]};
                    }
                    eventPayload = addEventSuccessToPayload(eventPayload);
                    return eventPayload;
                }

                 /**
                 * Returns object with reporting data formatted for feature object on accessory Recommender page
                 * @param {Object} featureItem
                 * @return {Object} eventPayload object
                 */
                function getAddToCartFeaturePayload (featureItem) {
                    var eventPayload = {};

                    if (featureItem) {
                        eventPayload = {
                            'items': [
                                {
                                    'itemSku': featureItem.skuId,
                                    'itemName': featureItem.displayName,
                                    'itemQty': '1',
                                    'itemOneTimePrice': 0,
                                    'itemRecurringPrice': featureItem.mrc,
                                    'itemCategory': 'Feature'
                                }
                            ]};
                    }
                    eventPayload = addEventSuccessToPayload(eventPayload);
                    return eventPayload;
                }

                /**
                * Returns object with reporting data formatted for device object on device recommender page
                * @param {Object} deviceItem
                * @return {Object} eventPayload object
                */
                function getDeviceRecommenderDevicePayload (skuItem, deviceTileIndex, ctn) {
                    if (skuItem) {
                        var mrc = Number.MAX_VALUE,
                            nextPricing = skuItem.attNextPricing;

                        if (nextPricing) {
                            for (var i = 0; i < nextPricing.length; i++) {
                                if (nextPricing[i].monthLeasePrice < mrc && nextPricing[i].termName.indexOf('DP') === -1) {
                                    mrc = nextPricing[i].monthLeasePrice;
                                }
                            }
                        }

                        mrc = (mrc === Number.MAX_VALUE) ? '' : mrc;
                        deviceRecommenderDevicePayload = {
                            'items': [
                                {
                                    'itemSku': skuItem.skuId,
                                    'itemName': skuItem.name,
                                    'itemQty': '1',
                                    'itemOneTimePrice': skuItem.listPrice,
                                    'itemRecurringPrice': mrc,
                                    'itemCategory': skuItem.type,
                                    'itemRackRatePrice': skuItem.price,
                                    'itemAnnualPrice': 0
                                }
                            ]};
                        deviceRecommenderDevicePayload = angular.extend(deviceRecommenderDevicePayload, getUpgradeEligibilityExistingItemsPayload(ctn));
                    }
                    deviceRecommenderDevicePayload = addEventSuccessToPayload(deviceRecommenderDevicePayload);
                    if (deviceTileIndex === 0) {
                        deviceRecommenderDevicePayload['page.pageInfo.friendlyPageName'] = exCommonConstants.friendlyPageName.deviceDetailsHero;
                        deviceRecommenderDevicePayload['page.location.url'] = exCommonConstants.virtualUrl.deviceDetailsHero;
                    } else if (deviceTileIndex === -1) {
                        deviceRecommenderDevicePayload['page.pageInfo.friendlyPageName'] = exCommonConstants.friendlyPageName.deviceRecommenderDetails;
                        deviceRecommenderDevicePayload['page.location.url'] = exCommonConstants.virtualUrl.deviceRecommenderDetails;
                    } else {
                        deviceRecommenderDevicePayload['page.pageInfo.friendlyPageName'] = exCommonConstants.friendlyPageName.deviceDetails;
                        deviceRecommenderDevicePayload['page.location.url'] = exCommonConstants.virtualUrl.deviceDetails;
                    }
                    return deviceRecommenderDevicePayload;
                }

                /**
                 * Returns object with reporting data formatted for selected items object on upgrade eligibility page
                 * @param {Object} user
                 * @return {Object} eventPayload object
                 */
                function getUpgradeEligibilitySelectedItemsPayload (user) {
                    var selectedItems = [],
                        eventPayload = {};

                    if (user) {
                        if (user.selectedLines) {
                            angular.forEach(user.selectedLines, function (line) {
                                var selectedItem = {
                                    itemQty: '1',
                                    itemCategory: 'device'
                                };

                                if (line.device && line.device.model) {
                                    selectedItem.itemsName = line.device.model;
                                }

                                if (line.device && line.device.skuId) {
                                    selectedItem.itemSku = line.device.skuId;
                                }

                                if (line.tradeInOptions.eligibleFlag) {
                                    selectedItem.itemUpgradeTypeSelected = exCommonConstants.itemUpgradeTypeSelected[line.tradeInOptions.eligibleFlag.toLowerCase()];
                                }

                                if (line.eligibilityInfo && line.eligibilityInfo.payUpAmount) {
                                    selectedItem.itemFullPrice = line.eligibilityInfo.payUpAmount;
                                    selectedItem.itemOneTimePrice = line.eligibilityInfo.payUpAmount;
                                }

                                selectedItem.itemDiscount = 0;

                                selectedItems.push(selectedItem);
                            });
                        }
                        eventPayload = {
                            items: selectedItems
                        };
                    }
                    return eventPayload;
                }

                /**
                 * Returns object with reporting data formatted for existing items object on upgrade eligibility page
                 * @param {Object} user
                 * @return {Object} eventPayload object
                 */
                function getUpgradeEligibilityExistingItemsPayload (user) {
                    var existingItems = [],
                        existingItemsForStorage = {},
                        isMultilineUpgradeEligible = '0',
                        eventPayload = {},
                        selectedDeviceContractLength = [],
                        selectedDeviceContractType = [];

                    if (typeof user === 'object') {
                        if (user.lines) {
                            isMultilineUpgradeEligible = (user.lines.length > 1) ? '1' : '0';

                            angular.forEach(user.lines, function (line) {
                                var existingItem = {
                                        itemQty: '1',
                                        itemCategory: 'device'
                                    },
                                    itemMreCodes = [];

                                if (line.device.model) {
                                    existingItem.itemsName = line.device.model;
                                }

                                if (line.device.skuId) {
                                    existingItem.itemSku = line.device.skuId;
                                    existingItem.networkSku = line.device.skuId;
                                }

                                if (line.eligibilityInfo.offerReasonCodes) {
                                    angular.forEach(line.eligibilityInfo.offerReasonCodes, function (itemMreCode, index) {
                                        itemMreCodes[index] = itemMreCode.substring(12);
                                    });

                                    existingItem.itemMreCodes = itemMreCodes.join('|');
                                }

                                var isFullyUpgradeEligible = (line.eligibilityInfo.eligibility === 'ELIGIBLE' ||
                                    line.eligibilityInfo.eligibility === 'DISCOUNT_ELIGIBLE' ||
                                    line.eligibilityInfo.earlyUpgrade) &&
                                    (line.eligibilityInfo.payUpAmount === 0 &&
                                        line.eligibilityInfo.payOffAmount === 0);

                                var isUpgradeIneligible = line.noCommitUpgradeEligible === false ||
                                    line.planChangeRequired === true ||
                                    line.IRUSplitLiability === true;

                                var isBuyAtFullPrice = isUpgradeIneligible === false &&
                                    line.noCommitUpgradeEligible === true;

                                if (line.eligibilityInfo.payUpAmount > 0) {
                                    existingItem.itemUpgradeTypeRecommended = exCommonConstants.itemUpgradeTypeRecommended.payUp;
                                } else if (line.eligibilityInfo.tradeInEligible === true) {
                                    existingItem.itemUpgradeTypeRecommended = exCommonConstants.itemUpgradeTypeRecommended.nextTradein;
                                } else if (line.eligibilityInfo.payOffAmount > 0) {
                                    existingItem.itemUpgradeTypeRecommended = exCommonConstants.itemUpgradeTypeRecommended.payOff;
                                } else if (isFullyUpgradeEligible === true) {
                                    existingItem.itemUpgradeTypeRecommended = exCommonConstants.itemUpgradeTypeRecommended.fullyEligible;
                                } else if (isUpgradeIneligible === true) {
                                    existingItem.itemUpgradeTypeRecommended = exCommonConstants.itemUpgradeTypeRecommended.inEligible;
                                } else if (isBuyAtFullPrice === true) {
                                    existingItem.itemUpgradeTypeRecommended = exCommonConstants.itemUpgradeTypeRecommended.fullPrice;
                                }

                                existingItemsForStorage[line.subscriberNumber] = existingItem;
                                existingItems.push(existingItem);

                                if (line.contractLength >= 0) {
                                    selectedDeviceContractLength.push(line.contractLength);
                                }

                                if (line.contractTypeWithoutDate) {
                                    selectedDeviceContractType.push(line.contractTypeWithoutDate);
                                }
                            });
                        }

                        $window.sessionStorage.setItem(exCommonConstants.reportingExistingItemsStorageKey, JSON.stringify(existingItemsForStorage));
                        $window.sessionStorage.setItem(exCommonConstants.reportingMultilineEligibleStorageKey, isMultilineUpgradeEligible);
                        $window.sessionStorage.setItem(exCommonConstants.reportingContractLengthStorageKey, selectedDeviceContractLength.join('|'));
                        $window.sessionStorage.setItem(exCommonConstants.reportingContractTypeStorageKey, selectedDeviceContractType.join('|'));
                        eventPayload = {
                            existingItems: existingItems,
                            isMultilineUpgradeEligible: isMultilineUpgradeEligible,
                            contractLength: selectedDeviceContractLength.join('|'),
                            contractType: selectedDeviceContractType.join('|')
                        };
                    } else if (typeof user === 'string') {
                        existingItems = $window.sessionStorage.getItem(exCommonConstants.reportingExistingItemsStorageKey);
                        if (existingItems) {
                            existingItems = JSON.parse(existingItems);
                            var existingItem = existingItems[user];
                            eventPayload.existingItems = [existingItem];
                        }

                        isMultilineUpgradeEligible = $window.sessionStorage.getItem(exCommonConstants.reportingMultilineEligibleStorageKey);
                        if (isMultilineUpgradeEligible) {
                            eventPayload.isMultilineUpgradeEligible = JSON.parse(isMultilineUpgradeEligible);
                        }

                        selectedDeviceContractLength = $window.sessionStorage.getItem(exCommonConstants.reportingContractLengthStorageKey);
                        if (selectedDeviceContractLength) {
                            eventPayload.contractLength = selectedDeviceContractLength;
                        }

                        selectedDeviceContractType = $window.sessionStorage.getItem(exCommonConstants.reportingContractTypeStorageKey);
                        if (selectedDeviceContractType) {
                            eventPayload.contractType = selectedDeviceContractType;
                        }
                    } else {
                        existingItems = $window.sessionStorage.getItem(exCommonConstants.reportingExistingItemsStorageKey);
                        if (existingItems) {
                            existingItems = JSON.parse(existingItems);
                            eventPayload.existingItems = existingItems;
                        }
                    }

                    return eventPayload;
                }

                /**
                 * Returns object with reporting data formatted for existing items object on upgrade eligibility page
                 * @param {Boolean} isMultilineUpgrade
                 * @param {Boolean} allMultilineUpgradeComplete
                 * @return {Object} eventPayload object
                 */
                function getMultilineReportingPayload (upgradeLinesInfoDetails, allMultilineUpgradeComplete) {
                    var eventPayload = {
                            allMultilineUpgradeComplete: '0',
                            isMultilineUpgrade: '0',
                            isMultilineUpgradeEligible: '0'
                        },
                        isMultilineUpgradeEligible;

                    if (allMultilineUpgradeComplete) {
                        eventPayload.allMultilineUpgradeComplete = '1';
                        eventPayload.isMultilineUpgrade = '1';
                    } else if (upgradeLinesInfoDetails &&
                        upgradeLinesInfoDetails.isMultiLineInProgress) {
                        eventPayload.isMultilineUpgrade = '1';
                    }

                    isMultilineUpgradeEligible = $window.sessionStorage.getItem(exCommonConstants.reportingMultilineEligibleStorageKey);
                    if (isMultilineUpgradeEligible) {
                        eventPayload.isMultilineUpgradeEligible = isMultilineUpgradeEligible;
                    }

                    return eventPayload;
                }

                /**
                 * Returns object with reporting data formatted for Upgrade Submit and upgrade options submit on upgrade eligibility page
                 * @param {Object} user
                 * @return {Object} eventPayload object
                 */
                function getUpgradeSubmitPayload (scope) {

                    var eventPayload = {
                        successFlag: '1',
                        statusCode: '0',
                        statusMessage: 'SUCCESS',
                        errorType: 'Success_Admit'
                    };

                    eventPayload = angular.extend(eventPayload,
                        getUpgradeEligibilityExistingItemsPayload(scope.selectedDataValue.subscriberNumber),
                        getUpgradeEligibilitySelectedItemsPayload(scope.user)
                    );
                    return eventPayload;
                }

                /**
                 * Returns modified eventPayload Object with failure information
                 * @param {Object} eventPayload
                 * @param {Object} data
                 * @return {Object} eventPayload object
                 */
                function updateEventPayloadFailure (eventPayload, data) {
                    eventPayload.errorType = 'Failure_Data';
                    eventPayload.successFlag = '0';
                    eventPayload.statusCode = [];
                    eventPayload.statusMessage = data.response.status;

                    for (var i = 0; i < data.response.errors.length; i++) {
                        eventPayload.statusCode.push(data.response.errors[i].field);
                    }

                    return eventPayload;
                }

                /**
                 * Returns modified eventPayload Object with failure information from checkout response
                 * @param {Object} eventPayload
                 * @param {Object} data
                 * @return {Object} eventPayload object
                 */
                function updateEventPayloadPaymentFailure (eventPayload, data) {
                    var statusCodes = [];
                    eventPayload.errorType = 'Failure_Data';
                    eventPayload.successFlag = '0';
                    eventPayload.statusMessage = data.response.status;

                    for (var i = 0; i < data.response.errors.length; i++) {
                        statusCodes.push(data.response.errors[i].code);
                    }
                    if (statusCodes.length > 0) {
                        eventPayload.statusCode = statusCodes.join(',');
                    }
                    return eventPayload;
                }

                /**
                 * Returns String with the event code for the upgrade eligibility page
                 * @param {Object} scope
                 * @return {String} Event Code value
                 */
                function getUpgradeSubmitEvent (scope) {
                    var firstKey = Object.keys(scope.user.selectedLines)[0];

                    if (firstKey && scope.user.selectedLines[firstKey].tradeInOptions.displayUpgradeOptionLink) {
                        return 'DS_Upgrade_Option_Submit';
                    } else {
                        return 'DS_Upgrade_Submit';
                    }

                }

                function proceedToCheckoutFeatures (features) {
                    var items = [];
                    for (var i = 0; i < Object.keys(features).length; i++) {
                        var skuId = Object.keys(features)[i],
                            item = {
                                'itemSku': skuId,
                                'itemName': features[skuId].productDisplayName,
                                'itemQty': '1',
                                'itemCategory': 'Feature'
                            };
                        items.push(item);
                    }
                    return items;
                }

                function proceedToCheckoutAccessories (accessories, configItemPrices) {
                    var items = [];
                    for (var i = 0; i < Object.keys(accessories).length; i++) {
                        var skuId = Object.keys(accessories)[i],
                            configItemPrice = (configItemPrices && configItemPrices[skuId]) ? configItemPrices[skuId] : {},
                            originalPrice = (parseFloat(configItemPrice.originalPrice)) ? parseFloat(configItemPrice.originalPrice).toFixed(2) : 0,
                            defaultPrice = (parseFloat(configItemPrice.defaultPrice)) ? parseFloat(configItemPrice.defaultPrice).toFixed(2) : 0,
                            item = {
                                'itemSku': skuId,
                                'itemName': accessories[skuId].productDisplayName,
                                'itemQty': '1',
                                'itemOneTimePrice': defaultPrice,
                                'itemDiscount': (originalPrice - defaultPrice).toFixed(2),
                                'itemCategory': 'Accessory'
                            };
                        items.push(item);
                    }
                    return items;
                }

                function proceedToCheckoutDevices (devices) {
                    var items = [];
                    for (var i = 0; i < Object.keys(devices).length; i++) {
                        var skuId = Object.keys(devices)[i],
                            priceList = devices[skuId].priceList,
                            regularPrice = Number.MAX_VALUE,
                            mrcPrice = Number.MAX_VALUE,
                            item = {};

                        for (var k = 0; k < priceList.length; k++) {
                            regularPrice = (priceList[k].type === 'regular' && priceList[k].dueToday < regularPrice) ? priceList[k].dueToday : regularPrice;
                            mrcPrice = (priceList[k].type === 'lease' && priceList[k].name.indexOf('DP') === -1 && priceList[k].monthlyLeasePrice < mrcPrice) ? priceList[k].monthlyLeasePrice : mrcPrice;
                        }

                        regularPrice = (regularPrice === Number.MAX_VALUE) ? '' : regularPrice;
                        mrcPrice = (mrcPrice === Number.MAX_VALUE) ? '' : mrcPrice;

                        item = {
                            'itemSku': skuId,
                            'itemName': devices[skuId].shortDisplayName,
                            'itemQty': '1',
                            'itemOneTimePrice': regularPrice,
                            'itemRecurringPrice': mrcPrice,
                            'itemCategory': 'Device'
                        };
                        items.push(item);
                    }
                    return items;
                }

                /**
                 * Returns object with reporting datafor items in cart formatted for proceed to checkoutfrom accessory Recommender
                 * @param {Object} scope
                 * @return {Object} eventPayload object
                 */
                function getOnProceedToCheckoutPayload (scope) {
                    var eventPayload = {
                            successFlag: '1',
                            statusCode: '0',
                            statusMessage: 'SUCCESS',
                            errorType: 'Success_Admit',
                            contractLength: scope.accessoryRecommender.myLOSGinfo.contractLength,
                            contractType: scope.accessoryRecommender.myLOSGinfo.contractType,
                            cartFulfillMethod: (scope.accessoryRecommender.cartData.storePickupOrder) ? 'Store' : 'Direct',
                            cartOneTimeAmt: scope.accessoryRecommender.cartData.cartOneTimeAmount,
                            cartTotalAmt: scope.accessoryRecommender.cartData.cartTotalAmount,
                            cartMonthlyAmt: scope.accessoryRecommender.cartData.cartMonthlyAmount
                        },
                        state = 'E',
                        losgs = scope.accessoryRecommender.cartData.losgs,
                        currentCtn = scope.accessoryRecommender.currentCtn;

                    if (losgs) {
                        var items = [],
                            deviceCount = 0,
                            hasAccessoryOnly = false;

                        for (var i = 0; i < Object.keys(losgs).length; i++) {
                            var losg = Object.keys(losgs)[i],
                                cartItems = losgs[losg].cartItems;

                            if (cartItems) {
                                var devices = cartItems.device,
                                    features = cartItems.feature,
                                    accessories = cartItems.accessory;
                                hasAccessoryOnly = (hasAccessoryOnly) ? hasAccessoryOnly : (typeof accessories === 'object' && typeof devices !== 'object');

                                if (typeof features === 'object') {
                                    items = items.concat(proceedToCheckoutFeatures(features));
                                }

                                if (typeof accessories === 'object') {
                                    var configItemPrices = scope.accessoryRecommender.itemPrice;
                                    state = (state === 'C') ? 'C' : 'I',
                                    items = items.concat(proceedToCheckoutAccessories(accessories, configItemPrices));
                                }

                                if (typeof devices === 'object') {
                                    deviceCount += Object.keys(devices).length;
                                    state = 'C';
                                    items = items.concat(proceedToCheckoutDevices(devices));
                                }
                            }
                        }
                        eventPayload['cartContents'] = 'Wireless (postpaid)|' + deviceCount + '|0|' + ((hasAccessoryOnly) ? '1' : '0');
                        eventPayload['items'] = items;
                    }
                    eventPayload = angular.extend(eventPayload, getUpgradeEligibilityExistingItemsPayload(currentCtn));
                    eventPayload['cartState'] = state;

                    return eventPayload;
                }

				/**
                 * Returns object with reporting datafor items in cart formatted for proceed to checkoutfrom accessory Recommender
                 * @param {Object} scope
                 * @return {Object} eventPayload object
                 */
                function getTradeinConsentEventPayload (consentCheckbox) {
                    var eventPayload = {
                        successFlag: '1',
                        statusCode: '0',
                        statusMessage: 'SUCCESS',
                        errorType: 'Success_Admit',
                        linkDestinationUrl: exCommonConstants.upgradePaymentConfirmation,
                        userResp: (consentCheckbox) ? 'Trade In Consent Selected' : 'Trade in Consent Unselected'
                    };
                    return eventPayload;
                }

                function getUpsellPayload (offerDetails) {
                    var eventPayload = {
                        successFlag: '1',
                        statusCode: '0',
                        statusMessage: 'SUCCESS',
                        errorType: 'Success_Admit',
                        offerCount: '0',
                        upSellOfferSelectedFlag: '0',
                        offerDisplayed: '1'
                    };

                    if (offerDetails && offerDetails.length > 0) {
                        var items = [], contractLengths = [], contractTypes = [];
                        for (var i = 0; i < offerDetails.length; i++) {
                            var item = {
                                    itemSku: offerDetails[i].skuId,
                                    itemQty: '1',
                                    itemName: offerDetails[i].displayName
                                }, contractType, contractLength;

                            if (offerDetails[i].priceList && offerDetails[i].priceList[0]) {
                                item.itemOneTimePrice = offerDetails[i].priceList[0].dueToday,
                                item.itemRecurringPrice = offerDetails[i].priceList[0].dueMonthlyLeasePrice;
                                item.itemRackRatePrice = offerDetails[i].priceList[0].itemPrice;
                                item.itemAnnualPrice = 0;
                                item.itemCategory = 'Device';
                                item.itemDiscount = offerDetails[i].priceList[0].MREDiscount;
                                contractType = offerDetails[i].priceList[0].type;
                                contractLength = offerDetails[i].priceList[0].name;
                            }
                            items.push(item);
                            contractLengths.push(contractLength);
                            contractTypes.push(contractType);
                        }
                        eventPayload.items = items;
                        eventPayload.offerCount = offerDetails.length;
                        eventPayload.contractLength = contractLengths.join('|');
                        eventPayload.contractType = contractTypes.join('|');
                    }
                    eventPayload = angular.extend(eventPayload, getMultilineReportingPayload());
                    return eventPayload;
                }


                /**
                 * Returns object with reporting datafor items in cart formatted for proceed to checkoutfrom accessory Recommender
                 * @param {Object} scope
                 * @return {Object} eventPayload object
                 */
                function getAddToCartUpsellPayload (upsellItems, offerDetails) {
                    var eventPayload = {
                        successFlag: '1',
                        statusCode: '0',
                        statusMessage: 'SUCCESS',
                        errorType: 'Success_Admit',
                        upSellOfferSelectedFlag: '1'
                    };

                    if (upsellItems && upsellItems.items && upsellItems.items.items) {
                        var items = [],
                            upsellItemsArray = upsellItems.items.items;

                        for (var i = 0; i < upsellItemsArray.length; i++) {
                            var item = {
                                'itemSku': upsellItemsArray[i].catalogRefId,
                                'itemQty': '1'
                            };

                            if (upsellItemsArray[i].valueMap && upsellItemsArray[i].valueMap.contractLength) {
                                eventPayload['contractLength'] = upsellItemsArray[i].valueMap.contractLength;
                            }

                            if (upsellItemsArray[i].valueMap && upsellItemsArray[i].valueMap.contractType) {
                                eventPayload['contractType'] = upsellItemsArray[i].valueMap.contractType;
                            }

                            for (var j = 0; j < offerDetails.length; j++) {
                                if (offerDetails[j].skuId === upsellItemsArray[i].catalogRefId) {
                                    item.itemName = offerDetails[j].displayName;
                                    if (offerDetails[j].priceList && offerDetails[j].priceList[0]) {
                                        item.itemOneTimePrice = offerDetails[j].priceList[0].dueToday,
                                        item.itemRecurringPrice = offerDetails[j].priceList[0].dueMonthlyLeasePrice;
                                    }
                                }
                            }
                            items.push(item);
                        }
                        eventPayload.items = items;
                    }
                    return eventPayload;
                }

                /**
                 * Returns object with reporting datafor items in cart formatted for proceed to checkoutfrom accessory Recommender
                 * @param {Object} paymentType
                 * @return {Object} eventPayload object
                 */
                function getUpgradePaymentFailurePayload (paymentType) {
                    var eventPayload = {
                        successFlag: '0',
                        statusCode: '-2',
                        statusMessage: '',
                        errorType: 'Failure_BusinessRule',
                        linkName: 'Submit Payment',
                        linkPosition: 'Body',
                        linkDestinationUrl: exCommonConstants.upgradePaymentConfirmation,
                        paymentMethod: paymentType
                    };
                    return eventPayload;
                }

                /**
                 * Returns object with reporting datafor items in cart formatted for proceed to checkoutfrom accessory Recommender
                 * @param {Object} eventPayload
                 * @param {Object} data
                 * @return {Object} eventPayload object
                 */
                function getTradeinIneligibleEventPayload (eventPayload, data) {
                    var existingItemsObject = getUpgradeEligibilityExistingItemsPayload(),
                        result = [];

                    if (existingItemsObject && existingItemsObject.existingItems) {
                        var existingItems = existingItemsObject.existingItems;
                        for (var i in existingItems) {
                            if (i === data.optionsBean.selectedSubscriber) {
                                existingItems[i].failureReason = data.response.errors[0].field;

                                if (data.optionsBean.contractSkuID) {
                                    existingItems[i].networkSku = existingItems[i].itemSku;
                                    existingItems[i].itemSku = data.optionsBean.contractSkuID;
                                }
                            }
                            result.push(existingItems[i]);
                        }
                        eventPayload.existingItems = result;
                    }

                    return eventPayload;
                }

                /**
                 * Returns object with reporting datafor items in cart formatted for proceed to checkoutfrom accessory Recommender
                 * @param {Object} paymentInfo
                 * @param {Object} ctn
                 * @return {Object} eventPayload object
                 */
                function getUpgradePaymentPayload (paymentInfo, upgradeTypeInfo) {
                    var eventPayload = {
                            paymentMethod: (paymentInfo && paymentInfo.paymentType && paymentInfo.paymentType === 'creditCard') ? 'New CC' : 'Payment Profile'
                        },
                        ctn = undefined,
                        itemUpgradeTypeSelected = undefined;
                    if (upgradeTypeInfo && upgradeTypeInfo.upgradeType) {
                        ctn = upgradeTypeInfo.customerCtn;
                        itemUpgradeTypeSelected = exCommonConstants.itemUpgradeTypeSelected[upgradeTypeInfo.upgradeType.toLowerCase()];
                    }
                    eventPayload = angular.extend(addEventSuccessToPayload(eventPayload), getUpgradeEligibilityExistingItemsPayload(ctn));
                    eventPayload.items = eventPayload.existingItems;
                    if (eventPayload.items && eventPayload.items[0] && upgradeTypeInfo.paymentAmount) {
                        eventPayload.items[0].itemOneTimePrice = upgradeTypeInfo.paymentAmount;
                        eventPayload.items[0].itemUpgradeTypeSelected = itemUpgradeTypeSelected;
                    }
                    delete eventPayload.existingItems;
                    return eventPayload;
                }
            }]);
})();
