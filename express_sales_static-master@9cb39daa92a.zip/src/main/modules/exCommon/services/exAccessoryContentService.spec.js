(function () {
    'use strict';

    define(['exAccessoryContentService'], function () {
        describe('src/main/modules/exCommon/services/exAccessoryContentService.spec.js', function () {
            describe('exAccessoryContentService service of exCommon', function () {
                var $httpBackend, service, $log;

                beforeEach(function () {

                    module('exCommon');

                    inject(function ($injector) {
                        $httpBackend = $injector.get('$httpBackend');
                        $log = $injector.get('$log');
                        service = $injector.get('exAccessoryContentService');
                        spyOn($log, 'error');
                    });
                });

                describe('network related calls', function () {
                    afterEach(function () {
                        $httpBackend.verifyNoOutstandingExpectation();
                        $httpBackend.verifyNoOutstandingRequest();
                    });

                    describe('getAccessoryDetailsLegacyContent', function () {
                        it('should return results when called successfully', function () {
                            var mockAccessoryPageUrl = '/cases/otterbox-defender-series-way-case-and-holster-iphone-7-plus';

                            $httpBackend.whenGET(Endpoint_accessoryDetailLegacyNode.get_legacy_content.url_match)
                                .respond(200, Endpoint_accessoryDetailLegacyNode.get_legacy_content.result);

                            service.getDetailsLegacyContent(mockAccessoryPageUrl).then(function (accessoryContent) {
                                expect(accessoryContent).toContain(
                                    '<p>Worry less while you’re on the job. Defender Series combines three ultra'
                                );
                            });

                            $httpBackend.flush();
                        });

                        it('should log console error when the request failed', function () {
                            var mockAccessoryPageUrl = '/cases/otterbox-defender-series-way-case-and-holster-iphone-7-plus',
                                expectedErrorMessage = 'exAccessoryContentService.getDetailsLegacyContent call failed.';

                            $httpBackend.whenGET(Endpoint_accessoryDetailLegacyNode.get_legacy_content.url_match)
                                .respond(404, '');
                            service.getDetailsLegacyContent(mockAccessoryPageUrl).then(function () {
                                fail('Response that should have failed, succeeded!');
                            }).catch(function () {
                                expect($log.error).toHaveBeenCalledWith(expectedErrorMessage);
                            });

                            $httpBackend.flush();
                        });
                    });
                });
            });
        });
    });
})();
