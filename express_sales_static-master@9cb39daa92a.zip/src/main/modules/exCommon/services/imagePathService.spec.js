(function () {
    'use strict';

    define(['imagePathService'], function () {
        describe('src/main/modules/exCommon/services/imagePathService.spec.js', function () {
            describe('imagePathService service of exCommon', function () {
                var service, exCommonConstants;

                beforeEach(function () {
                    module('exCommon');

                    inject(function ($injector) {
                        service = $injector.get('imagePathService');
                        exCommonConstants = $injector.get('exCommonConstants');
                    });
                });

                describe('getXpressImagePath', function () {
                    it('should use displayName if shortDisplayName is not available', function () {
                        var product = {
                            manufacturer: 'Superior',
                            shortDisplayName: null,
                            displayName: 'AT&T Cable Coiled 3 ft. Charge and Sync Micro USB',
                            color: 'Black',
                            ext: '-hero.png'
                        };
                        var expectedReturnValue = exCommonConstants.deviceImageUrlRoot +
                            'Superior/AT&T Cable Coiled 3 ft_ Charge and Sync Micro USB/Black-hero.png';

                        var imagePathReturned =
                            service.getXpressImagePath(
                                product.manufacturer,
                                product.shortDisplayName,
                                product.displayName,
                                product.color,
                                product.ext
                            );
                        expect(imagePathReturned).toEqual(expectedReturnValue);
                    });

                    it('should replace non-existing fields with the default value', function () {
                        var product = {
                            manufacturer: null,
                            shortDisplayName: null,
                            displayName: undefined,
                            color: null,
                            ext: '-hero.png'
                        };
                        var expectedReturnValue = exCommonConstants.deviceImageUrlRoot +
                            'unknown/unknown/unknown-hero.png';

                        var imagePathReturned =
                            service.getXpressImagePath(
                                product.manufacturer,
                                product.shortDisplayName,
                                product.displayName,
                                product.color,
                                product.ext
                            );
                        expect(imagePathReturned).toEqual(expectedReturnValue);
                    });

                    it('should trim param values properly', function () {
                        var product = {
                            manufacturer: '  Superior  ',
                            shortDisplayName: null,
                            displayName: ' AT&T Cable Coiled 3 ft. Charge and Sync Micro USB   ',
                            color: 'Black ',
                            ext: '-hero.png'
                        };
                        var expectedReturnValue = exCommonConstants.deviceImageUrlRoot +
                            'Superior/AT&T Cable Coiled 3 ft_ Charge and Sync Micro USB/Black-hero.png';

                        var imagePathReturned =
                            service.getXpressImagePath(
                                product.manufacturer,
                                product.shortDisplayName,
                                product.displayName,
                                product.color,
                                product.ext
                            );
                        expect(imagePathReturned).toEqual(expectedReturnValue);
                    });

                    it('should replace special characters properly', function () {
                        var product = {
                            manufacturer: '~#%*()Superior',
                            shortDisplayName: null,
                            displayName: '/\\:|"AT&T Cable Coiled 3 ft. Charge and Sync Micro USB',
                            color: 'Black',
                            ext: '-hero.png'
                        };
                        var expectedReturnValue = exCommonConstants.deviceImageUrlRoot +
                            '______Superior/_____AT&T Cable Coiled 3 ft_ Charge and Sync Micro USB/Black-hero.png';

                        var imagePathReturned =
                            service.getXpressImagePath(
                                product.manufacturer,
                                product.shortDisplayName,
                                product.displayName,
                                product.color,
                                product.ext
                            );
                        expect(imagePathReturned).toEqual(expectedReturnValue);
                    });
                });

                describe('getCatalogImagePath', function () {
                    it('should build an image path properly from the params provided', function () {
                        var product = {
                            path: exCommonConstants.deviceCatalogUrlRoot,
                            manufacturer: 'apple',
                            model: 'iphone 7',
                            color: 'black',
                            ext: '-100x160.jpg'
                        };
                        var expectedReturnValue = exCommonConstants.deviceCatalogUrlRoot +
                            'apple-iphone 7-black-100x160.jpg';

                        var imagePathReturned =
                            service.getCatalogImagePath(
                                product.path,
                                product.manufacturer,
                                product.model,
                                product.color,
                                product.ext
                            );
                        expect(imagePathReturned).toEqual(expectedReturnValue);
                    });

                    it('should build an image path properly from the params provided when color is not defined', function () {
                        var product = {
                            path: exCommonConstants.deviceCatalogUrlRoot,
                            manufacturer: 'apple',
                            model: 'iphone 7',
                            color: null,
                            ext: '-100x160.jpg'
                        };
                        var expectedReturnValue = exCommonConstants.deviceCatalogUrlRoot +
                            'apple-iphone 7-100x160.jpg';

                        var imagePathReturned =
                            service.getCatalogImagePath(
                                product.path,
                                product.manufacturer,
                                product.model,
                                product.color,
                                product.ext
                            );
                        expect(imagePathReturned).toEqual(expectedReturnValue);
                    });
                });
            });
        });
    });
})();
