(function () {
    'use strict';

    define(['protectionPlanService'], function () {
        describe('src/main/modules/exCommon/services/protectionPlanService.spec.js', function () {
            describe('protectionPlanService service of exCommon', function () {
                var $httpBackend, service, $log;

                beforeEach(function () {

                    module('exCommon');

                    inject(function ($injector) {
                        $httpBackend = $injector.get('$httpBackend');
                        $log = $injector.get('$log');
                        service = $injector.get('protectionPlanService');
                        spyOn($log, 'error');
                    });
                });

                describe('network related calls', function () {
                    afterEach(function () {
                        $httpBackend.verifyNoOutstandingExpectation();
                        $httpBackend.verifyNoOutstandingRequest();
                    });

                    it('should return results when called successfully', function () {
                        $httpBackend.whenGET(Endpoint_protectionApi.get_insurance_features.url_match)
                            .respond(200, Endpoint_protectionApi.get_insurance_features.result);
                        service.getInsuranceFeatures('reload').then(function (result) {
                            expect(result).toBeDefined();
                            expect(result.payload).toBeDefined();
                            expect(result.payload.sku5370279.skuId).toEqual('sku5370279');
                            expect(result.payload.sku5370279.isAccountLevelFeature).toEqual(false);
                            expect(result.payload.sku5370279.mRCDetailsBean).toBeDefined();
                            expect(result.payload.sku5370279.mRCDetailsBean.baseMRCPrice).toBeDefined();
                            expect(result.payload.sku5370279.mRCDetailsBean.baseMRCPrice).toEqual(10.99);
                        });
                        $httpBackend.flush();
                    });

                    it('should log console error when the request failed', function () {
                        var expectedErrorMessage = 'protectionPlanService.getInsuranceFeatures call failed.';
                        $httpBackend.whenGET(Endpoint_protectionApi.get_insurance_features.url_match)
                            .respond(404, '');
                        service.getInsuranceFeatures('reload').then(function () {
                            fail('Response that should have failed, succeeded!');
                        }).catch(function () {
                            expect($log.error).toHaveBeenCalledWith(expectedErrorMessage);
                        });
                        $httpBackend.flush();
                    });

                });
            });
        });
    });
})();
