(function () {
    'use strict';

    define(['upgradingUserInfoSrv'], function () {
        describe('src/main/modules/exCommon/services/upgradingUserInfoSrv.spec.js', function () {
            describe('upgradingUserInfoSrv service of exCommon', function () {
                var $httpBackend, upgradingUserInfoSrv, $window, exCacheManager, $cookies;

                beforeEach(function () {
                    module('exCommon');

                    inject(function ($injector) {
                        $httpBackend = $injector.get('$httpBackend');
                        upgradingUserInfoSrv = $injector.get('upgradingUserInfoSrv');
                        $window = $injector.get('$window');
                        exCacheManager = $injector.get('exCacheManager');
                        $cookies = $injector.get('$cookies');
                    });
                    spyOn($window.sessionStorage, 'getItem');
                    spyOn($window.sessionStorage, 'setItem');
                    spyOn($window.sessionStorage, 'removeItem');
                    spyOn(exCacheManager, 'clearCacheItem');
                    spyOn($cookies, 'get');
                });

                afterEach(function () {
                    $window.sessionStorage.removeItem.calls.reset();
                    exCacheManager.clearCacheItem.calls.reset();
                    $cookies.get.calls.reset();
                });

                it('should spin some webs', function () {});

                describe('getUpgradingDeviceDetailsData function of the upgradingUserInfoSrv', function () {
                    var sessionID = 'undefined';
                    it('should get the upgrading device detail from buyflow API', function () {
                        $httpBackend.whenGET(Endpoint_deviceRecommenderApi.getUpgradingDetails_Phone.url_match.params_sent).respond(200, Endpoint_deviceRecommenderApi.getUpgradingDetails_Phone.result);
                        upgradingUserInfoSrv.getUpgradingDeviceDetailsData().then(function (result) {
                            expect($window.sessionStorage.getItem).toHaveBeenCalledWith('selectedUpLine-' + sessionID);
                            expect($window.sessionStorage.setItem).toHaveBeenCalledWith('selectedUpLine-' + sessionID, JSON.stringify(Endpoint_deviceRecommenderApi.getUpgradingDetails_Phone.result));
                            expect(result).toBeDefined();
                            expect(result.response.redirectKey).toEqual(null);
                            expect(result.response.status).toEqual('success');
                            expect(result.payload.deviceMake).toEqual('APPLE');
                            expect(result.payload.color).toEqual('Space Gray');
                            expect(result.payload.deviceModel).toEqual('iPhone 6');
                            expect(result.payload.ctn).toEqual('4252951153');
                        });
                        $httpBackend.flush();
                    });
                });

                describe('getDeviceType function of the upgradingUserInfoSrv', function () {
                    var deviceType;
                    it('should set the upgrading device type if device type is pda or handset', function () {
                        deviceType = upgradingUserInfoSrv.getDeviceType('pda');
                        expect(deviceType).toEqual('phone');
                    });
                    it('should set the upgrading device type if device type is netbook', function () {
                        deviceType = upgradingUserInfoSrv.getDeviceType('netbook');
                        expect(deviceType).toEqual('tablet');
                    });
                    it('should set the upgrading device type if device type is network', function () {
                        deviceType = upgradingUserInfoSrv.getDeviceType('network');
                        expect(deviceType).toEqual('device');
                    });
                    it('should set the upgrading device type even if device type is blank', function () {
                        deviceType = upgradingUserInfoSrv.getDeviceType('');
                        expect(deviceType).toEqual('device');
                    });
                });

                describe('clearUpgradingLineCache function of the upgradingUserInfoSrv', function () {
                    it('should clear the cache and storage', function () {
                        upgradingUserInfoSrv.clearUpgradingLineCache();
                        expect($window.sessionStorage.removeItem).toHaveBeenCalled();
                        expect(exCacheManager.clearCacheItem).toHaveBeenCalled();
                    });
                });
            });
        });
    });
})();
