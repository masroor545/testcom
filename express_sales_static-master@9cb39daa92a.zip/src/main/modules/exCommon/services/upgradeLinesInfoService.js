(function () {
    'use strict';

    angular.module('exCommon')

        .factory('upgradeLinesInfoService', ['$window', 'exCommonConstants',
            function ($window, exCommonConstants) {

                var services = {
                    setUpgradeLinesInfo: setUpgradeLinesInfo,
                    getUpgradeLinesInfo: getUpgradeLinesInfo
                };

                /**
                 * Set shared upgrade lines information into session storage.
                 * @function setUpgradeLinesInfo
                 * @param {object} upgradeLinesInfo - upgrading lines details
                 */
                function setUpgradeLinesInfo (upgradeLinesInfo) {
                    $window.sessionStorage.setItem(exCommonConstants.upgradeLineStorageKey, JSON.stringify(upgradeLinesInfo));
                }

                /**
                 * function returns shared upgrade lines information from session storage.
                 * @function getUpgradeLinesInfo
                 * @returns {object} upgrading lines details
                 */
                function getUpgradeLinesInfo () {
                    var upgradeLinesInfoDetails = $window.sessionStorage.getItem(exCommonConstants.upgradeLineStorageKey);
                    return JSON.parse(upgradeLinesInfoDetails);
                }

                return services;
            }]);
})();
