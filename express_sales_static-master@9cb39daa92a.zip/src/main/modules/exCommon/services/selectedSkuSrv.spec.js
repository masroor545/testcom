(function () {
    'use strict';

    define(['selectedSkuSrv'], function () {
        describe('src/main/modules/exCommon/services/selectedSkuSrv.spec.js', function () {
            describe('selectedSkuSrv service of exCommon', function () {
                var $rootScope, service, exCommonConstants;

                beforeEach(function () {

                    module('exCommon');

                    inject(function ($injector) {
                        exCommonConstants = $injector.get('exCommonConstants');
                        service = $injector.get('selectedSkuSrv');
                        $rootScope = $injector.get('$rootScope');
                        spyOn($rootScope, '$broadcast');
                    });
                });

                describe('selected device service', function () {
                    it('should return null if sku has not been set', function () {
                        expect(service.getSelectedDevice()).toEqual(null);
                    });

                    it('should get and set the selected sku', function () {
                        var sku = 'sku8040300';
                        service.setSelectedDevice(sku);
                        expect($rootScope.$broadcast).toHaveBeenCalledWith(exCommonConstants.event.deviceSelected, sku);
                        expect(service.getSelectedDevice()).toEqual(sku);
                    });

                    it('should not broadcast if the selected sku has not changed', function () {
                        // Calls service to set the sku
                        var sku = 'sku8040300';
                        service.setSelectedDevice(sku);
                        $rootScope.$broadcast.calls.reset();

                        // Checks the service hasn't been called
                        service.setSelectedDevice(sku);
                        expect($rootScope.$broadcast).not.toHaveBeenCalledWith(exCommonConstants.event.deviceSelected, sku);
                    });

                    it('should throw an error if no argument is passed', function () {
                        expect(function () { service.setSelectedDevice(); }).toThrow(new SyntaxError('No argument passed'));
                    });

                });

                describe('selected accessory service', function () {
                    it('should return null if sku has not been set', function () {
                        expect(service.getSelectedAccessory()).toEqual(null);
                    });

                    it('should get and set the selected sku', function () {
                        var sku = 'sku8040300';
                        service.setSelectedAccessory(sku);
                        expect($rootScope.$broadcast).toHaveBeenCalledWith(exCommonConstants.event.accessorySelected, sku);
                        expect(service.getSelectedAccessory()).toEqual(sku);
                    });

                    it('should not broadcast if the selected sku has not changed', function () {
                        // Calls service to set the sku
                        var sku = 'sku8040300';
                        service.setSelectedAccessory(sku);
                        $rootScope.$broadcast.calls.reset();

                        // Checks the service hasn't been called
                        service.setSelectedAccessory(sku);
                        expect($rootScope.$broadcast).not.toHaveBeenCalledWith(exCommonConstants.event.deviceSelected, sku);
                    });

                    it('should throw an error if no argument is passed', function () {
                        expect(function () { service.setSelectedAccessory(); }).toThrow(new SyntaxError('No argument passed'));
                    });

                });

            });
        });
    });
})();
