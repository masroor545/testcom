(function () {
    'use strict';

    define(['exCommonConstants'], function () {
        describe('src/main/modules/exCommon/services/exCommonConstants.spec.js', function () {
            var service;

            beforeEach(module('exCommon'));

            beforeEach(function () {
                inject(function ($injector) {
                    service = $injector.get('exCommonConstants');
                });
            });

            it('Should check the constant values to be defined', function () {
                expect(service.accessoryDetailLegacyNode).toBeDefined();
                expect(service.accordionTimer).toBeDefined();
                expect(service.catalogApi).toBeDefined();
                expect(service.event.accessoryConfigWidgetAdded).toBeDefined();
                expect(service.event.accessoryConfigLoaded).toBeDefined();
                expect(service.buyflowApi).toBeDefined();
                expect(service.event.BVInitiated).toBeDefined();
                expect(service.event.BVSkuSelected).toBeDefined();
                expect(service.cartServiceApi).toBeDefined();
                expect(service.cartLookupApi).toBeDefined();
                expect(service.cartStorageKey).toBeDefined();
                expect(service.colorMatrix).toBeDefined();
                expect(service.commitmentTermCmsKeyPartForLegal).toBeDefined();
                expect(service.commitmentTermLabels).toBeDefined();
                expect(service.commitmentTermLegalLabels).toBeDefined();
                expect(service.commitTermDeviceConfigShortLegalLbl).toBeDefined();
                expect(service.contractDeviceErrorKey).toBeDefined();
                expect(service.cqTranslatorKeyApi).toBeDefined();
                expect(service.cqTranslatorStorageKey).toBeDefined();
                expect(service.deviceCatalogUrlRoot).toBeDefined();
                expect(service.deviceConfigHylaPromoDetailsModal).toBeDefined();
                expect(service.deviceDetailsApi).toBeDefined();
                expect(service.deviceImageUrlRoot).toBeDefined();
                expect(service.colorMatrix).toBeDefined();
                expect(service.event.cartCompletedOnAccessoryPageLoad).toBeDefined();
                expect(service.event.deviceSelected).toBeDefined();
                expect(service.event.deviceAddedFromDetails).toBeDefined();
                expect(service.event.deviceConfigWidgetBVInitiated).toBeDefined();
                expect(service.event.accessoryConfigWidgetBVInitiated).toBeDefined();
                expect(service.event.deviceConfigWidgetAdded).toBeDefined();
                expect(service.event.accessorySelected).toBeDefined();
                expect(service.event.cartDataUpdated).toBeDefined();
                expect(service.event.changePriceClickFromWidget).toBeDefined();
                expect(service.event.deviceAdded).toBeDefined();
                expect(service.event.deviceConfigLoaded).toBeDefined();
                expect(service.event.deviceSelected).toBeDefined();
                expect(service.event.hideGlobalNav).toBeDefined();
                expect(service.event.paymentInfoValidated).toBeDefined();
                expect(service.event.protectionPlanAdded).toBeDefined();
                expect(service.event.protectionPlanCancel).toBeDefined();
                expect(service.event.REFRESH_GLOBAL_NAV_CART).toBeDefined();
                expect(service.event.selectedSkuInFocus).toBeDefined();
                expect(service.event.showGlobalNav).toBeDefined();
                expect(service.event.DS_REPORTING_EVENT).toBeDefined();
                expect(service.event.DS_REPORTING_PAGELOAD_EVENT).toBeDefined();
                expect(service.globalNavCartUpdateTimeout).toBeDefined();
                expect(service.legalContentKeyPrefix).toBeDefined();
                expect(service.insuranceCategories.sku5370279).toBeDefined();
                expect(service.insuranceCategories.sku7250407).toBeDefined();
                expect(service.insuranceCategories.sku1040075).toBeDefined();
                expect(service.insuranceOptionsModalPath).toBeDefined();
                expect(service.insuranceDetailsLegalModalPath).toBeDefined();
                expect(service.itemUpgradeTypeRecommended.fullyEligible).toBeDefined();
                expect(service.itemUpgradeTypeRecommended.fullPrice).toBeDefined();
                expect(service.itemUpgradeTypeRecommended.inEligible).toBeDefined();
                expect(service.itemUpgradeTypeRecommended.nextTradein).toBeDefined();
                expect(service.itemUpgradeTypeRecommended.payOff).toBeDefined();
                expect(service.itemUpgradeTypeRecommended.payUp).toBeDefined();
                expect(service.itemUpgradeTypeSelected.none).toBeDefined();
                expect(service.itemUpgradeTypeSelected.payoff).toBeDefined();
                expect(service.itemUpgradeTypeSelected.payup).toBeDefined();
                expect(service.itemUpgradeTypeSelected.payupcontract).toBeDefined();
                expect(service.itemUpgradeTypeSelected.replace).toBeDefined();
                expect(service.itemUpgradeTypeSelected.tradein).toBeDefined();
                expect(service.itemUpgradeTypeSelected.tradeincontract).toBeDefined();
                expect(service.threeSixtyProductXmlPath).toBeDefined();
                expect(service.productContentNodePath).toBeDefined();
                expect(service.productLegalContentNodePath).toBeDefined();
                expect(service.selectedLineStorageKey).toBeDefined();
                expect(service.seoCrossLinkLegal).toBeDefined();
                expect(service.sharedContentRetrievalUrl).toBeDefined();
                expect(service.shortLegalContentCmsKey).toBeDefined();
                expect(service.hardStopPage).toBeDefined();
                expect(service.heroDeviceImageUrlExtension).toBeDefined();
                expect(service.http.postAuthReq).toBeDefined();
                expect(service.hylaPromotionContentUrl).toBeDefined();
                expect(service.hylaPromotionLabel).toBeDefined();
                expect(service.hylaPromotionLabel.hylaTradeInOffer).toBeDefined();
                expect(service.hylaPromotionLabel.hylaLegalTerms).toBeDefined();
                expect(service.hylaPromotionLabel.hylaSeeOfferDetails).toBeDefined();
                expect(service.hylaPromotionLabel.hylaCheckBoxLabel).toBeDefined();
                expect(service.paymentSummaryStorageKey).toBeDefined();
                expect(service.mobileViewportMax).toBeDefined();
                expect(service.profileInfoApi).toBeDefined();
                expect(service.profileStorageKey).toBeDefined();
                expect(service.protectionPlanLegalModal).toBeDefined();
                expect(service.protectionPlanStorageKey).toBeDefined();
                expect(service.recommendedAccessoriesNodePath).toBeDefined();
                expect(service.reportingContractLengthStorageKey).toBeDefined();
                expect(service.reportingContractTypeStorageKey).toBeDefined();
                expect(service.reportingExistingItemsStorageKey).toBeDefined();
                expect(service.reportingMultilineEligibleStorageKey).toBeDefined();
                expect(service.tradeinConsent).toBeDefined();
                expect(service.upgradeEligibility).toBeDefined();
                expect(service.upgradeEligibilityNoImage).toBeDefined();
                expect(service.upgradePaymentConfirmation).toBeDefined();
                expect(service.upsellOfferApi).toBeDefined();
                expect(service.upsellSeeOfferDetailsModal).toBeDefined();
                expect(service.upsellOfferApi).toBeDefined();
                expect(service.upsellOfferId).toBeDefined();
                expect(service.omniChannelDeliveryPromiseSuppression).toBeDefined();
                expect(service.onePageCheckout).toBeDefined();
                expect(service.favStoreStorageKey).toBeDefined();
                expect(service.favStoreApi).toBeDefined();
                expect(service.sharedContentFetchUrl).toBeDefined();
                expect(service.errorStatus).toBeDefined();
                expect(service.insuranceOptionContentPath).toBeDefined();
                expect(service.deviceRecommender).toBeDefined();
                expect(service.pricingOptionsModal).toBeDefined();
                expect(service.friendlyPageName).toBeDefined();
                expect(service.virtualUrl).toBeDefined();
                expect(service.cartSummaryPageUrl).toBeDefined();
                expect(service.cartSummaryPageUrl).toBeDefined();
                expect(service.friendlyPageName.accessoryDetails).toBeDefined();
                expect(service.friendlyPageName.accessoryRecommenderDetails).toBeDefined();
                expect(service.friendlyPageName.deviceDetails).toBeDefined();
                expect(service.friendlyPageName.deviceDetailsHero).toBeDefined();
                expect(service.friendlyPageName.deviceRecommenderDetails).toBeDefined();
                expect(service.friendlyPageName.insuranceOptions).toBeDefined();
                expect(service.friendlyPageName.insuranceOptionsLegal).toBeDefined();
                expect(service.friendlyPageName.priceChangeOptions).toBeDefined();
                expect(service.friendlyPageName.subTotalDetailsLegal).toBeDefined();
                expect(service.virtualUrl.accessoryDetails).toBeDefined();
                expect(service.virtualUrl.accessoryRecommenderDetails).toBeDefined();
                expect(service.virtualUrl.deviceDetails).toBeDefined();
                expect(service.virtualUrl.deviceDetailsHero).toBeDefined();
                expect(service.virtualUrl.deviceRecommenderDetails).toBeDefined();
                expect(service.virtualUrl.insuranceOptions).toBeDefined();
                expect(service.virtualUrl.insuranceOptionsLegal).toBeDefined();
                expect(service.virtualUrl.priceChangeOptions).toBeDefined();
                expect(service.virtualUrl.subTotalDetailsLegal).toBeDefined();
                expect(service.event.paymentModalTriggered).toBeDefined();
                expect(service.upgradeLineStorageKey).toBeDefined();
                expect(service.linkName).toBeDefined();
                expect(service.linkPosition).toBeDefined();
                expect(service.shopSessionId).toBeDefined();
                expect(service.enjoyDeliveryMesssageAPI).toBeDefined();
                expect(service.bopisDeliveryMesssageAPI).toBeDefined();
                expect(service.deliveryDatePromiseMessage).toBeDefined();
            });

            describe('color matrix', function () {
                it('should only contain all uppercase values', function () {
                    service.colorMatrix.forEach(function (hexValue) {
                        if (hexValue !== hexValue.toUpperCase()) {
                            fail(hexValue + ' must be uppercase');
                        }
                    });
                });
            });

            describe('commitment terms and cms key for legal', function () {
                it('should check for commitment term cms key', function () {
                    angular.forEach(service.commitmentTermCmsKeyPartForLegal, function (value) {
                        expect(value.termKey).toBeDefined();
                    });
                });
            });
        });
    });
})();
