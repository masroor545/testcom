(function () {
    'use strict';

    angular.module('exCommon')

        .factory('imagePathService', ['exCommonConstants',
            function (exCommonConstants) {
                var imagePathService = {
                    getXpressImagePath: getXpressImagePath,
                    getCatalogImagePath: getCatalogImagePath
                };

                /**
                 * Cleans any string by the same rules by which the zippy/xpress image paths have been
                 *  created for in SVN (/catalog/en/xpress).
                 * @function getCleanString
                 * @param dirty Uncleaned image string fragment
                 * @return {string} Cleaned image string fragment
                 * @private
                 */
                function getCleanString (dirty) {
                    var anythingThatDoesntMatch = /[^0-9a-zA-Z&+_ -]/g;
                    var leadingAndTrailingSpaces = /^\s+|\s+$/g;
                    var replacement = '_';
                    var nothing = '';
                    var clean;

                    clean = dirty || 'unknown';
                    clean = clean.replace(anythingThatDoesntMatch, replacement);
                    clean = clean.replace(leadingAndTrailingSpaces, nothing);

                    return clean;
                }

                /**
                 * Builds the xpress image path from the information contained within the function params.
                 * @function getXpressImagePath
                 * @param {string} manufacturer - manufacturer value from catalog
                 * @param {string} shortDisplayName - shortDisplayName value from catalog
                 * @param {string} displayName - displayName value from catalog
                 * @param {string} color - color value from catalog
                 * @param {string} extension - extension of the image wished ('-hero.png', '-hero-zoom.png', etc.pp)
                 * @return {string} xpress image path
                 * @public
                 */
                function getXpressImagePath (manufacturer, shortDisplayName, displayName, color, extension) {
                    var manufacturerClean = getCleanString(manufacturer);
                    var nameClean = getCleanString(shortDisplayName || displayName);
                    var colorClean = getCleanString(color);

                    return exCommonConstants.deviceImageUrlRoot
                        + manufacturerClean + '/'
                        + nameClean + '/'
                        + colorClean + extension;
                }

                /**
                 * Builds the legacy catalog image path from the provided function params.
                 * @param {string} image - image base path
                 * @param {string} manufacturer - product manufacturer
                 * @param {string} model - product model
                 * @param {string} color - product color
                 * @param {string} extension - extension wished for (Ex: '-100x160.jpg')
                 * @return {string} catalog image path
                 * @public
                 */
                function getCatalogImagePath (image, manufacturer, model, color, extension) {
                    if (color) {
                        return image + manufacturer + '-' + model + '-' + color + extension;
                    } else {
                        return image + manufacturer + '-' + model + extension;
                    }
                }

                return imagePathService;
            }]);
})();
