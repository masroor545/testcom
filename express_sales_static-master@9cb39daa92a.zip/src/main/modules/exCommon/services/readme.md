## Objects

<dl>
<dt><a href="#contentService">contentService</a> ⇒ <code>Promise.&lt;Object&gt;</code></dt>
<dd><p>Makes a request to a product 360 .xml file and returns a promise.
 If the promise resolves the result of the request will be returned.</p>
</dd>
<dt><a href="#contentService">contentService</a> ⇒ <code>Promise.&lt;Array&gt;</code></dt>
<dd><p>Makes a request to productPageUrl&#39;s product key features node, and returns a promise for it. If
 the response is received it converts the response.data into a developer friendly JSON and returns
 it.</p>
</dd>
<dt><a href="#contentService">contentService</a> ⇒ <code>Promise</code></dt>
<dd><p>Makes a request to productPageUrl&#39;s product specifications node and returns a Promise. If a successful
 response is received it is converted into a developer friendly JSON and returned.</p>
</dd>
<dt><a href="#contentService">contentService</a> ⇒ <code>Promise.&lt;Object&gt;</code></dt>
<dd><p>Makes a request call to the products page legal content nodes returns a promise.
 If the promise resolves the result of the request will be returned.</p>
</dd>
<dt><a href="#contentService">contentService</a> ⇒ <code>Promise.&lt;Array&gt;</code></dt>
<dd><p>Makes a request call to the shared content retrieval service for the legalPaths
 and returns a promise. If the promise resolves the result of the request will be returned.</p>
</dd>
<dt><a href="#deviceConfigSrv">deviceConfigSrv</a> : <code>object</code></dt>
<dd><p>Factory for services used in device configuration</p>
</dd>
<dt><a href="#exAccessoryContentService">exAccessoryContentService</a> ⇒ <code>Promise.&lt;Object&gt;</code></dt>
<dd><p>Makes a request to the accessory detail legacy content node and returns a promise.
 If the promise resolves the result of the request will be returned.</p>
</dd>
<dt><a href="#exCartService">exCartService</a> ⇒ <code>Promise.&lt;Object&gt;</code></dt>
<dd><p>Makes a request to the cart lookup API and returns a promise.
 If the promise resolves the result of the request will be returned.</p>
</dd>
<dt><a href="#exCqTranslatorKeyService">exCqTranslatorKeyService</a> ⇒ <code>Promise.&lt;Object&gt;</code></dt>
<dd><p>Makes a request to the CQ translator key API and returns a promise.
 If the promise resolves the result of the request will be returned.
 Only keys that aren&#39;t cached within the session will be requested.</p>
</dd>
<dt><a href="#favStoreService">favStoreService</a> ⇒ <code>Promise</code></dt>
<dd><p>Gets the favStoreId of the user on the basis of user&#39;s UUID</p>
</dd>
<dt><a href="#profileInfoService">profileInfoService</a> ⇒ <code>Promise</code></dt>
<dd></dd>
</dl>

## Functions

<dl>
<dt><a href="#getSharedContentForInsurance">getSharedContentForInsurance(skuIds)</a> ⇒ <code>Object</code></dt>
<dd><p>Gets the insurance plan description from shared content service of CQ for each
insurance sku.</p>
</dd>
<dt><a href="#transformThreeSixtyXml2Json">transformThreeSixtyXml2Json(response)</a> ⇒ <code>Array.&lt;Object&gt;</code></dt>
<dd><p>Transforms the 360 xml images data to a JSON array.</p>
</dd>
<dt><a href="#getProduct360ImagesCompleted">getProduct360ImagesCompleted(result)</a> ⇒ <code>Promise.&lt;Object&gt;</code></dt>
<dd><p>Returns the data property of the getProduct360Images response object.</p>
</dd>
<dt><a href="#getProductOverviewContentCompleted">getProductOverviewContentCompleted(result)</a> ⇒ <code>Array</code></dt>
<dd><p>Parses and converts the getProductOverviewContent response.data object and returns a developer
 friendly JSON.</p>
</dd>
<dt><a href="#getProductFeaturesContentCompleted">getProductFeaturesContentCompleted(result)</a> ⇒ <code>Promise.&lt;Array&gt;</code></dt>
<dd><p>Returns the parsed and converted JSON Array of the getProductFeaturesContent response.data object.</p>
</dd>
<dt><a href="#getProductLegalContentCompleted">getProductLegalContentCompleted(result)</a> ⇒ <code>Array</code></dt>
<dd><p>Returns the parsed and converted JSON of the getProductLegalPaths response object.</p>
</dd>
<dt><a href="#getProductLegalContentCompleted">getProductLegalContentCompleted(results, legalPaths)</a> ⇒ <code>Array</code></dt>
<dd><p>Returns the parsed and converted JSON of the getProductLegalContent response object.</p>
</dd>
<dt><a href="#getSharedContent">getSharedContent(contentPaths)</a> ⇒ <code>Promise.&lt;Array&gt;</code></dt>
<dd><p>Makes a request call to the device shared content retrieval service for the contentPaths
and returns a promise. If the promise resolves the result of the request will be returned.</p>
</dd>
<dt><a href="#getSharedContentCompleted">getSharedContentCompleted(result, contentPaths)</a> ⇒ <code>Array</code></dt>
<dd><p>Returns the parsed and converted JSON of the getSharedContent response object.</p>
</dd>
<dt><a href="#hylaPromotionDetails">hylaPromotionDetails()</a> ⇒ <code>object</code></dt>
<dd><p>gets the hyla offer content details from hylaPromotionContentUrl</p>
</dd>
<dt><a href="#getDetailsLegacyContentCompleted">getDetailsLegacyContentCompleted(result)</a> ⇒ <code>Promise.&lt;Object&gt;</code></dt>
<dd><p>Returns the parsed and converted data property of the
accessory detail legacy content response object.</p>
</dd>
<dt><a href="#addItemToCart">addItemToCart(items, params)</a> ⇒ <code>Promise.&lt;Object&gt;</code></dt>
<dd><p>Makes a POST request to the cart service API and returns a promise.</p>
</dd>
<dt><a href="#addItemToCartCompleted">addItemToCartCompleted(result)</a> ⇒ <code>Promise.&lt;Object&gt;</code></dt>
<dd><p>Returns the data property of the add item to cart response object.</p>
</dd>
<dt><a href="#addItemToCartFailed">addItemToCartFailed(error)</a> ⇒ <code>Promise.&lt;Error&gt;</code></dt>
<dd><p>Logs an error and rejects the promise returned by the add to cart item function.</p>
</dd>
<dt><a href="#getCartCompleted">getCartCompleted(result)</a> ⇒ <code>Promise.&lt;Object&gt;</code></dt>
<dd><p>Returns the data property of the cart lookup response object.</p>
</dd>
<dt><a href="#removeItemFromCart">removeItemFromCart(params)</a> ⇒ <code>Promise.&lt;Object&gt;</code></dt>
<dd><p>Makes a POST request to the remove cart item and returns a promise.</p>
</dd>
<dt><a href="#removeItemFromCartCompleted">removeItemFromCartCompleted(result)</a> ⇒ <code>Promise.&lt;Object&gt;</code></dt>
<dd><p>Returns the data property of the remove item from cart response object.</p>
</dd>
<dt><a href="#removeItemFromCartFailed">removeItemFromCartFailed(error)</a> ⇒ <code>Promise.&lt;Error&gt;</code></dt>
<dd><p>Logs an error and rejects the promise returned by the remove cart item function.</p>
</dd>
<dt><a href="#removeItemFromPersistentCart">removeItemFromPersistentCart(Items)</a> ⇒ <code>object</code></dt>
<dd><p>Empty current cart</p>
</dd>
<dt><a href="#getFavStoreIdCompleted">getFavStoreIdCompleted(result)</a></dt>
<dd><p>On successful callback of http GET from getFavStoreId, saves the returned favStoreId to
session storage and also returns the favStoreId</p>
</dd>
<dt><a href="#getFavStoreIdFailed">getFavStoreIdFailed(error)</a> ⇒ <code>Promise</code></dt>
<dd><p>On error callback of http GET from getFavStoreId, returns the error.</p>
</dd>
<dt><a href="#getFavStoreIdFromSessionStorage">getFavStoreIdFromSessionStorage()</a> ⇒ <code>string</code></dt>
<dd><p>Returns the stored favStorId from session storage.</p>
</dd>
<dt><a href="#getXpressImagePath">getXpressImagePath(manufacturer, shortDisplayName, displayName, color, extension)</a> ⇒ <code>string</code></dt>
<dd><p>Builds the xpress image path from the information contained within the function params.</p>
</dd>
<dt><a href="#getProfileInfoCompleted">getProfileInfoCompleted(result)</a></dt>
<dd></dd>
<dt><a href="#getProfileInfoFailed">getProfileInfoFailed(error)</a> ⇒ <code>Promise</code></dt>
<dd></dd>
<dt><a href="#getInsuranceFeatures">getInsuranceFeatures(action)</a> ⇒ <code>Promise.&lt;Object&gt;</code></dt>
<dd><p>Makes a request to the protection plan recommendations API to get the recommended protection features in context and
 returns a promise. If the promise resolves the result of the request will be returned.</p>
</dd>
<dt><a href="#getInsuranceFeaturesDetails">getInsuranceFeaturesDetails(result)</a> ⇒ <code>Promise.&lt;Object&gt;</code></dt>
<dd><p>Returns the data property of the protection plan recommendation response object.</p>
</dd>
<dt><a href="#setUpgradeLinesInfo">setUpgradeLinesInfo(upgradeLinesInfo)</a></dt>
<dd><p>Set shared upgrade lines information into session storage.</p>
</dd>
<dt><a href="#getUpgradeLinesInfo">getUpgradeLinesInfo()</a> ⇒ <code>object</code></dt>
<dd><p>function returns shared upgrade lines information from session storage.</p>
</dd>
<dt><a href="#getUpgradingDeviceDetailsData">getUpgradingDeviceDetailsData([action])</a> ⇒ <code>object</code></dt>
<dd><p>gets the upgrading device detail and store it to session storage</p>
</dd>
<dt><a href="#clearUpgradingLineCache">clearUpgradingLineCache()</a></dt>
<dd><p>Clean session storage for selected line and cache both</p>
</dd>
<dt><a href="#getDeviceType">getDeviceType(deviceType)</a> ⇒ <code>string</code></dt>
<dd><p>Returns formatted upgrading device type</p>
</dd>
<dt><a href="#getUpsellOfferDetails">getUpsellOfferDetails()</a> ⇒ <code>object</code></dt>
<dd><p>gets the upsell offer details from upsellOffer api</p>
</dd>
<dt><a href="#getUpsellContentDetails">getUpsellContentDetails(offerId)</a> ⇒ <code>object</code></dt>
<dd><p>gets the upsell offer content details from sharedContentRetrievalUrl</p>
</dd>
<dt><a href="#setRequiredOfferId">setRequiredOfferId()</a></dt>
<dd><p>Set shared information into session storage.</p>
</dd>
<dt><a href="#getRequiredOfferId">getRequiredOfferId()</a> ⇒ <code>object</code></dt>
<dd><p>Get shared information which is saved in into session storage.</p>
</dd>
<dt><a href="#getUpsellOfferLegalContentInfo">getUpsellOfferLegalContentInfo()</a> ⇒ <code>string</code></dt>
<dd><p>Get the offer details legal content information.</p>
</dd>
<dt><a href="#skipToCheckout">skipToCheckout()</a> ⇒ <code>Object</code></dt>
<dd><p>Makes a post service when clicked on proceed to checkout button
The param acts like a flag to let back-end know not to redirect to upsellOffer page</p>
</dd>
</dl>

<a name="contentService"></a>

## contentService ⇒ <code>Promise.&lt;Object&gt;</code>
Makes a request to a product 360 .xml file and returns a promise.
 If the promise resolves the result of the request will be returned.

**Kind**: global namespace  
**Returns**: <code>Promise.&lt;Object&gt;</code> - Returns a promise of getProduct360Images results.  

| Param | Description |
| --- | --- |
| skuId | SKU of the product of which we want to retrieve the image data for. |


* * *

<a name="contentService"></a>

## contentService ⇒ <code>Promise.&lt;Array&gt;</code>
Makes a request to productPageUrl's product key features node, and returns a promise for it. If
 the response is received it converts the response.data into a developer friendly JSON and returns
 it.

**Kind**: global namespace  
**Returns**: <code>Promise.&lt;Array&gt;</code> - Returns a promise of an overview content JSON object.  

| Param | Description |
| --- | --- |
| productPageUrl | URL of the product page of which we want to retrieve the overview content for. |


* * *

<a name="contentService"></a>

## contentService ⇒ <code>Promise</code>
Makes a request to productPageUrl's product specifications node and returns a Promise. If a successful
 response is received it is converted into a developer friendly JSON and returned.

**Kind**: global namespace  
**Returns**: <code>Promise</code> - Returns a promise of a features JSON object.  

| Param | Description |
| --- | --- |
| productPageUrl | URL of the product page of which we want to retrieve the overview content for. |


* * *

<a name="contentService"></a>

## contentService ⇒ <code>Promise.&lt;Object&gt;</code>
Makes a request call to the products page legal content nodes returns a promise.
 If the promise resolves the result of the request will be returned.

**Kind**: global namespace  
**Returns**: <code>Promise.&lt;Object&gt;</code> - Returns a promise of getProductLegalPaths results.  

| Param | Description |
| --- | --- |
| productPageUrl | URL of the page we want to retrieve legal content for. |


* * *

<a name="contentService"></a>

## contentService ⇒ <code>Promise.&lt;Array&gt;</code>
Makes a request call to the shared content retrieval service for the legalPaths
 and returns a promise. If the promise resolves the result of the request will be returned.

**Kind**: global namespace  
**Returns**: <code>Promise.&lt;Array&gt;</code> - Returns a promise of getProductLegalContent results.  

| Param | Type | Description |
| --- | --- | --- |
| legalPaths | <code>Array</code> | that contains the paths array, returned from the getProductLegalPaths call. |


* * *

<a name="deviceConfigSrv"></a>

## deviceConfigSrv : <code>object</code>
Factory for services used in device configuration

**Kind**: global namespace  

* * *

<a name="deviceConfigSrv.getDeviceDetails"></a>

### deviceConfigSrv.getDeviceDetails(skuId, params, [flushCache]) ⇒ <code>Promise</code>
Gets details about the sku

**Kind**: static method of [<code>deviceConfigSrv</code>](#deviceConfigSrv)  
**Returns**: <code>Promise</code> - Details about the device  
**Access**: public  

| Param | Type | Description |
| --- | --- | --- |
| skuId | <code>string</code> | The sku's ID |
| params | <code>object</code> | Params |
| [flushCache] | <code>boolean</code> | Flush the cache |


* * *

<a name="exAccessoryContentService"></a>

## exAccessoryContentService ⇒ <code>Promise.&lt;Object&gt;</code>
Makes a request to the accessory detail legacy content node and returns a promise.
 If the promise resolves the result of the request will be returned.

**Kind**: global namespace  
**Returns**: <code>Promise.&lt;Object&gt;</code> - Returns a promise of accessory detail legacy content results.  

| Param | Type | Description |
| --- | --- | --- |
| accessoryPagePath | <code>String</code> | The URL path to the page of which we want to retrieve the overview content for. |


* * *

<a name="exCartService"></a>

## exCartService ⇒ <code>Promise.&lt;Object&gt;</code>
Makes a request to the cart lookup API and returns a promise.
 If the promise resolves the result of the request will be returned.

**Kind**: global namespace  
**Returns**: <code>Promise.&lt;Object&gt;</code> - Returns a promise of cart lookup results.  

| Param | Type | Description |
| --- | --- | --- |
| action | <code>String</code> | Optional parameter which reloads the cart from the API,  even if stored locally, if it is set to anything but 'none'. |


* * *

<a name="exCqTranslatorKeyService"></a>

## exCqTranslatorKeyService ⇒ <code>Promise.&lt;Object&gt;</code>
Makes a request to the CQ translator key API and returns a promise.
 If the promise resolves the result of the request will be returned.
 Only keys that aren't cached within the session will be requested.

**Kind**: global namespace  
**Returns**: <code>Promise.&lt;Object&gt;</code> - Returns a promise of CQ translator key results.  

| Param | Type | Description |
| --- | --- | --- |
| keys | <code>Array</code> | Array of CQ translator key names, for which we will lookup the values. |


* * *

<a name="favStoreService"></a>

## favStoreService ⇒ <code>Promise</code>
Gets the favStoreId of the user on the basis of user's UUID

**Kind**: global namespace  
**Returns**: <code>Promise</code> - Returns a promise of the storeId returned by the FavStoreApi  

| Param | Description |
| --- | --- |
| uuid | user profile's uuid |


* * *

<a name="profileInfoService"></a>

## profileInfoService ⇒ <code>Promise</code>
**Kind**: global namespace  
**Returns**: <code>Promise</code> - Returns a promise of the profileInfo data returned by the profileInfoApi  

| Param | Description |
| --- | --- |
| action | Reloads the profile from the profileInfoApi instead of using the cached version if  action is anything different than 'none'. |


* * *

<a name="getSharedContentForInsurance"></a>

## getSharedContentForInsurance(skuIds) ⇒ <code>Object</code>
Gets the insurance plan description from shared content service of CQ for each
insurance sku.

**Kind**: global function  
**Returns**: <code>Object</code> - contain the description of insurance  

| Param | Type | Description |
| --- | --- | --- |
| skuIds | <code>Array.&lt;String&gt;</code> | An array of sku |


* * *

<a name="transformThreeSixtyXml2Json"></a>

## transformThreeSixtyXml2Json(response) ⇒ <code>Array.&lt;Object&gt;</code>
Transforms the 360 xml images data to a JSON array.

**Kind**: global function  
**Returns**: <code>Array.&lt;Object&gt;</code> - JSON array that contains objects with image data.  

| Param | Description |
| --- | --- |
| response | The response returned for the 360 .xml file request. |


* * *

<a name="getProduct360ImagesCompleted"></a>

## getProduct360ImagesCompleted(result) ⇒ <code>Promise.&lt;Object&gt;</code>
Returns the data property of the getProduct360Images response object.

**Kind**: global function  
**Returns**: <code>Promise.&lt;Object&gt;</code> - Returns the getProduct360Images response data  

| Param | Type | Description |
| --- | --- | --- |
| result | <code>Object</code> | getProduct360Images response |


* * *

<a name="getProductOverviewContentCompleted"></a>

## getProductOverviewContentCompleted(result) ⇒ <code>Array</code>
Parses and converts the getProductOverviewContent response.data object and returns a developer
 friendly JSON.

**Kind**: global function  
**Returns**: <code>Array</code> - Returns the getProductOverviewContent data as a developer friendly JSON.  

| Param | Type | Description |
| --- | --- | --- |
| result | <code>Object</code> | getProductOverviewContent response |


* * *

<a name="getProductFeaturesContentCompleted"></a>

## getProductFeaturesContentCompleted(result) ⇒ <code>Promise.&lt;Array&gt;</code>
Returns the parsed and converted JSON Array of the getProductFeaturesContent response.data object.

**Kind**: global function  
**Returns**: <code>Promise.&lt;Array&gt;</code> - Returns the getProductFeaturesContent response.data parsed and
 converted to JSON.  

| Param | Type | Description |
| --- | --- | --- |
| result | <code>Object</code> | getProductFeaturesContent response |


* * *

<a name="getProductLegalContentCompleted"></a>

## getProductLegalContentCompleted(result) ⇒ <code>Array</code>
Returns the parsed and converted JSON of the getProductLegalPaths response object.

**Kind**: global function  
**Returns**: <code>Array</code> - Returns the getProductLegalPaths response data  

| Param | Type | Description |
| --- | --- | --- |
| result | <code>Object</code> | getProductLegalPaths response |


* * *

<a name="getProductLegalContentCompleted"></a>

## getProductLegalContentCompleted(results, legalPaths) ⇒ <code>Array</code>
Returns the parsed and converted JSON of the getProductLegalContent response object.

**Kind**: global function  
**Returns**: <code>Array</code> - Returns the getProductLegalContent parsed and converted response as an array.  

| Param | Type | Description |
| --- | --- | --- |
| results | <code>Object</code> | getProductLegalContent response (one or multiple) |
| legalPaths | <code>Object.&lt;Array&gt;</code> | getProductLegalPaths response |


* * *

<a name="getSharedContent"></a>

## getSharedContent(contentPaths) ⇒ <code>Promise.&lt;Array&gt;</code>
Makes a request call to the device shared content retrieval service for the contentPaths
and returns a promise. If the promise resolves the result of the request will be returned.

**Kind**: global function  
**Returns**: <code>Promise.&lt;Array&gt;</code> - Returns a promise of shared content results.  

| Param | Type | Description |
| --- | --- | --- |
| contentPaths | <code>Array.&lt;String&gt;</code> | contains the content paths |


* * *

<a name="getSharedContentCompleted"></a>

## getSharedContentCompleted(result, contentPaths) ⇒ <code>Array</code>
Returns the parsed and converted JSON of the getSharedContent response object.

**Kind**: global function  
**Returns**: <code>Array</code> - Returns the getSharedContent parsed and converted response as an array.  

| Param | Type | Description |
| --- | --- | --- |
| result | <code>Object</code> | getSharedContent response |
| contentPaths | <code>Object.&lt;Array&gt;</code> | getSharedContent response |


* * *

<a name="hylaPromotionDetails"></a>

## hylaPromotionDetails() ⇒ <code>object</code>
gets the hyla offer content details from hylaPromotionContentUrl

**Kind**: global function  
**Returns**: <code>object</code> - hyla offer legal content details  

* * *

<a name="getDetailsLegacyContentCompleted"></a>

## getDetailsLegacyContentCompleted(result) ⇒ <code>Promise.&lt;Object&gt;</code>
Returns the parsed and converted data property of the
accessory detail legacy content response object.

**Kind**: global function  
**Returns**: <code>Promise.&lt;Object&gt;</code> - Returns the accessory detail legacy content  

| Param | Type | Description |
| --- | --- | --- |
| result | <code>Object</code> | accessory detail legacy content response |


* * *

<a name="addItemToCart"></a>

## addItemToCart(items, params) ⇒ <code>Promise.&lt;Object&gt;</code>
Makes a POST request to the cart service API and returns a promise.

**Kind**: global function  
**Returns**: <code>Promise.&lt;Object&gt;</code> - A promise of the add to cart results  

| Param | Type | Description |
| --- | --- | --- |
| items | <code>Object</code> | An object with key items and an array of items |
| params | <code>Object</code> | A header params object |


* * *

<a name="addItemToCartCompleted"></a>

## addItemToCartCompleted(result) ⇒ <code>Promise.&lt;Object&gt;</code>
Returns the data property of the add item to cart response object.

**Kind**: global function  
**Returns**: <code>Promise.&lt;Object&gt;</code> - Returns the add item to cart response data  

| Param | Type | Description |
| --- | --- | --- |
| result | <code>Object</code> | add item to cart response |


* * *

<a name="addItemToCartFailed"></a>

## addItemToCartFailed(error) ⇒ <code>Promise.&lt;Error&gt;</code>
Logs an error and rejects the promise returned by the add to cart item function.

**Kind**: global function  
**Returns**: <code>Promise.&lt;Error&gt;</code> - Returns rejected promise  

| Param | Type | Description |
| --- | --- | --- |
| error | <code>Error</code> | in add item to cart, error object. |


* * *

<a name="getCartCompleted"></a>

## getCartCompleted(result) ⇒ <code>Promise.&lt;Object&gt;</code>
Returns the data property of the cart lookup response object.

**Kind**: global function  
**Returns**: <code>Promise.&lt;Object&gt;</code> - Returns the cart lookup response data  

| Param | Type | Description |
| --- | --- | --- |
| result | <code>Object</code> | Cart lookup response |


* * *

<a name="removeItemFromCart"></a>

## removeItemFromCart(params) ⇒ <code>Promise.&lt;Object&gt;</code>
Makes a POST request to the remove cart item and returns a promise.

**Kind**: global function  
**Returns**: <code>Promise.&lt;Object&gt;</code> - A promise of the remove to cart results  

| Param | Type | Description |
| --- | --- | --- |
| params | <code>Object</code> | $http params object for commerce item removal |


* * *

<a name="removeItemFromCartCompleted"></a>

## removeItemFromCartCompleted(result) ⇒ <code>Promise.&lt;Object&gt;</code>
Returns the data property of the remove item from cart response object.

**Kind**: global function  
**Returns**: <code>Promise.&lt;Object&gt;</code> - Returns the remove item from cart response data  

| Param | Type | Description |
| --- | --- | --- |
| result | <code>Object</code> | remove item from cart response |


* * *

<a name="removeItemFromCartFailed"></a>

## removeItemFromCartFailed(error) ⇒ <code>Promise.&lt;Error&gt;</code>
Logs an error and rejects the promise returned by the remove cart item function.

**Kind**: global function  
**Returns**: <code>Promise.&lt;Error&gt;</code> - Returns rejected promise  

| Param | Type | Description |
| --- | --- | --- |
| error | <code>Error</code> | in remove item to cart, error object. |


* * *

<a name="removeItemFromPersistentCart"></a>

## removeItemFromPersistentCart(Items) ⇒ <code>object</code>
Empty current cart

**Kind**: global function  
**Returns**: <code>object</code> - success or failure response from API service  

| Param | Type | Description |
| --- | --- | --- |
| Items | <code>Param</code> | availabe in cart. |


* * *

<a name="getFavStoreIdCompleted"></a>

## getFavStoreIdCompleted(result)
On successful callback of http GET from getFavStoreId, saves the returned favStoreId to
session storage and also returns the favStoreId

**Kind**: global function  

| Param | Type | Description |
| --- | --- | --- |
| result | <code>object</code> | The data that is returned by the successful getFavStoreId function. |


* * *

<a name="getFavStoreIdFailed"></a>

## getFavStoreIdFailed(error) ⇒ <code>Promise</code>
On error callback of http GET from getFavStoreId, returns the error.

**Kind**: global function  
**Returns**: <code>Promise</code> - Returns a rejected promise.  

| Param | Type | Description |
| --- | --- | --- |
| error | <code>object</code> | object returned by the failed getFavStoreId function. |


* * *

<a name="getFavStoreIdFromSessionStorage"></a>

## getFavStoreIdFromSessionStorage() ⇒ <code>string</code>
Returns the stored favStorId from session storage.

**Kind**: global function  
**Returns**: <code>string</code> - Returns favStorId.  

* * *

<a name="getXpressImagePath"></a>

## getXpressImagePath(manufacturer, shortDisplayName, displayName, color, extension) ⇒ <code>string</code>
Builds the xpress image path from the information contained within the function params.

**Kind**: global function  
**Returns**: <code>string</code> - xpress image path  
**Access**: public  

| Param | Type | Description |
| --- | --- | --- |
| manufacturer | <code>string</code> | manufacturer value from catalog |
| shortDisplayName | <code>string</code> | shortDisplayName value from catalog |
| displayName | <code>string</code> | displayName value from catalog |
| color | <code>string</code> | color value from catalog |
| extension | <code>string</code> | extension of the image wished ('-hero.png', '-hero-zoom.png', etc.pp) |


* * *

<a name="getProfileInfoCompleted"></a>

## getProfileInfoCompleted(result)
**Kind**: global function  

| Param | Type | Description |
| --- | --- | --- |
| result | <code>object</code> | The data that is returned by the successful getProfileInfo function. |


* * *

<a name="getProfileInfoFailed"></a>

## getProfileInfoFailed(error) ⇒ <code>Promise</code>
**Kind**: global function  
**Returns**: <code>Promise</code> - Returns a rejected promise.  

| Param | Type | Description |
| --- | --- | --- |
| error | <code>object</code> | object returned by the failed getProfileInfo function. |


* * *

<a name="getInsuranceFeatures"></a>

## getInsuranceFeatures(action) ⇒ <code>Promise.&lt;Object&gt;</code>
Makes a request to the protection plan recommendations API to get the recommended protection features in context and
 returns a promise. If the promise resolves the result of the request will be returned.

**Kind**: global function  
**Returns**: <code>Promise.&lt;Object&gt;</code> - Returns a promise of insurance features results.  

| Param | Type | Description |
| --- | --- | --- |
| action | <code>String</code> | Optional parameter which reloads the insurance features from the API,  even if stored locally, if it is set to anything but 'none'. |


* * *

<a name="getInsuranceFeaturesDetails"></a>

## getInsuranceFeaturesDetails(result) ⇒ <code>Promise.&lt;Object&gt;</code>
Returns the data property of the protection plan recommendation response object.

**Kind**: global function  
**Returns**: <code>Promise.&lt;Object&gt;</code> - Returns the protection plan recommendation response data  

| Param | Type | Description |
| --- | --- | --- |
| result | <code>Object</code> | Protection plan recommendations response |


* * *

<a name="setUpgradeLinesInfo"></a>

## setUpgradeLinesInfo(upgradeLinesInfo)
Set shared upgrade lines information into session storage.

**Kind**: global function  

| Param | Type | Description |
| --- | --- | --- |
| upgradeLinesInfo | <code>object</code> | upgrading lines details |


* * *

<a name="getUpgradeLinesInfo"></a>

## getUpgradeLinesInfo() ⇒ <code>object</code>
function returns shared upgrade lines information from session storage.

**Kind**: global function  
**Returns**: <code>object</code> - upgrading lines details  

* * *

<a name="getUpgradingDeviceDetailsData"></a>

## getUpgradingDeviceDetailsData([action]) ⇒ <code>object</code>
gets the upgrading device detail and store it to session storage

**Kind**: global function  
**Returns**: <code>object</code> - promise object upgrading device  

| Param | Type | Description |
| --- | --- | --- |
| [action] | <code>boolean</code> | if action is true then reload the upgrading device details from buyflowApi, and if not then get the data from session. |


* * *

<a name="clearUpgradingLineCache"></a>

## clearUpgradingLineCache()
Clean session storage for selected line and cache both

**Kind**: global function  

* * *

<a name="getDeviceType"></a>

## getDeviceType(deviceType) ⇒ <code>string</code>
Returns formatted upgrading device type

**Kind**: global function  
**Returns**: <code>string</code> - upDeviceType formatted upgrading device type  

| Param | Type | Description |
| --- | --- | --- |
| deviceType | <code>string</code> | upgrading device type |


* * *

<a name="getUpsellOfferDetails"></a>

## getUpsellOfferDetails() ⇒ <code>object</code>
gets the upsell offer details from upsellOffer api

**Kind**: global function  
**Returns**: <code>object</code> - promise upsell offer details  

* * *

<a name="getUpsellContentDetails"></a>

## getUpsellContentDetails(offerId) ⇒ <code>object</code>
gets the upsell offer content details from sharedContentRetrievalUrl

**Kind**: global function  
**Returns**: <code>object</code> - data upsell offer legal content details  

| Param | Type | Description |
| --- | --- | --- |
| offerId | <code>string</code> | specific offer id |


* * *

<a name="setRequiredOfferId"></a>

## setRequiredOfferId()
Set shared information into session storage.

**Kind**: global function  

* * *

<a name="getRequiredOfferId"></a>

## getRequiredOfferId() ⇒ <code>object</code>
Get shared information which is saved in into session storage.

**Kind**: global function  
**Returns**: <code>object</code> - saved information in into session storage.  

* * *

<a name="getUpsellOfferLegalContentInfo"></a>

## getUpsellOfferLegalContentInfo() ⇒ <code>string</code>
Get the offer details legal content information.

**Kind**: global function  
**Returns**: <code>string</code> - offer legal information  

* * *

<a name="skipToCheckout"></a>

## skipToCheckout() ⇒ <code>Object</code>
Makes a post service when clicked on proceed to checkout button
The param acts like a flag to let back-end know not to redirect to upsellOffer page

**Kind**: global function  
**Returns**: <code>Object</code> - data post response  

* * *

