(function () {
    'use strict';
    /**
     * @property {boolean} enjoyDeliveryMesssageAPI - A flag that allows us to show/hide the enjoy delivery message.
     * @property {object} bopisDeliveryMesssageAPI - Check store inventory to show/hide bopis delivery message.
     * @property {object} deliveryDatePromiseMessage - Object that hold delivery promise message for Enjoy and BOPIS
     * @property {string} deliveryDatePromiseMessage.enjoyPromiseMessage - property key for enjoy promise message content
     * @property {number} globalNavCartUpdateTimeout - Timeout value to trigger injection of refreshing global nav
     * @property {string} deliveryDatePromiseMessage.bopisPromiseMessage - property key for BOPIS promise message content
     * @property {string} recommendedAccessoriesNodePath - Recommended accessories content node path of the product page
     */
    angular.module('exCommon')
        .constant('exCommonConstants', {
            accessoryDetailLegacyNode: '/jcr:content/accessorytabs/detailsoverviewpar/text.json',
            accordionTimer: 500,
            buyflowApi: '/services/shopwireless/model/att/ecom/api/BuyFlowController/service',
            cartServiceApi: '/services/shopwireless/model/att/ecom/api/CartServiceController/cartService',
            cartLookupApi: '/services/shopwireless/model/att/ecom/api/CartLookup/getCartInfo?lobType=ALL',
            cartStorageKey: 'cart',
            cartSummaryPageUrl: '/shop/cart/cartsummary.html',
            catalogApi: '/services/shopwireless/model/att/ecom/api/CatalogServiceController/catalogService',
            colorMatrix: [
                '#000000',
                '#5C5A5A',
                '#C14242',
                '#D2CCB5',
                '#8482A3',
                '#6E91AF',
                '#354D28',
                '#F1E0CC'
            ],
            commitmentTermCmsKeyPartForLegal: {
                0: {
                    termKey: 'regular0'
                },
                1: {
                    termKey: 'nocommitment',
                    deviceType: 'alldevices'
                },
                12: {
                    termKey: 'regular12'
                },
                24: {
                    termKey: 'twoyrcommit'
                }
            },
            commitmentTermLabels: {
                'commitmentTermNext': 'label.pb.leasename.NE30M80P',
                'commitmentDisclaimerNext': 'With $0 down, you\'ll pay {0} monthly installments. Trade in after {1}.',
                'commitmentTermEveryYear': 'label.pb.leasename.NE24M50P',
                'commitmentDisclaimerEveryYear': 'With $0 down, you\'ll pay {0} monthly installments. Trade in after {1}.',
                'commitmentTermTwoYear': 'label.2yr.noasterisk',
                'commitmentDisclaimerTwoYear': '${0} due today with a 2-year service contract. Upgrade with no trade-in after 24 months.',
                'commitmentTermZero': 'label.devices.nocommitment',
                'commitmentDisclaimerTermZero': 'Upgrade anytime.',
                'commitmentTermInstallment': 'label.pb.leasename.IP20A.mobile',
                'commitmentDisclaimerInstallment': 'With $0 down, you\'ll pay {0} monthly installments. Upgrade after device is paid off.'
            },
            commitmentTermLegalLabels: {
                'commitmentTermNext': 'with AT&T Next<sup class="super">&reg;</sup>',
                'commitmentTermEveryYear': 'with AT&T Next Every Year<sup class="super">SM</sup>',
                'commitmentTermTwoYear': 'with a 2-year contract',
                'commitmentTermZero': 'with no annual contract',
                'commitmentTermInstallment': 'with an installment plan'
            },
            commitTermDeviceConfigShortLegalLbl: {
                'lease': 'priceblock.starting.lease.lbl',
                'regulareq0': 'two.year.qualifying.plan.lbl',
                'regulargt0eq24': 'lbl.two.year.qual.plan',
                'regulargt0neq24': 'priceblock.starting.regular.lbl'
            },
            contractDeviceErrorKey: 'contractDeviceErrorKey',
            cqTranslatorKeyApi: '/services/shopwireless/model/att/ecom/api/CQKeyResolverServiceActor/getCQKeys',
            cqTranslatorStorageKey: 'cqTranslatorCache',
            deviceCatalogUrlRoot: '/catalog/en/skus/images/',
            deviceConfigHylaPromoDetailsModal: '/shop/xpress/modals/device-config-hyla-promo-details.modal.html',
            deviceImageUrlRoot: '/catalog/en/xpress/',
            deviceDetailsApi: '/services/shopwireless/model/att/ecom/api/DeviceDetailsActor/getDeviceProductDetails',
            deviceRecommender: '/shop/xpress/device-recommender.html',
            errorStatus: 'error',
            exUpHandOffToCheckoutUrl: '/services/shopwireless/model/att/ecom/api/ExUpHandOffToCheckoutActor/exUpCheckoutHandoffService',
            event: {
                accessoryConfigLoaded: 'ACCESSORY_CONFIG_LOADED',
                accessoryConfigWidgetAdded: 'EXACCESSORYCONFIGWIDGET_ACCESSORY_ADDED',
                accessorySelected: 'ACCESSORY_SELECTED',
                BVInitiated: 'BV_INITIATED',
                BVSkuSelected: 'BV_SKU_SELECTED',
                cartDataUpdated: 'CART_DATA_UPDATED',
                cartCompletedOnAccessoryPageLoad: 'CART_COMPLETED_ON_ACCESSORY_PAGE_LOAD',
                changePriceClickFromWidget: 'DEVICE_CLICKED',
                deviceAdded: 'DEVICE_ADDED',
                deviceConfigWidgetBVInitiated: 'DEVICE_EDIT_CLICKED',
                deviceConfigLoaded: 'DEVICE_CONFIG_LOADED',
                accessoryConfigWidgetBVInitiated: 'ACCESSORY_EDIT_CLICKED',
                deviceAddedFromDetails: 'ADDTOCART_CLICKED_FROM_DETAILS',
                deviceConfigWidgetAdded: 'EXDEVICECONFIGWIDGET_DEVICE_ADDED',
                deviceSelected: 'DEVICE_SELECTED',
                hideGlobalNav: 'HIDE_GLOBALNAV',
                paymentInfoValidated: 'PAYMENTINFO-VALIDATED',
                paymentModalTriggered: 'PAYMENT_MODAL_TRIGGERED',
                protectionPlanAdded: 'PROTECTION_PLAN_ADDED',
                protectionPlanCancel: 'PROTECTION_PLAN_CANCEL',
                REFRESH_GLOBAL_NAV_CART: 'Refresh_Global_Nav_Cart',
                selectedSkuInFocus: 'SELECTED_SKU_IN_FOCUS',
                showGlobalNav: 'DISPLAY_GLOBALNAV',
                DS_REPORTING_EVENT: 'DS_Reporting_Event',
                DS_REPORTING_PAGELOAD_EVENT: 'DS_Reporting_PageLoad_Event'
            },
            globalNavCartUpdateTimeout: 1000,
            friendlyPageName: {
                accessoryDetails: 'DS Upgrade Accessory Config Modal Pg',
                accessoryRecommenderDetails: 'DS Upgrade Protection And Accessories Pg',
                deviceDetails: 'DS Upgrade Device Details Pg',
                deviceDetailsHero: 'DS Upgrade Hero Device Details Pg',
                deviceRecommenderDetails: 'DS Upgrade Device Recommender Pg',
                insuranceOptions: 'DS Upgrade Insurance Config Modal Pg',
                insuranceOptionsLegal: 'DS Upgrade Insurance Legal Details Modal Pg',
                priceChangeOptions: 'DS Upgrade Price Change Options Modal Pg',
                subTotalDetailsLegal: 'DS Upgrade Subtotal Details Modal Pg'
            },
            favStoreApi: '/apis/personalization/favoriteStore/get',
            favStoreStorageKey: 'favStoreId',
            heroDeviceImageUrlExtension: '-hero-zoom.png',
            hardStopPage: '/shopmobile/shared/hardstop.html?errorCode=pmt.uv.err.UVU35066.mobile',

            http: { // network request configuration values
                postAuthReq: 'postAuthRequired'
            },
            hylaPromotionContentUrl: '/shop/wireless/legal.sharedcontentdetailsasjson.html',
            hylaPromotionLabel: {
                hylaTradeInOffer: 'label.hylaOffer.credit.message',
                hylaLegalTerms: 'label.hylaOffer.credit.qualify',
                hylaSeeOfferDetails: 'label.hylaOffer.credit.details',
                hylaCheckBoxLabel: 'label.hylaOffer.credit.optin'
            },
            insuranceCategories: {
                sku5370279: 'label.md5hdr.mpp',
                sku7250407: 'label.md5hdr.mdpp',
                sku1040075: 'label.md5hdr.mi'
            },
            insuranceOptionContentPath: '/Device_Insurance_Options/',
            insuranceOptionsModalPath: '/shop/xpress/modals/insurance-options.modal.html',
            insuranceDetailsLegalModalPath: '/shop/xpress/modals/protection-details.modal.html',
            itemUpgradeTypeRecommended: {
                fullyEligible: 'Fully Eligible',
                fullPrice: 'Full Price',
                inEligible: 'In Eligible',
                nextTradein: 'Next Tradein',
                payUp: 'Pay Up',
                payOff: 'Pay Off'
            },
            itemUpgradeTypeSelected: {
                none: 'Fully Eligible',
                payoff: 'Pay Off',
                payup: 'Pay Up',
                payupcontract: 'Pay Up',
                replace: 'Full Price',
                tradein: 'Next Tradein',
                tradeincontract: 'Next Tradein'
            },
            legalContentKeyPrefix: 'tos.sku.',
            linkName: {
                seePricingOptions: 'See other pricing options',
                longLegalLinkLabel: 'See price details',
                seeDeviceDetails: 'Explore the device details',
                seeAccessoryDetails: 'Explore the accessory details',
                seeSubtotalsToolTip: 'See subtotals Modal',
                showMoreInsurance: 'See more details and other options'
            },
            linkPosition: 'Body',
            mobileViewportMax: 767,
            omniChannelDeliveryPromiseSuppression: 'omni.suppress.productid.lbl',
            onePageCheckout: '/cart/onepagecheckoutcart.html',
            paymentSummaryStorageKey: 'paymentSummary',
            pricingOptionsModal: '/shop/xpress/modals/pricing-options.modal.html',
            productContentNodePath: '/jcr:content/devicetabs.eternity.json',
            productLegalContentNodePath: '/jcr:content/details/legalpar.eternity.json',
            profileInfoApi: '/services/shopwireless/model/att/ecom/api/ProfileServiceActor/getProfileInfo?viewType=zippy',
            profileStorageKey: 'exUpProfile',
            protectionPlanLegalModal: '/shop/xpress/modals/protection-plan-legal.modal.html',
            protectionPlanStorageKey: 'protectionPlans',
            recommendedAccessoriesNodePath: '/_jcr_content/recommendedAccessories.eternity.json',
            reportingContractLengthStorageKey: 'reportingContractLength',
            reportingContractTypeStorageKey: 'reportingContractType',
            reportingExistingItemsStorageKey: 'reportingExistingItems',
            reportingMultilineEligibleStorageKey: 'reportingMultilineEligible',
            selectedLineStorageKey: 'selectedUpLine',
            seoCrossLinkLegal: 'seo-cross-link',
            sharedContentFetchUrl: '/shop/wireless/device.sharedcontentdetailsasjson.html',
            sharedContentRetrievalUrl: '/shop/wireless/legal.sharedcontentdetailsasjson.html',
            shopSessionId: 'SHOPSESSIONID',
            shortLegalContentCmsKey: 'label.dlist.legal.{0}.{1}',
            threeSixtyProductXmlPath: '/shopcms/360s/xml/{0}.xml',
            tradeinConsent: '/shop/xpress/upgrade-tradein-consent.html',
            upgradeEligibility: '/shop/xpress/upgrade-eligibility.html',
            upgradeEligibilityNoImage: '/shopcms/media/att/2012/shop/wireless/common/prod-noImage-100x160.png',
            upgradeLineStorageKey: 'upgradeLineStorageKey',
            upgradePaymentConfirmation: '/shop/xpress/upgrade-payment-confirm.html',
            upsellSeeOfferDetailsModal: '/shop/xpress/modals/upsell-see-offer-details.modal.html',
            upsellOfferApi: '/services/shopwireless/model/att/ecom/api/UpsellServiceController/upsellService',
            upsellOfferId: 'requiredOfferId',
            virtualUrl: {
                accessoryDetails: '/shop/xpress/virtual/accessory-config.html',
                accessoryRecommenderDetails: '/shop/xpress/accessory-service-recommender.html',
                deviceDetails: '/shop/xpress/virtual/device-details.html',
                deviceDetailsHero: '/shop/xpress/virtual/device-details.html+HeroDevice',
                deviceRecommenderDetails: '/shop/xpress/device-recommender.html',
                insuranceOptions: '/shop/xpress/virtual/insurance-config.html',
                insuranceOptionsLegal: '/shop/xpress/virtual/insurance-legal-details.html',
                priceChangeOptions: '/cart/virtual/upgrade-price-change-options.html',
                subTotalDetailsLegal: '/shop/xpress/virtual/subtotal-details.html'
            },
            enjoyDeliveryMesssageAPI: 'services/shopwireless/model/att/ecom/api/StoreInventoryService/checkSDDAvailability',
            bopisDeliveryMesssageAPI: 'services/shopwireless/model/att/ecom/api/StoreInventoryService/getStoreInventory',
            deliveryDatePromiseMessage: {
                'enjoyPromiseMessage': 'Want it fast? Get FREE same-day delivery if you order by 7 p.m.',
                'bopisPromiseMessage': 'Want it fast? Pick it up at a store {0}'
            }
        });
})();
