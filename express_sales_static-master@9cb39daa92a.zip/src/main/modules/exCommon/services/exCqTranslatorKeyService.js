(function () {
    'use strict';

    angular.module('exCommon')

        .factory('exCqTranslatorKeyService', ['$log', '$q', '$http', '$window', 'exCommonConstants',
            function ($log, $q, $http, $window, exCommonConstants) {
                var storageKey = exCommonConstants.cqTranslatorStorageKey,
                    exCqTranslatorKeyService = {
                        getCqTranslatorKeys: getCqTranslatorKeys
                    };

                /**
                 * Makes a request to the CQ translator key API and returns a promise.
                 *  If the promise resolves the result of the request will be returned.
                 *  Only keys that aren't cached within the session will be requested.
                 * @function getCqTranslatorKeys
                 * @param {Array} keys Array of CQ translator key names, for which we will lookup the values.
                 * @param {Boolean} hideSpinner Spinner state during request. True: hide it, False/Undefined: show it.
                 * @returns {Promise<Object>} Returns a promise of CQ translator key results.
                 * @namespace exCqTranslatorKeyService
                 */
                function getCqTranslatorKeys (keys, hideSpinner) {
                    var cachedKeys,
                        nonCachedKeys = [];

                    // check if we have any of the keys requested in our cache
                    cachedKeys = getCachedCqTranslatorKeys(keys);

                    // create list of keys we haven't cached, and list of keys we have cached
                    for (var i = 0, len = keys.length; i < len; i++) {
                        if (cachedKeys[keys[i]] === undefined) {
                            nonCachedKeys.push(keys[i]);
                        }
                    }

                    // all keys were cached, return the cached keys.
                    if (nonCachedKeys.length === 0) {
                        return $q.when(cachedKeys);
                    } else {
                        // some or all keys need to be requested
                        return $http({
                            method: 'GET',
                            url: exCommonConstants.cqTranslatorKeyApi,
                            params: {
                                cmsKeys: nonCachedKeys.join(',')
                            },
                            spinner: (hideSpinner === true) ? false : true
                        })
                            .then(function (data) {
                                return getCqTranslatorKeysCompleted(data, nonCachedKeys, keys);
                            })
                            .catch(getCqTranslatorKeysFailed);
                    }
                }

                /**
                 * @function getCachedCqTranslatorKeys
                 * @param {Array} keys Translator key list to search for within the cached CQ translator keys.
                 * @return {Object}
                 * @private
                 */
                function getCachedCqTranslatorKeys (keys) {
                    var cache = $window.sessionStorage.getItem(storageKey);
                    // handling return values from browser and karma/browser
                    var parsedCache = (cache !== null && cache !== undefined) ? JSON.parse(cache) : undefined;
                    var cachedKeys = {};

                    if (parsedCache !== undefined) {
                        for (var i = 0, len = keys.length; i < len; i++) {
                            if (parsedCache[keys[i]] !== undefined) {
                                cachedKeys[keys[i]] = parsedCache[keys[i]];
                            }
                        }
                    }

                    return cachedKeys;
                }

                /**
                 * Returns the parsed and converted data property of the CQ translator key response object.
                 * @function getCqTranslatorKeysCompleted
                 * @param {Object} result CQ translator key response
                 * @param {Array} nonCachedKeys List of keys that is contained with the CQ translator key response.
                 * @param {Array} keys List of all keys that were requested from the service.
                 * @return {Object} Returns object of cq translator keys key/value pairs.
                 * @private
                 */
                function getCqTranslatorKeysCompleted (result, nonCachedKeys, keys) {
                    var cache = $window.sessionStorage.getItem(storageKey),
                        // handling return values from browser and karma/browser
                        parsedCache = (cache !== null && cache !== undefined) ? JSON.parse(cache) : {},
                        serviceKeys,
                        i,
                        len;

                    // store service response in a more accessible variable
                    if (result.data.result &&
                        result.data.result.methodReturnValue) {
                        serviceKeys = result.data.result.methodReturnValue;
                    }

                    // add keys from service response to the cache
                    for (i = 0, len = nonCachedKeys.length; i < len; i++) {
                        parsedCache[nonCachedKeys[i]] = serviceKeys[nonCachedKeys[i]];
                    }

                    // store updated cache
                    $window.sessionStorage.setItem(storageKey, JSON.stringify(parsedCache));

                    // create result with cached and requested keys by adding cached keys to serviceKeys
                    for (i = 0, len = keys.length; i < len; i++) {
                        if (serviceKeys[keys[i]] === undefined) {
                            serviceKeys[keys[i]] = parsedCache[keys[i]];
                        }
                    }

                    return serviceKeys;
                }

                /**
                 * Logs an error and rejects the promise returned by the getCqTranslatorKeys function.
                 * @param {Error} error CQ translator key response error object.
                 * @return {Promise<Error>} Returns rejected promise
                 * @private
                 */
                function getCqTranslatorKeysFailed (error) {
                    var message = 'exCqTranslatorKeyService.getCqTranslatorKeys call failed.';
                    if (error.data && error.data.description) {
                        message += '\n' + error.data.description;
                    }
                    $log.error(message);
                    return $q.reject(error);
                }

                return exCqTranslatorKeyService;
            }]);
})();
