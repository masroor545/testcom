(function () {
    'use strict';

    angular.module('exCommon')

        /**
         * Factory for services used in device configuration
         * @namespace deviceConfigSrv
         */
        .factory('deviceConfigSrv', ['$rootScope', '$http', '$log', '$q', '$cacheFactory', 'exCommonConstants', 'exCacheManager',
            function ($rootScope, $http, $log, $q, $cacheFactory, exCommonConstants, exCacheManager) {
                var services = {
                    getDeviceDetails: getDeviceDetails,
                    getColorTheme: getColorTheme,
                    getDeliveryPromiseMessage: getDeliveryPromiseMessage,
                    hylaPromotionDetails: hylaPromotionDetails,
                    getEnjoyDeliveryPromiseMessage: getEnjoyDeliveryPromiseMessage,
                    getBOPISDeliveryPromiseMessage: getBOPISDeliveryPromiseMessage

                };

                /**
                 * Gets details about the sku
                 * @function getDeviceDetails
                 * @public
                 * @memberof deviceConfigSrv
                 * @param {string} skuId The sku's ID
                 * @param {object} params Params
                 * @param {boolean} [flushCache] Flush the cache
                 * @param {boolean} hideSpinner Spinner state during request. True: hide it, False/Undefined: show it.
                 * @returns {Promise} Details about the device
                 */
                function getDeviceDetails (skuId, params, flushCache, hideSpinner) {
                    var detailsApi = exCommonConstants.deviceDetailsApi;
                    if (flushCache === true) {
                        exCacheManager.clearCacheItem(detailsApi, params);
                    }
                    return $http.get(detailsApi, {
                        params: params,
                        cache: exCacheManager.getCache(),
                        spinner: (hideSpinner === true) ? false : true
                    });
                }

                /**
                 * Gets color theme based on hex value.
                 * Compares hex value to color matrix.
                 * @public
                 * @param {string} hexValue The hex value
                 * @return {string} The name of the theme
                 */
                function getColorTheme (hexValue) {
                    hexValue = hexValue.toUpperCase();
                    if (exCommonConstants.colorMatrix.indexOf(hexValue) !== -1) {
                        return 'dark';
                    } else {
                        return 'light';
                    }
                }

                /**
                 * Gets Delivery Promise Message for devices.
                 * @public
                 * @param {string} skuList The comma separated skuids of devices
                 * @return {Object} delivery promise message of the devices
                 */
                function getDeliveryPromiseMessage (skuList) {
                    return $http({
                        method: 'GET',
                        url: exCommonConstants.buyflowApi,
                        cache: exCacheManager.getCache(),
                        params: {
                            actionType: 'getskudeliverydates',
                            pageId: 'detail',
                            skuList: skuList
                        }
                    });
                }

                /**
                 * gets the hyla offer content details from hylaPromotionContentUrl
                 * @function hylaPromotionDetails
                 * @returns {object} hyla offer legal content details
                 */
                function hylaPromotionDetails () {
                    return $http.get(exCommonConstants.hylaPromotionContentUrl, {
                        params: {path: 'offercontent/hylaOffer'},
                        cache: exCacheManager.getCache()
                    }).then(function (response) {
                        return response.data;
                    }).catch(getHylaPromotionDetailsFailed);
                }

                /**
                 * Logs an error and rejects the promise returned by the hylaPromotionDetails function.
                 * @param {Error} error hlya promotion details response error object.
                 * @return {Promise<Error>} Returns rejected promise
                 */
                function getHylaPromotionDetailsFailed (error) {
                    var message = 'deviceConfigSrv.hylaPromotionDetails call failed.';
                    if (error && error.data && error.data.description) {
                        message += '\n' + error.data.description;
                    }
                    $log.error(message);
                    return $q.reject(error);
                }
                /**
                 * Gets Enjoy Delivery Promise Message for devices.
                 * @public
                 * @param {string} skuList The comma separated skuids of devices
                 * @return {Object} enjoy delivery promise message of the devices
                 */
                function getEnjoyDeliveryPromiseMessage (skuId) {
                    return $http({
                        method: 'GET',
                        url: exCommonConstants.enjoyDeliveryMesssageAPI,
                        cache: exCacheManager.getCache(),
                        params: {
                            skuid: skuId
                        }
                    });
                }

                /**
                 * Gets Enjoy Delivery Promise Message for devices.
                 * @public
                 * @param {string} skuList The comma separated skuids of devices
                 * @return {Object} enjoy delivery promise message of the devices
                 */
                function getBOPISDeliveryPromiseMessage (storeId, zipCode, skuid) {
                    return $http({
                        method: 'GET',
                        url: exCommonConstants.bopisDeliveryMesssageAPI,
                        cache: exCacheManager.getCache(),
                        params: {
                            favStoreInvId: storeId,
                            favStoreZip: zipCode,
                            skuId: skuid
                        }
                    });
                }

                return services;
            }]);
})();