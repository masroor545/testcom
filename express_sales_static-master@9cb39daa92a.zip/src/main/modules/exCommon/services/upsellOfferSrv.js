(function () {
    'use strict';

    angular.module('exCommon')

        .factory('upsellOfferSrv', ['$rootScope', '$modal', '$http', '$window', '$location', 'exCommonConstants', 'exHelpUtils',
            function ($rootScope, $modal, $http, $window, $location, exCommonConstants, exHelpUtils) {

                var services = {
                    getUpsellOfferDetails: getUpsellOfferDetails,
                    getUpsellOfferContentDetails: getUpsellOfferContentDetails,
                    skipToCheckout: skipToCheckout,
                    getOfferCount: getOfferCount,
                    setOfferCount: setOfferCount,
                    getUpsellOfferLegalContentInfo: getUpsellOfferLegalContentInfo,
                    openSeeOfferDetailsModal: openSeeOfferDetailsModal
                };

                /**
                * gets the upsell offer details from upsellOffer api
                * @function getUpsellOfferDetails
                * @returns {object} promise upsell offer details
                */
                function getUpsellOfferDetails () {
                    return $http.get(exCommonConstants.upsellOfferApi, {
                        params: {
                            actionType: 'getupselldetails'
                        }
                    }).then(function (response) {
                        return response.data;
                    });
                }

                /**
                * gets the upsell offer content details from sharedContentRetrievalUrl
                * @function getUpsellContentDetails
                * @param {string} offerId specific offer id
                * @returns {Promise<string>} data upsell offer legal content details
                */
                function getUpsellOfferContentDetails (offerId) {
                    var paramKey = 'path=offercontent/',
                        retrievalUrl = exCommonConstants.sharedContentRetrievalUrl,
                        params = '?' + paramKey + offerId;
                    return $http.get(retrievalUrl + params).then(function (response) {
                        return response.data;
                    });
                }

                /**
                 * Get the offer details legal content information.
                 * @function getUpsellOfferLegalContentInfo
                 * @param {string} offerId
                 * @returns {string} offer legal information
                 */
                function getUpsellOfferLegalContentInfo (offerId) {
                    return getUpsellOfferContentDetails(offerId).then(function (data) {
                        var legalContent = '';
                        for (var item in data) {
                            if (data.hasOwnProperty(item)) {
                                legalContent = data[item]['jcr:description'][0];
                            }
                        }
                        return legalContent;
                    });
                }

                /**
                 * Open see offer details legal content overlay
                 * @public
                 * @param {string} offerId Offer ID of the content to be displayed
                 */
                function openSeeOfferDetailsModal (offerId) {
                    var offerScope = $rootScope.$new(true);
                    getUpsellOfferLegalContentInfo(offerId).then(function (response) {
                        offerScope.content = response;
                        offerScope.close = exHelpUtils.closeActiveModal;
                        $modal.open({
                            templateUrl: exCommonConstants.upsellSeeOfferDetailsModal,
                            windowClass: 'modal-fullscreen',
                            scope: offerScope
                        });
                    });
                }

                /**
                 * Gets the number of offers available to the user
                 * @public
                 * @return {Number} The number of offers
                 */
                function getOfferCount () {
                    return this.offerCount || null;
                }

                /**
                 * Sets the number of offers available to the user
                 * @public
                 * @param {Number} offerCount - The number of offers
                 */
                function setOfferCount (offerCount) {
                    var offerCountType = typeof offerCount;
                    if (offerCountType !== 'number') {
                        throw new TypeError('Invalid type given to offer count.\nExpected: Number\nGot: ' + offerCountType);
                    } else {
                        this.offerCount = offerCount;
                    }
                }

                /**
                 * Makes a post service when clicked on proceed to checkout button
                 * The param acts like a flag to let back-end know not to redirect to upsellOffer page
                 * @function skipToCheckout
                 * @return {Object} data post response
                 */
                function skipToCheckout () {
                    return $http.post(exCommonConstants.exUpHandOffToCheckoutUrl, {skipToCheckout: true, pageSource: $location.search().pageSource}).then(function (response) {
                        return response.data;
                    });
                }

                return services;
            }]);
})();