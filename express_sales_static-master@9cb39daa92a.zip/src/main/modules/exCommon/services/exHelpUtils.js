(function () {
    'use strict';

    angular.module('exCommon')

        .factory('exHelpUtils', ['$modalStack', '$anchorScroll', function ($modalStack, $anchorScroll) {
            var arrRegEx = (/\[|\]/g);
            var mapCache = {};

            return {
                getValue: getValue,
                closeActiveModal: closeActiveModal,
                replacePlaceholdersWithContent: replacePlaceholdersWithContent,
                scrollToAccordion: scrollToAccordion,
                uniqueByKey: uniqueByKey,
                memoize: memoize
            };

            /**
             * Assist function for getValue array conversion
             */
            function replaceBrackets (found, index) {
                return (found === '[' && index !== 0) ? '.' : '';
            }

            /**
             * Iterates through and object to find the value represented by the provided string
             * @param {string} key represents the value you need to retrieve
             * @param {object} obj item that contains said value
             * @returns {object} the value you searched for or undefined
             */
            function getValue (key, obj) {
                return key.replace(arrRegEx, replaceBrackets).split('.').reduce(function (source, id) {
                    return (source !== undefined && source !== null) ? source[id] : undefined;
                }, obj);
            }

            /**
             * Function to close an active DS2 modal
             */
            function closeActiveModal () {
                // gets the active modal in DOM
                var top = $modalStack.getTop();
                // if there is an opened modal in DOM, then close it.
                if (top) {
                    $modalStack.dismiss(top.key);
                }
            }

            /**
             * Search placeholder from input text and update with content.
             * @param {String} text with placeholder.
             * @param {Array} content to be passed and replace in with placeholder.
             * @returns {String} text with replaced content.
             */
            function replacePlaceholdersWithContent (textWithPlaceholder, content) {
                if (textWithPlaceholder !== undefined && content.length > 0) {
                    angular.forEach(content, function (value, $index) {
                        textWithPlaceholder = textWithPlaceholder.replace('{' + $index + '}', value);
                    });
                    return textWithPlaceholder;
                }
            }

            /**
             * Function to watch for whenever accordion is finished expanding and scroll to it.
             * @param {String} hash - the element to scroll to
             * @param {String} accordionId - id of an accordion
             * @param {Object} scope - $scope
             */
            function scrollToAccordion (hash, accordionId, scope) {

                var deregisterWatch = scope.$watch(function () {
                    // TODO: condition to check if first child available. The scrolling is not working as expected if we put the condition.
                    return angular.element('#' + accordionId).children()[1].className;
                }, function () {
                    $anchorScroll(hash);

                    // Deregister watcher if review accordion has reached at the top of screen
                    if (angular.element('#' + hash).offset().top === 0) {
                        deregisterWatch();
                    }
                });
            }

            /**
             * Filters out objects that share a value returned by key
             * @param {Array} list The array to be filtered. Can be an array of objects (including arrays)
             * @param {Function} key Callback to be applied to each item in list
             * @return {Array} Filtered list with unique keys
             */
            function uniqueByKey (list, key) {
                var seen = {};
                return list.filter(function (item) {
                    var k = key(item);
                    return seen.hasOwnProperty(k) ? false : (seen[k] = true);
                });
            }

            /**
             * Stores results of function calls to decrease computation time. Note that this function should only be used
             * for computationally expensive functions with relatively low memory results due to the memory requirements to cache results.
             * @param {Function} func The function whose calls are being cached
             * @param {number|boolean|string|Function} [key] An identifier which represents the function arguments. Objects are not valid identifiers.
             * @return {*} The result of func(arguments)
             */
            function memoize (func, key) {
                var memo = mapCache[func] = mapCache[func] || {};
                var slice = Array.prototype.slice;

                return function () {
                    var args = slice.call(arguments);
                    key = key || args.map(function (arg) {
                        return JSON.stringify(arg);
                    });

                    if (key in memo) {
                        return memo[key];
                    } else {
                        return (memo[key] = func.apply(this, args));
                    }

                };
            }
        }]);
})();
