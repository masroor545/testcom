#exCommon setup

### exCommonConfig

##### Description:
This config is used to set up caching of particular request

##### Use:
$http({
    method: 'GET',
    url: service_url,
    cache: exCacheManager.getCache()
});