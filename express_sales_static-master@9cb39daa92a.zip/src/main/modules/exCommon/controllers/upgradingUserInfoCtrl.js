(function () {
    'use strict';

    angular.module('exCommon')

        .controller('upgradingUserInfoCtrl', ['$scope', '$filter', 'upgradingUserInfoSrv', 'upgradeLinesInfoService',
            function ($scope, $filter, upgradingUserInfoSrv, upgradeLinesInfoService) {

                /**
                 * Reterive upgrading line details
                 * @function getUpgradingDeviceDetails
                 */
                $scope.getUpgradingDeviceDetails = function () {

                    // Hide tradein payUp Global Header
                    $scope.upgradeLinesInfoDetails = upgradeLinesInfoService.getUpgradeLinesInfo();
                    if ($scope.upgradeLinesInfoDetails) {
                        $scope.hideTradeInPayUpGlobalHeader = ($scope.upgradeLinesInfoDetails.hideTradeInPayUpHeader === true) ? true : false;
                    }

                    //Reterive upgrading line details from buyflow API
                    upgradingUserInfoSrv.getUpgradingDeviceDetailsData().then(function (result) {
                        // Get upgrading device details payload
                        $scope.upgradingDevice = result.payload;

                        $scope.upgradingDevice.subscriberName = $scope.upgradingDevice.subscriberName || '';
                        $scope.upgradingDevice.deviceMake = $scope.upgradingDevice.deviceMake || '';
                        $scope.upgradingDevice.deviceModel = $scope.upgradingDevice.deviceModel || '';
                        $scope.upgradingDevice.color = $scope.upgradingDevice.color || '';
                        $scope.upgradingDevice.size = $scope.upgradingDevice.size || '';

                        // Get formatted upgrading device type
                        $scope.upgradingDeviceType = upgradingUserInfoSrv.getDeviceType($scope.upgradingDevice.deviceType);

                        // Set upgrading user description
                        if ($scope.upgradingDevice.subscriberName !== '' && $scope.upgradingDevice.deviceModel !== '') {
                            $scope.upgradingUserDescription = $scope.upgradingDevice.subscriberName + "'s " + $scope.upgradingDevice.deviceModel;
                        } else {
                            $scope.upgradingUserDescription = '';
                        }

                        // Set upgrading device description
                        $scope.upgradingDeviceDescription = $filter('tel')($scope.upgradingDevice.ctn);

                    });
                };
                $scope.getUpgradingDeviceDetails();
            }]);
})();