(function () {
    'use strict';

    define(['protectionPlanCtrl'], function () {
        describe('src/main/modules/exCommon/controllers/protectionPlanCtrl.spec.js', function () {
            describe('protectionPlanCtrl controller of exCommon', function () {
                var $controller, $rootScope, $modal, protectionPlanService, exCartService, $scope, exCommonConstants,
                    contentService, exHelpUtils;

                beforeEach(function () {
                    module('exCommon', function ($provide) {
                        protectionPlanService = jasmine.createSpyObj('protectionPlanService', ['getInsuranceFeatures']);
                        $provide.value('protectionPlanService', protectionPlanService);
                        exCartService = jasmine.createSpyObj('exCartService', ['getCart', 'removeItemFromCart', 'addItemToCart']);
                        $provide.value('exCartService', exCartService);
                        contentService = jasmine.createSpyObj('contentService', ['getSharedContentForInsurance']);
                        $provide.value('contentService', contentService);
                        exHelpUtils = jasmine.createSpyObj('exHelpUtils', ['closeActiveModal']);
                        $provide.value('exHelpUtils', exHelpUtils);
                    });

                    inject(function ($injector) {
                        exCommonConstants = $injector.get('exCommonConstants');
                        $controller = $injector.get('$controller');
                        $rootScope = $injector.get('$rootScope');
                    });
                    $scope = $rootScope.$new();

                    exHelpUtils.closeActiveModal.and.returnValue(true);

                    protectionPlanService.getInsuranceFeatures.and.returnValue({
                        'then': function (callBackFN) {
                            callBackFN(Endpoint_protectionApi.get_insurance_features.result);
                        }
                    });

                    exCartService.removeItemFromCart.and.returnValue({
                        'then': function (callback) {
                            callback(true);
                        }
                    });

                    exCartService.getCart.and.returnValue({
                        'then': function (callback) {
                            callback(Endpoint_cartLookupApi.get_cart_lookup_new.result);
                        }
                    });

                    contentService.getSharedContentForInsurance.and.returnValue({
                        'then': function (callback) {
                            callback(Endpoint_deviceLegalContentNode.get_device_shared_content.result);
                        }
                    });

                    exCartService.addItemToCart.and.returnValue({
                        'then': function (callback) {
                            callback(true);
                        }
                    });

                    $modal = jasmine.createSpyObj('$modal', ['open']);
                    $modal.open.and.returnValue(true);

                    $controller('protectionPlanCtrl', {
                        $scope: $scope,
                        $modal: $modal,
                        protectionPlanService: protectionPlanService,
                        exCartService: exCartService,
                        contentService: contentService,
                        exHelpUtils: exHelpUtils
                    });
                });

                describe("Recommended protection feature and it's price", function () {

                    beforeEach(function () {
                        spyOn($scope, '$emit').and.callThrough();
                        $scope.$emit.calls.reset();
                    });

                    it('should populate scope data from service by default', function () {
                        expect(protectionPlanService.getInsuranceFeatures).toHaveBeenCalled();
                        protectionPlanService.getInsuranceFeatures().then(function (result) {
                            var insurancePlans = {
                                options: undefined
                            };
                            insurancePlans.options = Object.keys(result.payload).map(function (key) {
                                return result.payload[key];
                            });
                            $scope.protectionPlanDetails = insurancePlans.options[0];
                            expect($scope.protectionPlanDetails).toEqual(result.payload[Object.keys(result.payload)[0]]);
                            expect($scope.protectionPlanDetails.skuId).toEqual('sku5370279');
                            expect($scope.protectionPlanDetails.isAccountLevelFeature).toEqual(false);
                            expect($scope.protectionPlanDetails.mRCDetailsBean).toBeDefined();
                            expect($scope.protectionPlanDetails.mRCDetailsBean.baseMRCPrice).toBeDefined();
                            expect($scope.protectionPlanDetails.mRCDetailsBean.baseMRCPrice).toEqual(10.99);
                            var planDescriptonsToDisplay = Endpoint_deviceLegalContentNode.get_device_shared_content.result[exCommonConstants.insuranceOptionContentPath
                                + $scope.protectionPlanDetails.skuId];
                            // check wether the correct plan description is populated in the scope variable.
                            expect($scope.protectionPlanDetails.planDescriptonsToDisplay).toEqual(planDescriptonsToDisplay);
                        });
                    });

                    it('should remove an item from cart', function () {
                        $scope.protectionRemoveItemFromCart();
                        expect($scope.isProtectionATCDisabled).toEqual(false);
                        expect($scope.isProtectionRemoveDisabled).toEqual(true);
                        expect(exCartService.removeItemFromCart.calls.mostRecent().args.length).toEqual(1);
                        expect(typeof exCartService.removeItemFromCart.calls.mostRecent().args[0]).toEqual('object');
                        expect(exCartService.removeItemFromCart.calls.mostRecent().args[0].removalCommerceIds).toEqual($scope.featureCommerceItemId);
                    });

                    it('should refresh the cart', function () {
                        $rootScope.$broadcast(exCommonConstants.event.protectionPlanAdded, true);
                        expect(exCartService.getCart).toHaveBeenCalled();

                    });

                    it('should add an protection plan to cart ', function () {
                        spyOn($rootScope, '$broadcast').and.callThrough();
                        $scope.addProtectionPlanToCart();
                        expect(exCartService.addItemToCart).toHaveBeenCalled();
                        expect(exCartService.addItemToCart.calls.mostRecent().args.length).toEqual(2);
                        expect(typeof exCartService.addItemToCart.calls.mostRecent().args[0]).toEqual('object');
                        expect(exCartService.addItemToCart.calls.mostRecent().args[1].items.items[0].catalogRefId).toEqual($scope.protectionPlanDetails.skuId);
                        expect(exCartService.addItemToCart.calls.mostRecent().args[1].items.items[0].productId).toEqual($scope.protectionPlanDetails.productId);

                    });

                    it('should enable add to cart button if protection plan is not added by user', function () {
                        $rootScope.$broadcast(exCommonConstants.event.protectionPlanAdded, false);
                        expect($scope.isProtectionATCDisabled).toEqual(false);
                        expect($scope.isProtectionRemoveDisabled).toEqual(true);
                    });

                    it('should disables the AddToCart CTA when clicked once by user', function () {
                        $scope.atcProtectionDisabled();
                        expect($scope.isProtectionATCDisabled).toEqual(true);
                        expect($scope.isProtectionRemoveDisabled).toEqual(false);
                    });

                    it('should open insurance Options Modal or close the modal ' +
                        'on the basis of visible falg (true/false)', function () {

                        var params = {
                            templateUrl: exCommonConstants.insuranceOptionsModalPath,
                            windowClass: 'modal-fullscreen',
                            scope: $scope
                        };
                        // Should open the insurance option modal as visible flag is true
                        $scope.openInsuranceOptions();
                        expect($modal.open).toHaveBeenCalled();
                        expect($modal.open).toHaveBeenCalledWith(params);

                        // Should go to the top of the page as visible flag is false
                        $scope.closeInsuranceOption();
                        expect(exHelpUtils.closeActiveModal).toHaveBeenCalled();
                    });

                    it('should open insurance legal details Modal ', function () {
                        // Should open the insurance legal details modal
                        $scope.atcProtectionDisabled();
                        expect($modal.open).toHaveBeenCalled();
                        expect($scope.isProtectionATCDisabled).toEqual(true);
                        expect($scope.isProtectionRemoveDisabled).toEqual(false);
                    });


                    // check that link click event fires when user clicks on see price details link for devices
                    it('should fire link clink event with appropriate value when user clicks on See more details and other options link', function () {

                        var expectedReportingObject = jasmine.objectContaining({
                            eventAction: 'linkClick',
                            eventCode: 'Link_Click',
                            additionaldata: {
                                'linkName': 'See more details and other options',
                                'linkPosition': 'Body',
                                'linkDestinationURL': '/shop/xpress/virtual/insurance-config.html'
                            }
                        });

                        $scope.openInsuranceOptions();
                        expect($scope.$emit).toHaveBeenCalledWith('DS_Reporting_Event', expectedReportingObject,
                            $scope);
                    });
                });
            });
        });
    });
})();
