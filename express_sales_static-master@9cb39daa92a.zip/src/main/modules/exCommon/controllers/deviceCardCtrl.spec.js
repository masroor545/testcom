(function () {
    'use strict';

    define(['deviceCardCtrl'], function () {
        describe('src/main/modules/exCommon/controllers/deviceCardCtrl.spec.js', function () {
            describe('deviceCardCtrl controller of exCommon', function () {
                var $rootScope, exCartService, exCommonConstants, $controller, scope, $timeout;

                // Labels
                var commitmentTermLabels = {
                    'commitmentTermNext': 'AT&T NEXT',
                    'commitmentTermEveryYear': 'AT&T NEXT Every year',
                    'commitmentTermTwoYear': '2 year',
                    'commitmentTermZero': 'No Annual Contract'
                };

                var deviceCardTimer = 10;
                var cartData = Endpoint_cartLookupApi.get_cart_lookup_new.result.result;
                var forNMonthsLabel = 'for {0} months';

                beforeEach(function () {
                    module('exCommon');

                    inject(function ($injector) {
                        $controller = $injector.get('$controller');
                        $rootScope = $injector.get('$rootScope');
                        $timeout = $injector.get('$timeout');
                        exCommonConstants = $injector.get('exCommonConstants');
                    });

                    exCartService = jasmine.createSpyObj('exCartService', ['getCart']);
                    exCartService.getCart.and.returnValue({
                        'then': function (callBackFN) {
                            callBackFN(Endpoint_cartLookupApi.get_cart_lookup_new.result);
                        }
                    });
                });

                describe('the controllers scope', function () {

                    beforeEach(function () {
                        scope = $rootScope.$new();
                        scope.commitmentTermLabels = commitmentTermLabels;
                        scope.deviceCardTimer = deviceCardTimer;
                        scope.forNMonthsLabel = forNMonthsLabel;

                        $controller('deviceCardCtrl', {
                            $scope: scope,
                            exCartService: exCartService
                        });
                    });

                    afterEach(function () {
                        exCartService.getCart.calls.reset();
                    });

                    it('should populate scope data from service by default', function () {
                        scope.$apply();
                        $rootScope.$broadcast(exCommonConstants.event.cartCompletedOnAccessoryPageLoad, cartData);

                        expect(scope.deviceCard.device.displayName).toEqual('Apple iPhone 7 - 32GB');
                        expect(scope.deviceCard.device.color).toEqual('Black');
                        expect(scope.deviceCard.device.size).toEqual(32);
                        expect(scope.deviceCard.device.uom).toEqual('GB');
                        expect(scope.deviceCard.selectedCommitmentTerm.termContractLength).toEqual(30);
                        expect(scope.deviceCard.selectedCommitmentTerm.termContractType).toEqual('lease');
                        expect(scope.deviceCard.selectedCommitmentTerm.forTermMonthsDisplay).toEqual('for 30 months');
                    });

                    it('should set show device card to false after timeout', function () {
                        $rootScope.$broadcast(exCommonConstants.event.cartCompletedOnAccessoryPageLoad, cartData);
                        expect(scope.deviceCard.showDeviceCard).toEqual(true);
                        $timeout.flush(scope.deviceCardTimer);
                        scope.showDeviceCard();
                        expect(scope.deviceCard.showDeviceCard).toEqual(false);
                    });
                });
            });
        });
    });
})();
