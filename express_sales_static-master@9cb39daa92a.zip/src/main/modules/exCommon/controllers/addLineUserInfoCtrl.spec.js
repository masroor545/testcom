(function () { 
    'use strict'; 
 
    define(['addLineUserInfoCtrl'], function () { 
        describe('src/main/modules/exCommon/controllers/addLineUserInfoCtrl.spec.js', function () { 
            describe('addLineUserInfoCtrl controller of exCommon', function () { 
                var $controller, $scope, $rootScope, profileInfoService; 
 
                beforeEach(function () { 
                    module('exCommon', function ($provide) { 
                        profileInfoService = jasmine.createSpyObj('profileInfoService', ['getProfileInfo']); 
                        $provide.value('profileInfoService', profileInfoService); 
                    }); 
 
                    inject(function ($injector) { 
                        $controller = $injector.get('$controller'); 
                        $rootScope = $injector.get('$rootScope'); 
 
                    }); 
 
                    $scope = $rootScope.$new(); 
 
                    profileInfoService.getProfileInfo.and.returnValue({ 
                        'then': function (callBackFN) { 
                            callBackFN(Endpoint_profileInfoApi.get_profile_info_for_aal.result); 
                        } 
                    }); 
 
                    $controller('addLineUserInfoCtrl', { 
                        $scope: $scope, 
                        profileInfoService: profileInfoService 
                    }); 
 
                }); 
 
                describe('addLineUserInfoCtrl controller', function () { 
 
                    it('should set logged in user account name and plan name', function () { 
                        expect(profileInfoService.getProfileInfo).toHaveBeenCalled(); 
                        expect($scope.user.accountName).toBeDefined(); 
                        expect($scope.user.planName).toBeDefined(); 
                        expect($scope.user.planName).toEqual('AT&T Unlimited Plus'); 
                        expect($scope.user.accountName).toEqual("GLORIA"); 
                    }); 
                }); 
            }); 
        }); 
    }); 
})();