(function () {
    'use strict';

    angular.module('exCommon')

        .controller('accessoryConfigCtrl', ['$scope', '$rootScope', '$window', '$location', '$anchorScroll', 'exCommonConstants',
            'deviceConfigSrv', 'selectedSkuSrv', 'exCartService', 'reportingDataSrv', 'imagePathService', '$modalStack', 'exHelpUtils',
            function ($scope, $rootScope, $window, $location, $anchorScroll, exCommonConstants,
                deviceConfigSrv, selectedSkuSrv, exCartService, reportingDataSrv, imagePathService, $modalStack, exHelpUtils) {

                var accessoryConfig = {
                    selectedSku: {},
                    focusedSku: {},
                    sizeVariants: [],
                    colorVariants: [],
                    skuSiblings: [],
                    displayAccessoryDetails: false,
                    displayPricingOptions: false,
                    accessoriesInCart: {},
                    openReviewsTab: false,
                    isWidget: false,
                    openOverviewTab: true,
                    displayDeliveryPromiseMessage: false,
                    displayPreOrderMessage: false,
                    displayOutOfStockMessage: false,
                    deliveryPromiseMessage: [],
                    losgInContext: {},
                    renderBV: true
                };
                $scope.accessoryConfig = accessoryConfig;
                $scope.getSizeVariants = getSizeVariants;
                $scope.getColorVariants = getColorVariants;
                $scope.setSelectedSku = setSelectedSku;
                $scope.showAccessoryDetails = showAccessoryDetails;
                $scope.displayAccessoryDetails = displayAccessoryDetails;
                $scope.showReviewDetails = showReviewDetails;
                $scope.accessoryConfigAddToCart = accessoryConfigAddToCart;
                $scope.accessoryConfigRemoveItemFromCart = accessoryConfigRemoveItemFromCart;
                $scope.showDeliveryPromiseMessage = showDeliveryPromiseMessage;
                $scope.showPreOrderMessage = showPreOrderMessage;
                $scope.showOutOfStockMessage = showOutOfStockMessage;
                $scope.getAccDeliveryPromiseMessage = getAccDeliveryPromiseMessage;
                $scope.close = close;

                $scope.$on(exCommonConstants.event.accessorySelected, function (event, selectedSku) {
                    accessoryConfig.isWidget = $scope.initargs !== undefined;
                    if (accessoryConfig.isWidget === true) {
                        accessoryConfig.losgInContext = selectedSku;
                        getAccessoryInformation(selectedSku.commerceItem.skuID);
                    } else {
                        getAccessoryInformation(selectedSku);
                    }

                    if (accessoryConfig.isWidget !== true) {
                        getAccessoriesInCart();
                    }

                });

                $scope.$on(exCommonConstants.event.accessoryConfigWidgetBVInitiated, function () {
                    accessoryConfig.renderBV = true;
                });

                activate();

                /**
                 * Controller startup logic.
                 * @private
                 */
                function activate () {
                    if ($scope.initargs !== undefined) {
                        accessoryConfig.renderBV = false;
                    }
                    if ($scope.initargs === undefined) {
                        var skuId = $location.search().sku || selectedSkuSrv.getSelectedAccessory();
                        getAccessoryInformation(skuId);
                        getAccessoriesInCart();
                    }

                    $rootScope.$broadcast(exCommonConstants.event.accessoryConfigLoaded, null);
                }

                /**
                 * Close the modal logic.
                 * @private
                 */
                function close () {
                    // Dismisses any modals that are present
                    var top = $modalStack.getTop();
                    if (top) {
                        $modalStack.dismiss(top.key);

                        //Fire page load event when Accessory displayed on accessory recommender page as a modal. Should only be fired if getting called to show modal.
                        $scope.$emit(exCommonConstants.event.DS_REPORTING_PAGELOAD_EVENT,
                            exCommonConstants.friendlyPageName.accessoryRecommender
                        );
                    }
                }

                /**
                 * Formats sku based on display logic
                 * @private
                 * @param {object} sku
                 * @returns {object} Formatted sku object
                 */
                function formatSku (sku) {
                    var formattedSku = {};

                    formattedSku.size = sku.skuSize;
                    formattedSku.color = sku.color;
                    formattedSku.hexValue = sku.hexValue;
                    formattedSku.skuId = sku.skuId;
                    formattedSku.marketingsequence = sku.marketingsequence;
                    formattedSku.productId = sku.productId;
                    formattedSku.productDisplayName = sku.productDisplayName;
                    formattedSku.selectedCommitmentTerm = sku.priceList[0];
                    formattedSku.accessoryPageURL = sku.devicePageURL;
                    formattedSku.effectiveOutOfStock = sku.effectiveOutOfStock;
                    formattedSku.preOrderable = sku.preOrderable;

                    // CTA to display on the page
                    formattedSku.isPreOrderButton = sku.preOrderable && !sku.effectiveOutOfStock &&
                        !accessoryConfig.isWidget;
                    formattedSku.isAddToCartButton = !sku.preOrderable && !sku.effectiveOutOfStock &&
                        !accessoryConfig.isWidget;
                    formattedSku.isOutOfStockButton = sku.effectiveOutOfStock && !accessoryConfig.isWidget;

                    // data-qa for CTA
                    if (formattedSku.isPreOrderButton) {
                        formattedSku.dataQaForConfigCTA = 'accessoryConfig-AccessoryConfig-preOrder';
                        formattedSku.dataQaForDetailsCTA = 'accessoryDetails-AccessoryDetails-preOrder';
                    } else if (formattedSku.isOutOfStockButton) {
                        formattedSku.dataQaForConfigCTA = 'accessoryConfig-AccessoryConfig-outOfStock';
                        formattedSku.dataQaForDetailsCTA = 'accessoryDetails-AccessoryDetails-outOfStock';
                    } else if (accessoryConfig.isWidget) {
                        formattedSku.dataQaForConfigCTA = 'accessoryConfig-AccessoryConfig-updateCart';
                        formattedSku.dataQaForDetailsCTA = 'accessoryDetails-AccessoryDetails-updateCart';
                    } else {
                        // by default data-qa is addToCart
                        formattedSku.dataQaForConfigCTA = 'accessoryConfig-AccessoryConfig-addToCart';
                        formattedSku.dataQaForDetailsCTA = 'accessoryDetails-AccessoryDetails-addToCart';
                    }

                    // Ensures rating is always a number
                    formattedSku.rating = (typeof sku.rating === 'number' && sku.rating !== 0 ? Number(sku.rating.toFixed(2)) : 0);

                    // Assumes the first item is the best price
                    formattedSku.price = setPrice(sku.priceList[0]);

                    // Retrieves image url to call a common imagePathSerivce function e.g. /xpress/Fitbit/Fitbit Blaze Smart Fitness Watch/Black-hero.png
                    formattedSku.imgUrl = imagePathService.getXpressImagePath(accessoryConfig.manufacturer, null,
                                            sku.productDisplayName, formattedSku.color, '-hero.png');
                    // Color variant formatting
                    formattedSku.colorVariant = {};
                    formattedSku.colorVariant.id = sku.color;
                    formattedSku.colorVariant.colorCode = sku.hexValue;

                    // Size variant formatting
                    formattedSku.sizeVariant = {};
                    formattedSku.sizeVariant.id = formattedSku.size;

                    // Hazard legal notes
                    formattedSku.legalNotes = sku.legalNotes;

                    return formattedSku;
                }

                /**
                 * Sets price based on the commitment term
                 * @private
                 * @param {object} commitmentTerm
                 * @returns {number} the price
                 */
                function setPrice (commitmentTerm) {
                    return commitmentTerm.type === 'regular' ?
                        commitmentTerm.dueToday : commitmentTerm.monthlyLeasePrice;
                }

                /**
                 * Formats sku to be added as a cart item
                 * @private
                 * @param {object} sku
                 * @returns {object} Formatted cart item
                 */
                function formatCartItem (sku) {
                    var cartItem = {
                        items: {
                            items: [{}]
                        }
                    };

                    // Abbreviation
                    var item = cartItem.items.items[0];

                    item.quantity = 1;
                    item.catalogRefId = sku.skuId;
                    item.productId = sku.productId;
                    if (accessoryConfig.isWidget === true) {
                        item.losgId = Object.keys(accessoryConfig.losgInContext.losgId)[0];
                    }

                    return cartItem;
                }

                /**
                 * Scope function to add selectedSku to cart
                 * @public
                 */
                function accessoryConfigAddToCart () {
                    var cartItem = formatCartItem(accessoryConfig.selectedSku);
                    // actionType is always addItemAndGoToNextStep and skipRedirect
                    var params = {
                        actionType: 'addItemAndGoToNextStep',
                        skipRedirect: true
                    };
                    // Adding the removalCommerseID for updateCart scenario in widgets where we need to remove the item in cart,
                    // And replace it with the new item being added.
                    if (accessoryConfig.isWidget === true) {
                        if ($scope.initargs.type === 'cart'
                            && accessoryConfig.selectedSku.skuId !== accessoryConfig.losgInContext.commerceItem.skuID) {
                            params.removalCommerceIds = accessoryConfig.losgInContext.commerceItem.itemID;
                        }
                    }

                    var eventPayload = reportingDataSrv.getAddToCartAccessoryDetailsPayload($scope.accessoryConfig),
                        eventCode = accessoryConfig.selectedSku.preOrderable ? 'DS_Upgrade_Cart_Preorder_Submit' : 'DS_Upgrade_Cart_Add_Submit';

                    $scope.$emit(exCommonConstants.event.DS_REPORTING_EVENT, {
                        eventAction: 'formSubmit',
                        eventCode: eventCode,
                        additionaldata: eventPayload
                    }, $scope);

                    //checking to make sure the item we are adding is not already in cart.
                    var skuIDInCart = exHelpUtils.getValue('accessoryConfig.losgInContext.commerceItem.skuID', $scope);

                    if (accessoryConfig.selectedSku.skuId !== skuIDInCart) {
                        exCartService.addItemToCart(params, cartItem).then(function (data) {
                            if ($scope.initargs === undefined) {
                                getCartData();
                            }

                            if (data.response !== undefined && data.response !== null
                                && data.response.status === exCommonConstants.errorStatus) {
                                eventPayload = reportingDataSrv.updateEventPayloadFailure(eventPayload, data);
                            }

                            $rootScope.$emit(exCommonConstants.event.DS_REPORTING_EVENT, {
                                eventAction: 'formResponse',
                                eventCode: eventCode,
                                additionaldata: eventPayload
                            }, $scope);
                        });
                    }

                    if ($scope.initargs && $scope.initargs.type === 'cart') {
                        accessoryConfig.renderBV = false;
                        $rootScope.$broadcast(exCommonConstants.event.accessoryConfigWidgetAdded, true);
                    }
                    $scope.close();
                }

                /**
                 * Scope function to remove accessory from cart if already added and get updated cart data
                 * @public
                 */
                function accessoryConfigRemoveItemFromCart (skuId) {
                    if (skuId === undefined) {
                        throw new SyntaxError('No argument passed');
                    }

                    var accessoryCommerceItemId = accessoryConfig.accessoriesInCart[skuId];
                    if (accessoryCommerceItemId) {
                        var params = {removalCommerceIds: accessoryCommerceItemId};
                        exCartService.removeItemFromCart(params).then(function (result) {
                            if (result && result.response && result.response.status === 'success') {
                                getCartData();
                            }
                            $scope.close();
                        });
                    } else {
                        throw new Error('No commerce item found for sku ' + skuId);
                    }

                    // Reporting event that fires an add to cart event of -1 to notify a remove has been called.
                    $scope.$emit(exCommonConstants.event.DS_REPORTING_EVENT, {
                        eventAction: 'formSubmit',
                        eventCode: 'DS_Upgrade_Cart_Add_Submit',
                        additionaldata: reportingDataSrv.getRemovePayload()
                    }, $scope);
                }

                /**
                 * Get fresh cart data and broadcast results
                 * @private
                 */
                function getCartData () {
                    exCartService.getCart('reload').then(function (data) {
                        if (data && data.result) {
                            data = data.result;
                            $rootScope.$broadcast(exCommonConstants.event.cartDataUpdated, data);
                        }

                    });
                }

                /**
                 * Scope function setter to show or hide the delivery promise message section
                 * @public
                 * @param {String} selectedSkuId
                 */
                function showDeliveryPromiseMessage (selectedSkuId) {
                    if (accessoryConfig.deliveryPromiseMessage[selectedSkuId] !== undefined) {
                        accessoryConfig.displayDeliveryPromiseMessage = true;
                    } else {
                        accessoryConfig.displayDeliveryPromiseMessage = false;
                    }
                }

                /**
                 * Scope function setter to show or hide the pre-order message section
                 * @public
                 * @param {boolean} visible
                 */
                function showPreOrderMessage (visible) {
                    accessoryConfig.displayPreOrderMessage = visible;
                    if (visible === true) {
                        // If we are in landscape viewport
                        if ($window.document.documentElement.clientWidth > exCommonConstants.mobileViewportMax) {
                            $anchorScroll('device-config-container');
                        } else {
                            $anchorScroll('preOrderMessage');
                        }
                    }
                }

                /**
                 * Scope function setter to show or hide the out of stock information section
                 * @public
                 * @param {boolean} visible
                 */
                function showOutOfStockMessage (visible) {
                    accessoryConfig.displayOutOfStockMessage = visible;
                }

                /**
                 * Scope function setter to show or hide the accessory details section
                 * @public
                 * @param {boolean} visible
                 */
                function displayAccessoryDetails (visible) {
                    accessoryConfig.displayAccessoryDetails = visible;
                }

                /**
                 * Scope function to scroll to accessory details section
                 * @public
                 */
                function showAccessoryDetails () {
                    displayAccessoryDetails(true);
                    accessoryConfig.openOverviewTab = true;

                    // If we are in landscape viewport
                    if ($window.document.documentElement.clientWidth > exCommonConstants.mobileViewportMax) {

                        //Scroll to the accessory details after overview accordion is finished expanding
                        exHelpUtils.scrollToAccordion('accessory-details-container', 'overview-container', $scope);
                    }

                    // Fire link click event when user clicks on explore the device details link for device
                    $scope.$emit(exCommonConstants.event.DS_REPORTING_EVENT, {
                        eventAction: 'linkClick',
                        eventCode: 'Link_Click',
                        additionaldata: {
                            'linkName': exCommonConstants.linkName.seeAccessoryDetails,
                            'linkPosition': exCommonConstants.linkPosition,
                            'linkDestinationURL': exCommonConstants.virtualUrl.accessoryDetails
                        }
                    }, $scope);
                }

                /**
                 * Scope function to scroll to review details section
                 * @public
                 */
                function showReviewDetails () {
                    displayAccessoryDetails(true);

                    // Close overview accordian if it is open
                    if (accessoryConfig.openOverviewTab) {
                        accessoryConfig.openOverviewTab = false;
                    }

                    // If reviews tab isn't open watch for whenever
                    // accordion is finished expanding then scroll to it
                    if (accessoryConfig.openReviewsTab !== true) {
                        accessoryConfig.openReviewsTab = true;

                        var deregisterWatch = $scope.$watch(function () {
                            return angular.element('#reviews-container').children()[1].className;
                        }, function () {
                            $anchorScroll('reviews-container');

                            // Deregister watcher if review accordion has reached at the top of screen
                            if (angular.element('#reviews-container').offset().top === 0) {
                                deregisterWatch();
                            }
                        });
                    } else {
                        $anchorScroll('reviews-container');
                    }
                }

                /**
                 * Gets the size variants based on the sku.
                 * E.g. red L sku will return red S, red M, red L skus.
                 * Assumes color IS NOT the first key in the 2d array.
                 * @public
                 * @param {object} selSku The selected sku
                 * @param {Array<Array<object>>} skuSiblings A 2d array of skus
                 * @return {Array<object>} An array of skus with matching colors and varying sizes
                 */
                function getSizeVariants (selSku, skuSiblings) {
                    // Filters non-matching colors from skuItems and concats the arrays
                    return skuSiblings
                        .map(function (skus) {
                            return skus.filter(function (sku) {
                                return selSku.color === sku.color;
                            });
                        })
                        .reduce(function (matchingSkus, matchingSku) {
                            return matchingSkus.concat(matchingSku);
                        });
                }

                /**
                 * Gets the color variants based on the sku.
                 * If there is a color that does not come in the selected size, that sku will be added.
                 * E.g. red L sku will return red L, blue L, green L, purple M skus,
                 * assuming there is no purple L sku.
                 * @public
                 * @param {string} selSku - The selected sku
                 * @param {Array<Array<object>>} skuSiblings - A 2d array of skus
                 * @return {Array<object>} An array of skus with all colors and any matching sizes
                 */
                function getColorVariants (selSku, skuSiblings) {
                    var updatedSkuSiblings = [];
                    if (Array.isArray(skuSiblings[0]) !== true) {
                        return skuSiblings;
                    }
                    // Pushing all the colors variants under the selected size to the updatedSkuSiblings array.
                    for (var i = 0; i < skuSiblings.length; i++) {
                        if (skuSiblings[i][0].size === selSku.size) {
                            angular.forEach(skuSiblings[i], function (skuSibling) {
                                updatedSkuSiblings.push(skuSibling);
                            });
                        }
                    }
                    // Now pushing other color variants across all sizes which are not already present in the updatedSkuSiblings array.
                    for (var j = 0; j < skuSiblings.length; j++) {
                        angular.forEach(skuSiblings[j], function (skuSibling) {
                            var colorVariantsToBeAdded = true;
                            angular.forEach(updatedSkuSiblings, function (updatedSkuSibling) {
                                if (updatedSkuSibling.color === skuSibling.color) {
                                    colorVariantsToBeAdded = false;
                                }
                            });
                            if (colorVariantsToBeAdded === true) {
                                updatedSkuSiblings.push(skuSibling);
                            }
                        });
                    }
                    return updatedSkuSiblings.sort(marketingSequenceSort);
                }

                /**
                 * Scope function to set the selected sku and perform operations based on selected sku.
                 * show/hide pre-order warning message for selected sku
                 * @public
                 * @param {object} sku The sku to be set as the selected sku
                 */
                function setSelectedSku (sku) {
                    accessoryConfig.selectedSku = sku;
                    showDeliveryPromiseMessage(accessoryConfig.selectedSku.skuId);
                    showPreOrderMessage(accessoryConfig.selectedSku.preOrderable);
                    showOutOfStockMessage(accessoryConfig.selectedSku.effectiveOutOfStock);
                }

                /**
                 * Sort function by sku marketing sequence
                 * @param {number} a
                 * @param {number} b
                 */
                function marketingSequenceSort (a, b) {
                    return a.marketingsequence - b.marketingsequence;
                }

                /**
                 * Gets accessory sku ID/commerce item ID in cart
                 * @private
                 * @return {object} A map of skuIds to commerceItemIds
                 */
                function getAccessoriesInCart () {
                    exCartService.getCart().then(function (data) {
                        if (data && data.result) {
                            var cartData = data.result.methodReturnValue.lobTypes.WIRELESS;
                            var accessories = {};

                            angular.forEach(cartData.losgs, function (losg) {
                                angular.forEach(losg.cartItems.accessory, function (accessoryDetails, accessorySkuId) {
                                    accessories[accessorySkuId] = accessoryDetails.commerceItemId;
                                });
                            });

                            accessoryConfig.accessoriesInCart = accessories;
                        }
                    });
                }

                /**
                 * Gets Delivery Promise Message of all the accessory variants.
                 * @private accessoryConfig.getAccDeliveryPromiseMessage
                 * @param {string} accessoryMap color/size variant of selected accessory
                 * @param {string} variant type in accessoryMap, i.e. size/color/no variants
                 */
                function getAccDeliveryPromiseMessage (accessoryMap, variantType) {
                    var skuIds;
                    if (variantType === 'hasSizeVariants') {
                        skuIds = Object.keys(accessoryMap).map(function (sizes) {
                            return Object.keys(accessoryMap[sizes]).map(function (deviceSkuIds) {
                                return deviceSkuIds;
                            }).join(',');
                        }).join(',');
                    } else if (variantType === 'hasColorVariants') {
                        skuIds = (Object.keys(accessoryMap)).map(function (obj) {
                            return obj;
                        }).join(',');
                    } else {
                        skuIds = accessoryMap.skuId;
                    }

                    deviceConfigSrv.getDeliveryPromiseMessage(skuIds).then(function (deliveryPromiseMessage) {
                        var shipmentDates = deliveryPromiseMessage.data.payload.skuShipmentDates;
                        angular.forEach(shipmentDates, function (shipmentDate) {
                            accessoryConfig.deliveryPromiseMessage[shipmentDate.SKUId] = shipmentDate;
                        });
                        // show/hide delivery promise information based on selected sku
                        showDeliveryPromiseMessage(accessoryConfig.selectedSku.skuId);
                    });
                }

                /**
                 * Gets information about the sku.
                 * Stores siblings in a 2d array if there are multiple variants.
                 * Converts siblings in a 1d array if there is only one variant.
                 * @private accessoryConfig.getAccessoryInformation
                 * @param {string} skuId The selected sku
                 */
                function getAccessoryInformation (skuId) {
                    var params = {
                        includeAssociatedProducts: true,
                        includePrices: true,
                        skuId: skuId,
                        groupResultsByVariants: true,
                        filterOffer: false
                    };

                    deviceConfigSrv.getDeviceDetails(skuId, params).then(function (data) {
                        data = data.data.result.methodReturnValue;
                        if (data !== null) {
                            // Removes preexisting sku-specific information
                            accessoryConfig.selectedSku = {};
                            accessoryConfig.focusedSku = {};
                            accessoryConfig.sizeVariants = [];
                            accessoryConfig.colorVariants = [];
                            accessoryConfig.skuSiblings = [];

                            // Product-level information
                            accessoryConfig.manufacturer = data.manufacturer;

                            if (data.hasAccSizeVariants === true) {
                                accessoryConfig.selectedSku = formatSku(data.accessorySizeVariantsMap[data.selectedSkuSize][skuId]);
                                accessoryConfig.productDisplayName = data.accessorySizeVariantsMap[data.selectedSkuSize][skuId].productDisplayName;

                                // Converts map into 2d array, strips out unnecessary information
                                accessoryConfig.skuSiblings = Object.keys(data.accessorySizeVariantsMap).map(function (key1) {
                                    return Object.keys(data.accessorySizeVariantsMap[key1]).map(function (key2) {
                                        var sku = data.accessorySizeVariantsMap[key1][key2];
                                        return formatSku(sku);
                                    }).sort(marketingSequenceSort);
                                });

                                // Get delivery Message for Accessories
                                $scope.getAccDeliveryPromiseMessage(data.accessorySizeVariantsMap, 'hasAccSizeVariants');

                                accessoryConfig.sizeVariants = $scope.getSizeVariants(accessoryConfig.selectedSku, accessoryConfig.skuSiblings);
                                accessoryConfig.colorVariants = $scope.getColorVariants(accessoryConfig.selectedSku, accessoryConfig.skuSiblings);

                            } else if (data.hasColorVariants === true) {
                                accessoryConfig.selectedSku = formatSku(data.colorVariantsMap[skuId]);

                                // Get delivery Message for Accessories
                                $scope.getAccDeliveryPromiseMessage(data.colorVariantsMap, 'hasColorVariants');

                                // Converts map into array, strips out unnecessary information
                                accessoryConfig.colorVariants = Object.keys(data.colorVariantsMap).map(function (key) {
                                    var sku = data.colorVariantsMap[key];
                                    return formatSku(sku);
                                }).sort(marketingSequenceSort);
                                accessoryConfig.productDisplayName = data.colorVariantsMap[skuId].productDisplayName;

                            } else {
                                accessoryConfig.selectedSku = formatSku(data.selectedSkuDetails);

                                // Get delivery Message for Accessories
                                $scope.getAccDeliveryPromiseMessage(data.selectedSkuDetails, 'hasNoVariants');

                                accessoryConfig.productDisplayName = data.selectedSkuDetails.productDisplayName;
                            }

                            // Sets focused sku
                            accessoryConfig.focusedSku = {
                                color: accessoryConfig.selectedSku.color,
                                size: accessoryConfig.selectedSku.size
                            };

                            // Broadcast selected sku
                            $scope.$broadcast(exCommonConstants.event.selectedSkuInFocus, accessoryConfig.selectedSku);

                            // Broadcast selected sku for bazaar voice
                            $scope.$broadcast(exCommonConstants.event.BVSkuSelected, accessoryConfig.selectedSku);

                            // show/hide delivery promise information based on selected sku
                            showDeliveryPromiseMessage(accessoryConfig.selectedSku.skuId);

                            // show/hide pre-order warning message based on selected sku
                            showPreOrderMessage(accessoryConfig.selectedSku.preOrderable);

                            // show/hide out of stock information based on selected sku
                            showOutOfStockMessage(accessoryConfig.selectedSku.effectiveOutOfStock);
                        }
                    });
                }

            }]);
})();
