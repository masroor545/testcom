(function () {
    'use strict';

    angular.module('exCommon')

        .controller('deviceCardCtrl', ['$scope', '$timeout', 'exCommonConstants', function ($scope, $timeout, exCommonConstants) {
            var deviceCard = {
                selectedCommitmentTerm: {},
                device: {},
                showDeviceCard: true
            };
            $scope.deviceCard = deviceCard;
            $scope.showDeviceCard = showDeviceCard;

            /**
             * Show device card for specific time
             * @private
             */
            function showDeviceCard () {
                $timeout(function () {
                    $scope.deviceCard.showDeviceCard = false;
                }, $scope.deviceCardTimer);
            }

            /**
             * Sets up commitmentTerm list based on pricelist and term
             * @private
             * @param {object} device
             * @returns {object} formatted priceList
             */
            function createCommitmentTermList (device) {
                return device.priceList.map(function (commitmentTerm) {
                    if (commitmentTerm.leaseTotalMonths === 30) {
                        commitmentTerm.commitTermName = $scope.commitmentTermLabels.commitmentTermNext;
                        commitmentTerm.selectedskuPriceToDisplay = commitmentTerm.monthlyLeasePrice;
                    } else if (commitmentTerm.leaseTotalMonths === 20) {
                        commitmentTerm.commitTermName = $scope.commitmentTermLabels.commitmentTermInstallment;
                        commitmentTerm.selectedskuPriceToDisplay = commitmentTerm.monthlyLeasePrice;
                    } else if (commitmentTerm.leaseTotalMonths === 24) {
                        commitmentTerm.commitTermName = $scope.commitmentTermLabels.commitmentTermEveryYear;
                        commitmentTerm.selectedskuPriceToDisplay = commitmentTerm.monthlyLeasePrice;
                    } else if (commitmentTerm.name === '24') {
                        commitmentTerm.commitTermName = $scope.commitmentTermLabels.commitmentTermTwoYear;
                        commitmentTerm.selectedskuPriceToDisplay = commitmentTerm.dueToday;
                    } else if (commitmentTerm.name === '1') {
                        commitmentTerm.commitTermName = $scope.commitmentTermLabels.commitmentTermZero;
                        commitmentTerm.selectedskuPriceToDisplay = commitmentTerm.dueToday;
                    }

                    if (commitmentTerm.type !== 'regular') {
                        commitmentTerm.termContractLength = commitmentTerm.leaseTotalMonths;
                        commitmentTerm.termContractType = commitmentTerm.contractGroupType;
                    } else {
                        commitmentTerm.termContractLength = parseInt(commitmentTerm.name);
                        commitmentTerm.termContractType = commitmentTerm.type;
                    }

                    commitmentTerm.forTermMonthsDisplay = $scope.forNMonthsLabel.replace('{0}', commitmentTerm.leaseTotalMonths);

                    return commitmentTerm;
                });
            }


            /**
             * Makes a cart service and get the cart data, filter out current losg's device item
             * @private
             */
            function activate () {

                $scope.$on(exCommonConstants.event.cartCompletedOnAccessoryPageLoad, function (event, data) {
                    var cartData, myLOSGinfo;

                    if (data &&
                        data.methodReturnValue &&
                        data.methodReturnValue.lobTypes &&
                        data.methodReturnValue.lobTypes.WIRELESS &&
                        data.methodReturnValue.lobTypes.WIRELESS.currentLOSGId) {

                        cartData = data.methodReturnValue.lobTypes.WIRELESS;
                        myLOSGinfo = cartData.losgs[cartData.currentLOSGId];
                        $scope.deviceCard.device = myLOSGinfo.cartItems.device[Object.keys(myLOSGinfo.cartItems.device)[0]];
                        angular.forEach(createCommitmentTermList($scope.deviceCard.device), function (commitmentTerm) {
                            if (myLOSGinfo.contractType === commitmentTerm.termContractType && parseInt(myLOSGinfo.contractLength) === commitmentTerm.termContractLength) {
                                $scope.deviceCard.selectedCommitmentTerm = commitmentTerm;
                                showDeviceCard();
                            }
                        });
                    }

                });
            }
            activate();
        }]);
})();
