(function () {
    'use strict';

    angular.module('exCommon')

        .controller('protectionPlanCtrl', ['$scope', '$rootScope', '$modal', 'protectionPlanService', 'exCartService', 'exCommonConstants',
            'contentService', 'exCqTranslatorKeyService', 'reportingDataSrv', 'exHelpUtils',
            function ($scope, $rootScope, $modal, protectionPlanService, exCartService, exCommonConstants, contentService,
                exCqTranslatorKeyService, reportingDataSrv, exHelpUtils) {

                var insurancePlans = {
                    options: undefined
                };

                //insurancePlans logic is used in multiple pug files: exinsuranceoptions.pug, exprotectionplan.pug, exprotectionplanlegal.pug
                $scope.insurancePlans = insurancePlans;
                $scope.protectionFeature = {
                    showProtectionPlanDetails: false,
                    displayInsuranceOptions: false
                };
                $scope.protectionPlanDetails = {};
                $scope.defaultProtectionPlanDetails = {};
                $scope.selectedPlanInCartItem = undefined;
                $scope.protectionRemoveItemFromCart = protectionRemoveItemFromCart;
                $scope.atcProtectionDisabled = atcProtectionDisabled;
                $scope.isProtectionRemoveDisabled = '';
                $scope.protectionPlanDescription = undefined;
                $scope.openInsuranceOptions = openInsuranceOptions;
                $scope.closeInsuranceOption = closeInsuranceOption;
                $scope.setSelectedInsurance = setSelectedInsurance;
                $scope.getProtectionPlanLegal = getProtectionPlanLegal;
                $scope.addProtectionPlanToCart = addProtectionPlanToCart;

                /**
                 * Scope level broadcasts that gets set when protection plan is added to cart
                 * or resets the CTA's if user clicked cancel CTA from protection detail modal
                 */
                $scope.$on(exCommonConstants.event.protectionPlanAdded, function (event, status) {
                    if (!status) {
                        $scope.isProtectionATCDisabled = false;
                        $scope.isProtectionRemoveDisabled = true;
                    } else {
                        exHelpUtils.closeActiveModal();
                    }
                    getCartData('reload');
                });

                /**
                 * Scope function to add protection plan to cart if available
                 */
                function addProtectionPlanToCart () {

                    // Update the state(enable/disable) of cta once add to cart function is triggered
                    $scope.isProtectionRemoveDisabled = true;
                    $scope.isProtectionATCDisabled = false;

                    //getting the item to add to the cart
                    var cartItem = formatCartItem();

                    // actionType is always addItemAndGoToNextStep
                    // the only action type for insurance since we always take users back to accessory recommender
                    // so we don't want a redirect we just want to add to cart and close the modal.
                    //if insurance is in cart, we remove it and add the new insurance because we want to update the insurance to the
                    //new one selected by the user
                    var params = {
                        actionType: 'addItemAndGoToNextStep',
                        skipRedirect: true
                    };

                    // If insurance is already in cart then pass removalCommerceId
                    if ($scope.selectedPlanInCartItem) {
                        params.removalCommerceIds = $scope.featureCommerceItemId;
                    }

                    exCartService.addItemToCart(params, cartItem).then(function (result) {
                        if (result && result.payload && result.payload.rollupStatus === 'SUCCESS') {
                            $rootScope.$broadcast(exCommonConstants.event.protectionPlanAdded, true);
                            $scope.isProtectionRemoveDisabled = true;

                            // Updating the protectionPlanDetails and defaultSelectedInsurance to the Insurance added in cart
                            $scope.protectionPlanDetails = $scope.insurancePlans.selectedInsurance;
                            $scope.insurancePlans.defaultSelectedInsurance = $scope.insurancePlans.selectedInsurance;
                            $rootScope.$emit(exCommonConstants.event.DS_REPORTING_EVENT, {
                                eventAction: 'formSubmit',
                                eventCode: 'DS_Upgrade_Cart_Add_Submit',
                                additionaldata: reportingDataSrv.getAddToCartFeaturePayload($scope.insurancePlans.selectedInsurance)
                            }, $scope);

                        }
                    });
                    closeInsuranceOption();
                }

                /**
                 * Formats protection feature to be added as a cart item
                 * @returns {Object} Formatted cart item
                 */
                function formatCartItem () {
                    if ($scope.insurancePlans.selectedInsurance.skuId && $scope.insurancePlans.selectedInsurance.productId) {
                        var cartItem = {
                            items: {
                                items: [{}]
                            }
                        };

                        // Abbreviation
                        var item = cartItem.items.items[0];

                        item.quantity = 1;
                        item.catalogRefId = $scope.insurancePlans.selectedInsurance.skuId;
                        item.productId = $scope.insurancePlans.selectedInsurance.productId;

                        return cartItem;
                    }
                }


                /**
                 * Scope function that disables the ATC CTA when once clicked by user, and enables Remove CTA
                 * of protection plan
                 */
                function atcProtectionDisabled () {
                    $scope.isProtectionRemoveDisabled = false;
                    $scope.isProtectionATCDisabled = true;
                    var modalInstance = $modal.open({
                        templateUrl: exCommonConstants.insuranceDetailsLegalModalPath,
                        windowClass: 'modal-fullscreen light-theme',
                        scope: $scope
                    });

                    // Promise resolves when the modal close/dismiss functionality is triggered.
                    if (modalInstance !== undefined && modalInstance.result !== undefined) {
                        modalInstance.result.then(function () {
                            // This block is never reached. Close is acting like a dismiss due to a Zippy code change.
                        }, function () {
                            //Fire page load event when accessory recommender page loads.
                            $scope.$emit(exCommonConstants.event.DS_REPORTING_PAGELOAD_EVENT,
                                exCommonConstants.friendlyPageName.accessoryRecommenderDetails,
                                exCommonConstants.virtualUrl.accessoryRecommenderDetails
                            );
                        });
                    }

                    // Fire link click event when user clicks on show more insurance details legal link for protection plans
                    $scope.$emit(exCommonConstants.event.DS_REPORTING_EVENT, {
                        eventAction: 'linkClick',
                        eventCode: 'Link_Click',
                        additionaldata: {
                            'linkName': exCommonConstants.linkName.showMoreInsurance,
                            'linkPosition': exCommonConstants.linkPosition,
                            'linkDestinationURL': exCommonConstants.virtualUrl.insuranceOptionsLegal
                        }
                    }, $scope);

                    // Fire page load event when accessory displayed on Insurance details legal page as a modal. Should only be fired if getting called to show modal.
                    $scope.$emit(exCommonConstants.event.DS_REPORTING_PAGELOAD_EVENT,
                        exCommonConstants.friendlyPageName.insuranceOptionsLegal,
                        exCommonConstants.virtualUrl.insuranceOptionsLegal
                    );


                }

                /**
                 * Scope function to see Insurance Options Overlay
                 * @public
                 * @param {boolean} visible
                 */
                function openInsuranceOptions () {
                    var modalInstance = $modal.open({
                        templateUrl: exCommonConstants.insuranceOptionsModalPath,
                        windowClass: 'modal-fullscreen',
                        scope: $scope
                    });

                    // Promise resolves when the modal close/dismiss functionality is triggered.
                    if (modalInstance !== undefined && modalInstance.result !== undefined) {
                        modalInstance.result.then(function () {
                            // This block is never reached. Close is acting like a dismiss due to a Zippy code change.
                        }, function () {
                            //Fire page load event when accessory recommender page loads.
                            $scope.$emit(exCommonConstants.event.DS_REPORTING_PAGELOAD_EVENT,
                                exCommonConstants.friendlyPageName.accessoryRecommenderDetails,
                                exCommonConstants.virtualUrl.accessoryRecommenderDetails
                            );
                        });
                    }

                    // Fire link click event when user clicks on show more insurance options link for protection plans
                    $scope.$emit(exCommonConstants.event.DS_REPORTING_EVENT, {
                        eventAction: 'linkClick',
                        eventCode: 'Link_Click',
                        additionaldata: {
                            'linkName': exCommonConstants.linkName.showMoreInsurance,
                            'linkPosition': exCommonConstants.linkPosition,
                            'linkDestinationURL': exCommonConstants.virtualUrl.insuranceOptions
                        }
                    }, $scope);

                    // Fire page load event when accessory displayed on Insurance options page as a modal. Should only be fired if getting called to show modal.
                    $scope.$emit(exCommonConstants.event.DS_REPORTING_PAGELOAD_EVENT,
                        exCommonConstants.friendlyPageName.insuranceOptions,
                        exCommonConstants.virtualUrl.insuranceOptions
                    );

                }

                /**
                 * Scope function to close Insurance Options Overlay
                 * @public
                 * @param {string} cta
                 */
                function closeInsuranceOption (cta) {
                    if (cta === 'cancel') {
                        // Reset the selectedInsurance & protectionPlanDetails to
                        // default selected Insurance if cancel CTA is clicked
                        $scope.insurancePlans.selectedInsurance = $scope.insurancePlans.defaultSelectedInsurance;
                        $scope.protectionPlanDetails = $scope.insurancePlans.defaultSelectedInsurance;
                    }
                    exHelpUtils.closeActiveModal();
                    //Sending broadcast for Widget to notify cancel button has been clicked
                    $rootScope.$broadcast(exCommonConstants.event.protectionPlanCancel, null);
                }

                /**
                 * Scope function to set selected insurance from insurance options page
                 * Input param it requires is the protection plan object that contains all the details of the insurance selected
                 * @public
                 * @param {object} protectionPlanDetailSelected
                 */
                function setSelectedInsurance (protectionPlanDetailSelected) {
                    $scope.insurancePlans.selectedInsurance = protectionPlanDetailSelected;
                    $scope.protectionPlanDetails = protectionPlanDetailSelected;
                    $modal.open({
                        templateUrl: exCommonConstants.protectionPlanLegalModal,
                        windowClass: 'modal-fullscreen',
                        scope: $scope
                    });
                    getProtectionPlanLegal($scope.insurancePlans.selectedInsurance);
                    // Fire link click event when user clicks on show more insurance details legal link for protection plans
                    $scope.$emit(exCommonConstants.event.DS_REPORTING_EVENT, {
                        eventAction: 'linkClick',
                        eventCode: 'Link_Click',
                        additionaldata: {
                            'linkName': exCommonConstants.linkName.showMoreInsurance,
                            'linkPosition': exCommonConstants.linkPosition,
                            'linkDestinationURL': exCommonConstants.virtualUrl.insuranceOptionsLegal
                        }
                    }, $scope);

                    // Fire page load event when accessory displayed on Insurance details legal page as a modal. Should only be fired if getting called to show modal.
                    $scope.$emit(exCommonConstants.event.DS_REPORTING_PAGELOAD_EVENT,
                        exCommonConstants.friendlyPageName.insuranceOptionsLegal,
                        exCommonConstants.virtualUrl.insuranceOptionsLegal
                    );
                }

                /**
                 * Scope function to remove protection plan from cart if already added
                 */
                function protectionRemoveItemFromCart () {
                    $scope.isProtectionRemoveDisabled = true;
                    $scope.isProtectionATCDisabled = false;
                    var params = {removalCommerceIds: $scope.featureCommerceItemId};
                    exCartService.removeItemFromCart(params).then(function (result) {
                        if (result && result.response && result.response.status === 'success') {
                            // Updating the selected insurance option and detail to default.
                            $scope.protectionPlanDetails = $scope.defaultProtectionPlanDetails;
                            $scope.insurancePlans.defaultSelectedInsurance = $scope.defaultProtectionPlanDetails;
                            $scope.protectionPlanInCartItem = false;
                            $scope.selectedPlanInCartItem = undefined;
                            $scope.insurancePlans.selectedInsurance = $scope.protectionPlanDetails;
                            getCartData('reload');
                        }
                    });
                    // Reporting event that fires an add to cart event of -1 to notify a remove has been called.
                    $scope.$emit(exCommonConstants.event.DS_REPORTING_EVENT, {
                        eventAction: 'formSubmit',
                        eventCode: 'DS_Upgrade_Cart_Add_Submit',
                        additionaldata: reportingDataSrv.getRemovePayload()
                    }, $scope);
                }

                /**
                 * Get cart data and updated few scope objects based on response
                 */
                function getCartData (action) {
                    exCartService.getCart(action).then(function (data) {
                        var currentLosg;
                        data = data.result;
                        $scope.protectionPlanInCartItem = false;
                        if (data &&
                            data.methodReturnValue &&
                            data.methodReturnValue.lobTypes &&
                            data.methodReturnValue.lobTypes.WIRELESS &&
                            data.methodReturnValue.lobTypes.WIRELESS.currentLOSGId) {
                            //broadcasting the updated cart data.
                            $rootScope.$broadcast(exCommonConstants.event.cartDataUpdated, data);
                            currentLosg = data.methodReturnValue.lobTypes.WIRELESS.losgs[data.methodReturnValue.lobTypes.WIRELESS.currentLOSGId];
                            if (currentLosg && currentLosg.cartItems && currentLosg.cartItems.feature) {
                                // Iterating all the features and finding the insurance feature.
                                angular.forEach(currentLosg.cartItems.feature, function (feature, featureKey) {
                                    if (feature.insuranceFeature === true
                                        && $scope.insurancePlans.selectedInsurance !== undefined
                                        && featureKey === $scope.insurancePlans.selectedInsurance.skuId) {
                                        $scope.protectionPlanInCartItem = true;
                                        $scope.selectedPlanInCartItem = $scope.insurancePlans.selectedInsurance;
                                        $scope.featureCommerceItemId = feature.commerceItemId;
                                    } else if (feature.insuranceFeature === true) {
                                        $scope.protectionPlanInCartItem = true;
                                        $scope.selectedPlanInCartItem = feature;
                                        $scope.featureCommerceItemId = feature.commerceItemId;
                                    }
                                });
                            }
                        }
                    });
                }

                /**
                 * Scope function to get protection plan to legal if available
                 * Input param it requires is the protection plan object that contains the skuid needed to fetch the legal information
                 * @param {object} protectionFeature
                 */
                function getProtectionPlanLegal (protectionFeature) {
                    var cmsKeys = [];
                    var protectionLegalHeader = exCommonConstants.insuranceCategories[protectionFeature.skuId];
                    cmsKeys.push(exCommonConstants.legalContentKeyPrefix + protectionFeature.skuId);
                    cmsKeys.push(protectionLegalHeader);
                    exCqTranslatorKeyService.getCqTranslatorKeys(cmsKeys).then(function (result) {
                        if (result) {
                            $scope.insurancePlans.selectedInsurance.legalHeader = result[protectionLegalHeader];
                            $scope.insurancePlans.selectedInsurance.legalDescription = result[exCommonConstants.legalContentKeyPrefix + protectionFeature.skuId];
                        }
                    });
                }

                /**
                 * Starts up the controller
                 */
                function activate () {
                    // Get cached cart data from session storage to get insurance in cart
                    getCartData();

                    protectionPlanService.getInsuranceFeatures().then(function (result) {
                        var isProtectionDetailsSet = false,
                            skuIds = [];

                        insurancePlans.options = Object.keys(result.payload).map(function (key) {
                            skuIds.push(result.payload[key].skuId);
                            return result.payload[key];
                        });

                        contentService.getSharedContentForInsurance(skuIds).then(function (result) {
                            angular.forEach(insurancePlans.options, function (insuranceOption) {

                                insuranceOption.planDescriptonsToDisplay = result[exCommonConstants.insuranceOptionContentPath + insuranceOption.skuId];

                                if (insuranceOption.billCode === $scope.defaultInsuranceBillCode) {
                                    $scope.defaultProtectionPlanDetails = insuranceOption;
                                }

                                if (($scope.selectedPlanInCartItem !== undefined && insuranceOption.billCode === $scope.selectedPlanInCartItem.billCode)
                                    || ($scope.selectedPlanInCartItem === undefined && insuranceOption.billCode === $scope.defaultInsuranceBillCode)) {
                                    $scope.protectionPlanDetails = insuranceOption;
                                    $scope.insurancePlans.selectedInsurance = $scope.protectionPlanDetails;
                                    $scope.insurancePlans.defaultSelectedInsurance = $scope.protectionPlanDetails;
                                    getProtectionPlanLegal($scope.insurancePlans.selectedInsurance);

                                    if ($scope.selectedPlanInCartItem !== undefined) {
                                        $scope.protectionPlanInCartItem = true;
                                    } else {
                                        $scope.protectionPlanInCartItem = false;
                                    }
                                    isProtectionDetailsSet = true;
                                }
                            });
                        });

                        if (isProtectionDetailsSet === false) {
                            // Default to the first insurance coming from API
                            $scope.protectionPlanDetails = insurancePlans.options[0];
                            $scope.insurancePlans.selectedInsurance = $scope.protectionPlanDetails;
                            $scope.insurancePlans.defaultSelectedInsurance = $scope.protectionPlanDetails;
                            getProtectionPlanLegal($scope.insurancePlans.selectedInsurance);

                            // Default to the first insurance coming from API
                            $scope.defaultProtectionPlanDetails = insurancePlans.options[0];

                            // update protectionPlanInCartItem flag to check if insurance is in cart
                            if ($scope.selectedPlanInCartItem) {
                                $scope.protectionPlanInCartItem = true;
                            } else {
                                $scope.protectionPlanInCartItem = false;
                            }
                        }

                    });
                }

                activate();
            }]);
})();
