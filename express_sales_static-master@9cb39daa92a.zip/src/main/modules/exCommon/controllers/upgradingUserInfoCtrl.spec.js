(function () {
    'use strict';

    define(['upgradingUserInfoCtrl'], function () {
        describe('src/main/modules/exCommon/controllers/upgradingUserInfoCtrl.spec.js', function () {
            describe('upgradingUserInfoCtrl of exCommon', function () {
                var $controller, $scope, $rootScope, upgradingUserInfoSrv;

                beforeEach(function () {
                    module('exCommon', function ($provide) {
                        upgradingUserInfoSrv = jasmine.createSpyObj('upgradingUserInfoSrv', ['getUpgradingDeviceDetailsData', 'getDeviceType']);
                        $provide.value('upgradingUserInfoSrv', upgradingUserInfoSrv);
                    });
                    inject(function ($injector) {
                        $controller = $injector.get('$controller');
                        $rootScope = $injector.get('$rootScope');
                    });
                });

                describe('device type is pda or handset', function () {
                    beforeEach(function () {
                        $scope = $rootScope.$new();

                        upgradingUserInfoSrv.getUpgradingDeviceDetailsData.and.returnValue({
                            'then': function (callBackFN) {
                                callBackFN(Endpoint_deviceRecommenderApi.getUpgradingDetails_Phone.result);
                            }
                        });
                        upgradingUserInfoSrv.getDeviceType.and.returnValue('phone');

                        $controller('upgradingUserInfoCtrl', {
                            $scope: $scope,
                            upgradingUserInfoSrv: upgradingUserInfoSrv
                        });
                    });
                    it('should set the upgrading device type if device type is pda or handset', function () {
                        expect(upgradingUserInfoSrv.getDeviceType).toHaveBeenCalled();
                        expect($scope.upgradingDeviceType).toEqual('phone');
                        expect($scope.upgradingDevice.subscriberName).toEqual('BEDROCK');
                        expect($scope.upgradingDevice.deviceMake).toEqual('APPLE');
                        expect($scope.upgradingDevice.deviceModel).toEqual('iPhone 6');
                    });
                });

                describe('device type is netbook', function () {
                    beforeEach(function () {
                        $scope = $rootScope.$new();

                        upgradingUserInfoSrv.getUpgradingDeviceDetailsData.and.returnValue({
                            'then': function (callBackFN) {
                                callBackFN(Endpoint_deviceRecommenderApi.getUpgradingDetails_Tablet.result);
                            }
                        });
                        upgradingUserInfoSrv.getDeviceType.and.returnValue('tablet');

                        $controller('upgradingUserInfoCtrl', {
                            $scope: $scope,
                            upgradingUserInfoSrv: upgradingUserInfoSrv
                        });
                    });
                    it('should set the upgrading device type if device type is netbook', function () {
                        expect(upgradingUserInfoSrv.getDeviceType).toHaveBeenCalled();
                        expect($scope.upgradingDeviceType).toEqual('tablet');
                        expect($scope.upgradingDevice.subscriberName).toEqual('BEDROCK');
                        expect($scope.upgradingDevice.deviceMake).toEqual('SAMSUNG');
                        expect($scope.upgradingDevice.deviceModel).toEqual('SM-T537A');
                    });
                });

                describe('device type is network', function () {
                    beforeEach(function () {
                        $scope = $rootScope.$new();

                        upgradingUserInfoSrv.getUpgradingDeviceDetailsData.and.returnValue({
                            'then': function (callBackFN) {
                                callBackFN(Endpoint_deviceRecommenderApi.getUpgradingDetails_Device.result);
                            }
                        });
                        upgradingUserInfoSrv.getDeviceType.and.returnValue('device');

                        $controller('upgradingUserInfoCtrl', {
                            $scope: $scope,
                            upgradingUserInfoSrv: upgradingUserInfoSrv
                        });
                    });
                    it('should set the upgrading device type if device type is network', function () {
                        expect(upgradingUserInfoSrv.getDeviceType).toHaveBeenCalled();
                        expect($scope.upgradingDeviceType).toEqual('device');
                        expect($scope.upgradingDevice.subscriberName).toEqual('BEDROCK');
                        expect($scope.upgradingDevice.deviceMake).toEqual('SAMSUNG');
                        expect($scope.upgradingDevice.deviceModel).toEqual('Gear S2');
                    });
                });
            });
        });
    });
})();