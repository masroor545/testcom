(function () {
    'use strict';

    define(['deviceConfigCtrl'], function () {
        describe('src/main/modules/exCommon/controllers/deviceConfigCtrl.spec.js', function () {
            describe('deviceConfigCtrl controller of exCommon', function () {
                var controller, scope, $modal, $rootScope, $q, $anchorScroll, $window, exCommonConstants, reportingDataSrv,
                    upgradingUserInfoSrv, deviceConfigSrv, upsellOfferSrv, exCqTranslatorKeyService, contentService,
                    imagePathService, $modalStack, exHelpUtils, profileInfoService, sessionStore;


                // Endpoint abbreviation. Does not appear in tests
                var deviceDetails = Endpoint_deviceDetailsApi.get_device_details;
                var noSizeVariants = Endpoint_deviceDetailsApi.get_device_details_no_size_variants;
                var colorAndSizeVariants = Endpoint_deviceDetailsApi.get_device_details_size_and_color_variants;
                var noVariants = Endpoint_deviceDetailsApi.get_device_details_no_variants;
                var defaultRegularContract = Endpoint_deviceDetailsApi.get_device_details_regular_contract;
                var iruPriceList = Endpoint_deviceDetailsApi.get_device_details_iru_priceList;
                var upsellOfferDetails = Endpoint_deviceDetailsApi.get_filtered_upsell_device_details;
                var upsellCartDetails = Endpoint_deviceDetailsApi.get_upsell_cart_details;
                var deliveryPromise = Endpoint_deviceDetailsApi.get_device_delivery_promises;
                var enjoyDeliveryPromise = Endpoint_deviceDetailsApi.get_device_enjoy_delivery_promises;
                var bopisDeliveryPromise = Endpoint_deviceDetailsApi.get_device_bopis_delivery_promises;
                var addToCartDetails = Endpoint_addToCart.upsell_add_to_cart;
                var addToCartDetailsFail = Endpoint_addToCart.add_to_cart_fail;
                var offerContentDetails = Endpoint_upsellOfferContentNode.get_legal_content_node;
                var hylaPromoDetails = Endpoint_hylaPromotion.hyla_promotion_legal_details;
                var iruPriceListSku = 'sku8040303';
                var colorAndCapacitySku = 'sku8040300';
                var noSizeVariantsSku = 'sku7840239';
                var colorAndSizeVariantsSku = 'sku7940325';
                var noVariantsSku = 'sku7900638';
                var defaultRegularContractSku = 'sku1234567';
                var upsellOfferSku = 'sku8040300';
                var upsellCartSku = 'sku8520225';

                sessionStore = {
                    'myFavLocalData': JSON.stringify({
                        'favStore': {
                            'locationId': '2183',
                            'storeAddress': {
                                'zipCode': '94105'
                            }
                        }
                    })
                };
                deviceConfigSrv = jasmine.createSpyObj('deviceConfigSrv', ['getDeviceDetails', 'displayDeviceConfig', 'getColorTheme', 'getDeliveryPromiseMessage', 'hylaPromotionDetails', 'getEnjoyDeliveryPromiseMessage', 'getBOPISDeliveryPromiseMessage']);

                deviceConfigSrv.getDeliveryPromiseMessage.and.callFake(function () {
                    var deferred = $q.defer();
                    deferred.resolve({
                        data: {
                            payload: deliveryPromise.result.payload
                        }
                    });
                    return deferred.promise;
                });

                deviceConfigSrv.getEnjoyDeliveryPromiseMessage.and.callFake(function () {
                    var deferred = $q.defer();
                    deferred.resolve({
                        data: enjoyDeliveryPromise.result
                    });
                    return deferred.promise;
                });

                deviceConfigSrv.getBOPISDeliveryPromiseMessage.and.callFake(function () {
                    var deferred = $q.defer();
                    deferred.resolve({
                        data: bopisDeliveryPromise.result
                    });
                    return deferred.promise;
                });

                deviceConfigSrv.getDeviceDetails.and.callFake(function (skuId) {
                    var deferred = $q.defer();
                    switch (skuId) {
                    case colorAndCapacitySku:
                        deferred.resolve({
                            data: {
                                result: deviceDetails.result
                            }
                        });
                        break;
                    case noSizeVariantsSku:
                        deferred.resolve({
                            data: {
                                result: noSizeVariants.result
                            }
                        });
                        break;
                    case colorAndSizeVariantsSku:
                        deferred.resolve({
                            data: {
                                result: colorAndSizeVariants.result
                            }
                        });
                        break;
                    case noVariantsSku:
                        deferred.resolve({
                            data: {
                                result: noVariants.result
                            }
                        });
                        break;
                    case defaultRegularContractSku:
                        deferred.resolve({
                            data: {
                                result: defaultRegularContract.result
                            }
                        });
                        break;
                    case iruPriceListSku:
                        deferred.resolve({
                            data: {
                                result: iruPriceList.result
                            }
                        });
                        break;
                    case upsellOfferSku:
                        deferred.resolve({
                            data: {
                                result: upsellOfferDetails.result
                            }
                        });
                        break;
                    case upsellCartSku:
                        deferred.resolve({
                            data: {
                                result: upsellCartDetails.result
                            }
                        });
                        break;
                    }

                    return deferred.promise;
                });

                upgradingUserInfoSrv = jasmine.createSpyObj('upgradingUserInfoSrv', ['getDeviceType']);
                upgradingUserInfoSrv.getDeviceType.and.returnValue('phone');

                profileInfoService = jasmine.createSpyObj('profileInfoService', ['getProfileInfo']);

                upsellOfferSrv = jasmine.createSpyObj('upsellOfferSrv',
                    [
                        'getUpsellOfferDetails',
                        'getUpsellOfferContentDetails',
                        'skipToCheckout',
                        'setRequiredOfferId',
                        'getRequiredOfferId',
                        'getOfferCount',
                        'getUpsellOfferLegalContentInfo'
                    ]);
                upsellOfferSrv.skipToCheckout.and.returnValue({
                    'then': function (callback) {
                        callback(Endpoint_upsellOfferSkipToCheckoutApi.skip_to_checkout.result);
                    }
                });
                upsellOfferSrv.getUpsellOfferContentDetails.and.returnValue({
                    'then': function (callback) {
                        callback(offerContentDetails.result);
                    }
                });
                upsellOfferSrv.getRequiredOfferId.and.returnValue({
                    'offerId': '200004'
                });
                upsellOfferSrv.getUpsellOfferLegalContentInfo.and.returnValue({
                    'then': function (callback) {
                        callback(offerContentDetails.result);
                    }
                });
                deviceConfigSrv.hylaPromotionDetails.and.returnValue({
                    'then': function (callback) {
                        callback(hylaPromoDetails.result);
                    }
                });

                contentService = jasmine.createSpyObj('contentService', ['getProductLegalPaths', 'getProductLegalContent']);
                contentService.getProductLegalPaths.and.returnValue({
                    'then': function (callBackFN) {
                        callBackFN(Endpoint_deviceLegalContentNode.get_content_node.result);
                    }
                });

                contentService.getProductLegalContent.and.returnValue({
                    'then': function (callBackFN) {
                        callBackFN(Endpoint_deviceLegalContentNode.get_shared_content.result);
                    }
                });

                profileInfoService.getProfileInfo.and.returnValue({
                        'then': function (callBackFN) {
                            callBackFN(Endpoint_profileInfoApi.get_profile_info_auth.result);
                        }
                    });

                deviceConfigSrv.displayDeviceConfig.and.returnValue(true);
                deviceConfigSrv.getColorTheme.and.returnValue(true);

                var exUpProfile = '{"ProfileInfo": {"exUpFlow": true}}';
                $window = {
                    sessionStorage: {
                        getItem: function (key) {
                            if (key === exCommonConstants.profileStorageKey) {
                                return exUpProfile;
                            } else {
                                return sessionStore[key];
                            }
                        },
                        setItem: function (key, value) {
                            return sessionStore[key] = value || '';
                        },
                        removeItem: function () { return true; }
                    },
                    localStorage: {
                        getItem: function () { return false; },
                        setItem: function () { return true; }
                    },
                    document: {
                        documentElement: {
                            clientWidth: 0
                        }
                    }
                };

                $anchorScroll = jasmine.createSpy('$anchorScroll');
                $modal = jasmine.createSpyObj('$modal', ['open']);
                $modal.open.and.returnValue(true);

                var exCartService = jasmine.createSpyObj('exCartService', ['addItemToCart']);
                exCartService.addItemToCart.and.returnValue({
                    'then': function (callback) {
                        callback(addToCartDetails.result);
                    }
                });

                reportingDataSrv = jasmine.createSpyObj('reportingDataSrv',
                    ['getAddToCartDevicePayload', 'getDeviceRecommenderDevicePayload', 'updateEventPayloadFailure']);

                reportingDataSrv.getAddToCartDevicePayload.and.returnValue({
                    items: [{'itemSku': colorAndCapacitySku}],
                    contractType: 'lease'
                });

                reportingDataSrv.updateEventPayloadFailure.and.returnValue({
                    errorType: 'Failure_Data',
                    successFlag: '0'
                });

                imagePathService = jasmine.createSpyObj('imagePathService', ['getXpressImagePath']);
                imagePathService.getXpressImagePath.and.returnValue({
                    'then': function (callBackFN) {
                        callBackFN(true);
                    }
                });

                exCqTranslatorKeyService = jasmine.createSpyObj('exCqTranslatorKeyService', ['getCqTranslatorKeys']);
                exCqTranslatorKeyService.getCqTranslatorKeys.and.returnValue({
                    'then': function (callBackFN) {
                        callBackFN(Endpoint_cqTranslatorKeys.getLabelsForDeviceConfig.result);
                    }
                });

                $modalStack = jasmine.createSpyObj('$modalStack', ['getTop', 'dismiss']);
                $modalStack.getTop.and.returnValue(true);

                beforeEach(function () {
                    module('exCommon', {
                        exCommonConstants: exCommonConstants,
                        $modalStack: $modalStack,
                        deviceConfigSrv: deviceConfigSrv,
                        exCartService: exCartService,
                        upgradingUserInfoSrv: upgradingUserInfoSrv,
                        $window: $window,
                        $anchorScroll: $anchorScroll,
                        $modal: $modal,
                        upsellOfferSrv: upsellOfferSrv,
                        exCqTranslatorKeyService: exCqTranslatorKeyService,
                        contentService: contentService
                    });

                    inject(function ($injector) {
                        controller = $injector.get('$controller');
                        exCommonConstants = $injector.get('exCommonConstants');
                        exHelpUtils = $injector.get('exHelpUtils');
                        $rootScope = $injector.get('$rootScope');
                        $q = $injector.get('$q');
                        scope = $rootScope.$new();
                    });

                    spyOn(exHelpUtils, 'closeActiveModal');
                    spyOn(exHelpUtils, 'scrollToAccordion');
                    spyOn($rootScope, '$broadcast').and.callThrough();
                    controller('deviceConfigCtrl', {
                        $scope: scope,
                        imagePathService: imagePathService,
                        reportingDataSrv: reportingDataSrv,
                        profileInfoService: profileInfoService
                    });

                });

                afterEach(function () {
                    // cleaning up the spies
                    $modal.open.calls.reset();
                    $rootScope.$broadcast.calls.reset();
                    deviceConfigSrv.getDeviceDetails.calls.reset();
                    exCartService.addItemToCart.calls.reset();
                    exHelpUtils.closeActiveModal.calls.reset();
                    exHelpUtils.scrollToAccordion.calls.reset();
                    upsellOfferSrv.skipToCheckout.calls.reset();
                    upgradingUserInfoSrv.getDeviceType.calls.reset();
                    imagePathService.getXpressImagePath.calls.reset();
                });

                // General functionality and skus with color + capacity
                describe('general functionality', function () {
                    beforeEach(function () {
                        $rootScope.$broadcast(exCommonConstants.event.deviceSelected, colorAndCapacitySku);
                        $rootScope.$digest();
                    });

                    it('should get exUpFlow as true when user is a zippy upgrade user', function () {
                        profileInfoService.getProfileInfo('reload').then(function (profile) {
                            expect(profile.ProfileInfo.exUpFlow).toEqual(true);
                        });
                    });

                    it('should get exAlFlow as true when user is a zippy add a line user', function () {
                        // ProfileInfo service returning info of AAL user
                        profileInfoService.getProfileInfo.and.returnValue({
                            'then': function (callBackFN) {
                                callBackFN(Endpoint_profileInfoApi.get_profile_info_for_aal.result);
                            }
                        });
                        
                        profileInfoService.getProfileInfo('reload').then(function (profile) {
                            expect(profile.ProfileInfo.exAlFlow).toEqual(true);
                        });
                    });

                    it('should get details about the selected device', function () {
                        expect(scope.deviceConfig).toBeDefined();
                        expect(scope.deviceConfig).not.toEqual({});

                        // Product-level information
                        expect(scope.deviceConfig.manufacturer).toEqual('Apple');
                        expect(scope.deviceConfig.model).toEqual('iPhone 7');
                        expect(scope.deviceConfig.monthlyPrice).toEqual(true);

                        // Sku-level information
                        expect(scope.deviceConfig.selectedSku.rating).toEqual(4.3067.toFixed(2));
                        expect(scope.deviceConfig.selectedSku.color).toEqual('Black');
                        expect(scope.deviceConfig.selectedSku.hexValue).toEqual('#5C5A5A');
                        expect(scope.deviceConfig.selectedSku.colorTheme).toBeDefined();
                        expect(scope.deviceConfig.selectedSku.size).toEqual(32);
                        expect(scope.deviceConfig.selectedSku.capacity).toEqual('32GB');
                        expect(scope.deviceConfig.selectedSku.priceList).toBeDefined();
                        expect(scope.deviceConfig.selectedSku.priceList[0].monthlyLeasePrice).toEqual(21.67);
                        expect(scope.deviceConfig.selectedSku.priceList[0].monthlyRebate).toEqual(21.67);
                        expect(scope.deviceConfig.selectedSku.priceList[0].mlpAfterRebate).toEqual(0);
                        expect(scope.deviceConfig.selectedSku.priceList[1].offerDueToday).toEqual(99.99);
                        expect(scope.deviceConfig.selectedSku.priceList[1].dueTodayLease).toEqual(359.99);
                        expect(scope.deviceConfig.selectedSku.priceList[1].name).toEqual('24');
                        expect(scope.deviceConfig.selectedSku.selectedCommitmentTerm).toEqual(scope.deviceConfig.selectedSku.priceList[0]);
                        expect(scope.deviceConfig.selectedSku.wirelessHylaOfferInfo.defaultChecked).toEqual(true);
                        expect(scope.deviceConfig.selectedSku.wirelessHylaOfferInfo.acceptanceNeeded).toEqual(true);
                        expect(scope.deviceConfig.selectedSku.wirelessHylaOfferInfo.eligible).toEqual(true);
                        // Color variant
                        expect(scope.deviceConfig.selectedSku.colorVariant).toBeDefined();
                        expect(scope.deviceConfig.selectedSku.colorVariant.id).toEqual(scope.deviceConfig.selectedSku.color);
                        expect(scope.deviceConfig.selectedSku.colorVariant.colorCode).toEqual(scope.deviceConfig.selectedSku.hexValue);

                        // Capacity variant
                        expect(scope.deviceConfig.selectedSku.capacityVariant).toBeDefined();
                        expect(scope.deviceConfig.selectedSku.capacityVariant.id).toEqual(scope.deviceConfig.selectedSku.capacity);

                        expect(scope.deviceConfig.selectedSku.price).toEqual(21.67);
                        expect(scope.deviceConfig.selectedSku.marketingsequence).toEqual(1000);
                        expect(scope.deviceConfig.selectedSku.preOwned).toEqual(false);
                        expect(scope.deviceConfig.selectedSku.refurbished).toEqual(false);
                        expect(scope.deviceConfig.selectedSku.preOrderable).toEqual(false);
                        expect(scope.deviceConfig.selectedSku.effectiveOutOfStock).toEqual(false);

                        // Retrieves image url to call a common imagePathSerivce function
                        expect(imagePathService.getXpressImagePath).toHaveBeenCalled();
                        expect(typeof imagePathService.getXpressImagePath.calls.mostRecent().args[1]).toEqual('string');
                        expect(imagePathService.getXpressImagePath.calls.count()).toEqual(17);

                        //hyla promotion information
                        expect(scope.deviceConfig.hylaLabelMessage).toBeDefined();
                        expect(scope.deviceConfig.hylaLabelMessage.hylaTradeInOffer).toEqual('Trade in for $650 in credit');
                        expect(scope.deviceConfig.hylaLabelMessage.hylaLegalTerms).toEqual('Get up to $650 in bill credit');
                        expect(scope.deviceConfig.hylaLabelMessage.hylaSeeOfferDetails).toEqual('See offer details and terms');
                        expect(scope.deviceConfig.hylaLabelMessage.hylaCheckBoxLabel).toEqual('Yes, I like to trade in my old device');
                    });

                    it('should list its color siblings', function () {
                        expect(scope.deviceConfig.capacityVariants).toBeDefined();
                        expect(scope.deviceConfig.capacityVariants).not.toEqual([]);
                        expect(scope.deviceConfig.selectedSku).toBeDefined();
                        expect(scope.deviceConfig.selectedSku).not.toEqual({});
                        expect(scope.deviceConfig.capacityVariants).toContain(scope.deviceConfig.selectedSku);
                        scope.deviceConfig.capacityVariants.forEach(function (sku) {
                            expect(sku.color).toEqual(scope.deviceConfig.selectedSku.color);
                        });
                    });

                    it('should have called the CqTranslatorKeyService if setSelected Sku has been called', function () {
                        scope.setSelectedSku(scope.deviceConfig.selectedSku);
                        expect(exCqTranslatorKeyService.getCqTranslatorKeys).toHaveBeenCalled();
                    });

                    it('should list its capacity siblings', function () {
                        expect(scope.deviceConfig.colorVariants).toBeDefined();
                        expect(scope.deviceConfig.colorVariants).not.toEqual([]);
                        expect(scope.deviceConfig.selectedSku).toBeDefined();
                        expect(scope.deviceConfig.selectedSku).not.toEqual({});
                        expect(scope.deviceConfig.colorVariants).toContain(scope.deviceConfig.selectedSku);
                        scope.deviceConfig.colorVariants.forEach(function (sku) {
                            expect(sku.size).toEqual(scope.deviceConfig.selectedSku.size);
                        });
                    });

                    it('should list its size variants', function () {
                        $rootScope.$broadcast(exCommonConstants.event.deviceSelected, colorAndSizeVariantsSku);
                        $rootScope.$digest();

                        expect(scope.deviceConfig.sizeVariants).toBeDefined();
                        expect(scope.deviceConfig.sizeVariants).not.toEqual([]);
                        expect(scope.deviceConfig.selectedSku).toBeDefined();
                        expect(scope.deviceConfig.selectedSku).not.toEqual({});
                        expect(scope.deviceConfig.sizeVariants).toContain(scope.deviceConfig.selectedSku);
                        scope.deviceConfig.sizeVariants.forEach(function (sku) {
                            expect(sku.color).toEqual(scope.deviceConfig.selectedSku.color);
                        });
                    });

                    it('should update its size siblings when a new color is selected', function () {
                        var oldColorVariants = scope.deviceConfig.colorVariants;

                        var newSku = scope.deviceConfig.capacityVariants[1];
                        expect(newSku).not.toEqual(scope.deviceConfig.selectedSku);

                        var newColorVariants = scope.getColorVariants(newSku, scope.deviceConfig.skuSiblings);
                        expect(newColorVariants).not.toEqual(oldColorVariants);
                        expect(newColorVariants.length).toEqual(6);
                        expect(newColorVariants).toContain(newSku);
                    });

                    it('should update its color siblings when a new capacity is selected', function () {
                        var oldCapacityVariants = scope.deviceConfig.capacityVariants;

                        var newSku = scope.deviceConfig.colorVariants[1];
                        expect(newSku).not.toEqual(scope.deviceConfig.selectedSku);

                        var newCapacityVariants = scope.getCapacityVariants(newSku, scope.deviceConfig.skuSiblings);
                        expect(newCapacityVariants).not.toEqual(oldCapacityVariants);
                        expect(newCapacityVariants.length).toEqual(3);
                        expect(newCapacityVariants).toContain(newSku);
                    });

                    it('should update its color siblings when a new size is selected', function () {
                        var oldSizeVariants = scope.deviceConfig.sizeVariants;
                        var newSku = scope.deviceConfig.colorVariants[1];
                        expect(newSku).not.toEqual(scope.deviceConfig.selectedSku);

                        var newSizeVariants = scope.getSizeVariants(newSku, scope.deviceConfig.skuSiblings);
                        expect(newSizeVariants).not.toEqual(oldSizeVariants);
                        expect(newSizeVariants.length).toEqual(3);
                        expect(newSizeVariants).toContain(newSku);
                    });

                    it('should remove any preexisting sku information but keep user input information', function () {
                        var oldSelectedSku = scope.deviceConfig.selectedSku;
                        var oldFocusedSku = scope.deviceConfig.focusedSku;
                        var oldCapacityVariants = scope.deviceConfig.capacityVariants;
                        var oldColorVariants = scope.deviceConfig.colorVariants;
                        var oldSkuSiblings = scope.deviceConfig.skuSiblings;
                        var oldModel = scope.deviceConfig.model;
                        var oldManufacturer = scope.deviceConfig.manufacturer;
                        var oldShortDisplayName = scope.deviceConfig.shortDisplayName;

                        var oldDisplayDeviceDetails = 'clearly obviously fake data';
                        var oldDisplayPricingOptions = 'clearly obviously fake data';
                        var oldSelectedTerm = 'clearly obviously fake data';
                        var oldMonthlyPrice = 'clearly obviously fake data';

                        scope.deviceConfig.displayDeviceDetails = oldDisplayDeviceDetails;
                        scope.deviceConfig.displayPricingOptions = oldDisplayPricingOptions;
                        scope.deviceConfig.selectedTerm = oldSelectedTerm;
                        scope.deviceConfig.monthlyPrice = oldMonthlyPrice;

                        $rootScope.$broadcast(exCommonConstants.event.deviceSelected, noSizeVariantsSku);
                        $rootScope.$digest();

                        expect(scope.deviceConfig.selectedSku).not.toEqual(oldSelectedSku);
                        expect(scope.deviceConfig.focusedSku).not.toEqual(oldFocusedSku);
                        expect(scope.deviceConfig.capacityVariants).not.toEqual(oldCapacityVariants);
                        expect(scope.deviceConfig.colorVariants).not.toEqual(oldColorVariants);
                        expect(scope.deviceConfig.skuSiblings).not.toEqual(oldSkuSiblings);
                        expect(scope.deviceConfig.model).not.toEqual(oldModel);
                        expect(scope.deviceConfig.manufacturer).not.toEqual(oldManufacturer);
                        expect(scope.deviceConfig.shortDisplayName).not.toEqual(oldShortDisplayName);
                        expect(scope.deviceConfig.selectedTerm).not.toEqual(oldSelectedTerm);
                        expect(scope.deviceConfig.monthlyPrice).not.toEqual(oldMonthlyPrice);

                        expect(scope.deviceConfig.displayDeviceDetails).toEqual(oldDisplayDeviceDetails);
                        expect(scope.deviceConfig.displayPricingOptions).toEqual(oldDisplayPricingOptions);
                    });

                    it('should sort capacity siblings by marketing sequence', function () {
                        var sortedSiblings = scope.getColorVariants(scope.deviceConfig.selectedSku, scope.deviceConfig.skuSiblings);

                        // Iterates through all siblings and checks if the current
                        // marketing sequence is greater than the previous
                        sortedSiblings.reduce(function (marketingsequence, sku) {
                            if (sku.marketingsequence < marketingsequence) {
                                fail('sku siblings not sorted by marketing sequence');
                            }
                            return sku.marketingsequence;
                        }, 0);
                    });

                    it('should set a focused sku', function () {
                        expect(scope.deviceConfig.focusedSku.color).toEqual(scope.deviceConfig.selectedSku.color);
                        expect(scope.deviceConfig.focusedSku.capacity).toEqual(scope.deviceConfig.selectedSku.capacity);
                    });

                    it('should get the formatted name of the device type', function () {
                        expect(upgradingUserInfoSrv.getDeviceType).toHaveBeenCalledWith('pda');
                        expect(scope.deviceConfig.deviceType).toEqual('phone');
                    });

                    it('should listen to updated sku broadcast', function () {
                        expect(scope.deviceConfig.selectedSku.skuId).not.toEqual('sku7840239');
                        $rootScope.$broadcast(exCommonConstants.event.deviceSelected, noSizeVariantsSku);
                        $rootScope.$digest();
                        expect(scope.deviceConfig.selectedSku.skuId).toEqual('sku7840239');
                    });

                    it('should get the delivery promise message for the passed device skuIds for DF shipping method', function () {
                        var deviceSkuIdList = 'skuList=sku8040303,sku8040302,sku8040301,sku8040300,sku8250255';
                        deviceConfigSrv.getDeliveryPromiseMessage(deviceSkuIdList).then(function () {
                            expect(deviceConfig.deliveryPromiseMessage['sku8040300']).toBeDefined();
                            expect(deviceConfig.deliveryPromiseMessage['sku8250255']).toBeDefined();
                            expect(deviceConfig.deliveryPromiseMessage['sku8250255'].deliveryDateMessage).toEqual(
                                '!label.shipbetween.text! Jul 7, 2017 - Jul 11, 2017');
                            expect(deviceConfig.deliveryPromiseMessage['sku8040300'].deliveryDateMessage).toEqual(
                                '!label.shipbetween.text! Apr 12, 2017 - Apr 14, 2017');
                        });
                    });

                    it('should get the delivery promise message for the passed device skuId for enjoy shipping method', function () {
                        var deviceSkuId = 'sku8040303';
                        deviceConfigSrv.getEnjoyDeliveryPromiseMessage(deviceSkuId).then(function () {
                            expect(deviceConfig.enjoyDeliveryPromise.personalDeliveryShowLink).toEqual(true);
                        });
                    });

                    it('should get the delivery promise message for the passed device skuId for BOPIS shipping method', function () {
                        var deviceSkuId = 'sku8040303';
                        var storeId = 'D129';
                        var zipCode = '75115';
                        deviceConfigSrv.getBOPISDeliveryPromiseMessage(storeId, zipCode, deviceSkuId).then(function () {
                            expect(deviceConfig.bopisDeliveryPromiseMessage.isAvailable).toEqual(false);
                        });
                    });

                    it('should calculate today or tomorrow bases on BOPIS response', function () {
                        var baseTime = new Date(2018, 2, 2, 12);
                        jasmine.clock().mockDate(baseTime);
                        var  currentTimeInMinutes = baseTime;
                        var todayTomorrowIndicator = scope.getTodayTomorrowIndicator(bopisDeliveryPromise.result);
                        expect(todayTomorrowIndicator).toEqual('today');
                    });

                    it('should check the functionality of showHylaOffer', function () {
                        var getSelectedSku = scope.deviceConfig.selectedSku;
                        var hylaOfferVisible = scope.showHylaOffer(getSelectedSku);
                        expect(hylaOfferVisible).toEqual(true);
                    });

                    it('should check the functionality of closeHylaModal', function () {
                        scope.closeHylaModal();
                        expect(exHelpUtils.closeActiveModal).toHaveBeenCalled();
                    });

                    describe('add to cart', function () {
                        it('should add an item to cart from device recommender page', function () {
                            scope.type = 'heroDevice';
                            var params = {
                                actionType: 'addItemAndGoToNextStep',
                                hylaOptin: true
                            };
                            scope.addToCart();
                            expect(exCartService.addItemToCart).toHaveBeenCalled();
                            expect(exCartService.addItemToCart.calls.mostRecent().args.length).toEqual(2);
                            expect(typeof exCartService.addItemToCart.calls.mostRecent().args[0]).toEqual('object');
                            expect(typeof exCartService.addItemToCart.calls.mostRecent().args[1]).toEqual('object');

                            var cartItem = exCartService.addItemToCart.calls.mostRecent().args[0].items;
                            expect(typeof cartItem).toEqual('object');
                            expect(cartItem).toBeDefined();
                            expect(typeof cartItem.items[0].valueMap).toEqual('object');
                            expect(typeof cartItem.items[0].valueMap.contractType).toEqual('string');
                            expect(typeof cartItem.items[0].valueMap.contractLength).toEqual('string');
                            expect(cartItem.items[0].quantity).toEqual(1);
                            expect(cartItem.items[0].catalogRefId).toEqual(scope.deviceConfig.selectedSku.skuId);
                            expect(typeof cartItem.items[0].productId).toEqual('string');
                            expect(typeof params).toEqual('object');
                            expect(exCartService.addItemToCart.calls.mostRecent().args[1]).toEqual(params);
                        });

                        it('should disable add to cart button after a single click to prevent multiple submissions', function () {
                            expect(scope.isAddToCartDisabled()).toEqual(false);
                            scope.addToCart();
                            expect(scope.isAddToCartDisabled()).toEqual(true);
                        });

                        it('should add an item to cart from upsellOffer page', function () {
                            scope.type = 'upsellOffer';
                            scope.$parent.offerId = '40000354';
                            controller('deviceConfigCtrl', {
                                $scope: scope,
                                imagePathService: imagePathService,
                                reportingDataSrv: reportingDataSrv
                            });
                            $rootScope.$broadcast(exCommonConstants.event.deviceSelected, colorAndCapacitySku);
                            $rootScope.$digest();
                            var params = {
                                actionType: 'addItemAndGoToNextStep',
                                redirectionUrl: scope.deviceConfig.redirectUrl,
                                losgBuyFlowType: 'AL',
                                addNewLine: 'true',
                                wirelessBuyFlowType: 'MIXEDCART',
                                quantity: 1,
                                offerId: scope.$parent.offerId
                            };
                            scope.addToCart();
                            expect(exCartService.addItemToCart).toHaveBeenCalled();
                            expect(exCartService.addItemToCart.calls.mostRecent().args.length).toEqual(2);
                            expect(typeof exCartService.addItemToCart.calls.mostRecent().args[0]).toEqual('object');
                            expect(typeof exCartService.addItemToCart.calls.mostRecent().args[1]).toEqual('object');

                            var cartItem = exCartService.addItemToCart.calls.mostRecent().args[0].items;
                            expect(typeof cartItem).toEqual('object');
                            expect(cartItem).toBeDefined();
                            expect(typeof cartItem.items[0].valueMap).toEqual('object');
                            expect(typeof cartItem.items[0].valueMap.contractType).toEqual('string');
                            expect(typeof cartItem.items[0].valueMap.contractLength).toEqual('string');
                            expect(cartItem.items[0].quantity).toEqual(1);
                            expect(cartItem.items[0].catalogRefId).toEqual(scope.deviceConfig.selectedSku.skuId);
                            expect(typeof cartItem.items[0].productId).toEqual('string');
                            expect(typeof params).toEqual('object');
                            expect(exCartService.addItemToCart.calls.mostRecent().args[1]).toEqual(params);
                        });
                    });

                    describe('from widget', function () {
                        beforeEach(function () {
                            scope.initargs = {
                                type: 'cart'
                            };
                            //getting cart data for single losg in cart for one device added
                            var selectedDevice = Endpoint_cartLookupApi.get_checkout_data_for_singleLOSG;
                            $rootScope.$broadcast.calls.reset();
                            $rootScope.$broadcast(exCommonConstants.event.deviceSelected, selectedDevice);
                        });
                        var params = {
                            actionType: 'addItemAndGoToNextStep',
                            skipRedirect: true,
                            losgBuyFlowType: 'UP',
                            removalCommerceIds: '84208002789'
                        };

                        it('should not redirect if the config is a widget', function () {
                            scope.addToCart();
                            expect(exCartService.addItemToCart.calls.mostRecent().args[1]).toEqual(params);
                        });

                        it('should set renderBV to false after addtocart from widget', function () {
                            scope.addToCart();
                            expect(scope.deviceConfig.renderBV).toEqual(false);
                            expect(exCartService.addItemToCart.calls.mostRecent().args[1]).toEqual(params);
                        });

                        it('should broadcast if the widget type is cart', function () {
                            scope.addToCart();
                            expect($rootScope.$broadcast).toHaveBeenCalledWith(exCommonConstants.event.deviceConfigWidgetAdded, true);
                        });

                        describe('upsell', function () {
                            beforeEach(function () {
                                scope.initargs = {
                                    type: 'cart'
                                };
                                var selectedDevice = Endpoint_cartLookupApi.get_checkout_data_for_mixedCartLOSG;
                                $rootScope.$broadcast.calls.reset();
                                $rootScope.$broadcast(exCommonConstants.event.deviceSelected, selectedDevice);
                                $rootScope.$digest();
                            });

                            it('should have an offerId', function () {
                                expect(scope.offerId).toBeDefined();
                            });

                            it('should close the modal when there are multiple offers', function () {
                                upsellOfferSrv.getOfferCount.and.returnValue(2);
                                spyOn(scope, 'close').and.callThrough();
                                scope.closeUpsellModal();
                                expect(scope.close).toHaveBeenCalled();
                            });

                            it('should skip to checkout when there is a single offer', function () {
                                upsellOfferSrv.getOfferCount.and.returnValue(1);
                                spyOn(scope, 'onSkipToCheckout').and.callThrough();
                                scope.closeUpsellModal();
                                expect(scope.onSkipToCheckout).toHaveBeenCalled();
                            });
                        });
                    });

                    describe('checking change pricing term for widget', function () {
                        it('should fire add to cart and not broadcast deviceAdded if the widget type is the widget type is changePricingTermInCart and add to cart status is error', function () {
                            // Getting cart data for single losg in cart for one device added
                            var selectedDevice = Endpoint_cartLookupApi.get_checkout_data_for_singleLOSG;
                            scope.initargs = {
                                type: 'changePricingTermInCart'
                            };
                            exCartService.addItemToCart.and.returnValue({
                                'then': function (callback) {
                                    callback(addToCartDetailsFail.result);
                                }
                            });
                            $rootScope.$broadcast.calls.reset();
                            $rootScope.$broadcast(exCommonConstants.event.deviceSelected, selectedDevice);
                            // setCommitmentTerm will be calling add to cart
                            scope.setCommitmentTerm(scope.deviceConfig.selectedSku.priceList[0]);
                            expect(exCartService.addItemToCart).toHaveBeenCalled();
                            expect($rootScope.$broadcast).not.toHaveBeenCalledWith(exCommonConstants.event.deviceAdded, true);
                        });

                        it('should fire add to cart and broadcast deviceAdded if the widget type is changePricingTermInCart and add to cart status is success', function () {
                            // Getting cart data for single losg in cart for one device added
                            var selectedDevice = Endpoint_cartLookupApi.get_checkout_data_for_singleLOSG;
                            scope.initargs = {
                                type: 'changePricingTermInCart'
                            };
                            exCartService.addItemToCart.and.returnValue({
                                'then': function (callback) {
                                    callback(addToCartDetails.result);
                                }
                            });
                            $rootScope.$broadcast.calls.reset();
                            $rootScope.$broadcast(exCommonConstants.event.deviceSelected, selectedDevice);
                            // setCommitmentTerm will be calling add to cart
                            scope.setCommitmentTerm(scope.deviceConfig.selectedSku.priceList[0]);
                            expect(exCartService.addItemToCart).toHaveBeenCalled();
                            expect($rootScope.$broadcast).toHaveBeenCalledWith(exCommonConstants.event.deviceAdded, true);
                        });
                    });

                    describe('checking change upsellOffer config for widget', function () {
                        it('should add an item to cart from upsellOffer config if the config is a widget and not redirect', function () {
                            //getting cart data for mixed cart losg in cart
                            var selectedDevice = Endpoint_cartLookupApi.get_checkout_data_for_mixedCartLOSG,
                                mixedCartParams = {
                                    actionType: 'addItemAndGoToNextStep',
                                    redirectionUrl: scope.deviceConfig.redirectUrl,
                                    losgBuyFlowType: 'AL',
                                    addNewLine: 'false',
                                    wirelessBuyFlowType: 'MIXEDCART',
                                    quantity: 1,
                                    skipRedirect: true,
                                    removalCommerceIds: '84208002789',
                                    offerId: undefined
                                };
                            scope.initargs = {
                                type: 'cart'
                            };
                            $rootScope.$broadcast.calls.reset();
                            $rootScope.$broadcast(exCommonConstants.event.deviceSelected, selectedDevice);
                            scope.addToCart();
                            expect(exCartService.addItemToCart.calls.mostRecent().args[1]).toEqual(mixedCartParams);
                        });
                    });

                    it('should display the default price and contract type when a new sku is selected', function () {
                        expect(scope.deviceConfig.selectedSku.price).toEqual(21.67);
                        expect(scope.deviceConfig.monthlyPrice).toEqual(true);

                        $rootScope.$broadcast(exCommonConstants.event.deviceSelected, defaultRegularContractSku);
                        $rootScope.$digest();

                        expect(scope.deviceConfig.selectedSku.price).toEqual(649.99);
                        expect(scope.deviceConfig.monthlyPrice).toEqual(false);
                    });

                    it('should scroll to the device details on landscape viewports', function () {
                        // Sets the client width below the breakpoint
                        $window.document.documentElement.clientWidth = 0;
                        scope.showDeviceDetails();
                        expect(exHelpUtils.scrollToAccordion).not.toHaveBeenCalled();

                        // Sets the client width above the breakpoint
                        $window.document.documentElement.clientWidth = 10000;
                        scope.showDeviceDetails();
                        expect(exHelpUtils.scrollToAccordion).toHaveBeenCalled();
                    });

                    it('should scroll to the legal accordion and open it', function () {
                        scope.showLegalAccordion();
                        expect(scope.deviceConfig.legalAccordionOpen).toEqual(true);
                        expect(scope.deviceConfig.openOverviewTab).toEqual(false);
                    });

                    it('should make a post call to request for redirect to onePageCheckout', function () {
                        scope.onSkipToCheckout();
                        expect(upsellOfferSrv.skipToCheckout).toHaveBeenCalled();
                    });

                    it('should get the boolean value return as true if upsellOffer already in cart', function () {
                        // assuming the type is upsellOffer
                        scope.type = 'upsellOffer';
                        expect(scope.isUpsellOfferInCart()).toEqual(true);
                    });

                    it('should open the hyla promo details modal', function () {
                        scope.openHylaPromoDetailsModal();
                        expect($modal.open).toHaveBeenCalled();
                    });

                    it('should return hyla promo details', function () {
                        scope.openHylaPromoDetailsModal();
                        expect(scope.deviceConfig.hylaPromoDetails).toBeDefined();
                        expect(scope.deviceConfig.hylaHeadLine).toBeDefined();
                        expect(scope.deviceConfig.hylaInBodyContent).toBeDefined();
                        expect(scope.deviceConfig.hylaLongLegalContent).toBeDefined();
                        expect(scope.deviceConfig.hylaPromoDetails[0].headLine).toEqual(hylaPromoDetails.result['offercontent/hylaOffer']['pageTitle'][0]);
                        expect(scope.deviceConfig.hylaPromoDetails[0].longLegalContent).toEqual(hylaPromoDetails.result['offercontent/hylaOffer']['subtitle'][0]);
                        expect(scope.deviceConfig.hylaPromoDetails[0].inBodyContent).toEqual(hylaPromoDetails.result['offercontent/hylaOffer']['jcr:description'][0]);
                        expect(scope.deviceConfig.showHylaOfferLegalDetails).toEqual(true);
                    });

                    // Pricing functionality
                    describe('Pricing Functionality', function () {
                        beforeEach(function () {
                            $rootScope.$broadcast(exCommonConstants.event.deviceSelected, iruPriceListSku);
                            $rootScope.$digest();
                        });

                        it('check when priceList[i].leaseTotalMonths === 30', function () {
                            expect(scope.deviceConfig).toBeDefined();
                            expect(scope.deviceConfig).not.toEqual({});
                            expect(scope.deviceConfig.selectedSku.priceList).toBeDefined();
                            expect(scope.deviceConfig.selectedSku.priceList[0].shortLegalKey).toEqual('priceblock.starting.lease.lbl');
                            expect(scope.deviceConfig.selectedSku.priceList[0].shortLegalContent).toEqual('Requires 0% APR 30-month installment agreement, well-qualified credit and service. Other options available.');
                            expect(scope.deviceConfig.selectedSku.priceList[0].commitTermName).toEqual(scope.deviceConfig.commitmentTermLabelToDisplay.commitmentTermNext);
                            expect(scope.deviceConfig.selectedSku.priceList[0].commitTermLegal).toEqual(exCommonConstants.commitmentTermLegalLabels.commitmentTermNext);
                            expect(scope.deviceConfig.selectedSku.priceList[0].disclaimer).toEqual('With $0 down, you\'ll pay 30 monthly installments. Trade in after Apr\'19.');
                            expect(scope.deviceConfig.selectedSku.priceList[0].selectedskuPriceToDisplay).toEqual(21.67);
                            expect(scope.deviceConfig.selectedSku.priceList[0].type).toEqual('lease');
                        });
                        it('check when priceList[i].leaseTotalMonths === 24', function () {
                            expect(scope.deviceConfig).toBeDefined();
                            expect(scope.deviceConfig).not.toEqual({});
                            expect(scope.deviceConfig.selectedSku.priceList).toBeDefined();
                            expect(scope.deviceConfig.selectedSku.priceList[1].shortLegalKey).toEqual('priceblock.starting.lease.lbl');
                            expect(scope.deviceConfig.selectedSku.priceList[1].shortLegalContent).toEqual('Requires 0% APR 24-month installment agreement, well-qualified credit and service. Other options available.');
                            expect(scope.deviceConfig.selectedSku.priceList[1].commitTermName).toEqual(scope.deviceConfig.commitmentTermLabelToDisplay.commitmentTermEveryYear);
                            expect(scope.deviceConfig.selectedSku.priceList[1].commitTermLegal).toEqual(exCommonConstants.commitmentTermLegalLabels.commitmentTermEveryYear);
                            expect(scope.deviceConfig.selectedSku.priceList[1].disclaimer).toEqual('With $0 down, you\'ll pay 24 monthly installments. Trade in after Apr\'18.');
                            expect(scope.deviceConfig.selectedSku.priceList[1].selectedskuPriceToDisplay).toEqual(27.09);
                            expect(scope.deviceConfig.selectedSku.priceList[1].type).toEqual('lease');
                        });
                        it('check when priceList[i].name === 24', function () {
                            expect(scope.deviceConfig).toBeDefined();
                            expect(scope.deviceConfig).not.toEqual({});
                            expect(scope.deviceConfig.selectedSku.priceList).toBeDefined();
                            expect(scope.deviceConfig.selectedSku.priceList[2].shortLegalKey).toEqual('lbl.two.year.qual.plan');
                            expect(scope.deviceConfig.selectedSku.priceList[2].shortLegalContent).toEqual('with 2-year contract w/qual. plans');
                            expect(scope.deviceConfig.selectedSku.priceList[2].commitTermName).toEqual(scope.deviceConfig.commitmentTermLabelToDisplay.commitmentTermTwoYear);
                            expect(scope.deviceConfig.selectedSku.priceList[2].commitTermLegal).toEqual(exCommonConstants.commitmentTermLegalLabels.commitmentTermTwoYear);
                            expect(scope.deviceConfig.selectedSku.priceList[2].disclaimer).toEqual('$549.99 due today with a 2-year service contract. Upgrade with no trade-in after 24 months.');
                            expect(scope.deviceConfig.selectedSku.priceList[2].selectedskuPriceToDisplay).toEqual(549.99);
                            expect(scope.deviceConfig.selectedSku.priceList[2].type).toEqual('regular');
                        });
                        it('check when priceList[i].name === 1', function () {
                            expect(scope.deviceConfig).toBeDefined();
                            expect(scope.deviceConfig).not.toEqual({});
                            expect(scope.deviceConfig.selectedSku.priceList).toBeDefined();
                            expect(scope.deviceConfig.selectedSku.priceList[3].shortLegalKey).toEqual('priceblock.starting.regular.lbl');
                            expect(scope.deviceConfig.selectedSku.priceList[3].shortLegalContent).toEqual('Retail price. Requires qualified service.');
                            expect(scope.deviceConfig.selectedSku.priceList[3].commitTermName).toEqual(scope.deviceConfig.commitmentTermLabelToDisplay.commitmentTermZero);
                            expect(scope.deviceConfig.selectedSku.priceList[3].commitTermLegal).toEqual(exCommonConstants.commitmentTermLegalLabels.commitmentTermZero);
                            expect(scope.deviceConfig.selectedSku.priceList[3].disclaimer).toEqual(exCommonConstants.commitmentTermLabels.commitmentDisclaimerTermZero);
                            expect(scope.deviceConfig.selectedSku.priceList[3].selectedskuPriceToDisplay).toEqual(649.99);
                            expect(scope.deviceConfig.selectedSku.priceList[3].type).toEqual('regular');
                        });

                        it('should update the price and monthly price value when a new commitment term is selected', function () {
                            var priceList = scope.deviceConfig.selectedSku.priceList;

                            // Lease commitment term
                            expect(scope.deviceConfig.selectedTerm).toBeDefined();
                            expect(scope.deviceConfig.selectedSku.price).toEqual(21.67);
                            expect(scope.deviceConfig.monthlyPrice).toEqual(true);

                            // Regular commitment term
                            var regularCommitmentTerm = priceList[3];
                            scope.setCommitmentTerm(regularCommitmentTerm);
                            expect(scope.deviceConfig.selectedSku.selectedCommitmentTerm).toEqual(priceList[3]);
                            expect(scope.deviceConfig.selectedTerm).toEqual(regularCommitmentTerm.name);
                            expect(scope.deviceConfig.monthlyPrice).toEqual(false);
                            expect(scope.deviceConfig.selectedSku.price).toEqual(regularCommitmentTerm.dueToday);

                            // Lease commitment term
                            var leaseCommitmentTerm = priceList[0];
                            scope.setCommitmentTerm(leaseCommitmentTerm);
                            expect(scope.deviceConfig.selectedSku.selectedCommitmentTerm).toEqual(priceList[0]);
                            expect(scope.deviceConfig.selectedTerm).toEqual(priceList[0].name);
                            expect(scope.deviceConfig.monthlyPrice).toEqual(true);
                            expect(scope.deviceConfig.selectedSku.price).toEqual(priceList[0].monthlyLeasePrice);
                        });

                        it('should get the sku\'s price based on the contract type', function () {
                            var priceList = scope.deviceConfig.selectedSku.priceList;


                            // Original sku lease commitment term
                            expect(scope.deviceConfig.selectedSku.selectedCommitmentTerm).toEqual(priceList[0]);
                            expect(scope.deviceConfig.selectedTerm).toEqual('NE30M80P');
                            expect(scope.deviceConfig.selectedSku.price).toEqual(21.67);
                            expect(scope.deviceConfig.monthlyPrice).toEqual(true);

                            // New sku lease commitment term
                            var newSku = scope.deviceConfig.capacityVariants[1];
                            var monthlyCommitmentTerm = newSku.selectedCommitmentTerm;

                            expect(scope.deviceConfig.selectedTerm).toEqual(monthlyCommitmentTerm.name);
                            expect(newSku.price).toEqual(monthlyCommitmentTerm.monthlyLeasePrice);

                            // Regular commitment term
                            var regularCommitmentTerm = priceList[3];
                            scope.setCommitmentTerm(regularCommitmentTerm);

                            expect(scope.deviceConfig.selectedTerm).toEqual(regularCommitmentTerm.name);
                            expect(scope.deviceConfig.monthlyPrice).toEqual(false);
                            expect(scope.deviceConfig.selectedSku.selectedCommitmentTerm).toEqual(regularCommitmentTerm);
                            expect(scope.deviceConfig.selectedSku.price).toEqual(regularCommitmentTerm.dueToday);
                        });

                        it('should open pricing options modal', function () {
                            var params = {
                                templateUrl: exCommonConstants.pricingOptionsModal,
                                windowClass: 'modal-fullscreen',
                                scope: scope
                            };
                            expect(scope.deviceConfig.displayPricingOptions).toEqual(false);
                            scope.changePricingOption();
                            expect($modal.open).toHaveBeenCalled();
                            expect($modal.open).toHaveBeenCalledWith(params);
                        });

                        it('should close pricing options modal', function () {
                            scope.initargs = undefined;
                            scope.closePricingOption();
                            expect(exHelpUtils.closeActiveModal).toHaveBeenCalled();
                        });

                        it('should show and hide long legal content on pricing option modal', function () {
                            expect(scope.deviceConfig.showLongLegal).toEqual(false);

                            scope.showLongLegalOnPricingOption(true);
                            expect(scope.deviceConfig.showLongLegal).toEqual(true);

                            scope.showLongLegalOnPricingOption(false);
                            expect(scope.deviceConfig.showLongLegal).toEqual(false);
                        });
                    });

                });

                describe('checking bv render flag', function () {
                    beforeEach(function () {
                        $rootScope.$broadcast(exCommonConstants.event.deviceConfigWidgetBVInitiated, null);
                        $rootScope.$digest();
                    });
                    it('should set bv render flag to true', function () {
                        expect(scope.deviceConfig.renderBV).toEqual(true);
                    });
                });

                describe('products with no size variants', function () {
                    beforeEach(function () {
                        $rootScope.$broadcast(exCommonConstants.event.deviceSelected, noSizeVariantsSku);
                        $rootScope.$digest();
                    });

                    it('should list its color siblings', function () {
                        expect(scope.deviceConfig.colorVariants).toBeDefined();
                        expect(scope.deviceConfig.colorVariants).not.toEqual([]);
                        expect(scope.deviceConfig.selectedSku).toBeDefined();
                        expect(scope.deviceConfig.selectedSku).not.toEqual({});
                        expect(scope.deviceConfig.colorVariants).toContain(scope.deviceConfig.selectedSku);
                        scope.deviceConfig.colorVariants.forEach(function (sku) {
                            expect(sku.size).toEqual(scope.deviceConfig.selectedSku.size);
                        });
                    });

                    it('should set a focused sku', function () {
                        expect(scope.deviceConfig.focusedSku.color).toEqual(scope.deviceConfig.selectedSku.color);
                        expect(scope.deviceConfig.focusedSku.capacity).toEqual(scope.deviceConfig.selectedSku.capacity);
                    });

                });

                describe('products with no variants', function () {
                    beforeEach(function () {
                        $rootScope.$broadcast(exCommonConstants.event.deviceSelected, noVariantsSku);
                        $rootScope.$digest();
                    });

                    it('should display the selected sku', function () {
                        expect(scope.deviceConfig.selectedSku).toBeDefined();
                        expect(scope.deviceConfig.selectedSku.skuId).toEqual('sku7900638');
                    });

                    it('should set a focused sku', function () {
                        expect(scope.deviceConfig.focusedSku.color).toEqual(scope.deviceConfig.selectedSku.color);
                        expect(scope.deviceConfig.focusedSku.capacity).toEqual(scope.deviceConfig.selectedSku.capacity);
                    });
                });

                describe('upsell device details', function () {
                    beforeEach(function () {
                        deviceConfigSrv.getDeviceDetails.calls.reset();
                        scope.type = 'upsellOffer';
                        scope.$parent.offerId = '40000354';
                        controller('deviceConfigCtrl', {
                            $scope: scope,
                            imagePathService: imagePathService,
                            reportingDataSrv: reportingDataSrv
                        });
                        $rootScope.$digest();
                    });

                    it('should pass the offerId to the service', function () {
                        var params = {
                            offerId: scope.$parent.offerId
                        };
                        // expect(deviceConfigSrv.getDeviceDetails).toHaveBeenCalledWith(params);
                        expect(deviceConfigSrv.getDeviceDetails.calls.mostRecent().args[1]).toEqual(jasmine.objectContaining(params));
                    });
                });

                describe('should check add to cart device reporting functionalities', function () {

                    beforeEach(function () {
                        spyOn(scope, '$emit').and.callThrough();
                        $rootScope.$broadcast(exCommonConstants.event.deviceSelected, colorAndCapacitySku);
                        $rootScope.$digest();
                        scope.$emit.calls.reset();
                    });

                    it('should check add to cart device reporting functionalities from device recommender page', function () {
                        var expectedReportingObjectSubmit = jasmine.objectContaining({
                                eventAction: 'formSubmit',
                                eventCode: 'DS_Upgrade_Cart_Add_Submit',
                                additionaldata: jasmine.objectContaining({
                                    items: [jasmine.objectContaining({itemSku: colorAndCapacitySku})],
                                    contractType: 'lease'
                                })
                            }),
                            expectedReportingObjectResponse = jasmine.objectContaining({
                                eventAction: 'formResponse',
                                eventCode: 'DS_Upgrade_Cart_Add_Submit',
                                additionaldata: jasmine.objectContaining({
                                    items: [jasmine.objectContaining({itemSku: colorAndCapacitySku})],
                                    contractType: 'lease'
                                })
                            });
                        scope.addToCart();
                        expect(scope.$emit).toHaveBeenCalledWith('DS_Reporting_Event', expectedReportingObjectSubmit, jasmine.any(Object));
                        expect(scope.$emit).toHaveBeenCalledWith('DS_Reporting_Event', expectedReportingObjectResponse, jasmine.any(Object));
                        scope.$apply();
                    });

                    it('should check add to cart device reporting functionalities for preorder from device recommender page', function () {
                        var expectedReportingObjectSubmit = jasmine.objectContaining({
                                eventAction: 'formSubmit',
                                eventCode: 'DS_Upgrade_Cart_Preorder_Submit',
                                additionaldata: jasmine.objectContaining({
                                    items: [jasmine.objectContaining({itemSku: colorAndCapacitySku})],
                                    contractType: 'lease'
                                })
                            }),
                            expectedReportingObjectResponse = jasmine.objectContaining({
                                eventAction: 'formResponse',
                                eventCode: 'DS_Upgrade_Cart_Preorder_Submit',
                                additionaldata: jasmine.objectContaining({
                                    items: [jasmine.objectContaining({itemSku: colorAndCapacitySku})],
                                    contractType: 'lease'
                                })
                            });
                        scope.deviceConfig.selectedSku.preOrderable = true;
                        scope.addToCart();
                        expect(scope.$emit).toHaveBeenCalledWith('DS_Reporting_Event', expectedReportingObjectSubmit, jasmine.any(Object));
                        expect(scope.$emit).toHaveBeenCalledWith('DS_Reporting_Event', expectedReportingObjectResponse, jasmine.any(Object));
                        scope.$apply();
                    });

                    it('should fire link clink event with appropriate value when user clicks on explore more devices', function () {
                        var expectedReportingObject = jasmine.objectContaining({
                            eventAction: 'linkClick',
                            eventCode: 'Link_Click',
                            additionaldata: {'linkName': 'Explore the device details', 'linkPosition': 'Body', 'linkDestinationURL': '/shop/xpress/device-recommender.html'}
                        });

                        scope.showDeviceDetails();
                        expect(scope.$emit).toHaveBeenCalledWith('DS_Reporting_Event', expectedReportingObject, jasmine.anything());
                        scope.$apply();
                    });

                    it('should fire link clink event with appropriate value when user clicks on See price details', function () {
                        var expectedReportingObject = jasmine.objectContaining({
                            eventAction: 'linkClick',
                            eventCode: 'Link_Click',
                            additionaldata: {'linkName': 'See price details', 'linkPosition': 'Body', 'linkDestinationURL': '/shop/xpress/device-recommender.html'}
                        });
                        scope.deviceConfig.legalAccordionOpen = true;
                        scope.showLegalAccordion();
                        expect(scope.$emit).toHaveBeenCalledWith('DS_Reporting_Event', expectedReportingObject, jasmine.anything());
                        scope.$apply();
                    });

                    it('should fire link clink event with appropriate value when user clicks on Explore the device details', function () {
                        var expectedReportingObject = jasmine.objectContaining({
                            eventAction: 'linkClick',
                            eventCode: 'Link_Click',
                            additionaldata: {'linkName': 'Explore the device details', 'linkPosition': 'Body', 'linkDestinationURL': '/shop/xpress/device-recommender.html'}
                        });
                        scope.showDeviceDetails();
                        expect(scope.$emit).toHaveBeenCalledWith('DS_Reporting_Event', expectedReportingObject, jasmine.anything());
                        scope.$apply();
                    });

                });

            });

        });
    });

})();