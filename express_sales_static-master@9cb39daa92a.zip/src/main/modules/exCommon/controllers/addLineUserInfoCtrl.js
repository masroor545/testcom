(function () {
    'use strict';

    /**
     * This controller exists to get the add a line user's profile information.
     *
     * ProfileInfo service is called to get the user's information and store the result
     * in a scope variable that is to be displayed on HTML
     *
     *
     * @module addLineUserInfoCtrl
     *
     * @property {object} user - contains all the data in this controller
     * @property {string} [user.accountName] - user's account name
     * @property {string[]} [user.planName] - user's current plan name
     *
     */
    angular.module('exCommon')

        .controller('addLineUserInfoCtrl', ['$scope', 'profileInfoService',
            function ($scope, profileInfoService) {

                $scope.user = {
                    accountName: '',
                    planName: ''
                };
                $scope.getProfileInfoDetails = getProfileInfoDetails;

                /**
                 * Controller startup logic
                 */
                function activate () {
                    getProfileInfoDetails();
                }

                activate();

                /**
                 * This function gets the profile information of the logged in user
                 * @function getProfileInfoDetails
                 * @example @lang html
                 * <a ng-click="getProfileInfoDetails()">Get Profile Info</a>
                 */
                function getProfileInfoDetails () {
                    profileInfoService.getProfileInfo().then(function (result) {

                        if (result['ProfileInfo'].accountFirstName &&
                            (result['ProfileInfo'].currentPlanName &&
                             result['ProfileInfo'].currentPlanName.length !== 0)) {
                            $scope.user.accountName = result['ProfileInfo'].accountFirstName;
                            $scope.user.planName = result['ProfileInfo'].currentPlanName[0];
                        }
                    });
                }
            }
        ]);
})();
