(function () {
    'use strict';

    angular.module('exCommon')

        .controller('deviceConfigCtrl', ['$scope', '$modal', '$window', '$location', '$anchorScroll', '$modalStack', 'exCommonConstants',
            'deviceConfigSrv', 'reportingDataSrv', 'selectedSkuSrv', 'exCartService', 'upgradingUserInfoSrv', 'upsellOfferSrv',
            '$rootScope', 'contentService', 'exHelpUtils', 'exCqTranslatorKeyService', 'imagePathService', '$timeout', 'profileInfoService',
            function ($scope, $modal, $window, $location, $anchorScroll, $modalStack, exCommonConstants,
                deviceConfigSrv, reportingDataSrv, selectedSkuSrv, exCartService, upgradingUserInfoSrv, upsellOfferSrv,
                $rootScope, contentService, exHelpUtils, exCqTranslatorKeyService, imagePathService, $timeout, profileInfoService) {

                var deviceConfig = {
                    selectedSku: {},
                    focusedSku: {},
                    capacityVariants: [],
                    sizeVariants: [],
                    colorVariants: [],
                    skuSiblings: [],
                    shortDisplayName: '',
                    displayDeviceDetails: false,
                    displayPricingOptions: false,
                    selectedTerm: null,
                    monthlyPrice: null,
                    commitmentTermLabelToDisplay: undefined,
                    legalAccordionOpen: false,
                    openReviewsTab: false,
                    redirectUrl: null,
                    longLegalContent: undefined,
                    showLongLegal: false,
                    openOverviewTab: true,
                    displayDeliveryPromiseMessage: false,
                    displayPreOrderMessage: false,
                    seeOfferDetailsContent: '',
                    showOfferDetails: false,
                    displayOutOfStockMessage: false,
                    isWidget: false,
                    deliveryPromiseMessage: [],
                    sddDeliveryPromiseMessage: [],
                    bopisDeliveryPromiseMessage: [],
                    losgInContext: {},
                    renderBV: true,
                    hylaPromoDetails: [],
                    isHylaOpted: false,
                    showHylaOfferLegalDetails: false,
                    hylaHeadLine: '',
                    hylaInBodyContent: '',
                    hylaLongLegalContent: '',
                    hylaLabelMessage: undefined,
                    prodIdHidingDeliveryPromise: null,
                    isAddToCartClicked: false,
                    deviceMap: null,
                    variantType: ''
                };
                $scope.deviceConfig = deviceConfig;
                $scope.getCapacityVariants = getCapacityVariants;
                $scope.getSizeVariants = getSizeVariants;
                $scope.getColorVariants = getColorVariants;
                $scope.setSelectedSku = setSelectedSku;
                $scope.addToCart = addToCart;
                $scope.isAddToCartDisabled = isAddToCartDisabled;
                $scope.showDeviceDetails = showDeviceDetails;
                $scope.changePricingOption = changePricingOption;
                $scope.displayDeviceDetails = displayDeviceDetails;
                $scope.showReviewDetails = showReviewDetails;
                $scope.setCommitmentTerm = setCommitmentTerm;
                $scope.showLegalAccordion = showLegalAccordion;
                $scope.onSkipToCheckout = onSkipToCheckout;
                $scope.close = close;
                $scope.showLongLegalOnPricingOption = showLongLegalOnPricingOption;
                $scope.showDeliveryPromiseMessage = showDeliveryPromiseMessage;
                $scope.showPreOrderMessage = showPreOrderMessage;
                $scope.getHylaPromoDetailsContent = getHylaPromoDetailsContent;
                $scope.showOutOfStockMessage = showOutOfStockMessage;
                $scope.closeUpsellModal = closeUpsellModal;
                $scope.getDeliveryPromiseMessage = getDeliveryPromiseMessage;
                $scope.showHylaOffer = showHylaOffer;
                $scope.closePricingOption = closePricingOption;
                $scope.displayEmptySmallerSpacingDiv = displayEmptySmallerSpacingDiv;
                $scope.closeHylaModal = closeHylaModal;
                $scope.exUpFlow = false;
                $scope.exAlFlow = false;
                $scope.getEnjoyOrBopisDeliveryPromise = getEnjoyOrBopisDeliveryPromise;
                $scope.storeDeliveryPromiseResults = storeDeliveryPromiseResults;
                $scope.getTodayTomorrowIndicator = getTodayTomorrowIndicator;
                $scope.openSeeOfferDetailsModal = upsellOfferSrv.openSeeOfferDetailsModal;

                $scope.$on(exCommonConstants.event.deviceSelected, function (event, selectedDevice) {
                    var initargsType = exHelpUtils.getValue('initargs.type', $scope);
                    deviceConfig.isWidget = $scope.initargs !== undefined;
                    if (deviceConfig.isWidget === true
                        && (initargsType === 'cart' || initargsType === 'changePricingTermInCart')) {
                        // Setting type to upsell for mixedcart if flowtype is not Upgrade
                        if (selectedDevice.commerceItem.flowType !== 'UP') {
                            $scope.type = 'upsellOffer';
                        } else {
                            // If it is upgrade flow then reset the type to being empty
                            $scope.type = '';
                        }

                        // Override overflow property to fix scroll bar issue when widget is open
                        angular.element('html').addClass('widgetIsDisplaying');

                        //From widget: selectedDevice is an object that contains losg and commerceItem
                        deviceConfig.losgInContext = selectedDevice;
                        getDeviceInformation(selectedDevice.commerceItem.skuID);
                    } else if (selectedDevice.commerceItem === undefined) {
                        getDeviceInformation(selectedDevice);
                    }

                });

                $scope.$on(exCommonConstants.event.deviceAddedFromDetails, function (event, data) {
                    if (data === true) {
                        addToCart();
                    }
                });

                /**
                 * Scope function to show hyla promotion details content on overlay
                 */
                $scope.openHylaPromoDetailsModal = function () {
                    getHylaPromoDetailsContent(deviceConfig);
                    $modal.open({
                        templateUrl: exCommonConstants.deviceConfigHylaPromoDetailsModal,
                        windowClass: 'modal-fullscreen',
                        scope: $scope
                    });
                };

                /**
                 * function to toggle the flag for show and hide legal content
                 */
                $scope.isHylaPromoLegalDetailsToggled = function () {
                    deviceConfig.showHylaOfferLegalDetails = !deviceConfig.showHylaOfferLegalDetails;
                };

                $scope.$on(exCommonConstants.event.deviceConfigWidgetBVInitiated, function () {
                    deviceConfig.renderBV = true;
                });

                /**
                 * Scope function to check if the upsellOffer already in the cart
                 */
                $scope.isUpsellOfferInCart = function () {
                    return ($scope.type === 'upsellOffer' && deviceConfig.isWidget !== true);
                };

                activate();

                /**
                 * Controller startup logic.
                 * @private
                 */
                function activate () {
                    if ($scope.initargs !== undefined) {
                        deviceConfig.renderBV = false;
                    }

                    // If upsell offer bind offerId
                    if ($scope.type === 'upsellOffer') {
                        $scope.offerId = $scope.$parent.offerId;
                    }

                    if ($scope.initargs === undefined) {
                        var skuId = $location.search().sku || selectedSkuSrv.getSelectedDevice();
                        getDeviceInformation(skuId);
                    }

                    $rootScope.$broadcast(exCommonConstants.event.deviceConfigLoaded, null);

                    // Checks for flow type if user is add line or upgrade user
                    profileInfoService.getProfileInfo().then(function (result) {
                         // User logged in is Zippy upgrade
                        if (result.ProfileInfo.exUpFlow) {

                            $scope.exUpFlow = true;
                        }

                        // User logged in is Zippy add a line flow
                        if (result.ProfileInfo.exAlFlow) {

                            $scope.exAlFlow = true;
                        }

                    });

                }

                /**
                 * Close the modal logic.
                 * @public
                 */
                function close () {
                    // Dismisses any modals that are present
                    var top = $modalStack.getTop();
                    if (top) {
                        $modalStack.dismiss(top.key);
                    }
                }

                /**
                 * Skips to checkout if multiple upsell offers exist, otherwise closes the modal.
                 */
                function closeUpsellModal () {
                    if (upsellOfferSrv.getOfferCount() > 1) {
                        $scope.close();
                    } else {
                        $scope.onSkipToCheckout();
                    }
                }

                /**
                 * Gets the commitment term from the pricelist and price based on the user's selected term.
                 * If the selected term is not available then the first commitment term in the list is returned.
                 * @private
                 * @param {string} term the user's selected term
                 * @param {object} priceList the sku's priceList
                 */
                function formatSkuPrice (term, priceList) {
                    for (var i = 0; i < priceList.length; i++) {
                        if (priceList[i].name === term) {
                            priceList.selectedCommitmentTerm = priceList[i];
                            return priceList[i];
                        }
                    }
                    return priceList[0];
                }

                /**
                 * Formats sku based on display logic
                 * @private
                 * @param {object} sku
                 * @returns {object} Formatted sku object
                 */
                function formatSku (sku) {
                    var formattedSku = {};

                    formattedSku.size = sku.size !== null ? sku.size : sku.skuSize;
                    formattedSku.skuSize = sku.skuSize !== null ? sku.skuSize : '';
                    formattedSku.capacity = '';
                    formattedSku.color = sku.color;
                    formattedSku.hexValue = sku.hexValue;
                    formattedSku.colorTheme = deviceConfigSrv.getColorTheme(formattedSku.hexValue);
                    formattedSku.skuId = sku.skuId;
                    formattedSku.deviceType = sku.deviceType;
                    formattedSku.marketingsequence = sku.marketingsequence;
                    formattedSku.productId = sku.productId;
                    formattedSku.devicePageURL = sku.devicePageURL;
                    formattedSku.preOwned = sku.preOwned;
                    formattedSku.refurbished = sku.refurbished;
                    formattedSku.preOrderable = sku.preOrderable;
                    formattedSku.priceList = createCommitmentTermList(sku);

                    formattedSku.effectiveOutOfStock = sku.effectiveOutOfStock;
                    formattedSku.skuExcludedFromBOPISForFlow = sku.skuExcludedFromBOPISForFlow;
                    formattedSku.wirelessHylaOfferInfo = getHylaOfferInfo(sku);

                    // Capacity to display on page
                    if (sku.skuSize !== null) {
                        formattedSku.capacity = sku.skuSize;
                    } else if (sku.size !== null) {
                        formattedSku.capacity = sku.size + sku.uom;
                    } else {
                        formattedSku.capacity = '';
                    }

                    // CTA to display on the page
                    formattedSku.isPreOrderButton = sku.preOrderable && !sku.effectiveOutOfStock &&
                        !deviceConfig.isWidget;
                    formattedSku.isAddToCartButton = !sku.preOrderable && !sku.effectiveOutOfStock &&
                        !deviceConfig.isWidget;
                    formattedSku.isOutOfStockButton = sku.effectiveOutOfStock && !deviceConfig.isWidget;

                    // data-qa for CTA
                    if (formattedSku.isPreOrderButton) {
                        formattedSku.dataQaForConfigCTA = 'deviceConfig-DeviceConfig-preOrder';
                        formattedSku.dataQaForDetailsCTA = 'deviceDetails-DeviceDetails-preOrder';
                    } else if (formattedSku.isOutOfStockButton) {
                        formattedSku.dataQaForConfigCTA = 'deviceConfig-DeviceConfig-outOfStock';
                        formattedSku.dataQaForDetailsCTA = 'deviceDetails-DeviceDetails-outOfStock';
                    } else if (deviceConfig.isWidget) {
                        formattedSku.dataQaForConfigCTA = 'deviceConfig-DeviceConfig-updateCart';
                        formattedSku.dataQaForDetailsCTA = 'deviceDetails-DeviceDetails-updateCart';
                    } else {
                        // by default data-qa is addToCart
                        formattedSku.dataQaForConfigCTA = 'deviceConfig-DeviceConfig-addToCart';
                        formattedSku.dataQaForDetailsCTA = 'deviceDetails-DeviceDetails-addToCart';
                    }

                    // Assumes the first commitment term is the default price
                    formattedSku.selectedCommitmentTerm = formattedSku.priceList[0];

                    //sets the default term passed from widget if this function is called from a widget
                    if (deviceConfig.isWidget === true) {
                        var initargsType = exHelpUtils.getValue('initargs.type', $scope);

                        if (initargsType === 'cart' || initargsType === 'changePricingTermInCart') {
                            if (deviceConfig.losgInContext.commerceItem.IPIdentifier !== 'regular') {
                                formattedSku.selectedCommitmentTerm =
                                        formatSkuPrice(deviceConfig.losgInContext.commerceItem.IPIdentifier,
                                            formattedSku.priceList);
                            } else {
                                formattedSku.selectedCommitmentTerm =
                                        formatSkuPrice(deviceConfig.losgInContext.commerceItem.contractLength.toString(),
                                            formattedSku.priceList);
                            }

                        }
                    }

                    formattedSku.price = getPrice(formattedSku.selectedCommitmentTerm);

                    // Ensures rating is always a number
                    formattedSku.rating = (typeof sku.rating === 'number' && sku.rating !== 0 ? sku.rating.toFixed(2) : 0);

                    // Retrieves image url to call a common imagePathSerivce function e.g. /xpress/Apple/Apple iPhone 7/Black-hero.png
                    formattedSku.imgUrl = imagePathService.getXpressImagePath(deviceConfig.manufacturer, deviceConfig.shortDisplayName,
                                            deviceConfig.productDisplayName, formattedSku.color, '-hero-zoom.png');

                    // Color variant formattnig
                    formattedSku.colorVariant = {};
                    formattedSku.colorVariant.id = sku.color;
                    formattedSku.colorVariant.colorCode = sku.hexValue;

                    // Capacity variant formatting
                    formattedSku.capacityVariant = {};
                    formattedSku.capacityVariant.id = formattedSku.capacity;

                    // Size variant formatting
                    formattedSku.sizeVariant = {};
                    formattedSku.sizeVariant.id = formattedSku.size;

                    // Hazard legal notes
                    formattedSku.legalNotes = sku.legalNotes;

                    // Gets monthly lease price after rebate value
                    formattedSku.mlpRebate = getMonthlyLeasePriceRebate(sku);

                    return formattedSku;
                }

                /** Gets price based on the commitment term
                 * @private
                 * @param {object} commitmentTerm
                 * @returns {number} the price
                 */
                function getPrice (commitmentTerm) {
                    return commitmentTerm.type === 'regular' ?
                        commitmentTerm.dueToday : commitmentTerm.monthlyLeasePrice;
                }

                /**
                 * Gets monthly price based on commitment term
                 * @private
                 * @param {object} commitmentTerm
                 * @returns {boolean} True if the commitmentTerm is a monthly price. False if not.
                 */
                function getMonthlyPrice (commitmentTerm) {
                    return commitmentTerm.type !== 'regular';
                }

                /**
                 * Gets monthly lease price rebate for the selected sku
                 * @private
                 * @param {object} selectedSku
                 * @returns {number} the monthly lease price after rebate
                 */
                function getMonthlyLeasePriceRebate (selectedSku) {
                    if ($scope.type === 'upsellOffer' && selectedSku.priceList[0].monthlyRebate > 0) {
                        selectedSku.mlpRebate = selectedSku.priceList[0].mlpAfterRebate;
                    } else if ($scope.type === 'upsellOffer' && (selectedSku.priceList[0].offerDueToday <= selectedSku.priceList[0].dueToday)
                            && (selectedSku.priceList[0].name === '24' || selectedSku.priceList[0].name === '1')) {
                        selectedSku.mlpRebate = selectedSku.priceList[0].offerDueToday;
                    }
                    return selectedSku.mlpRebate;
                }

                /**
                 * Fetch CMS key content commitment terms of selected device and call cms translator key service to get short legal content
                 * @private fetchShortLegalContentForSelectedDevice
                 * @param {object} commitmentTerms
                 */
                function fetchShortLegalContentForSelectedDevice (commitmentTerms) {
                    var cmsKeys = [], legalCmsKeyContent;

                    angular.forEach(commitmentTerms, function (commitmentTerm) {
                        cmsKeys.push(commitmentTerm.shortLegalKey);
                    });

                    cmsKeys.push(exCommonConstants.commitmentTermLabels.commitmentTermNext);
                    cmsKeys.push(exCommonConstants.commitmentTermLabels.commitmentTermEveryYear);
                    cmsKeys.push(exCommonConstants.commitmentTermLabels.commitmentTermInstallment);
                    cmsKeys.push(exCommonConstants.commitmentTermLabels.commitmentTermTwoYear);
                    cmsKeys.push(exCommonConstants.commitmentTermLabels.commitmentTermZero);
                    cmsKeys.push(exCommonConstants.hylaPromotionLabel.hylaTradeInOffer);
                    cmsKeys.push(exCommonConstants.hylaPromotionLabel.hylaLegalTerms);
                    cmsKeys.push(exCommonConstants.hylaPromotionLabel.hylaSeeOfferDetails);
                    cmsKeys.push(exCommonConstants.hylaPromotionLabel.hylaCheckBoxLabel);
                    cmsKeys.push(exCommonConstants.omniChannelDeliveryPromiseSuppression);

                    exCqTranslatorKeyService.getCqTranslatorKeys(cmsKeys).then(
                        function (result) {
                            deviceConfig.hylaLabelMessage = {
                                hylaTradeInOffer: result[exCommonConstants.hylaPromotionLabel.hylaTradeInOffer],
                                hylaLegalTerms: result[exCommonConstants.hylaPromotionLabel.hylaLegalTerms],
                                hylaSeeOfferDetails: result[exCommonConstants.hylaPromotionLabel.hylaSeeOfferDetails],
                                hylaCheckBoxLabel: result[exCommonConstants.hylaPromotionLabel.hylaCheckBoxLabel]
                            };
                            angular.forEach(commitmentTerms, function (commitmentTerm) {
                                legalCmsKeyContent = result[commitmentTerm.shortLegalKey];
                                deviceConfig.commitmentTermLabelToDisplay = {
                                    commitmentTermNext: result[exCommonConstants.commitmentTermLabels.commitmentTermNext],
                                    commitmentTermEveryYear: result[exCommonConstants.commitmentTermLabels.commitmentTermEveryYear],
                                    commitmentTermInstallment: result[exCommonConstants.commitmentTermLabels.commitmentTermInstallment],
                                    commitmentTermTwoYear: result[exCommonConstants.commitmentTermLabels.commitmentTermTwoYear],
                                    commitmentTermZero: result[exCommonConstants.commitmentTermLabels.commitmentTermZero]
                                };
                                if (commitmentTerm.type === 'lease') {
                                    legalCmsKeyContent = legalCmsKeyContent.replace('{0}', commitmentTerm.leaseTotalMonths);
                                }
                                if (commitmentTerm.leaseTotalMonths === 30) {
                                    commitmentTerm.commitTermName = deviceConfig.commitmentTermLabelToDisplay.commitmentTermNext;
                                } else if (commitmentTerm.leaseTotalMonths === 20) {
                                    commitmentTerm.commitTermName = deviceConfig.commitmentTermLabelToDisplay.commitmentTermInstallment;
                                } else if (commitmentTerm.leaseTotalMonths === 24) {
                                    commitmentTerm.commitTermName = deviceConfig.commitmentTermLabelToDisplay.commitmentTermEveryYear;
                                } else if (commitmentTerm.name === '24') {
                                    commitmentTerm.commitTermName = deviceConfig.commitmentTermLabelToDisplay.commitmentTermTwoYear;
                                } else if (commitmentTerm.name === '1') {
                                    commitmentTerm.commitTermName = deviceConfig.commitmentTermLabelToDisplay.commitmentTermZero;
                                }
                                commitmentTerm.shortLegalContent = legalCmsKeyContent;
                            });

                            // Special code to force deliveryPromiseMessage to be false for nda label
                            // Since it is inside Private function. It will shall not be used by anything else other than this controller
                            // If label contains the product ID
                            if (result[exCommonConstants.omniChannelDeliveryPromiseSuppression].indexOf(deviceConfig.selectedSku.productId) !== -1) {
                                // Then set prodIdHidingDeliveryPromise to productID that should not show the delivery promise
                                deviceConfig.prodIdHidingDeliveryPromise = deviceConfig.selectedSku.productId;
                            }

                        });
                }

                /**
                 * Formats sku to be added as a cart item
                 * @private
                 * @param {object} sku
                 * @param {object} commitmentTerm
                 * @returns {object} Formatted cart item
                 */
                function formatCartItem (sku, commitmentTerm) {
                    var cartItem = {
                        items: {
                            items: [{}]
                        }
                    };

                    // Abbreviation
                    var item = cartItem.items.items[0];

                    item.valueMap = {};
                    item.valueMap.contractType = commitmentTerm.type === 'regular' ?
                        'regular' : commitmentTerm.name;

                    // If the contract type is regular then the contract length is the name (1)
                    item.valueMap.contractLength = item.valueMap.contractType === 'regular' ?
                        commitmentTerm.name.toString() : commitmentTerm.leaseTotalMonths.toString();

                    item.quantity = 1;
                    item.catalogRefId = sku.skuId;
                    item.productId = sku.productId;
                    if (deviceConfig.isWidget === true) {
                        item.losgId = getPrimaryLOSGFromCheckout();
                    }

                    return cartItem;
                }

                /**
                 * Sets up commitmentTerm list based on pricelist and term
                 * @private
                 * @param {object} sku
                 * @returns {object} formatted priceList
                 */
                function createCommitmentTermList (sku) {
                    return sku.priceList.map(function (commitmentTerm) {
                        if (commitmentTerm.leaseTotalMonths === 30) {
                            commitmentTerm.commitTermLegal = exCommonConstants.commitmentTermLegalLabels.commitmentTermNext;
                            commitmentTerm.disclaimer = getCommitmentDisclaimer(commitmentTerm, exCommonConstants.commitmentTermLabels.commitmentDisclaimerNext);
                            commitmentTerm.selectedskuPriceToDisplay = commitmentTerm.monthlyLeasePrice;
                            commitmentTerm.shortLegalKey = exCommonConstants.commitTermDeviceConfigShortLegalLbl.lease;
                        } else if (commitmentTerm.leaseTotalMonths === 20) {
                            commitmentTerm.commitTermLegal = exCommonConstants.commitmentTermLegalLabels.commitmentTermInstallment;
                            commitmentTerm.disclaimer = getCommitmentDisclaimer(commitmentTerm, exCommonConstants.commitmentTermLabels.commitmentDisclaimerInstallment);
                            commitmentTerm.selectedskuPriceToDisplay = commitmentTerm.monthlyLeasePrice;
                            commitmentTerm.shortLegalKey = exCommonConstants.commitTermDeviceConfigShortLegalLbl.lease;
                        } else if (commitmentTerm.leaseTotalMonths === 24) {
                            commitmentTerm.commitTermLegal = exCommonConstants.commitmentTermLegalLabels.commitmentTermEveryYear;
                            commitmentTerm.disclaimer = getCommitmentDisclaimer(commitmentTerm, exCommonConstants.commitmentTermLabels.commitmentDisclaimerEveryYear);
                            commitmentTerm.selectedskuPriceToDisplay = commitmentTerm.monthlyLeasePrice;
                            commitmentTerm.shortLegalKey = exCommonConstants.commitTermDeviceConfigShortLegalLbl.lease;
                        } else if (commitmentTerm.name === '24') {
                            commitmentTerm.commitTermLegal = exCommonConstants.commitmentTermLegalLabels.commitmentTermTwoYear;
                            commitmentTerm.disclaimer = getCommitmentDisclaimer(commitmentTerm, exCommonConstants.commitmentTermLabels.commitmentDisclaimerTwoYear);
                            commitmentTerm.selectedskuPriceToDisplay = commitmentTerm.dueToday;
                            if (commitmentTerm.dueToday === 0) {
                                commitmentTerm.shortLegalKey = exCommonConstants.commitTermDeviceConfigShortLegalLbl.regulareq0;
                            } else {
                                commitmentTerm.shortLegalKey = exCommonConstants.commitTermDeviceConfigShortLegalLbl.regulargt0eq24;
                            }
                        } else if (commitmentTerm.name === '1') {
                            commitmentTerm.commitTermLegal = exCommonConstants.commitmentTermLegalLabels.commitmentTermZero;
                            commitmentTerm.disclaimer = getCommitmentDisclaimer(commitmentTerm, exCommonConstants.commitmentTermLabels.commitmentDisclaimerTermZero);
                            commitmentTerm.selectedskuPriceToDisplay = commitmentTerm.dueToday;
                            if (commitmentTerm.dueToday === 0) {
                                commitmentTerm.shortLegalKey = exCommonConstants.commitTermDeviceConfigShortLegalLbl.regulareq0;
                            } else {
                                commitmentTerm.shortLegalKey = exCommonConstants.commitTermDeviceConfigShortLegalLbl.regulargt0neq24;
                            }
                        }
                        return commitmentTerm;
                    });

                }

                /**
                 * Scope function to set price.
                 * Updates selected sku with the new selected price.
                 * @public
                 * @param {object} commitmentTerm Commitment term from the pricelist
                 */
                function setCommitmentTerm (commitmentTerm) {
                    deviceConfig.selectedSku.selectedCommitmentTerm = commitmentTerm;
                    deviceConfig.selectedTerm = commitmentTerm.name;
                    deviceConfig.selectedSku.price = getPrice(commitmentTerm);
                    deviceConfig.monthlyPrice = getMonthlyPrice(deviceConfig.selectedSku.selectedCommitmentTerm);
                    $rootScope.$broadcast(exCommonConstants.event.selectedSkuInFocus, deviceConfig);
                    if ($scope.initargs !== undefined) {
                        addToCart();
                    }

                    // Closes pricing options
                    closePricingOption();
                }


                /**
                 * Scope function to add selectedSku to cart
                 * @public
                 */
                function addToCart () {
                    // add to cart button is clicked
                    deviceConfig.isAddToCartClicked = true;

                    var cartItem = formatCartItem(deviceConfig.selectedSku, deviceConfig.selectedSku.selectedCommitmentTerm),
                        eventPayload = reportingDataSrv.getAddToCartDevicePayload($scope.deviceConfig),
                        eventCode = deviceConfig.selectedSku.preOrderable ? 'DS_Upgrade_Cart_Preorder_Submit' : 'DS_Upgrade_Cart_Add_Submit';


                    $scope.$emit(exCommonConstants.event.DS_REPORTING_EVENT, {
                        eventAction: 'formSubmit',
                        eventCode: eventCode,
                        additionaldata: eventPayload
                    }, $scope);

                    // actionType is always addItemAndGoToNextStep
                    var params = {
                        actionType: 'addItemAndGoToNextStep'
                    };

                    if ($scope.type === 'upsellOffer' || exHelpUtils.getValue('initargs.type', $scope) === 'upsellCart') {
                        params.redirectionUrl = deviceConfig.redirectUrl;
                        params.losgBuyFlowType = 'AL';
                        params.addNewLine = 'true';
                        params.wirelessBuyFlowType = 'MIXEDCART';
                        params.quantity = 1;
                        params.offerId = $scope.offerId;
                    }

                    if (deviceConfig.isWidget !== true &&
                        $scope.type !== 'upsellOffer' &&
                        deviceConfig.selectedSku.selectedCommitmentTerm &&
                        deviceConfig.selectedSku.selectedCommitmentTerm.type !== 'regular' &&
                        deviceConfig.isHylaOpted === true &&
                        deviceConfig.selectedSku.wirelessHylaOfferInfo &&
                        deviceConfig.selectedSku.wirelessHylaOfferInfo.eligible) {
                        params.hylaOptin = true;
                    }

                    // Widgets never redirect. We always let the widget implementer decide when to redirect
                    if (deviceConfig.isWidget === true) {
                        params.skipRedirect = true;

                        //setting adddNewLine to False for widget since we are only updating line in the cart page
                        if ($scope.type === 'upsellOffer' || exHelpUtils.getValue('initargs.type', $scope) === 'upsellCart') {
                            params.addNewLine = 'false';
                        } else {
                            // Add to cart service requires losgBuyFlowType of UP when flow type is not mixed cart
                            params.losgBuyFlowType = 'UP';
                        }
                        // Adding the removalCommerseID for updateCart scenario in widgets.
                        if (exHelpUtils.getValue('initargs.type', $scope) === 'cart'
                            && deviceConfig.selectedSku.skuId !== deviceConfig.losgInContext.commerceItem.skuID) {
                            params.removalCommerceIds = deviceConfig.losgInContext.commerceItem.itemID;
                        }
                    }
                    var skuIDInCart = exHelpUtils.getValue('deviceConfig.losgInContext.commerceItem.skuID', $scope);
                    var initargsType = exHelpUtils.getValue('initargs.type', $scope);

                    if (deviceConfig.selectedSku.skuId !== skuIDInCart || initargsType === 'changePricingTermInCart') {
                        exCartService.addItemToCart(cartItem, params).then(function (data) {
                            if (data.response !== undefined && data.response !== null
                                && data.response.status === exCommonConstants.errorStatus) {
                                eventPayload = reportingDataSrv.updateEventPayloadFailure(eventPayload, data);
                            }

                            if (data.response !== undefined
                                && data.response !== null
                                && data.response.status !== exCommonConstants.errorStatus
                                && initargsType === 'changePricingTermInCart') {
                                // Event Listener for anyone that uses this widget
                                $rootScope.$broadcast(exCommonConstants.event.deviceAdded, true);
                            }

                            $scope.$emit(exCommonConstants.event.DS_REPORTING_EVENT, {
                                eventAction: 'formResponse',
                                eventCode: eventCode,
                                additionaldata: eventPayload
                            }, $scope);
                        });
                    }


                    if (exHelpUtils.getValue('initargs.type', $scope) === 'cart') {
                        deviceConfig.renderBV = false;
                        angular.element('html').removeClass('widgetIsDisplaying');
                        $rootScope.$broadcast(exCommonConstants.event.deviceConfigWidgetAdded, true);
                    }
                }

                /**
                 * Check if add to cart button is disabled or not
                 *
                 * @function isAddToCartDisabled
                 * @returns {Boolean} disabled value of the button
                 *
                 * @example
                 * isAddToCartDisabled()
                 */
                function isAddToCartDisabled () {
                    // Disable add to cart button after a single click to prevent multiple submissions
                    // Disable add to cart button if the selected sku is out of stock
                    if (deviceConfig.selectedSku.isOutOfStockButton || deviceConfig.isAddToCartClicked) {
                        return true;
                    } else {
                        return false;
                    }
                }

                /**
                 * Scope function setter to show or hide the delivery promise message section
                 * @public
                 * @param {String} selectedSkuId
                 */
                function showDeliveryPromiseMessage (selectedSkuId) {
                    if (deviceConfig.sddDeliveryPromiseMessage[selectedSkuId] === null
                            || deviceConfig.sddDeliveryPromiseMessage[selectedSkuId] === undefined) {
                        getEnjoyOrBopisDeliveryPromise();
                    } else if (deviceConfig.sddDeliveryPromiseMessage[selectedSkuId].isAvailable === true) {
                        deviceConfig.displaySDDDeliveryPromiseMessage = true;
                        deviceConfig.displayBOPISDeliveryPromiseMessage = false;
                        deviceConfig.displayDeliveryPromiseMessage = false;
                    } else {
                        deviceConfig.displaySDDDeliveryPromiseMessage = false;
                        if (deviceConfig.bopisDeliveryPromiseMessage[selectedSkuId].isAvailable === true) {
                            deviceConfig.displayBOPISDeliveryPromiseMessage = true;
                            deviceConfig.displayDeliveryPromiseMessage = false;
                        } else {
                            deviceConfig.displayBOPISDeliveryPromiseMessage = false;
                            if (deviceConfig.deliveryPromiseMessage[selectedSkuId]
                        && deviceConfig.prodIdHidingDeliveryPromise !== deviceConfig.selectedSku.productId) {
                                deviceConfig.displayDeliveryPromiseMessage = true;
                            } else {
                                deviceConfig.displayDeliveryPromiseMessage = false;
                            }
                        }
                    }
                }

                /**
                 * Scope function setter to show or hide the pre-order message section
                 * @public
                 * @param {boolean} visible
                 */
                function showPreOrderMessage (visible) {
                    deviceConfig.displayPreOrderMessage = visible;
                    if (visible === true) {
                        // If we are in landscape viewport
                        if ($window.document.documentElement.clientWidth > exCommonConstants.mobileViewportMax) {
                            $anchorScroll('device-config-container');
                        } else {
                            $anchorScroll('preOrderMessage');
                        }
                    }
                }

                /**
                 * Scope function setter to show or hide the out of stock information section
                 * @public
                 * @param {boolean} visible
                 */
                function showOutOfStockMessage (visible) {
                    deviceConfig.displayOutOfStockMessage = visible;
                }

                /**
                 * Scope function to display an empty div for dynamic spacing for price block
                 * @public
                 * @returns {boolean}
                 */
                function displayEmptySmallerSpacingDiv () {
                    return deviceConfig.displayDeliveryPromiseMessage || deviceConfig.displayOutOfStockMessage;
                }

                /**
                 * Scope function setter to show or hide the device details section
                 * @public
                 * @param {boolean} visible
                 */
                function displayDeviceDetails (visible) {
                    deviceConfig.displayDeviceDetails = visible;
                }

                /**
                 * Scope function to scroll to device details section
                 * @public
                 */
                function showDeviceDetails () {
                    displayDeviceDetails(true);
                    deviceConfig.openOverviewTab = true;

                    // If we are in landscape viewport
                    if ($window.document.documentElement.clientWidth > exCommonConstants.mobileViewportMax) {

                      //Scroll to the device details after overview accordion is finished expanding
                        exHelpUtils.scrollToAccordion('device-details-container', 'overview-container', $scope);
                    }

                    // Fire link click event when user clicks on explore the device details link for device
                    $scope.$emit(exCommonConstants.event.DS_REPORTING_EVENT, {
                        eventAction: 'linkClick',
                        eventCode: 'Link_Click',
                        additionaldata: {
                            'linkName': exCommonConstants.linkName.seeDeviceDetails,
                            'linkPosition': exCommonConstants.linkPosition,
                            'linkDestinationURL': exCommonConstants.deviceRecommender
                        }
                    }, $scope);
                }

                /**
                 * Scope function to scroll to review details section and open reviews tab
                 * @public
                 */
                function showReviewDetails () {
                    displayDeviceDetails(true);

                    // Close overview accordian if it is open
                    if (deviceConfig.openOverviewTab) {
                        deviceConfig.openOverviewTab = false;
                    }

                    // If reviews tab isn't open watch for whenever
                    // accordion is finished expanding then scroll to it
                    if (deviceConfig.openReviewsTab !== true) {
                        deviceConfig.openReviewsTab = true;
                        $rootScope.$broadcast(exCommonConstants.event.selectedSkuInFocus, deviceConfig);
                        var deregisterWatch = $scope.$watch(function () {
                            return angular.element('#reviews-container').children()[1].className;
                        }, function () {
                            $anchorScroll('reviews-container');

                            // Deregister watcher if review accordion has reached at the top of screen
                            if (angular.element('#reviews-container').offset().top === 0) {
                                deregisterWatch();
                            }
                        });
                    } else {
                        $anchorScroll('reviews-container');
                    }
                }

                /**
                 * Scope function to open legal accordion and scroll to legal section
                 * @public
                 */
                function showLegalAccordion () {

                    if (deviceConfig.selectedSku.devicePageURL == null) {
                        showDeviceDetails();

                    } else {

                        displayDeviceDetails(true);
                        deviceConfig.legalAccordionOpen = true;

                        // Close overview accordian if it is open
                        if (deviceConfig.openOverviewTab) {
                            deviceConfig.openOverviewTab = false;
                        }

                        // Scroll to the legal section after legal accordion is finished expanding
                        // Timeout of half a second is given as overview accordion takes time to collapse and
                        // it scrolls to the half of the page. TODO: Better solution in next release
                        $timeout(function () {
                            exHelpUtils.scrollToAccordion('legal-container', 'legal-container', $scope);
                        }, exCommonConstants.accordionTimer);

                        $rootScope.$broadcast(exCommonConstants.event.selectedSkuInFocus, deviceConfig);

                        // Fire link click event when user clicks on see price details link for device
                        $scope.$emit(exCommonConstants.event.DS_REPORTING_EVENT, {
                            eventAction: 'linkClick',
                            eventCode: 'Link_Click',
                            additionaldata: {
                                'linkName': exCommonConstants.linkName.longLegalLinkLabel,
                                'linkPosition': exCommonConstants.linkPosition,
                                'linkDestinationURL': exCommonConstants.deviceRecommender
                            }
                        }, $scope);
                    }
                }

                /**
                 * Scope function to fetch long legal content from CQ using content service and then show long legal in pricing option
                 * @public
                 */
                function showLongLegalOnPricingOption (visible) {
                    if (visible) {
                        contentService.getProductLegalPaths(deviceConfig.selectedSku.devicePageURL).then(function (deviceLegalPaths) {
                            contentService.getProductLegalContent(deviceLegalPaths).then(function (deviceLegalContent) {
                                deviceConfig.longLegalContent = deviceLegalContent;
                                deviceConfig.showLongLegal = visible;
                                //Scroll to long legal after dom has been rendered and digest cyle is complete of rendering the dom
                                $timeout(function () {
                                    $anchorScroll('changePricingLongLegal');
                                }, 0, false);
                            });
                        });
                    } else {
                        deviceConfig.showLongLegal = visible;
                    }
                }

                /**
                 * Scope function to see pricing Options Overlay
                 * @public
                 * @param {boolean} visible
                 */
                function changePricingOption () {
                    $modal.open({
                        templateUrl: exCommonConstants.pricingOptionsModal,
                        windowClass: 'modal-fullscreen',
                        scope: $scope
                    });
                }

                /**
                 * Function to close pricing options modal
                 * @public
                 */
                function closePricingOption () {
                    if ($scope.initargs !== undefined) {
                        angular.element('html').removeClass('widgetIsDisplaying');
                        $rootScope.$broadcast(exCommonConstants.event.deviceAdded, false);
                    } else {
                        exHelpUtils.closeActiveModal();
                    }

                    /**
                     * Override DS2 modal close logic as we are opening pricing option modal on top of device config modal,
                     * DS2 logic only works when modal is opened on the page.
                     */
                    if (deviceConfig.isWidget !== true) {
                        angular.element('html').addClass('styled-by-modal');
                    }

                    // Fire link click event when user clicks on see other pricing options link for device
                    $scope.$emit(exCommonConstants.event.DS_REPORTING_EVENT, {
                        eventAction: 'linkClick',
                        eventCode: 'Link_Click',
                        additionaldata: {
                            'linkName': exCommonConstants.linkName.seePricingOptions,
                            'linkPosition': exCommonConstants.linkPosition,
                            'linkDestinationURL': exCommonConstants.deviceRecommender
                        }
                    }, $scope);
                }

                /**
                 * Gets the capacity variants based on the sku.
                 * E.g. red 32gb sku will return red 32gb, red 128gb, red 256gb skus.
                 * Assumes color IS NOT the first key in the 2d array.
                 * @public
                 * @param {object} selSku The selected sku
                 * @param {Array<Array<object>>} skuSiblings A 2d array of skus
                 * @return {Array<object>} An array of skus with matching colors and varying capacities
                 */
                function getCapacityVariants (selSku, skuSiblings) {
                    if (Array.isArray(skuSiblings[0]) !== true) {
                        return skuSiblings;
                    }

                    // Filters non-matching colors from skuItems and concats the arrays
                    return skuSiblings
                        .map(function (skus) {
                            return skus.filter(function (sku) {
                                return selSku.color === sku.color;
                            });
                        })
                        .reduce(function (matchingSkus, matchingSku) {
                            return matchingSkus.concat(matchingSku);
                        });
                }

                /**
                 * Gets the size variants based on the sku.
                 * E.g. red L sku will return red S, red M, red L skus.
                 * Assumes color IS NOT the first key in the 2d array.
                 * @public
                 * @param {object} selSku The selected sku
                 * @param {Array<Array<object>>} skuSiblings A 2d array of skus
                 * @return {Array<object>} An array of skus with matching colors and varying sizes
                 */
                function getSizeVariants (selSku, skuSiblings) {
                    if (skuSiblings.length > 0) {
                        // Filters non-matching colors from skuItems and concats the arrays
                        return skuSiblings
                            .map(function (skus) {
                                return skus.filter(function (sku) {
                                    return selSku.color === sku.color;
                                });
                            })
                            .reduce(function (matchingSkus, matchingSku) {
                                return matchingSkus.concat(matchingSku);
                            });
                    }
                }

                /**
                 * Gets the color variants based on the sku.
                 * E.g. red 32gb sku will return red 32gb, blue 32gb, green 32gb skus.
                 * Assumes capacity IS the first key in the 2d array.
                 * @public
                 * @param {string} selSku The selected sku
                 * @param {Array<Array<object>>} skuSiblings A  2d array of skus
                 * @return {Array<object>} An array of skus with matching capacities and varying colors
                 */
                function getColorVariants (selSku, skuSiblings) {
                    if (Array.isArray(skuSiblings[0]) !== true) {
                        return skuSiblings;
                    }
                    for (var i = 0; i < skuSiblings.length; i++) {
                        if (skuSiblings[i][0].capacity === selSku.capacity) {
                            return skuSiblings[i];
                        }
                    }
                }

                /**
                 * Scope function to set the selected sku and perform operations based on selected sku.
                 * Sets the price based on the selected contract type
                 * Gets short legal content for selected sku
                 * show/hide pre-order warning message for selected sku
                 * @public
                 * @param {object} sku The sku to be set as the selected sku
                 * @param {string} variant indicator that identifies if capacity has been clicked
                 */
                function setSelectedSku (sku, variant) {
                    deviceConfig.selectedSku = sku;
                    deviceConfig.skuId = sku.skuId;
                    deviceConfig.selectedSku.selectedCommitmentTerm = formatSkuPrice(deviceConfig.selectedTerm, deviceConfig.selectedSku.priceList);
                    deviceConfig.selectedSku.price = getPrice(deviceConfig.selectedSku.selectedCommitmentTerm);
                    deviceConfig.selectedSku.mlpRebate = getMonthlyLeasePriceRebate(deviceConfig.selectedSku);
                    deviceConfig.isHylaOpted = getHylaOpted(deviceConfig.selectedSku);
                    showDeliveryPromiseMessage(deviceConfig.selectedSku.skuId);
                    fetchShortLegalContentForSelectedDevice(deviceConfig.selectedSku.priceList);
                    showPreOrderMessage(deviceConfig.selectedSku.preOrderable);
                    showOutOfStockMessage(deviceConfig.selectedSku.effectiveOutOfStock);
                    showHylaOffer(deviceConfig.selectedSku);
                    if (variant === 'capacityVariants' || variant === 'sizeVariants') {
                        deviceConfig.colorVariants = getColorVariants(sku, deviceConfig.skuSiblings);
                    } else if (deviceConfig.hasSizeVariants) {
                        deviceConfig.capacityVariants = getCapacityVariants(sku, deviceConfig.skuSiblings);
                    } else {
                        deviceConfig.sizeVariants = getSizeVariants(sku, deviceConfig.skuSiblings);
                    }
                    $rootScope.$broadcast(exCommonConstants.event.selectedSkuInFocus, deviceConfig);
                }

                /**
                 * Sort function by sku marketing sequence
                 * @private
                 * @param {number} a
                 * @param {number} b
                 */
                function marketingSequenceSort (a, b) {
                    return a.marketingsequence - b.marketingsequence;
                }

                /**
                 * this method makes a post service when clicked on proceed to checkout button on device config page
                 * @function onSkipToCheckout
                 */
                function onSkipToCheckout () {
                    upsellOfferSrv.skipToCheckout();
                }

                /**
                 * Gets Delivery Promise Message of all the device variants.
                 * @private deviceConfig.getDeliveryPromiseMessage
                 * @param {string} deviceMap color/size variant of selected device
                 * @param {string} variant type in deviceMap, i.e. size/color/no variants
                 */
                function getDeliveryPromiseMessage (deviceMap, variantType) {
                    var skuIds;
                    if (variantType === 'hasSizeVariants' || variantType === 'hasAccSizeVariants') {
                        skuIds = Object.keys(deviceMap).map(function (sizes) {
                            return Object.keys(deviceMap[sizes]).map(function (deviceSkuIds) {
                                return deviceSkuIds;
                            }).join(',');
                        }).join(',');
                    } else if (variantType === 'hasColorVariants') {
                        skuIds = (Object.keys(deviceMap)).map(function (obj) {
                            return obj;
                        }).join(',');
                    } else {
                        skuIds = deviceMap.skuId;
                    }

                    deviceConfigSrv.getDeliveryPromiseMessage(skuIds).then(function (deliveryPromiseMessage) {
                        var shipmentDates = deliveryPromiseMessage.data.payload.skuShipmentDates;
                        angular.forEach(shipmentDates, function (shipmentDate) {
                            deviceConfig.deliveryPromiseMessage[shipmentDate.SKUId] = shipmentDate;
                        });
                        // show/hide delivery promise information based on selected sku
                        showDeliveryPromiseMessage(deviceConfig.selectedSku.skuId);
                    });
                }

                /**
                 * gets the hyla promo details for device config page
                 * @function getHylaPromoDetailsContent
                 * @public
                 * @param {object} deviceConfig
                 */
                function getHylaPromoDetailsContent (deviceConfig) {
                    deviceConfigSrv.hylaPromotionDetails().then(function (Content) {
                        if (Content !== undefined && Content !== null) {
                            deviceConfig.hylaPromoDetails = getRequiredHylaPromoDetails(Content);
                            deviceConfig.hylaHeadLine = deviceConfig.hylaPromoDetails[0].headLine;
                            deviceConfig.hylaInBodyContent = deviceConfig.hylaPromoDetails[0].inBodyContent;
                            deviceConfig.hylaLongLegalContent = deviceConfig.hylaPromoDetails[0].longLegalContent;
                            deviceConfig.showHylaOfferLegalDetails = true;
                        }
                    });
                }

                /**
                 * gets the offer legal content details from sharedContentRetrievalUrl
                 * @function getRequiredHylaPromoDetails
                 * @param {Object} offerContent Offer legal content information
                 * @returns {object} offer specific legal content details
                 */
                function getRequiredHylaPromoDetails (hylaContent) {
                    var hylaPromoRequiredDetails = [];
                    angular.forEach(hylaContent, function (item, key) {
                        if (hylaContent.hasOwnProperty(key)) {
                            hylaPromoRequiredDetails.push({
                                headLine: (item.pageTitle) ? item.pageTitle[0] : '',
                                inBodyContent: (item['jcr:description']) ? item['jcr:description'][0] : '',
                                longLegalContent: (item.subtitle) ? item.subtitle[0] : ''
                            });
                        }
                    });
                    return hylaPromoRequiredDetails;
                }

                /**
                 * Gets the Hyla Promo details
                 * @function getHylaOfferInfo
                 * @private
                 * @param {object} sku
                 * @returns {object} hyla promo details
                 */
                function getHylaOfferInfo (sku) {
                    if ($scope.type !== 'upsellOffer' &&
                        sku.wirelessHylaOfferInfo) {

                        deviceConfig.isHylaOpted = sku.wirelessHylaOfferInfo.defaultChecked;

                        return {
                            defaultChecked: sku.wirelessHylaOfferInfo.defaultChecked,
                            acceptanceNeeded: sku.wirelessHylaOfferInfo.acceptanceNeeded,
                            eligible: sku.wirelessHylaOfferInfo.eligible
                        };
                    }
                }

                /**
                 * Scope function to show/hide hyla promo details on the view
                 * @function showHylaOffer
                 * @public
                 * @param {object} sku
                 * @returns {boolean}
                 */
                function showHylaOffer (sku) {
                    // Show the checkbox and the details of hyla promo if the commitment term is not regular
                    // and the selected sku is eligible for hyla offer
                    // and the user is in zippy upgrade flow
                    var storedProfile = $window.sessionStorage.getItem(exCommonConstants.profileStorageKey);
                    var exUpFlow = JSON.parse(storedProfile).ProfileInfo.exUpFlow;
                    return (deviceConfig.isWidget !== true &&
                        exUpFlow &&
                        sku &&
                        sku.wirelessHylaOfferInfo &&
                        sku.wirelessHylaOfferInfo.eligible &&
                        sku.selectedCommitmentTerm.type !== 'regular') ? true : false;
                }

                /** Gets default opted value for hyla promo
                 * @function getHylaOpted
                 * @private
                 * @param {object} sku
                 * @returns {boolean} the default checked value
                 */
                function getHylaOpted (sku) {
                    return (sku.wirelessHylaOfferInfo &&
                        (sku.wirelessHylaOfferInfo.defaultChecked ||
                        sku.wirelessHylaOfferInfo.acceptanceNeeded !== true)) ? true : false;
                }

                /**
                 * Function to close hyla promotion modal
                 * @function closeHylaModal
                 */
                function closeHylaModal () {
                    exHelpUtils.closeActiveModal();
                    angular.element('html').addClass('styled-by-modal');
                }

                /** Gets the primary losgid of line selected by user from checkout when editing that line
                 * @function getPrimaryLOSGFromCheckout
                 * @private
                 * @returns {string} the primary losgID selecteed by user
                 */
                function getPrimaryLOSGFromCheckout () {
                    var primaryLosgID = '';
                    // checkout team must always pass us only one losg object that is only the line selected by the user.
                    if (Object.keys(deviceConfig.losgInContext.losgId).length === 1) {
                        primaryLosgID = Object.keys(deviceConfig.losgInContext.losgId)[0];
                    }
                    return primaryLosgID;
                }

                /**
                 * Gets information about the sku
                 * Stores siblings in a 2d array if there are multiple variants.
                 * Converts siblings in a 1d array if there is only one variant.
                 * @private deviceConfig.getDeviceInformation
                 * @param {string} skuId The selected sku
                 */
                function getDeviceInformation (skuId) {
                    var params = {
                        includeAssociatedProducts: true,
                        includePrices: true,
                        skuId: skuId,
                        groupResultsByVariants: true,
                        filterOffers: $scope.type === 'upsellOffer'
                    };

                    // Passing currentLosgId whenever getDeviceDetails service is called on a widget
                    if (deviceConfig.isWidget === true) {
                        params.currentLosgId = getPrimaryLOSGFromCheckout();
                    }

                    // If upsell offer the offerId must be passed
                    if ($scope.type === 'upsellOffer' && deviceConfig.isWidget !== true) {
                        params.offerId = $scope.offerId;
                    }

                    deviceConfigSrv.getDeviceDetails(skuId, params).then(function (data) {
                        data = data.data.result.methodReturnValue;
                        if (data !== null) {
                            // Removes preexisting sku-specific information
                            deviceConfig.selectedSku = {};
                            deviceConfig.focusedSku = {};
                            deviceConfig.capacityVariants = [];
                            deviceConfig.sizeVariants = [];
                            deviceConfig.colorVariants = [];
                            deviceConfig.skuSiblings = [];
                            deviceConfig.model = '';
                            deviceConfig.manufacturer = '';
                            deviceConfig.shortDisplayName = '';
                            deviceConfig.monthlyPrice = null;
                            deviceConfig.selectedTerm = null;
                            deviceConfig.redirectUrl = null;
                            deviceConfig.skuId = skuId;

                            // Product-level information
                            deviceConfig.manufacturer = data.manufacturer;
                            deviceConfig.model = data.model;
                            deviceConfig.shortDisplayName = data.shortDisplayName;
                            deviceConfig.hasSizeVariants = data.hasSizeVariants;

                            // Formats selected sku and sku siblings
                            if (data.hasSizeVariants === true) {

                                // If product has both color and capacity
                                deviceConfig.selectedSku = formatSku(data.sizeVariantsMap[data.selectedSkuSize][skuId]);

                                // Converts map into 2d array, strips out unnecessary information
                                deviceConfig.skuSiblings = Object.keys(data.sizeVariantsMap).map(function (key1) {
                                    return Object.keys(data.sizeVariantsMap[key1]).map(function (key2) {
                                        var sku = data.sizeVariantsMap[key1][key2];
                                        return formatSku(sku);
                                    }).sort(marketingSequenceSort);
                                });

                                // Get delivery Message for devices
                                $scope.getEnjoyOrBopisDeliveryPromise(data.sizeVariantsMap, 'hasSizeVariants');

                                deviceConfig.capacityVariants = $scope.getCapacityVariants(deviceConfig.selectedSku, deviceConfig.skuSiblings);
                                deviceConfig.colorVariants = $scope.getColorVariants(deviceConfig.selectedSku, deviceConfig.skuSiblings);

                            } else if (data.hasAccSizeVariants === true) {

                                // If product has both color and capacity
                                deviceConfig.selectedSku = formatSku(data.accessorySizeVariantsMap[data.selectedSkuSize][skuId]);

                                // Converts map into 2d array, strips out unnecessary information
                                deviceConfig.skuSiblings = Object.keys(data.accessorySizeVariantsMap).map(function (key1) {
                                    return Object.keys(data.accessorySizeVariantsMap[key1]).map(function (key2) {
                                        var sku = data.accessorySizeVariantsMap[key1][key2];
                                        return formatSku(sku);
                                    }).sort(marketingSequenceSort);
                                });

                                // Get delivery Message for devices
                                $scope.getEnjoyOrBopisDeliveryPromise(data.accessorySizeVariantsMap, 'hasAccSizeVariants');

                                deviceConfig.sizeVariants = $scope.getSizeVariants(deviceConfig.selectedSku, deviceConfig.skuSiblings);
                                deviceConfig.colorVariants = $scope.getColorVariants(deviceConfig.selectedSku, deviceConfig.skuSiblings);
                            } else if (data.hasColorVariants === true) {

                                // If product only has color
                                deviceConfig.selectedSku = formatSku(data.colorVariantsMap[skuId]);

                                // Get delivery Message for devices
                                $scope.getEnjoyOrBopisDeliveryPromise(data.colorVariantsMap, 'hasColorVariants');

                                // Converts map into array, strips out unnecessary information
                                deviceConfig.colorVariants = Object.keys(data.colorVariantsMap).map(function (key) {
                                    var sku = data.colorVariantsMap[key];
                                    return formatSku(sku);
                                }).sort(marketingSequenceSort);
                            } else {

                                // Get delivery Message for devices
                                $scope.getEnjoyOrBopisDeliveryPromise(data.selectedSkuDetails, 'hasNoVariants');

                                // Product has no variants
                                deviceConfig.selectedSku = formatSku(data.selectedSkuDetails);
                            }

                            // Sets focused sku
                            deviceConfig.focusedSku = {
                                color: deviceConfig.selectedSku.color,
                                capacity: deviceConfig.selectedSku.capacity
                            };

                            fetchShortLegalContentForSelectedDevice(deviceConfig.selectedSku.priceList);

                            // Gets formatted device type (pda -> phone)
                            deviceConfig.deviceType = upgradingUserInfoSrv.getDeviceType(deviceConfig.selectedSku.deviceType);

                            // Sets default term and flag to determine if price is lease(monthly)/regular(full price)
                            deviceConfig.selectedTerm = deviceConfig.selectedTerm || deviceConfig.selectedSku.priceList[0].name;
                            deviceConfig.monthlyPrice = getMonthlyPrice(deviceConfig.selectedSku.selectedCommitmentTerm);

                            // Sets offerId if upsell cart widget
                            if (($scope.type === 'upsellOffer' && exHelpUtils.getValue('initargs.type', $scope) === 'cart') || exHelpUtils.getValue('initargs.type', $scope) === 'upsellCart') {
                                $scope.offerId = data.offerId;
                            }

                            deviceConfig.redirectUrl = data.nextStepUrl;
                            deviceConfig.devicePageURL = deviceConfig.selectedSku.devicePageURL;
                            $rootScope.$broadcast(exCommonConstants.event.selectedSkuInFocus, deviceConfig);
                            // Broadcast selected sku
                            $scope.$on(exCommonConstants.event.BVInitiated, function () {
                                $rootScope.$broadcast(exCommonConstants.event.BVSkuSelected, deviceConfig);
                            });

                            // show/hide pre-order warning message based on selected sku
                            showPreOrderMessage(deviceConfig.selectedSku.preOrderable);

                            // show/hide out of stock information based on selected sku
                            showOutOfStockMessage(deviceConfig.selectedSku.effectiveOutOfStock);
                        }

                    });
                }

                /**
                 * Function to return commitment term disclaimer
                 * @function getCommitmentDisclaimer
                 * @param {Object} commitmentTerm
                 * @param {String} raw disclaimer text
                 */
                function getCommitmentDisclaimer (commitmentTerm, disclaimer) {
                    var monthsToUpgrade = commitmentTerm.monthsToUpgrade === null || commitmentTerm.monthsToUpgrade === undefined ? '' : commitmentTerm.monthsToUpgrade;

                    disclaimer = disclaimer.replace('{1}', monthsToUpgrade);

                    if (commitmentTerm.type === 'lease') {
                        disclaimer = disclaimer.replace('{0}', commitmentTerm.leaseTotalMonths);
                    } else if (commitmentTerm.name === '24') {
                        disclaimer = disclaimer.replace('{0}', commitmentTerm.dueToday);
                    }

                    return disclaimer;
                }


                function getEnjoyOrBopisDeliveryPromise (deviceMap, variantType) {
                    var myFavLocalData = $window.sessionStorage.getItem('myFavLocalData');
                    var parseMyFavLocalData = JSON.parse(myFavLocalData);
                    if (deviceMap !== undefined && deviceMap !== null) {
                        if (variantType !== undefined && variantType !== null) {
                            deviceConfig.deviceMap = deviceMap;
                            deviceConfig.variantType = variantType;
                        }
                    }
                    // for delivery promise message Enjoy gets first preference , than BOPIS and afterwards DF
                    deviceConfigSrv.getEnjoyDeliveryPromiseMessage(deviceConfig.selectedSku.skuId)
                        .then(function (enjoyDeliveryPromiseMessage) {
                            if (enjoyDeliveryPromiseMessage.data.personalDeliveryShowLink === true) {
                                storeDeliveryPromiseResults('SDD', enjoyDeliveryPromiseMessage.data);
                                showDeliveryPromiseMessage(deviceConfig.selectedSku.skuId);
                            } else {
                                // for Future if same sku is called , no need to call service again
                                storeDeliveryPromiseResults('SDD', enjoyDeliveryPromiseMessage.data);
                                if (parseMyFavLocalData === null || parseMyFavLocalData === undefined) {
                                    var storeDefaultPromise = {};
                                    storeDefaultPromise.isAvailable = false;
                                    storeDeliveryPromiseResults('BOPIS', storeDefaultPromise);
                                    if (deviceConfig.deliveryPromiseMessage.length === 0) {
                                        getDeliveryPromiseMessage(deviceConfig.deviceMap, deviceConfig.variantType);
                                    } else {
                                        showDeliveryPromiseMessage(deviceConfig.selectedSku.skuId);
                                    }
                                } else {
                                    deviceConfigSrv.getBOPISDeliveryPromiseMessage(parseMyFavLocalData.favStore.locationId, parseMyFavLocalData.favStore.storeAddress.zipCode, deviceConfig.selectedSku.skuId)
                                        .then(function (bopisDeliveryPromiseMessage) {
                                            if (bopisDeliveryPromiseMessage.data.isAvailable === true) {
                                                storeDeliveryPromiseResults('BOPIS', bopisDeliveryPromiseMessage.data);
                                                showDeliveryPromiseMessage(deviceConfig.selectedSku.skuId);
                                            } else {
                                                storeDeliveryPromiseResults('BOPIS', bopisDeliveryPromiseMessage.data);
                                                if (deviceConfig.deliveryPromiseMessage.length === 0) {
                                                    getDeliveryPromiseMessage(deviceConfig.deviceMap, deviceConfig.variantType);
                                                } else {
                                                    showDeliveryPromiseMessage(deviceConfig.selectedSku.skuId);
                                                }
                                            }
                                        });
                                }
                            }
                        });
                }

                function storeDeliveryPromiseResults (promiseType, promiseValue) {
                    var deliveryPromise = {};
                    if (promiseType === 'SDD') {
                        deliveryPromise.SKUId = deviceConfig.selectedSku.skuId;
                        deliveryPromise.deliveryDateMessage = exCommonConstants.deliveryDatePromiseMessage.enjoyPromiseMessage;
                        deliveryPromise.isAvailable = promiseValue.personalDeliveryShowLink;
                        deviceConfig.sddDeliveryPromiseMessage[deviceConfig.selectedSku.skuId] = deliveryPromise;
                    } else {
                        deliveryPromise.SKUId = deviceConfig.selectedSku.skuId;
                        if (promiseValue.isAvailable === true) {
                            deliveryPromise.deliveryDateMessage = exCommonConstants.deliveryDatePromiseMessage.bopisPromiseMessage
                                .replace('{0}', getTodayTomorrowIndicator(promiseValue));
                        }
                        deliveryPromise.isAvailable = promiseValue.isAvailable;
                        deviceConfig.bopisDeliveryPromiseMessage[deviceConfig.selectedSku.skuId] = deliveryPromise;
                    }
                }

                function getTodayTomorrowIndicator (bopisData) {
                    var zones = {
                        'EST': -5,
                        'EDT': -4,
                        'CST': -6,
                        'CDT': -5,
                        'MST': -7,
                        'MDT': -6,
                        'PST': -8,
                        'PDT': -7,
                        'AST': -4,
                        'ADT': -3,
                        'HAST': -10,
                        'HADT': -10,
                        'AKST': -9,
                        'AKDT': -8
                    };
                    var days = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
                    var minuteInAnHOur = 60;
                    var d = new Date(new Date().getTime() + (new Date().getTimezoneOffset()
                            + (zones[bopisData.favStore.timeZone] ? zones[bopisData.favStore.timeZone] * minuteInAnHOur : -new Date().getTimezoneOffset())) * minuteInAnHOur * 1000);
                    var currentTimeInMinutes = parseInt((d.getHours() * minuteInAnHOur)) + parseInt(d.getMinutes());
                    var currentDay = days[d.getDay()] + 'ClosingTime';
                    var closingTimeTodayInMinutes = (bopisData.favStore[currentDay].split(':')[0]) * minuteInAnHOur;
                    // BOPIS order for today can only be placed till two hours before store closing time
                    if ((closingTimeTodayInMinutes - currentTimeInMinutes) >= (2 * minuteInAnHOur)) {
                        return 'today';
                    } else {
                        return 'tomorrow';
                    }
                }

            }]);
})();