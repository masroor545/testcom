(function () {
    'use strict';

    /**
     * This directive serves the purpose show protection plan on accessory hub page.
     *
     * __Requirements:__
     * * Loads the protection plan on accessory hub page
     * * It will be shown if user has not insurance on their current device
     *
     * @module exProtectionPlan
     *
     * @see {@link ../controllers/#module_protectionPlanCtrl|protectionPlanCtrl}
     *
     * @example @lang html
     * <ex-protection-plan></ex-protection-plan>
     */
    angular.module('exCommon')

        .directive('exProtectionPlan', [function () {
            return {
                restrict: 'EA',
                templateUrl: function (ele, attr) {
                    return attr.templateName ? attr.templateName : '/templates/exprotectionplan.html';
                },
                controller: 'protectionPlanCtrl'
            };
        }]);
})();