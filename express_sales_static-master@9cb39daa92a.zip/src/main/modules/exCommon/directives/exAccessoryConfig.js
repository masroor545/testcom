(function () {
    'use strict';

    angular.module('exCommon')

        .directive('exAccessoryConfig', [function () {
            return {
                restrict: 'EA',
                templateUrl: function (ele, attr) {
                    return attr.templateName ? attr.templateName : '/templates/exaccessoryconfig.html';
                },
                controller: 'accessoryConfigCtrl'
            };
        }]);
})();
