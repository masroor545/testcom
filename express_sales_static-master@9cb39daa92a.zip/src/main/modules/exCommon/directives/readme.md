# exCommon Directives

### <a name='exUpgradingUserInfo'></a> `exUpgradingUserInfo`

##### Description:
This directive serves the purpose to display the current device of the user, which he wants to upgrade.

##### Usage:

```html
<exUpgradingUserInfo templateName="/templates/exUpgradingUserInfo.html">
</exUpgradingUserInfo>
```

##### Attributes:
* ```templateName``` (optional) - /templates/exUpgradingUserInfo.html

##### Requirements:
* displays the current line of the user which he wants to upgrade
* displays the current device details of the user

---
---

### <a name='exAddLineUserInfo'></a> `exAddLineUserInfo`

##### Description:
This directive serves the purpose to display the current device of the user, which he wants to add a new line to his account.

##### Usage:

```html
<exAddLineUserInfo templateName="/templates/exAddLineUserInfo.html">
</exAddLineUserInfo>
```

##### Attributes:
* ```templateName``` (optional) - /templates/exAddLineUserInfo.html

##### Requirements:
* displays the current line of the user which he wants to add a line
* displays the current details of the user

---
---

### <a name='exDeviceConfig'></a> `exDeviceConfig`

##### Description:
Displays the device config of the user's selected device.
Accepts a type parameter to configure what instance of the config it is. The template defaults to /templates/exdeviceconfig.html

##### Usage:

```html
<div ex-device-config template-name="/templates/notexdeviceconfig.html"></div>

<div ex-device-config type="hero"></div>
```

##### Requirements:
* displays the selected item image
* displays selected item name
* displays priceblock
* displays an add to cart button

___
___

### <a name='exPricingOptions'></a> `exPricingOptions`

##### Description:
Displays the pricing options available based off the differnet commitmentTerms the user is eligbile for. The template defaults to /templates/expricingoptions.html

##### Usage:

```html
<div ex-pricing-options template-name="/templates/notexdevicedetails.html"></div>

<div ex-pricing-options></div>
```

##### Requirements:
* displays the selected item's make, model, color, capacity
* displays the commitment terms available if the user is qualified for that pricing
* displays an Update pricing Selection button
* clicking the the button results in the price of the device selected.

___
___

### <a name='exProtectionPlanLegal'></a> `exProtectionPlanLegal`

##### Description:
Displays the insurance options legal content based off what was selected from the insurance options page. It will use the parent controller from where it is being called for that way we would not need to fetch data again. The template defaults to /templates/exprotectionplanlegal.html

##### Usage:

```html
<div ex-protection-plan-legal template-name="/templates/notprotectionplanlegal.html"></div>

<div ex-protection-plan-legal></div>
```

##### Requirements:
* displays the long legal content generated from cq shared content for the specific insurance selected from insurance options page
* displays an add to cart button
* displays a cancel button
* clicking the add to cart button results checking the cart and seeing if the in the insurance plan selected being added to the cart is there or not. If it is not there in the cart then it adds the insurance selected to cart and closes all the modals. If the insurance is in the cart then it will just close the modal without any furthur action.
* clicking the cancel button will close all the modals present without any further action.

___
___

### <a name='exDeviceDetails'></a> `exDeviceDetails`

##### Description:
Displays the details of the user's selected device. The template defaults to /templates/exdevicedetails.html

##### Usage:

```html
<div ex-device-details template-name="/templates/notexdevicedetails.html"></div>

<div ex-device-details></div>
```

##### Requirements:
* displays the selected item's make, model, color, capacity
* displays an accordion of other device details
* displays an add to cart button
* displays a button to return to the device config on mobile
___
___

### <a name='exAccessoryConfig'></a> `exAccessoryConfig`

##### Description:
Displays the accessory config of the user's selected accessory. The template defaults to /templates/exaccessoryconfig.html

##### Usage:

```html
<div ex-accessory-config template-name="/templates/notexaccessoryconfig.html"></div>

<div ex-accessory-config display-type="overlay"></div>
```

##### Requirements:
* displays the selected item image
* displays selected item name
* displays priceblock
* displays an add to cart button
___
___

### <a name='exDeviceCard'></a> `exDeviceCard`

##### Description:
Displays the device card of the user's in card device. The template defaults to /templates/exdevicecard.html

##### Usage:

```html
<div ex-device-card template-name="/templates/notexdevicecard.html"></div>

<div ex-device-card></div>

<ex-device-card></ex-device-card>
```
##### Attributes:
* ```templateName``` (optional) - path of html template
* ```commitmentTermLabels (required)```  - labels for commitment terms
* ```deviceCardTimer (required)```  - to display device card for given milliseconds
 * ```forNMonthsLabel (required)```  - label to show no of months for selected commitment term is valid

##### Requirements:
* displays the in cart device details like device name, device color, device size and its prize.
___
___

### <a name='exInsuranceOptions'></a> `exInsuranceOptions`

##### Description:
Displays the insurance options available based off the insurance soc's passed from catalog. The template defaults to /templates/exinsuranceoptions.html

##### Usage:

```html
<div ex-insurance-options template-name="/templates/notexinsuranceoptions.html"></div>

<div ex-insurance-options></div>
```

##### Requirements:
* displays the protection plan image 
* displays the insurance plans available if the user is qualified
* displays an add to cart  button
* clicking the the button results in the insurance being added to the cart
* displays an cancel  button
* clicking the the button results in the user taken back to the accessory recommender page

___
___