(function () {
    'use strict';

    define(['exProtectionPlanDetails'], function () {
        describe('src/main/modules/exCommon/directives/exProtectionPlanDetails.spec.js', function () {
            describe('exProtectionPlanDetails directive of exCommon', function () {
                var element, scope, $rootScope, $compile, html;

                beforeEach(function () {
                    module('exCommon', function ($provide, $controllerProvider) {
                        $controllerProvider.register('protectionPlanDetailsCtrl', function ($scope) {
                            $scope.addProtectionPlanToCart = function () { return true; };
                        });
                    });

                    inject(function ($injector) {
                        $rootScope = $injector.get('$rootScope');
                        $compile = $injector.get('$compile');
                    });

                    html = '<div ex-protection-plan-details></div>';
                    element = angular.element(html);
                    scope = $rootScope.$new();
                    $compile(element)(scope);
                    scope = element.isolateScope() || element.scope();
                });
                it('should have the correct HTML rendered and binding for legal content shown be done', function () {
                    scope.$apply();
                    expect(element.html()).toContain('ng-bind-html="protectionPlanDetails.legalDescription"');
                    expect(element.html()).toContain('ng-bind-html="protectionPlanDetails.legalHeader"');
                });
            });
        });
    });
})();
