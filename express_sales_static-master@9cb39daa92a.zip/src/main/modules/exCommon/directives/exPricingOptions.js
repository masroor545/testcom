(function () {
    'use strict';

    angular.module('exCommon')

        .directive('exPricingOptions', [function () {
            return {
                restrict: 'E',
                templateUrl: function (ele, attr) {
                    return attr.templateName ? attr.templateName : '/templates/expricingoptions.html';
                }
            };
        }]);
})();
