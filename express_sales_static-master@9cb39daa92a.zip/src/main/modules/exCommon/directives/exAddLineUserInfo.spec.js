(function () {
    'use strict';

    define(['exAddLineUserInfo'], function () {
        describe('src/main/modules/exCommon/directives/exAddLineUserInfo.spec.js', function () {
            describe('exAddLineUserInfo directive of exCommon', function () {
                var $scope, $rootScope, $compile, template, templateAsHtml;

                beforeEach(function () {
                    module('exCommon', function ($provide, $controllerProvider) {
                        $controllerProvider.register('addLineUserInfoCtrl', function ($scope) {
                            // Set some values on your $scope
                            $scope.user = {};
                            $scope.user.accountName = "GLORIA's";
                            $scope.user.planName = ["Unlimited Plus"];
                        });
                    });

                    inject(function ($injector) {
                        $rootScope = $injector.get('$rootScope');
                        $compile = $injector.get('$compile');
                    });

                    $scope = $rootScope.$new();
                    // $compile the template, and pass in the $scope. This will find your directive and run everything
                    template = $compile('<ex-add-line-user-info></ex-add-line-user-info>')($scope);
                    // Now run a $digest cycle to update your template with new data
                    $scope.$digest();
                    // Render the template as a string
                    templateAsHtml = template.html();
                });

                it('should render the subscriber name and ctn as passed in by $scope', inject(function () {
                    // Verify that the $scope variables are in the template
                    expect(templateAsHtml).toContain($scope.user.accountName);
                    expect(templateAsHtml).toContain($scope.user.planName);
                }));
            });
        });
    });
})();
