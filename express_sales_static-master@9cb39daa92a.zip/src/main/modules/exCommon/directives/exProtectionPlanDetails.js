(function () {
    'use strict';

    /**
     * This directive serves the purpose to show protection plan details modal to user.
     *
     * __Requirements:__
     * * Loads the protection plan on accessory hub page
     * * It will be shown if user does not insurance on their current device
     *
     * @module exProtectionPlanDetails
     *
     * @property {*} [defaultInsuranceBillCode] - @todo implement details
     *
     * @see {@link ../controllers/#module_protectionPlanDetailsCtrl|protectionPlanDetailsCtrl}
     *
     * @example @lang html
     * <ex-protection-plan-details></ex-protection-plan-details>
     */
    angular.module('exCommon')

        .directive('exProtectionPlanDetails', [function () {
            return {
                restrict: 'EA',
                templateUrl: function (ele, attr) {
                    return attr.templateName ? attr.templateName : '/templates/exprotectionplandetails.html';
                },
                scope: {
                    defaultInsuranceBillCode: '@?'
                },
                controller: 'protectionPlanDetailsCtrl'
            };
        }]);
})();