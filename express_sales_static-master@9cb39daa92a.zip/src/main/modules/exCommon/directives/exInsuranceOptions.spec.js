(function () {
    'use strict';

    define(['exInsuranceOptions'], function () {
        describe('src/main/modules/exCommon/directives/exInsuranceOptions.spec.js', function () {
            describe('exInsuranceOptions directive of exCommon', function () {
                var element, scope, $rootScope, $compile, html;

                beforeEach(function () {
                    module('exCommon');

                    inject(function ($injector) {
                        $rootScope = $injector.get('$rootScope');
                        $compile = $injector.get('$compile');
                    });
                    html = '<ex-insurance-options></ex-insurance-options>';
                    element = angular.element(html);
                    scope = $rootScope.$new();
                    scope.insurancePlans = {
                        'options': [{
                            'displayName': 'AT&amp;T Mobile Protection Pack',
                            'mrc': 11.99
                        },
                        {
                            'displayName': 'AT&amp;T Multi-Device Protection Pack',
                            'mrc': 34.99
                        },
                        {
                            'displayName': 'AT&amp;T Mobile Insurance',
                            'mrc': 8.99
                        }
                        ]


                    };
                    $compile(element)(scope);
                    scope.$apply();
                    scope = element.isolateScope() || element.scope();

                });
                describe('exInsuranceOptions template of exCommon', function () {
                    it('should display information about the insurance', function () {
                        expect(element.html()).toContain(scope.insurancePlans.options[0].displayName);
                        expect(element.html()).toContain(scope.insurancePlans.options[0].mrc);
                        expect(element.html()).toContain(scope.insurancePlans.options[1].displayName);
                        expect(element.html()).toContain(scope.insurancePlans.options[1].mrc);
                        expect(element.html()).toContain(scope.insurancePlans.options[2].displayName);
                        expect(element.html()).toContain(scope.insurancePlans.options[2].mrc);
                    });
                });
            });
        });
    });
})();