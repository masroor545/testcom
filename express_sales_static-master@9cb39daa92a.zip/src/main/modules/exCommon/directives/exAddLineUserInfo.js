(function () {
    'use strict';

    /**
     * This directive exists to display the add a line user's information..
     * on device recommender page and device config overlay
     *
     * __Requirements:__
     * * If a user is adding a new line, then on device recommender page and
     * * device config overlay, on the blue info bar, user's profile info
     * * and user's current device information should be displayed
     *
     * @module exAddLineUserInfo
     *
     * @property [template-name = "exaddlineuserinfo.html"] - template to use
     *
     *
     * @example @lang html
     * <ex-add-line-user-info>
     * </ex-add-line-user-info>
     */
    angular.module('exCommon')

        .directive('exAddLineUserInfo', [function () {
            return {
                restrict: 'EA',
                templateUrl: function (ele, attr) {
                    return attr.templateName ? attr.templateName : '/templates/exaddlineuserinfo.html';
                },
                controller: 'addLineUserInfoCtrl'
            };
        }]);
})();
