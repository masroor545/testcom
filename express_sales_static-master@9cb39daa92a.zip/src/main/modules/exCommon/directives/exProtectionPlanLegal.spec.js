(function () {
    'use strict';

    define(['exProtectionPlanLegal'], function () {
        describe('src/main/modules/exCommon/directives/exProtectionPlanLegal.spec.js', function () {
            describe('exProtectionPlanLegal directive of exCommon', function () {
                var element, scope, $rootScope, $compile, html;

                beforeEach(function () {
                    module('exCommon');

                    inject(function ($injector) {
                        $rootScope = $injector.get('$rootScope');
                        $compile = $injector.get('$compile');
                    });
                    html = '<ex-protection-plan-legal></ex-protection-plan-legal>';
                    element = angular.element(html);
                    scope = $rootScope.$new();
                    scope.insurancePlans = {selectedInsurance: {
                        'legalDescription': '$7.99 per mobile number enrolled',
                        'legalHeader': 'AT&amp;T Mobile Insurance program details'
                    }};
                    $compile(element)(scope);
                    scope.$apply();
                    scope = element.isolateScope() || element.scope();

                });
                describe('exInsuranceOptions template of exCommon', function () {
                    it('should display information about the insurance', function () {
                        expect(element.html()).toContain(scope.insurancePlans.selectedInsurance.legalDescription);
                        expect(element.html()).toContain(scope.insurancePlans.selectedInsurance.legalHeader);
                    });
                });
            });
        });
    });
})();
