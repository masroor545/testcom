(function () {
    'use strict';

    define(['exAccessoryConfig'], function () {
        describe('src/main/modules/exCommon/directives/exAccessoryConfig.spec.js', function () {
            describe('exAccessoryConfig directive of exCommon', function () {
                var element, scope, $rootScope, $compile, $httpBackend;

                beforeEach(function () {
                    module('exCommon', function ($provide, $controllerProvider) {
                        $controllerProvider.register('accessoryConfigCtrl', function ($scope) {
                            $scope.accessoryConfig = {
                                'productDisplayName': 'Fitbit Blaze',
                                accessoriesInCart: {
                                    'skuId': 'NOTsku1234567'
                                },
                                selectedSku: {
                                    'skuId': 'sku1234567',
                                    'size': 'L',
                                    'color': 'Black',
                                    'rating': 4.3,
                                    'price': 149.99,
                                    'imgUrl': '/path/to/fitbit.png',

                                    'colorVariant': {
                                        id: 'Black',
                                        colorCode: '#000000'
                                    },

                                    'sizeVariant': {
                                        id: 'L'
                                    }
                                }
                            };

                            $scope.close = function () {
                                return true;
                            };

                            $scope.showAccessoryDetails = function () {
                                return true;
                            };
                            $scope.accessoryConfigAddToCart = function () {
                                return true;
                            };
                            $scope.accessoryConfigRemoveItemFromCart = function () {
                                return true;
                            };
                        });
                    });

                    inject(function ($injector) {
                        $rootScope = $injector.get('$rootScope');
                        $compile = $injector.get('$compile');
                        $httpBackend = $injector.get('$httpBackend');
                    });

                    // Catches all backend calls because we have directives that make calls we don't care about
                    $httpBackend.whenGET('').respond(200, '');


                    var html = '<ex-accessory-config></ex-accessory-config>';

                    element = angular.element(html);
                    scope = $rootScope.$new();
                    $compile(element)(scope);
                    scope.$apply();
                    scope = element.isolateScope() || element.scope();
                    scope.$dismiss = function () {
                        return true;
                    };
                });

                describe('exaccessoryconfig template of exCommon', function () {
                    it('should display information about the selected accessory', function () {
                        expect(element.html()).toContain(scope.accessoryConfig.productDisplayName);
                        expect(element.html()).toContain(scope.accessoryConfig.selectedSku.size);
                        expect(element.html()).toContain(scope.accessoryConfig.selectedSku.color);
                        expect(element.html()).toContain(scope.accessoryConfig.selectedSku.rating);
                        expect(element.html()).toContain(scope.accessoryConfig.selectedSku.price);
                        expect(element.html()).toContain(scope.accessoryConfig.selectedSku.imgUrl);
                    });

                    describe('accessory config as a modal', function () {

                        it('should should provide a link to the accessory details section', function () {
                            var seeDetailsElement = element.find('#config-see-accessory-details')[0];
                            expect(seeDetailsElement).toBeDefined();
                            spyOn(scope, 'showAccessoryDetails');
                            seeDetailsElement.click();
                            expect(scope.showAccessoryDetails).toHaveBeenCalled();
                        });

                        it('should provide a button to close itself', function () {
                            spyOn(scope, 'close');
                            element.find('.config-close-btn')[0].click();
                            expect(scope.close).toHaveBeenCalled();
                        });

                        it('should provide a button to add to cart when the item has not yet been added to cart', function () {
                            var addToCartElement = element.find('.config-add-to-cart')[0];
                            expect(addToCartElement).toBeDefined();
                            expect(addToCartElement.getAttribute('class')).not.toContain('ng-hide');

                            spyOn(scope, 'accessoryConfigAddToCart');
                            addToCartElement.click();
                            expect(scope.accessoryConfigAddToCart).toHaveBeenCalled();
                        });

                        it('should provide a button to remove from cart when the item already exists in cart', function () {
                            var removeFromCartElement;
                            var mockCommerceItemId;

                            // Mock the selected sku in cart
                            mockCommerceItemId = 'mock data';
                            scope.accessoryConfig.accessoriesInCart[scope.accessoryConfig.selectedSku.skuId] = mockCommerceItemId;
                            scope.$apply();

                            removeFromCartElement = element.find('.config-remove-from-cart')[0];
                            expect(removeFromCartElement).toBeDefined();
                            expect(removeFromCartElement.getAttribute('class')).not.toContain('ng-hide');

                            spyOn(scope, 'accessoryConfigRemoveItemFromCart');
                            removeFromCartElement.click();
                            expect(scope.accessoryConfigRemoveItemFromCart).toHaveBeenCalledWith(scope.accessoryConfig.selectedSku.skuId);
                        });

                    });


                });

            });
        });
    });
})();
