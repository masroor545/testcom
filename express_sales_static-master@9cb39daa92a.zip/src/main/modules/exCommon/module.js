(function () {
    'use strict';

    angular.module('exCommon', ['ngSanitize', 'ngCookies', '/templates/exCommon']);
})();
