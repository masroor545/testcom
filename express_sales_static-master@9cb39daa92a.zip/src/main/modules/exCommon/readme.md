# exCommon

This module contains functionality shared between the modules.

### Directory
* **controllers** - controllers expose in the module
* **directives** - directives exposed in the module
* **html** - markup used by the directives
* **services** - service used by the controllers / directives 

