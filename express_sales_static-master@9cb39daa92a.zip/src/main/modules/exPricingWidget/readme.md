# exPricingWidget

This module contains functionality that is related to the change your commitment term functionality. This will be leveraged
for inline edits and any other various plateforms that would want to allow the user to change the device Price. 

### Initialization Arguments

The following key value pairs are passed into `scope.initargs`:

* skuID - [String] unique id for the widget etc...
```javascript
{
    skuID: 'Skuid Value',    // SkuID passed when calling the widget
}
```

### Event Information

Sends:

* DEVICE_ADDED - signals the add to cart occured after the click of the 'update pricing' button

### deviceConfigCtrl

##### Description:
This controller contains functionality that is related to the change your commitment term functionality. This will be leveraged
for inline edits and any other various plateforms that would want to allow the user to change the device Price.

**See:** [deviceConfigCtrl Documentation](../../../main/modules/exCommon/controllers/)

---
---