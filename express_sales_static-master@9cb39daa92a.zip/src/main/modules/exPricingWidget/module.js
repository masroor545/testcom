/*global widget*/
(function () {
    'use strict';

    angular.module('exPricingWidget', []);

    angular.module('exPricingWidgetModule', ['ng', 'exPricingWidget', 'exCommon'])

        .provider('widget', function widgetProvider () {
            this.config = {
                'exPricingWidget': {
                    'currentState': 'state1',
                    'states': {
                        'state1': {
                            'templateURL': '/templates/expricingoptions.html',
                            'controller': 'deviceConfigCtrl'
                        }
                    },
                    'styleSource': ['/styles/pricing.min.css']
                }
            };

            this.setConfig = function (config) {
                this.config = config;
            };

            this.$get = [function widgetFactory () { return new widget(this.config); }];
        });


})();