# exUpgrade

This module contains functionality related to upgrading lines and other upgrades

### Directory
* **controllers** - controllers expose in the module
* **directives** - directives exposed in the module
* **html** - markup used by the directives
* **services** - service used by the controllers / directives 