(function () {
    'use strict';

    angular.module('exUpgrade')

        .factory('upgradeEligSrv', ['$http', 'exUpgradeConstants', 'exCommonConstants', '$window', '$q',
            function ($http, exUpgradeConstants, exCommonConstants, $window, $q) {
                var storageKey = exUpgradeConstants.upgradeEligibility;
                var services = {
                    fetchUserDetails: fetchUserDetails,
                    upgradeSelectedLines: upgradeSelectedLines
                };

            /**
             * gets the upgrade eligible lines details from upgradeEligibility api
             * @function fetchUserDetails
             * @returns {object} promise upgrade eligibility lines details
             */
                function fetchUserDetails () {
                    var storedProfile;
                    storedProfile = $window.sessionStorage.getItem(storageKey);
                    // we don't want to refresh the profile, and we got it from storage.
                    if (storedProfile !== null && storedProfile !== undefined) {
                        return $q.when(JSON.parse(storedProfile));
                    } else {
                        // load the profile, store it and then return it.
                        return $http.get(exUpgradeConstants.upgradeEligibility).then(function (response) {
                            $window.sessionStorage.setItem(storageKey, JSON.stringify(response.data));
                            return response.data;
                        });
                    }
                }

            /**
             * Makes POST request to the express upgrade api
             * @function upgradeSelectedLines
             * @param {object} params A header params object
             * @returns {object} promise of the express upgrade results
             */
                function upgradeSelectedLines (params) {
                    return $http.post(exUpgradeConstants.expressUpgradeApi,
                    params, {
                        spinner: true,
                        att: [exCommonConstants.http.postAuthReq]
                    }).then(function (resp) {
                        return resp.data;
                    });
                }

                return services;
            }]);
})();
