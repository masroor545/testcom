(function () {
    'use strict';

    angular.module('exUpgrade')

        .factory('upgradeTradeinConsentSrv', ['$http', 'exUpgradeConstants',
            function ($http, exUpgradeConstants) {
                var services = {
                    tradeinConsentContinue: tradeinConsentContinue
                };

                /**
                 * Makes POST request to the express tradein api
                 * @param {object} params A header params object
                 * @returns {object} promise of the express tradein results
                 */
                function tradeinConsentContinue (params) {
                    return $http.post(exUpgradeConstants.upgradeTradeinConsent, params).then(function (resp) {
                        return resp.data;
                    });
                }

                return services;
            }]);
})();
