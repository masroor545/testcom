(function () {
    'use strict';

    angular.module('exUpgrade')

        .factory('upgradeSharedPaymentInfoSrv', ['$window', 'exCommonConstants',
            function ($window, exCommonConstants) {

                var services = {
                    setSharedPaymentInfo: setSharedPaymentInfo,
                    getSharedPaymentInfo: getSharedPaymentInfo
                };

                /**
                 * Set shared information into session storage.
                 * @function setSharedPaymentInfo
                 */
                function setSharedPaymentInfo (sharedData) {
                    $window.sessionStorage.setItem(exCommonConstants.paymentSummaryStorageKey, JSON.stringify(sharedData));
                }

                /**
                 * Get shared information which is saved in into session storage.
                 * @function getSharedPaymentInfo
                 * @returns {object} saved information in into session storage.
                 */
                function getSharedPaymentInfo () {
                    var storedPaymentSummary = $window.sessionStorage.getItem(exCommonConstants.paymentSummaryStorageKey);
                    return JSON.parse(storedPaymentSummary);
                }

                return services;
            }]);
})();