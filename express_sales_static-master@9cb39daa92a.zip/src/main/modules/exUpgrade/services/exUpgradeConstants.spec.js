(function () {
    'use strict';

    define(['exUpgradeConstants'], function () {
        describe('src/main/modules/exUpgrade/services/exUpgradeConstants.spec.js', function () {
            var service;

            beforeEach(module('exUpgrade'));

            beforeEach(function () {
                inject(function ($injector) {
                    service = $injector.get('exUpgradeConstants');
                });
            });

            it('Should check the constant values to be defined', function () {
                expect(service.customerAgreement).toBeDefined();
                expect(service.expressUpgradeApi).toBeDefined();
                expect(service.upgradeEligibility).toBeDefined();
                expect(service.upgradeEligibilityPayment).toBeDefined();
                expect(service.classType).toBeDefined();
                expect(service.UpgradeSelectionInfo).toBeDefined();
                expect(service.eligibleFlag).toBeDefined();
                expect(service.errorStatus).toBeDefined();
                expect(service.errorStatusCode).toBeDefined();
                expect(service.errorStatusCode.isCardDeclined).toBeDefined();
                expect(service.upgradeTradeinConsent).toBeDefined();
                expect(service.upgradePaymentPost).toBeDefined();
                expect(service.upgradedLinesInProgress).toBeDefined();
                expect(service.upgradeOptionsModalPath).toBeDefined();
                expect(service.paymentCardMasterCard).toBeDefined();
                expect(service.paymentCardVisa).toBeDefined();
                expect(service.paymentCardDiscover).toBeDefined();
                expect(service.paymentCardAmericanExpress).toBeDefined();
                expect(service.creditCard).toBeDefined();
                expect(service.imageUrlExtension).toBeDefined();
                expect(service.paymentProfile).toBeDefined();
                expect(service.friendlyPageName).toBeDefined();
                expect(service.virtualUrl).toBeDefined();
                expect(service.event.updatePaymentInfoSubmit).toBeDefined();
                expect(service.event.updatePaymentInfoResponse).toBeDefined();
                expect(service.tradeInPayUpErrorCodes).toBeDefined();
            });
        });
    });
})();