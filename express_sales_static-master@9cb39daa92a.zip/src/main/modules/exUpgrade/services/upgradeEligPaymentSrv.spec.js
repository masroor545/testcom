(function () {
    'use strict';

    define(['upgradeEligPaymentSrv'], function () {
        describe('src/main/modules/exUpgrade/services/upgradeEligPaymentSrv.spec.js', function () {
            describe('upgradeEligPaymentSrv service of exUpgrade', function () {
                var $httpBackend, service, $log;

                beforeEach(function () {
                    module('exUpgrade');

                    inject(function ($injector) {
                        $httpBackend = $injector.get('$httpBackend');
                        $log = $injector.get('$log');
                        service = $injector.get('upgradeEligPaymentSrv');
                        spyOn($log, 'error');
                    });
                });

                describe('fetchPaymentDetails function of the upgradeEligPaymentSrv in exUpgrade', function () {

                    it('should get payment details by calling endpoint of upgrade eligibility payment service', function () {
                        $httpBackend.whenGET(Endpoint_upgradeEligibilityPayment.get_upgrade_payment_details.url_match).respond(200, Endpoint_upgradeEligibilityPayment.get_upgrade_payment_details.result);
                        var userUUID = '976b99d3-9220-0054-61f3-a745c98d6bd2';
                        service.fetchPaymentDetails(userUUID).then(function (result) {
                            expect(result).toBeDefined();
                            expect(result.payload.paymentInfo.paymentMethods.PAYMENT_OPTION_01.cardType).toEqual('MC');
                            expect(result.payload.paymentInfo.paymentMethods.PAYMENT_OPTION_01.displayName).toEqual('MC ending With 2200');
                        });

                        $httpBackend.flush();
                    });
                });
                describe('getUpgradingDevicePaymentData function of the upgradeEligPaymentSrv', function () {

                    it('should get upgrading type and payment amount by calling endpoint rest api', function () {
                        $httpBackend.whenGET(Endpoint_upgradeDevicePayment.getUpgradingDevicePaymentData.url_match).respond(
                            200, Endpoint_upgradeDevicePayment.getUpgradingDevicePaymentData.result);
                        service.getUpgradingDevicePaymentData().then(function (result) {
                            expect(result).toBeDefined();
                            expect(result.payload.upgradeOptionSelected).toEqual('PAYOFF');
                            expect(result.payload.payOffAmount).toEqual(100);
                        });

                        $httpBackend.flush();
                    });
                });

                describe('upgradePaymentContinue function of the upgradeEligPaymentSrv', function () {

                    it('should call the upgradePaymentPost service with the params provided', function () {
                        $httpBackend.whenPOST(Endpoint_upgradePaymentPost.upgrade_payment_post.url_match)
                            .respond(200, Endpoint_upgradePaymentPost.upgrade_payment_post.result);
                        var inputParams = {
                                foo: 'foo',
                                bar: 'bar',
                                baz: 'baz'
                            },

                            userUUID = '976b99d3-9220-0054-61f3-a745c98d6bd2',

                            header = {
                                'X-CCC-AWP-ACCESS-TOKEN': '',
                                'Accept': 'application/json, text/plain, */*',
                                'Content-Type': 'application/json;charset=utf-8'
                            };

                        service.upgradePaymentContinue(userUUID, inputParams);

                        // checking if the required header is passed to the POST method
                        $httpBackend.expectPOST(Endpoint_upgradePaymentPost.upgrade_payment_post.url_match,
                            inputParams, header).respond(201, '');

                        service.upgradePaymentContinue(userUUID, inputParams).then(function (result) {
                            expect(result).toBeDefined();
                            expect(result.payload.ReferenceInformation).toEqual('1013075606');
                        });
                        $httpBackend.flush();
                    });

                    it('should log console error when the upgrade payment request failed', function () {
                        var expectedErrorMessage = 'upgradeEligPaymentSrv.upgradePaymentContinue call failed.';

                        $httpBackend.whenPOST(Endpoint_upgradePaymentPost.upgrade_payment_post.url_match)
                            .respond(404, '');

                        var inputParams = {
                                foo: 'foo',
                                bar: 'bar',
                                baz: 'baz'
                            },

                            userUUID = '976b99d3-9220-0054-61f3-a745c98d6bd2',

                            header = {
                                'X-CCC-AWP-ACCESS-TOKEN': '',
                                'Accept': 'application/json, text/plain, */*',
                                'Content-Type': 'application/json;charset=utf-8'
                            };

                        service.upgradePaymentContinue(userUUID, inputParams);

                        // checking if the required header is passed to the POST method
                        $httpBackend.expectPOST(Endpoint_upgradePaymentPost.upgrade_payment_post.url_match,
                            inputParams, header).respond(201, '');

                        service.upgradePaymentContinue(userUUID, inputParams).then(function () {
                            fail('Response that should have failed, succeeded!');
                        }).catch(function () {
                            expect($log.error).toHaveBeenCalledWith(expectedErrorMessage);
                        });
                        $httpBackend.flush();
                    });
                });

                describe('updateUpgradeEligibility function of the upgradeEligPaymentSrv', function () {

                    it('should get refreshed upgrade eligibility device list by calling endpoint rest api', function () {
                        $httpBackend.whenGET(Endpoint_refreshUpgradeEligibility.get_device_details.url_match).respond(
                            200, Endpoint_refreshUpgradeEligibility.get_device_details.result);
                        service.updateUpgradeEligibility().then(function (result) {
                            expect(result).toBeDefined();
                            expect(result.payload['G20251984'][0].subscriberNumber).toEqual('4256862891');
                            expect(result.payload['Individual'][0].customerFirstName).toEqual('BEDROCK');
                        });

                        $httpBackend.flush();
                    });
                });

            });
        });
    });
})();
