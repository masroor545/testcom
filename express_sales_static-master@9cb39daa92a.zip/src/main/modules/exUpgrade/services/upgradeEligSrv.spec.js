(function () {
    'use strict';

    define(['upgradeEligSrv'], function () {
        describe('src/main/modules/exUpgrade/services/upgradeEligSrv.spec.js', function () {
            describe('upgradeEligSrv service of exUpgrade', function () {
                var $httpBackend, service;

                beforeEach(function () {
                    module('exUpgrade');

                    inject(function ($injector) {
                        $httpBackend = $injector.get('$httpBackend');
                        service = $injector.get('upgradeEligSrv');
                    });
                });

                describe('fetchUserDetails function of the upgradeEligSrv in exUpgrade', function () {

                    it('should get upgrade eligible lines by calling endpoint of upgrade eligibility', function () {
                        $httpBackend.whenGET(Endpoint_upgradeEligibility.get_device_details.url_match)
                            .respond(200, Endpoint_upgradeEligibility.get_device_details.result);

                        service.fetchUserDetails().then(function (result) {
                            expect(result).toBeDefined();
                            expect(result.payload['G20251984'][0].subscriberNumber).toEqual('4256862891');
                            expect(result.payload['Individual'][0].customerFirstName).toEqual('BEDROCK');
                        });
                        $httpBackend.flush();
                    });
                });
                describe('upgradeSelectedLines function of the upgradeEligSrv in exUpgrade', function () {

                    it('should call the express upgarde service with the params provided', function () {
                        $httpBackend.whenPOST(Endpoint_expressUpgradeApi.express_upgrade.url_match)
                            .respond(200, Endpoint_expressUpgradeApi.express_upgrade.result);

                        var inputParams = {
                            foo: 'foo',
                            bar: 'bar',
                            baz: 'baz'
                        };
                        service.upgradeSelectedLines(inputParams).then(function (result) {
                            expect(result).toBeDefined();
                        });
                        $httpBackend.flush();
                    });
                });
            });
        });
    });
})();
