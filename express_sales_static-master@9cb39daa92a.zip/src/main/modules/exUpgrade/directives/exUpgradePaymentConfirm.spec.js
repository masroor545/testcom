(function () {
    'use strict';

    define(['exUpgradePaymentConfirm'], function () {
        describe('src/main/modules/exUpgrade/directives/exUpgradePaymentConfirm.spec.js', function () {
            describe('exUpgradePaymentConfirm directive of exUpgrade', function () {
                var element, scope, $rootScope, $compile;

                beforeEach(function () {
                    module('exUpgrade', function ($provide, $controllerProvider) {
                        $controllerProvider.register('upgradePaymentConfirmCtrl', function ($scope) {
                            $scope.paymentConfirmation = {
                                'paymentDetails': {
                                    'amount': '85',
                                    'paymentDate': 'May 30 2017',
                                    'referenceInformation': '456789'
                                }
                            };
                            $scope.redirectToUpgradeElig = function () {
                                return true;
                            };
                        });
                    });

                    inject(function ($injector) {
                        $rootScope = $injector.get('$rootScope');
                        $compile = $injector.get('$compile');
                    });
                    element = angular.element('<div ex-upgrade-payment-confirm></div>');
                    scope = $rootScope.$new();
                    $compile(element)(scope);
                    scope.$apply();
                    scope = element.isolateScope() || element.scope();
                });

                describe('exupgradepaymentconfirm template of upgradePaymentConfirmCtrl', function () {

                    it('should bind its attributes to scope', function () {
                        expect(scope.paymentConfirmation).toBeDefined();
                    });
                    it('should display details about payment confirmation', function () {
                        expect(element.html()).toContain(scope.paymentConfirmation.paymentDetails.amount);
                        expect(element.html()).toContain(scope.paymentConfirmation.paymentDetails.paymentDate);
                        expect(element.html()).toContain(scope.paymentConfirmation.paymentDetails.referenceInformation);
                    });

                    it('should check cancel button click function', function () {
                        spyOn(scope, 'redirectToUpgradeElig');
                        element.find('.submitPaymentReturn-cta')[0].click();
                        expect(scope.redirectToUpgradeElig).toHaveBeenCalled();
                    });

                });
            });
        });
    });
})();
