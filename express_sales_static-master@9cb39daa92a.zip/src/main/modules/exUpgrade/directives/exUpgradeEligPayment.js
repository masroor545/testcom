(function () {
    'use strict';

    /**
     * Shows the paymnet related details which user has.  Allows the user to change the payment card which they have stored. The template defaults to /templates/exupgradeeligpayment.html
     *
     * __Requirements:__
     * * displays payment summary
     * * displays payment details
     * * displays link to chnage payment card
     * * displays term and condition.
     * * displays submit payment cta.
     * * displays cancel cta.
     *
     * @module exUpgradeEligPayment
     *
     * @property [template-name = exupgradeeligpayment.html] -
     * @property card-declined-msg - Error message when card is declined.
     * @property pay-off-legal - legal terms and conditions in case of payOff.
     * @property pay-up-legal - legal terms and conditions in case of payUp.
     * @property upgrade-payment-payup - The upgrade payment payup message.
     * @property upgrade-payment-payoff - The upgrade payment payoff message.
     *
     * @see {@link ../controllers/#module_upgradeEligPaymentCtrl|upgradeEligPaymentCtrl}
     *
     * @example @lang html
     * <ex-upgrade-elig-payment></ex-upgrade-elig-payment>
     */
    angular.module('exUpgrade')

        .directive('exUpgradeEligPayment', [function () {
            return {
                restrict: 'AE',
                templateUrl: function (ele, attr) {
                    return attr.templateName ? attr.templateName : '/templates/exupgradeeligpayment.html';
                },
                scope: {
                    cardDeclinedMsg: '@',
                    payOffLegal: '@',
                    payUpLegal: '@',
                    upgradePaymentPayup: '@',
                    upgradePaymentPayoff: '@'
                },
                controller: 'upgradeEligPaymentCtrl'
            };
        }]);
})();
