(function () {
    'use strict';

    /**
     * Shows the tradein consent message for upgradeing device. Allows the user to select tradein consent.
     *
     * __Requirements__
     * * displays checkbox to select tradein consent message.
     * * displays continue cta.
     * * displays cancel cta.
     *
     * @module exUpgradeTradeinConsent
     *
     * @property [template-name = 'exupgradetradeinconsent.html']
     * @property tradein-message - The upgrade eligibility messages for each device
     * @property tradin-avoid-charges - Message to avoid charges for customer if their device is not sent back.
     *
     * @see {@link ../controllers/#module_upgradeTradeinConsentCtrl|upgradeTradeinConsentCtrl}
     *
     * @example @lang html
     * <div ex-upgrade-tradein-consent
     *     tradein-message=""
     *     tradein-avoid-charges="">
     * </div>
     */
    angular.module('exUpgrade')

        .directive('exUpgradeTradeinConsent', [function () {
            return {
                restrict: 'AE',
                templateUrl: function (ele, attr) {
                    return attr.templateName ? attr.templateName : '/templates/exupgradetradeinconsent.html';
                },
                scope: {
                    contractAvoidCharges: '@',
                    tradeinMessage: '@',
                    tradeinAvoidCharges: '@'
                },
                controller: 'upgradeTradeinConsentCtrl'
            };
        }]);
})();
