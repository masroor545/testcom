(function () {
    'use strict';

    /**
     * Shows the username and any devices available for upgrade.  Allows the devices to be checked and submited for upgrade. The template defaults to /templates/upgradeeligibility.html
     *
     * __Requirements__
     * * displays user name
     * * displays upgrade device description
     * * displays upgrade details
     * * displays device Image
     * * displays link to show more options to upgrade the device
     * * displays button to upgrade the device
     *
     * @module exUpgrade
     *
     * @property [template-name = 'exupgradelinespage.html']
     * @property [eligibility-message] - ???
     * @property [upgrade-options-messages] - ???
     *
     * @todo Fix documentation of properties to be meaningful
     *
     * @see {@link ../controllers/#module_upgradeEligCtrl|upgradeEligCtrl}
     *
     * @example @lang html
     * <div ex-upgrade-elig
     *     template-name="/templates/upgradeeligibility.html"
     *     eligibility-messages=upgrade_eligibility.upgradeMessages
     *     device-image=url.xpress.imageUrl>
     * </div>
     */
    angular.module('exUpgrade')

        .directive('exUpgradeElig', [function () {
            return {
                restrict: 'EA',
                templateUrl: function (ele, attr) {
                    return attr.templateName ? attr.templateName : '/templates/exupgradelinespage.html';
                },
                scope: {
                    eligibilityMessages: '=',
                    upgradeOptionsMessages: '=',
                    commonApostrophes: '@',
                    commonSeparator: '@',
                    informationMessage: '@',
                    displayUpgradeEligibilityHeading: '@'
                },
                controller: 'upgradeEligCtrl',
                link: function (scope, elem, attr) {
                    if (attr.deviceImage) {
                        scope.deviceImage = attr.deviceImage;
                    }
                }
            };
        }]);
})();