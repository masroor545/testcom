(function () {
    'use strict';

    define(['exUpgradeOptions'], function () {
        describe('src/main/modules/exUpgrade/directives/exUpgradeOptions.spec.js', function () {
            describe('exUpgradeOptions directive of exUpgrade', function () {
                var element, scope, $rootScope, $compile, html;

                beforeEach(function () {
                    module('exUpgrade');

                    inject(function ($injector) {
                        $rootScope = $injector.get('$rootScope');
                        $compile = $injector.get('$compile');
                    });

                    html = '<div ex-upgrade-options></div>';
                    element = angular.element(html);
                    scope = $rootScope.$new();

                    scope.user = {
                        'modalData': {
                            'customerDetailWithDevice': {
                                'customerNameWithDevice': "BEDROCK's SM-T537A",
                                'customerCTNWithDevice': 'SM-T537A | (425) 205-0545'
                            },
                            'contractType': 'Two-year contract ends',
                            'device': {
                                'model': 'SM-T537A'

                            },
                            'optionPageSelection': [
                                {
                                    'upgradeMessageWithPrice': 'Trade in your device to upgrade',
                                    'eligibleFlagMsg': 'this is trade in eligible'
                                },
                                {
                                    'upgradeMessageWithPrice': '',
                                    'eligibleFlagMsg': 'Replace your lost, stolen, or broken device.'
                                },
                                {
                                    'upgradeMessageWithPrice': 'Upgrade this device now',
                                    'eligibleFlagMsg': 'How do you want to upgrade'
                                }
                            ]
                        }
                    };
                    $compile(element)(scope);
                    scope.$apply();
                    scope = element.isolateScope() || element.scope();

                });

                describe('exupgradeoptions template of upgradeEligCtrl', function () {
                    it('should display upgrade line details in option modal', function () {
                        expect(element.html()).toContain(scope.user.modalData.customerDetailWithDevice.customerNameWithDevice);
                        expect(element.html()).toContain(scope.user.modalData.device.model);
                        expect(element.html()).toContain(scope.user.modalData.optionPageSelection[2].upgradeMessageWithPrice);
                        expect(element.html()).toContain(scope.user.modalData.optionPageSelection[2].eligibleFlagMsg);
                    });

                    it('should check hideModal button is available', function () {
                        var hideModalElement = element.find('.option-upgrade-block .close-btn');
                        expect(hideModalElement[0]).toBeDefined();
                    });

                });
            });
        });
    });
})();