(function () {
    'use strict';

    define(['exUpgradeEligPayment'], function () {
        describe('src/main/modules/exUpgrade/directives/exUpgradeEligPayment.spec.js', function () {
            describe('exUpgradeEligPayment directive of exUpgrade', function () {
                var element, scope, $rootScope, $compile;

                beforeEach(function () {
                    module('exUpgrade', function ($provide, $controllerProvider) {
                        $controllerProvider.register('upgradeEligPaymentCtrl', function ($scope) {
                            $scope.upgradePayment = {
                                'paymentInfo': {
                                    'displayName': 'MC Ending With 2200',
                                    'cardType': 'MC'
                                },
                                'upgradeTypeInfo': {
                                    'upgradeType': 'PAYUP',
                                    'paymentAmount': '100'
                                }
                            };
                            $scope.redirectToUpgradeElig = function () {
                                return true;
                            };
                        });
                    });

                    inject(function ($injector) {
                        $rootScope = $injector.get('$rootScope');
                        $compile = $injector.get('$compile');
                    });
                    element = angular.element('<div ex-upgrade-elig-payment upgrade-payment-payup="{key: value}"'
                        + 'upgrade-payment-payoff="{key: value}" pay-off-legal="{key: value}"'
                        + 'pay-up-legal="{key: value}" card-declined-msg="card was declined"></div>');
                    scope = $rootScope.$new();
                    $compile(element)(scope);
                    scope.$apply();
                    scope = element.isolateScope() || element.scope();
                });

                describe('exupgradeeligpayment template of upgradeEligPaymentCtrl', function () {

                    it('should display details about the upgrade payment', function () {
                        expect(scope.upgradePayment).toBeDefined();
                        expect(element.html()).toContain(scope.upgradePayment.paymentInfo.displayName);
                        expect(element.html()).toContain(scope.upgradePayment.paymentInfo.cardType);
                        expect(element.html()).toContain('Total of remaining installments');
                        expect(element.html()).toContain(scope.upgradePayment.upgradeTypeInfo.paymentAmount);
                    });
                    it('should bind its attributes to scope', function () {
                        expect(scope.upgradePaymentPayup).toBeDefined();
                        expect(scope.upgradePaymentPayoff).toBeDefined();
                        expect(scope.payOffLegal).toBeDefined();
                        expect(scope.payUpLegal).toBeDefined();
                        expect(scope.cardDeclinedMsg).toBeDefined();
                    });

                    it('should check cancel button click function', function () {
                        spyOn(scope, 'redirectToUpgradeElig');
                        element.find('.submitPaymentCancel-cta')[0].click();
                        expect(scope.redirectToUpgradeElig).toHaveBeenCalled();
                    });

                });
            });
        });
    });
})();
