(function () {
    'use strict';

    define(['exUpgradeTradeinConsent'], function () {
        describe('src/main/modules/exUpgrade/directives/exUpgradeTradeinConsent.spec.js', function () {
            describe('exUpgradeTradeinConsent directive of exUpgrade', function () {
                var element, scope, $rootScope, $compile;

                beforeEach(function () {
                    module('exUpgrade', function ($provide, $controllerProvider) {
                        $controllerProvider.register('upgradeTradeinConsentCtrl', function ($scope) {
                            $scope.upgradeTradein = {
                                'terms': 'Trade in consent: Trade in consent message',
                                'avoidChargesDesc': 'Pack up your IPhone (16GB) trade-in in your new device box and send it back within 14 days to avoid a charge.'
                            };
                        });
                    });

                    inject(function ($injector) {
                        $rootScope = $injector.get('$rootScope');
                        $compile = $injector.get('$compile');
                    });
                    var tradeinConsentDirective = '<div' +
                        ' ex-upgrade-tradein-consent tradein-message = "{key: value}"' +
                        ' tradein-avoid-charges = "{key: value}"' +
                        ' contract-avoid-charges = "Trade in your Apple device to be eligible for an upgrade. Your device must be working and in good physical condition"' +
                        ' ></div>';
                    element = angular.element(tradeinConsentDirective);
                    $compile(element)($rootScope.$new());
                    $rootScope.$digest();
                    scope = element.isolateScope() || element.scope();
                });

                describe('exupgradetradeinconsent template of upgradeTradeinConsentCtrl', function () {
                    it('should exupgradetradeinconsent', function () {
                        expect(element.html()).toContain(scope.upgradeTradein.terms);
                    });
                    it('should bind its attributes to scope', function () {
                        expect(scope.tradeinMessage).toBeDefined();
                        expect(scope.tradeinAvoidCharges).toBeDefined();
                        expect(scope.contractAvoidCharges).toBeDefined();
                    });
                });
            });
        });
    });
})();
