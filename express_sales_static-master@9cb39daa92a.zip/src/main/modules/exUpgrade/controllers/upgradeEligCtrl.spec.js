(function () {
    'use strict';

    define(['upgradeEligCtrl'], function () {
        describe('src/main/modules/exUpgrade/controllers/upgradeEligCtrl.spec.js', function () {
            describe('upgradeEligCtrl controller of exUpgrade', function () {
                var controller, upgradeEligSrv, scope, $rootScope, $q, profileInfoService, reportingDataSrv,
                    exCommonConstants, exUpgradeConstants, expressUpgrade, getUserDevicedetails,
                    profileInfo, $filter, $window, $modal, $modalStack,
                    exHelpUtils, $cookies, exCartService, upgradingUserInfoSrv;

                expressUpgrade = Endpoint_expressUpgradeApi.express_upgrade;
                getUserDevicedetails = Endpoint_upgradeEligibility.get_device_details;
                profileInfo = Endpoint_profileInfoApi.get_profile_info_auth;

                beforeEach(function () {
                    reportingDataSrv = jasmine.createSpyObj('reportingDataSrv',
                        ['getUpgradeEligibilityExistingItemsPayload',
                            'getUpgradeEligibilitySelectedItemsPayload',
                            'getUpgradeSubmitPayload',
                            'getUpgradeSubmitEvent',
                            'updateEventPayloadFailure']);


                    reportingDataSrv.getUpgradeSubmitPayload.and.returnValue({
                        isMultilineUpgradeEligible: '0',
                        existingItems: [],
                        items: [{itemSku: 'sku12345'}, {itemSku: 'sku1234'}, {itemSku: 'sku123'}]
                    });

                    reportingDataSrv.getUpgradeSubmitEvent.and.returnValue(
                        'DS_Upgrade_Submit'
                    );

                    reportingDataSrv.updateEventPayloadFailure.and.returnValue({
                        errorType: 'Failure_Data',
                        successFlag: '0'
                    });

                    reportingDataSrv.getUpgradeEligibilityExistingItemsPayload.and.returnValue({
                        isMultilineUpgradeEligible: '0',
                        existingItems: []
                    });

                    reportingDataSrv.getUpgradeEligibilitySelectedItemsPayload.and.returnValue({
                        items: [{itemSku: 'sku12345'}, {itemSku: 'sku1234'}, {itemSku: 'sku123'}]
                    });
                });

                beforeEach(function () {
                    module('exUpgrade', function ($provide) {
                        $modalStack = jasmine.createSpyObj('$modalStack', ['close', 'getTop']);
                        $modalStack.getTop.and.returnValue(true);
                        $provide.value('$modalStack', $modalStack);
                        $provide.value('$window', {
                            location: {
                                href: ''
                            },
                            sessionStorage: {
                                getItem: function () { return true; },
                                setItem: function () { return true; },
                                removeItem: function () { return true; }
                            }
                        });
                    });
                    inject(function ($injector) {
                        controller = $injector.get('$controller');
                        $rootScope = $injector.get('$rootScope');
                        $window = $injector.get('$window');
                        exCommonConstants = $injector.get('exCommonConstants');
                        exUpgradeConstants = $injector.get('exUpgradeConstants');
                        scope = $rootScope.$new();
                        $q = $injector.get('$q');
                        $filter = $injector.get('$filter');
                        $window.document = {
                            cookie: {
                                indexOf: function (key) {
                                    return this[key];
                                }
                            }
                        };
                        profileInfoService = {
                            getProfileInfo: function () {
                                return $q.when(profileInfo.result);
                            }
                        };

                        upgradeEligSrv = jasmine.createSpyObj('upgradeEligSrv', ['fetchUserDetails', 'upgradeSelectedLines']);

                        exHelpUtils = jasmine.createSpyObj('exHelpUtils', ['replacePlaceholdersWithContent']);

                        exCartService = jasmine.createSpyObj('exCartService', ['removeItemFromPersistentCart']);

                        upgradingUserInfoSrv = jasmine.createSpyObj('upgradingUserInfoSrv', ['clearUpgradingLineCache', 'getDeviceType']);

                        upgradingUserInfoSrv.clearUpgradingLineCache.and.returnValue(true);
                        upgradingUserInfoSrv.getDeviceType.and.returnValue('phone');

                        exCartService.removeItemFromPersistentCart.and.returnValue({
                            'then': function (callBackFN) {
                                callBackFN(true);
                            }
                        });

                        upgradeEligSrv.fetchUserDetails.and.returnValue({
                            'then': function (callback) {
                                callback(getUserDevicedetails.result);
                            }
                        });

                        upgradeEligSrv.upgradeSelectedLines.and.returnValue({
                            'then': function (callback) {
                                callback(expressUpgrade.result);
                            }
                        });

                        $modal = jasmine.createSpyObj('$modal', ['open']);
                        $modal.open.and.returnValue(true);

                        $cookies = jasmine.createSpyObj('$cookies', ['get']);

                        exHelpUtils.replacePlaceholdersWithContent.and.returnValue({
                            customerNameAndMsg: 'Hi, BEDROCK! Which device would you like to upgrade?',
                            payUp: 'Pay $50.00 and trade in your device to upgrade early',
                            payOff: 'Pay off $70.00 to upgrade early',
                            contractTerm: 'Two-year contract ends Nov.',
                            installmentPlan: '24-month installment plan ends Nov.'
                        });

                        spyOn(profileInfoService, 'getProfileInfo').and.callThrough();
                        spyOn($window.sessionStorage, 'getItem');
                        spyOn($window.sessionStorage, 'setItem');
                        spyOn($window.sessionStorage, 'removeItem');
                        scope.eligibilityMessages = {
                            'accountHolderforSingleLine': 'Hi, {0}! Let’s start your upgrade.',
                            'accountHolderforMultipleLine': 'Hi, {0}! Which device would you like to upgrade?',
                            'hi': 'Hi',
                            'for': 'for',
                            'moreWaysToUpgrade': 'See more ways to upgrade',
                            'upgradeLineNow': 'Upgrade this line now',
                            'upgradeMessages': {
                                'buyAtFullPrice': 'Buy a device at full price',
                                'fullEligible': 'Upgrade now',
                                'splitLiability': 'This device is ready to upgrade but can’t be upgraded online because of the benefits attached to the phone number. To upgrade, please call 888.444.4410.',
                                'tradeIn': 'Trade in your device to upgrade',
                                'tradeInOff': 'Pay off $70.00 to upgrade early',
                                'tradeInUp': 'Pay $50.00 and trade in your device to upgrade early'
                            },
                            'withTradeIn': 'with trade in'
                        };
                        scope.commonSeparator = ' | ';
                        scope.commonApostrophes = "'s";
                        scope.deviceImage = {
                            'imageUrl': '/catalog/en/xpress/'
                        };
                        scope.eligibleFlag = {
                            'none': 'NONE',
                            'payOff': 'PAYOFF',
                            'payUp': 'PAYUP',
                            'replace': 'REPLACE',
                            'tradeIn': 'TRADEIN'
                        };

                        scope.upgradeOptionsMessages = {
                            'buyAtFullPrice': 'Buy a device at full price',
                            'monthInstallment': '{0}-month installment plan ends {1}',
                            'twoYearContract': 'Two-year contract ends {0}',
                            'upgradeHow': 'How do you want to upgrade?',
                            'upgradeDevice': 'Your device is ready to upgrade.',
                            'payOff': 'Pay off $70.00 to upgrade early',
                            'payOffWithPrice': 'Pay off your AT&T Next&reg balance',
                            'tradeIn': 'Trade in your device to upgrade',
                            'tradeInEarly': 'Pay $50.00 and trade in your device to upgrade early',
                            'tradeInCurrent': 'Trade in your current AT&T Next &reg; device',
                            'tradeInWithPrice': 'Want to trade in and upgrade your device?',
                            'replaceYourDevice': 'Replace your lost'
                        };
                        scope.informationMessage = 'Alert message for upgrade eligibility page';

                        // Instantiates controller
                        controller('upgradeEligCtrl', {
                            $scope: scope,
                            $modal: $modal,
                            upgradeEligSrv: upgradeEligSrv,
                            profileInfoService: profileInfoService,
                            reportingDataSrv: reportingDataSrv,
                            exHelpUtils: exHelpUtils,
                            $cookies: $cookies,
                            exCartService: exCartService,
                            upgradingUserInfoSrv: upgradingUserInfoSrv
                        });
                    });
                    $rootScope.$digest();
                    spyOn(scope, '$emit').and.callThrough();
                });

                describe('Basic functionality', function () {
                    it('should remove selected line from session storage', function () {
                        expect(upgradingUserInfoSrv.clearUpgradingLineCache).toHaveBeenCalled();
                    });
                    it('should provide an array of lines to the view', function () {
                        expect(scope.user.lines).toBeDefined();
                        expect(scope.user.lines[0].subscriberNumber).toEqual('4252951809');
                        expect(scope.user.lines[0].customerFirstName).toEqual('BEDROCK');
                        expect(scope.user.lines[0].deviceURL).toEqual(
                            exCommonConstants.deviceCatalogUrlRoot.toLowerCase() + scope.user.lines[0].device.manufacturerForImage.toLowerCase() + '-' +
                            scope.user.lines[0].device.modelForImage.toLowerCase() + '-' + scope.user.lines[0].device.color.toLowerCase() +
                            exUpgradeConstants.imageUrlExtension.toLowerCase());
                    });
                    it('should return a boolean of true or false for multiline flag', function () {
                        expect(typeof scope.user.multiLineEnabledFlag).toEqual('boolean');
                    });
                    it('should return a main account user first name', function () {
                        expect(scope.user.customerNameWithMsg.customerNameAndMsg).toEqual('Hi, BEDROCK! Which device would you like to upgrade?');
                    });
                    it('should return subscriber line that is in progress', function () {
                        expect(scope.user.upgradedLinesInProgress).toEqual('4252050545');
                    });
                    it('should return contract type without date and contract length for reporting implementation', function () {
                        expect(scope.user.lines[1].contractTypeWithoutDate).toEqual('regular');
                        expect(scope.user.lines[1].contractLength).toEqual(24);
                    });
                });
                describe('tradeInOptions based on eligibility', function () {
                    it('should show conditions when payUpAmount is greater than 0', function () {
                        expect(scope.user.lines[0].tradeInOptions.message.payUp).toEqual(scope.eligibilityMessages.upgradeMessages.tradeInUp);
                        expect(scope.user.lines[0].tradeInOptions.displayUpgradeOptionLink).toEqual(true);
                        expect(scope.user.lines[0].tradeInOptions.eligibleFlag).toEqual(scope.eligibleFlag.payUp);
                    });
                    it('if tradein eligible', function () {
                        expect(scope.user.lines[2].tradeInOptions.message).toEqual(scope.eligibilityMessages.upgradeMessages.tradeIn);
                        expect(scope.user.lines[2].tradeInOptions.displayUpgradeOptionLink).toEqual(true);
                        expect(scope.user.lines[2].tradeInOptions.eligibleFlag).toEqual(scope.eligibleFlag.tradeIn);
                    });
                    it('if tradein ineligible but payoff amount is greater than 0', function () {
                        expect(scope.user.lines[1].tradeInOptions.message.payOff).toEqual(scope.eligibilityMessages.upgradeMessages.tradeInOff);
                        expect(scope.user.lines[1].tradeInOptions.displayUpgradeOptionLink).toEqual(true);
                        expect(scope.user.lines[1].tradeInOptions.eligibleFlag).toEqual(scope.eligibleFlag.payOff);
                    });
                    it('should show conditions for discount eligible', function () {
                        expect(scope.user.lines[4].tradeInOptions.message).toEqual(scope.eligibilityMessages.upgradeMessages.fullEligible);
                        expect(scope.user.lines[4].tradeInOptions.displayUpgradeOptionLink).toEqual(false);
                        expect(scope.user.lines[4].tradeInOptions.eligibleFlag).toEqual(scope.eligibleFlag.none);
                    });
                    it('should show conditions for ineligible', function () {
                        expect(scope.user.lines[5].tradeInOptions.message).toEqual(scope.eligibilityMessages.upgradeMessages.splitLiability);
                        expect(scope.user.lines[5].tradeInOptions.displayUpgradeOptionLink).toEqual(false);
                        expect(scope.user.lines[5].tradeInOptions.eligibleFlag).toEqual('');
                    });
                    it('should show conditions when payUpAmount is greater than 0', function () {
                        expect(scope.user.lines[3].tradeInOptions.message).toEqual(scope.eligibilityMessages.upgradeMessages.buyAtFullPrice);
                        expect(scope.user.lines[3].tradeInOptions.displayUpgradeOptionLink).toEqual(false);
                        expect(scope.user.lines[3].tradeInOptions.eligibleFlag).toEqual(scope.eligibleFlag.replace);
                    });
                });

                describe('Enable and disable lines functionality', function () {
                    it('user.selectedLines should contain selected lines subscriber number', function () {
                        scope.user.multiLineEnabledFlag = false;
                        var lineObject = {
                            'subscriberNumber': 7293857654,
                            'isLineSelected': true,
                            'eligibilityInfo': {
                                'payUpAmount': 0
                            },
                            'tradeInOptions': {
                                'disableTile': false,
                                'displayUpgradeOptionLink': true,
                                'eligibleFlag': 'PAYOFF',
                                'message': 'Pay off $100.00 to upgrade early',
                                'tradeInEligible': false
                            },
                            'optionPageSelection': {
                                'PAYOFF': {
                                    'eligibleFlag': 'Pay off your AT&T Next&reg balance to become eligible for an upgrade while keeping your current device'
                                }
                            }
                        };
                        scope.user.upgradedLinesInProgress = '';
                        scope.updateLineSelection(lineObject);
                        expect(scope.user.selectedLines[lineObject.subscriberNumber]).toBeDefined();
                        expect(scope.user.selectedLines[lineObject.subscriberNumber]).toEqual(lineObject);
                    });
                    it('user.selectedLines should  not contain unselected line', function () {
                        var lineObject = {
                            'subscriberNumber': 4564654664,
                            'isLineSelected': false,
                            'tradeInOptions': {
                                'disableTile': false,
                                'displayUpgradeOptionLink': true,
                                'eligibleFlag': 'PAYOFF',
                                'message': 'Pay off $100.00 to upgrade early',
                                'tradeInEligible': false
                            }
                        };
                        scope.updateLineSelection(lineObject);
                        expect(scope.user.selectedLines[lineObject.subscriberNumber]).not.toBeDefined();
                    });
                });
                describe('upgrade selected Lines functionality', function () {
                    it('should check redirection works on CTA click when upgraded line is in progress', function () {
                        scope.user.multiLineEnabledFlag = true;
                        scope.user.upgradedLinesInProgress = '4252050545';
                        scope.upgradeLines();
                        expect($window.location.href).toEqual(exCommonConstants.cartSummaryPageUrl);
                    });
                    it('should add selected Lines Details to express upgrade', function () {
                        scope.user.selectedLines = [
                            {
                                tradeInOptions: {
                                    eligibleFlag: true
                                },
                                subscriberNumber: 'false'

                            }
                        ];
                        scope.user.multiLineEnabledFlag = false;
                        scope.user.upgradedLinesInProgress = '4252050545';
                        scope.user.isUpdateCTAEnabled = true;
                        scope.upgradeLines();
                        expect(upgradeEligSrv.upgradeSelectedLines.calls.mostRecent().args[0]).toBeDefined();
                        expect(upgradeEligSrv.upgradeSelectedLines.calls.mostRecent()
                            .args[0].upgradingLineCount).toEqual(scope.user.selectedLines.length);
                        expect(upgradeEligSrv.upgradeSelectedLines.calls.mostRecent()
                            .args[0].selectedUpgradeLines['atg-rest-values']).toBeDefined();
                        expect(upgradeEligSrv.upgradeSelectedLines.calls.mostRecent()
                            .args[0].selectedUpgradeLines['atg-rest-values'].length)
                            .toEqual(scope.user.selectedLines.length);
                        expect(upgradeEligSrv.upgradeSelectedLines.calls.mostRecent()
                            .args[0].selectedUpgradeLines['atg-rest-values'][0].selectedUpgradeOption)
                            .toEqual(scope.user.selectedLines[0].tradeInOptions.eligibleFlag);

                        scope.user.selectedLines = ['4252050545'];
                        scope.user.multiLineEnabledFlag = true;
                        scope.user.upgradedLinesInProgress = '4252050545';
                        scope.user.isUpdateCTAEnabled = false;
                        scope.upgradeLines();
                        expect(upgradeEligSrv.upgradeSelectedLines.calls.mostRecent()
                            .args[0].selectedUpgradeLines['atg-rest-values'].length)
                            .toEqual(scope.user.selectedLines.length);
                    });
                });
                describe('Upgrade Lines now cta should be disabled if no line is selected ', function () {
                    it('disableUpgradeLineCta should be enable and disabled', function () {
                        scope.user = {
                            selectedLines:
                            {
                                'subscriberNumber': 7293857654
                            }
                        };
                        scope.user.isUpdateCTAEnabled = false;

                        scope.disableUpgradeLineCta();
                        expect(scope.disableUpgradeLineCta()).toBe(false);
                        scope.user = {
                            selectedLines: {}
                        };
                        scope.user.isUpdateCTAEnabled = false;
                        scope.user.upgradedLinesInProgress = '';
                        scope.disableUpgradeLineCta();
                        expect(scope.disableUpgradeLineCta()).toBe(true);
                    });
                });
                describe('Enable TradeIn and PayUp when isISEFailed', function () {
                    it('should upgrade with tradein payup options ', function () {
                        var tradeInOptions =
                            {
                                tradeInOptions: {
                                    eligibleFlag: true
                                },
                                eligibilityInfo: {
                                    payUpAmount: 50,
                                    tradeInIneligible: true,
                                    eligibleFlag: true,
                                    tradeInEligible: true
                                },
                                device: {
                                    make: 'Samsung'
                                },
                                customerDetailWithDevice: {
                                    customerCTNWithDevice: 'BEDROCK\'s Galaxy S8'
                                },
                                deviceURL: 'testURL',
                                optionPageSelection: {
                                    'CONTRACT_TRADEIN': {
                                        'eligibleFlag': 'CONTRACT_TRADEIN'
                                    },
                                    'TRADEIN': {
                                        'tradeIn': 'TRADEIN'
                                    }
                                },
                                selectedSubscriber: '4252050541'
                            };

                        exCartService.removeItemFromPersistentCart().then(function () {
                            upgradeEligSrv.upgradeSelectedLines().then(function (data) {
                                expect(data.response.optionsBean.isISEFailed).toEqual(exUpgradeConstants.errorStatusCode.isISEFailed);
                            });
                        });

                        scope.user.selectedLines = {};
                        scope.user.selectedLines[tradeInOptions.selectedSubscriber] = tradeInOptions;
                        scope.user.upgradedLinesInProgress = '';
                        scope.upgradeLines();
                        scope.$digest();
                        expect($cookies.get).toHaveBeenCalledWith('SHOPSESSIONID');
                        scope.$apply();

                    });
                });
                describe('Showing Modal for more options to upgrade functionality', function () {
                    it('should check modal opens and load radio buttons content', function () {
                        var upgradeLineItem = scope.user.lines[0];
                        scope.user.showOptionModal(upgradeLineItem);
                        expect(scope.user.modalData).toBeDefined();
                        expect($modal.open).toHaveBeenCalled();
                        expect(scope.user.modalData.optionPageSelection).toBeDefined();
                        expect(Object.keys(scope.user.modalData.optionPageSelection).length).toBeGreaterThan(0);
                        expect(Object.keys(scope.user.modalData.optionPageSelection).length).toEqual(2);
                        expect(scope.user.modalData.optionPageSelection[scope.eligibleFlag.payUp].upgradeMessageWithPrice.payUp)
                            .toEqual(scope.upgradeOptionsMessages.tradeInEarly);
                        expect(scope.user.modalData.optionPageSelection[scope.eligibleFlag.payUp].eligibleFlagMsg)
                            .toEqual(scope.upgradeOptionsMessages.tradeInWithPrice);
                        expect(scope.user.modalData.optionPageSelection[scope.eligibleFlag.replace].upgradeMessageWithPrice)
                            .toEqual(scope.upgradeOptionsMessages.buyAtFullPrice);
                        expect(scope.user.modalData.optionPageSelection[scope.eligibleFlag.replace].eligibleFlagMsg)
                            .toEqual(scope.upgradeOptionsMessages.replaceYourDevice);
                    });
                    it('should check modal close', function () {
                        var lineObject = {
                            'subscriberNumber': 4564654664,
                            'isLineSelected': false,
                            'eligibilityInfo': {
                                'payUpAmount': 70
                            },
                            'tradeInOptions': {
                                'disableTile': false,
                                'displayUpgradeOptionLink': true,
                                'eligibleFlag': 'PAYOFF',
                                'message': 'Pay off $100.00 to upgrade early',
                                'tradeInEligible': false
                            }
                        };
                        scope.user.showOptionModal(lineObject);
                        scope.user.modalData.isLineOptionClicked = false;
                        scope.user.hideOptionModal();
                        expect(scope.user.selectedLines[scope.user.modalData.subscriberNumber])
                            .not.toBeDefined();
                        scope.user.modalData.isLineOptionClicked = true;
                        scope.user.hideOptionModal();
                    });
                    it('should check updateTradeInSelection', function () {
                        var upgradeLineItem = scope.user.lines[2];
                        var lineData = {};
                        var lineRadioOption = {};
                        scope.user.showOptionModal(upgradeLineItem);
                        lineData = scope.user.modalData;
                        lineRadioOption = scope.user.modalData.optionPageSelection[scope.eligibleFlag.replace];
                        scope.user.updateTradeInSelection(lineData, lineRadioOption);
                        expect(lineData.tradeInOptions.eligibleFlag).toEqual(lineRadioOption.eligibleFlag);
                        expect(lineData.tradeInOptions.priceVal).toEqual(lineRadioOption.priceVal);
                        expect(lineData.tradeInOptions.message).toEqual(lineRadioOption.message);
                    });
                });

                describe('should check updateHeaderDetails function ', function () {
                    it('should provide customer name and device name if shortDisplayName is present', function () {

                        var lineInfo = {
                            'customerFirstName': 'BEDROCK',
                            'device': {
                                'model': 'iPhone6sPlus',
                                'deviceType': 'phone',
                                'shortDisplayName': 'Apple Iphone 6s Plus',
                                'make': 'Apple'
                            },
                            'subscriberNumber': 4256862891,
                            'tradeInOptions': {
                                'disableTile': false,
                                'displayUpgradeOptionLink': true,
                                'eligibleFlag': 'PAYOFF',
                                'message': 'Pay off $100.00 to upgrade early',
                                'tradeInEligible': false
                            }
                        };
                        expect(scope.user.lines[0].customerDetailWithDevice.customerNameWithDevice)
                            .toEqual(lineInfo.customerFirstName + scope.commonApostrophes + ' ' +
                            lineInfo.device.deviceType);
                        expect(scope.user.lines[2].customerDetailWithDevice.customerCTNWithDevice)
                            .toEqual(lineInfo.device.shortDisplayName + ' ' + scope.commonSeparator + ' ' +
                            $filter('tel')(lineInfo.subscriberNumber));
                    });

                    it('should provide customer name and device name if shortDisplayName is not present', function () {

                        var lineInfo = {
                            'customerFirstName': 'BEDROCK',
                            'device': {
                                'model': 'iPhone6sPlus',
                                'deviceType': 'phone',
                                'make': 'Apple'
                            },
                            'subscriberNumber': 4252951809,
                            'tradeInOptions': {
                                'disableTile': false,
                                'displayUpgradeOptionLink': true,
                                'eligibleFlag': 'PAYOFF',
                                'message': 'Pay off $100.00 to upgrade early',
                                'tradeInEligible': false
                            }
                        };
                        expect(scope.user.lines[0].customerDetailWithDevice.customerNameWithDevice)
                            .toEqual(lineInfo.customerFirstName + scope.commonApostrophes + ' ' +
                            lineInfo.device.deviceType);
                        expect(scope.user.lines[0].customerDetailWithDevice.customerCTNWithDevice)
                            .toEqual(lineInfo.device.make + ' ' + lineInfo.device.model + ' ' + scope.commonSeparator + ' ' +
                            $filter('tel')(lineInfo.subscriberNumber));
                    });
                });
                describe('select and submit fully eligible CTN', function () {
                    it('should check autoSubmitFullyEligible function', function () {
                        var selectedCTNforUpgrade = {
                            '4252951809': {
                                'subscriberNumber': '4252951809',
                                'tradeInOptions': {
                                    'eligibleFlag': 'NONE'
                                }
                            }
                        };
                        expect(scope.user.selectedLines[4252951809].subscriberNumber)
                            .toEqual(selectedCTNforUpgrade[4252951809].subscriberNumber);
                        expect(scope.user.selectedLines[4252951809].tradeInOptions.eligibleFlag)
                            .toEqual(selectedCTNforUpgrade[4252951809].tradeInOptions.eligibleFlag);
                    });
                });
                describe('should check contract message of the subscriber line based on contract type', function () {
                    var contractTypeMsg = {
                        'regularMsg': 'Two-year contract ends Nov.',
                        'leaseMsg': '24-month installment plan ends Nov.'
                    };
                    it('if contract type is regular', function () {
                        expect(scope.user.lines[1].contractType.contractTerm).toContain(contractTypeMsg.regularMsg);
                    });
                    it('if contract type is lease', function () {
                        expect(scope.user.lines[2].contractType.installmentPlan).toContain(contractTypeMsg.leaseMsg);
                    });

                });

                describe('Reporting functionality', function () {

                    it('should emit event for landing on upgrade eligibility page and pass reporting information with correct event code and data', function () {
                        var notExpectedReportingObject = jasmine.objectContaining({
                            eventAction: 'pageLoad',
                            eventCode: 'page_load'
                        });
                        //expect(scope.$emit).toHaveBeenCalledWith(exCommonConstants.event.DS_REPORTING_EVENT, expectedReportingObject, jasmine.any(Object));
                        expect(scope.$emit).not.toHaveBeenCalledWith(exCommonConstants.event.DS_REPORTING_EVENT, notExpectedReportingObject, jasmine.any(Object));
                        scope.$apply();
                    });

                    it('should emit event for upgrade options modal on upgrade eligibility page and pass reporting information with correct event code and data', function () {
                        var expectedReportingObject = {
                                eventAction: 'systemEvent',
                                eventCode: 'DS_System_Upgrade_Options_Displayed',
                                additionaldata: jasmine.objectContaining({
                                    isMultilineUpgradeEligible: '0',
                                    existingItems: jasmine.any(Array)
                                })
                            },
                            notExpectedReportingObject = {
                                eventAction: 'systemEvent',
                                eventCode: 'DS_System_Upgrade_Eligibility_Displayed'
                            };

                        scope.$emit.calls.reset();
                        var upgradeLineItem = scope.user.lines[2];
                        scope.user.showOptionModal(upgradeLineItem);

                        expect(scope.$emit).toHaveBeenCalledWith(exCommonConstants.event.DS_REPORTING_PAGELOAD_EVENT);
                        expect(scope.$emit).toHaveBeenCalledWith(exCommonConstants.event.DS_REPORTING_EVENT, expectedReportingObject, jasmine.any(Object));
                        expect(scope.$emit).not.toHaveBeenCalledWith(exCommonConstants.event.DS_REPORTING_EVENT, notExpectedReportingObject, jasmine.any(Object));
                        scope.$apply();
                    });

                    it('should emit event for upgrade on upgrade eligibility page and pass reporting information with correct event code and data', function () {
                        var expectedReportingObjectSubmit = jasmine.objectContaining({
                                eventAction: 'formSubmit',
                                eventCode: 'DS_Upgrade_Submit',
                                additionaldata: jasmine.objectContaining({
                                    items: [jasmine.objectContaining({itemSku: 'sku12345'}), jasmine.objectContaining({itemSku: 'sku1234'}), jasmine.objectContaining({itemSku: 'sku123'})],
                                    existingItems: jasmine.any(Array)
                                })
                            }),
                            expectedReportingObjectResponse = jasmine.objectContaining({
                                eventAction: 'formResponse',
                                eventCode: 'DS_Upgrade_Submit',
                                additionaldata: jasmine.objectContaining({
                                    items: [jasmine.objectContaining({itemSku: 'sku12345'}), jasmine.objectContaining({itemSku: 'sku1234'}), jasmine.objectContaining({itemSku: 'sku123'})],
                                    existingItems: jasmine.any(Array)
                                })
                            }),
                            expectedReportingObjectSystem = jasmine.objectContaining({
                                eventAction: 'systemEvent',
                                eventCode: 'DS_System_Upgrade_Tradein_Ineligible_Displayed',
                                additionaldata: jasmine.objectContaining({
                                    items: [jasmine.objectContaining({itemSku: 'sku12345'}), jasmine.objectContaining({itemSku: 'sku1234'}), jasmine.objectContaining({itemSku: 'sku123'})],
                                    existingItems: jasmine.any(Array)
                                })
                            }),
                            notExpectedReportingObject = jasmine.objectContaining({
                                eventAction: 'systemEvent',
                                eventCode: 'DS_System_Upgrade_Eligibility_Displayed'
                            });

                        scope.$emit.calls.reset();
                        scope.user.selectedLines = [
                            {
                                tradeInOptions: {
                                    eligibleFlag: true,
                                    displayUpgradeOptionLink: false
                                },
                                subscriberNumber: 'false',
                                device: {
                                    color: 'Black',
                                    make: 'Samsung',
                                    model: 'Galaxy S8',
                                    skuId: 'sku12345'
                                }
                            }
                        ];
                        scope.user.multiLineEnabledFlag = false;
                        scope.user.upgradedLinesInProgress = '4252050545';
                        scope.upgradeLines();
                        expect(scope.$emit).toHaveBeenCalledWith(exCommonConstants.event.DS_REPORTING_EVENT, expectedReportingObjectSubmit, jasmine.any(Object));
                        expect(scope.$emit).toHaveBeenCalledWith(exCommonConstants.event.DS_REPORTING_EVENT, expectedReportingObjectResponse, jasmine.any(Object));
                        expect(scope.$emit).not.toHaveBeenCalledWith(exCommonConstants.event.DS_REPORTING_EVENT, notExpectedReportingObject, jasmine.any(Object));
                        expect(scope.$emit).not.toHaveBeenCalledWith(exCommonConstants.event.DS_REPORTING_EVENT, expectedReportingObjectSystem, jasmine.any(Object));
                        scope.$apply();
                    });
                });

                describe('Execute showUpgradeEligMessage function', function () {

                    it('Should check showUpgradeEligMessage function ', function () {
                        scope.showUpgradeEligMessage(true);
                        expect(scope.user.displayUpgradeEligMessage).toEqual(true);
                    });

                    it('Should check isMassageAvailabe function ', function () {
                        expect(scope.user.isMessageAvailable).toEqual(true);
                    });

                });

                describe('Execute eligibilityLineCheckboxState function', function () {
                    it('Should check eligibilityLineCheckboxState function', function () {
                        var line = {
                            'enableLine': true,
                            'tradeInOptions': {
                                'disableTile': true
                            }
                        };
                        var disableCheckbox = scope.eligibilityLineCheckboxState(line);
                        expect(disableCheckbox).toEqual(true);
                    });
                });
            });
        });
    });
})();