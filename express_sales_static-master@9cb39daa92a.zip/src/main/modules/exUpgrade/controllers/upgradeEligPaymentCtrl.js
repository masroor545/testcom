(function () {
    'use strict';

    /**
     * This controller retrieves the payment related details which user has from the service
     *
     * __Requirements:__
     * * gets payment details which user has.
     *
     * @module upgradeEligPaymentCtrl
     *
     * @property {object} upgradePayment - ???
     * @property {string} [upgradePayment.terms] - ???
     * @property {string} [upgradePayment.errorMessage] - ???
     * @property {boolean} [upgradePayment.consentCheckbox = false] - ???
     * @property {boolean} [upgradePayment.displayPaymentOptions = false] - ???
     * @property {string} [upgradePayment.cvv] - ???
     *
     * @listens exCommonConstants.event.updatePaymentInfoSubmit
     * @listens exUpgradeConstants.event.updatePaymentInfoSubmit
     * @listens exUpgradeConstants.event.updatePaymentInfoResponse
     *
     * @fires DS_Upgrade_Update_Payment_Info_Submit
     *
     * @todo update information and make it accurate
     */
    angular.module('exUpgrade')

        .controller('upgradeEligPaymentCtrl', ['$q', '$scope', '$filter', '$location', 'upgradeSharedPaymentInfoSrv',
            'upgradeEligPaymentSrv', 'profileInfoService', 'exCqTranslatorKeyService',
            'exUpgradeConstants', 'exCommonConstants', 'reportingDataSrv', '$window', '$rootScope',
            function ($q, $scope, $filter, $location, upgradeSharedPaymentInfoSrv,
                upgradeEligPaymentSrv, profileInfoService, exCqTranslatorKeyService,
                exUpgradeConstants, exCommonConstants, reportingDataSrv, $window, $rootScope) {

                $scope.upgradePayment = {};
                $scope.upgradePayment.terms = '';
                $scope.continueToPayment = continueToPayment;
                $scope.upgradePayment.errorMessage = '';
                $scope.upgradePayment.consentCheckbox = false;
                $scope.upgradePayment.displayPaymentOptions = false;
                $scope.redirectToUpgradeElig = redirectToUpgradeElig;
                $scope.changePaymentMethod = changePaymentMethod;
                $scope.upgradePayment.cvv = '';

                $scope.$on(exCommonConstants.event.paymentInfoValidated, function (event, isPaymentValidated) {
                    var validateData = isPaymentValidated !== false &&
                        isPaymentValidated.paymentInfo !== undefined &&
                        isPaymentValidated.paymentInfo.duetoday !== undefined &&
                        isPaymentValidated.paymentInfo.duetoday !== null &&
                        isPaymentValidated.paymentInfo.duetoday.cardNumber !== undefined &&
                        isPaymentValidated.paymentInfo.duetoday.cardNumber !== null &&
                        isPaymentValidated.paymentInfo.duetoday.cvv !== undefined &&
                        isPaymentValidated.paymentInfo.duetoday.cvv !== null;

                    if (validateData === true) {
                        $scope.upgradePayment.cvv = isPaymentValidated.paymentInfo.duetoday.cvv;
                        getPaymentData($scope.upgradePayment.userId);
                    }
                    $scope.upgradePayment.displayPaymentOptions = false;
                });

                //Called when update payment info on update payment info modal is submitted
                $scope.$on(exUpgradeConstants.event.updatePaymentInfoSubmit, function () {
                    var eventPayload = {};

                    $scope.$emit(exCommonConstants.event.DS_REPORTING_EVENT, {
                        eventAction: 'formSubmit',
                        eventCode: 'DS_Upgrade_Update_Payment_Info_Submit',
                        additionaldata: reportingDataSrv.addEventSuccessToPayload(eventPayload)
                    }, $scope);
                });

                //Called with response from update payment info on update payment info modal
                $scope.$on(exUpgradeConstants.event.updatePaymentInfoResponse, function (event, paymentMethod, data) {
                    var eventPayload = {};

                    if (data && data.response !== undefined &&
                        data.response !== null &&
                        data.response.status === ($filter('uppercase')(exUpgradeConstants.statusFailed)) &&
                        data.response.errors[0] !== undefined &&
                        data.response.errors[0] !== null) {
                        eventPayload = reportingDataSrv.updateEventPayloadFailure(eventPayload);
                    } else {
                        eventPayload = reportingDataSrv.addEventSuccessToPayload(eventPayload);
                    }

                    $scope.$emit(exCommonConstants.event.DS_REPORTING_EVENT, {
                        eventAction: 'formResponse',
                        eventCode: 'DS_Upgrade_Update_Payment_Info_Submit',
                        additionaldata: eventPayload
                    }, $scope);
                });


                activate();

                /**
                 * Controller startup logic
                 */
                function activate () {
                    var payTypeLegal;
                    $q.all({
                        profile: profileInfoService.getProfileInfo(true).then(function (response) {
                            $scope.upgradePayment.userId = response.ProfileInfo.uuid;
                            $scope.upgradePayment.accountNumber = response.ProfileInfo.billingAccountNumber;
                            $scope.upgradePayment.systemDivision = response.ProfileInfo.billingMarket;

                            $scope.upgradePayment.userBillingInfo = {
                                firstName: response.ProfileInfo.accountFirstName,
                                lastName: response.ProfileInfo.accountLastName,
                                zipCode: response.ProfileInfo.zipCode
                            };

                            if ($scope.upgradePayment.userId !== undefined &&
                                $scope.upgradePayment.userId !== null) {
                                return getPaymentData($scope.upgradePayment.userId);
                            }
                        }),
                        upgradeDetails: upgradeEligPaymentSrv.getUpgradingDevicePaymentData().then(function (data) {
                            $scope.upgradePayment.upgradeTypeInfo = getUpgradeDetails(data);
                            if (data.payload.upgradeOptionSelected === exUpgradeConstants.eligibleFlag.payUp ||
                                data.payload.upgradeOptionSelected === exUpgradeConstants.eligibleFlag.payUpContract) {
                                payTypeLegal = $scope.payUpLegal;
                            } else if (data.payload.upgradeOptionSelected === exUpgradeConstants.eligibleFlag.payOff) {
                                payTypeLegal = $scope.payOffLegal;
                            }

                            exCqTranslatorKeyService.getCqTranslatorKeys([payTypeLegal]).then(function (result) {
                                $scope.upgradePayment.terms = result[payTypeLegal];
                            });
                        })
                    }).then(function () {
                        var eventPayload = reportingDataSrv.getUpgradePaymentPayload($scope.upgradePayment.paymentInfo,
                            $scope.upgradePayment.upgradeTypeInfo);

                        $scope.$emit(exCommonConstants.event.DS_REPORTING_EVENT, {
                            eventAction: 'systemEvent',
                            eventCode: 'DS_System_Upgrade_Payment_Displayed',
                            additionaldata: eventPayload
                        }, $scope);
                    });
                }

                /**
                 * Gets payment information by calling fetchPaymentDetails function of upgradeEligPaymentSrv.
                 * @param {Numbers} user UUID
                 */
                function getPaymentData (userId) {
                    return upgradeEligPaymentSrv.fetchPaymentDetails(userId).then(function (data) {
                        $scope.upgradePayment.paymentInfo = getPaymentDetails(data);
                    });
                }

                /**
                 * Gets payment details that user has for upgrading line.
                 * @param {Object} data User account payment information
                 */
                function getPaymentDetails (data) {
                    var paymentDetails = undefined,
                        paymentMethod = undefined;

                    var validatePayment = data.payload !== undefined &&
                        data.payload !== null &&
                        data.payload.paymentInfo !== undefined &&
                        data.payload.paymentInfo !== null &&
                        data.payload.paymentInfo.paymentMethods !== undefined &&
                        data.payload.paymentInfo.paymentMethods !== null &&
                        Object.keys(data.payload.paymentInfo.paymentMethods).length > 0;

                    if (validatePayment === true) {
                        //Always display first payment profile method
                        paymentMethod = Object.keys(data.payload.paymentInfo.paymentMethods)[0];
                        paymentDetails = data.payload.paymentInfo.paymentMethods[paymentMethod];

                        var paymentParm = '';
                        if ($scope.upgradePayment.cvv !== '' ||
                            paymentDetails.paymentType === exUpgradeConstants.paymentProfile) {
                            paymentParm = {
                                displayName: parseDisplayName(paymentDetails.displayName),
                                cardType: paymentDetails.cardType,
                                checkCard: cardImage,
                                paymentType: paymentDetails.paymentType,
                                expYear: paymentDetails.expYear,
                                expMonth: paymentDetails.expMonth,
                                customerName: paymentDetails.name,
                                zipCode: paymentDetails.billingZipCode,
                                cardNumber: paymentDetails.cardNumber,
                                isPaymentProfile: false
                            };
                        } else {
                            paymentParm = {
                                isPaymentProfile: true
                            };
                        }
                        return paymentParm;

                    } else {
                        return {
                            isPaymentProfile: true
                        };
                    }
                }


                /**
                 * Gets upgrading type and payment amount for upgrading line.
                 * @param {Object} data User account upgrading type information
                 */
                function getUpgradeDetails (data) {
                    if (data.payload !== undefined && data.payload !== null) {
                        // if user selection is either contract PAYUP or PAYUP then always pass PAYUP to AWP call
                        var paymentUpgradeType = (data.payload.upgradeOptionSelected === exUpgradeConstants.eligibleFlag.payUpContract ||
                        data.payload.upgradeOptionSelected === exUpgradeConstants.eligibleFlag.payUp) ? exUpgradeConstants.eligibleFlag.payUp : data.payload.upgradeOptionSelected;
                        return {
                            upgradeType: paymentUpgradeType,
                            paymentAmount: getPaymentAmount(data.payload),
                            headingTextMsg: (data.payload.upgradeOptionSelected === exUpgradeConstants.eligibleFlag.payUp ||
                                data.payload.upgradeOptionSelected === exUpgradeConstants.eligibleFlag.payUpContract) ? $scope.upgradePaymentPayup : $scope.upgradePaymentPayoff,
                            customerCtn: data.payload.selectedSubscriber,
                            invoiceNumber: getInvoiceNumber(data.payload),
                            installmentId: data.payload.installmentID
                        };
                    }
                }

                /**
                 * Parse displayName with newDisplayname.
                 * @param {string} card display name.
                 */
                function parseDisplayName (newDisplayName) {
                    if (newDisplayName.indexOf(exUpgradeConstants.paymentCardMasterCard) !== -1) {
                        newDisplayName = newDisplayName.replace('MC', 'MasterCard');
                    } else if (newDisplayName.indexOf(exUpgradeConstants.paymentCardVisa) !== -1) {
                        newDisplayName = newDisplayName.replace('VISA', 'Visa');
                    } else if (newDisplayName.indexOf(exUpgradeConstants.paymentCardDiscover) !== -1) {
                        newDisplayName = newDisplayName.replace('DISC', 'Discover');
                    } else if (newDisplayName.indexOf(exUpgradeConstants.paymentCardAmericanExpress) !== -1) {
                        newDisplayName = newDisplayName.replace('AE', 'American Express');
                    }
                    return newDisplayName;
                }

                /**
                 * Provide dynamic images to payment card.
                 * @param {Object} data User account payment information
                 */
                function cardImage (upgradePayment) {
                    if (upgradePayment.paymentInfo.cardType === 'MC') {
                        return 'cards-mastercard';
                    } else if (upgradePayment.paymentInfo.cardType === 'VISA') {
                        return 'cards-visa';
                    } else if (upgradePayment.paymentInfo.cardType === 'AE') {
                        return 'cards-american';
                    } else if (upgradePayment.paymentInfo.cardType === 'DISC') {
                        return 'cards-discover';
                    }
                }

                /**
                 * Provide payment amount for device being upgrade.
                 * @param {object} upgrading type information.
                 */
                function getPaymentAmount (upgradingInfo) {
                    if (upgradingInfo.upgradeOptionSelected === exUpgradeConstants.eligibleFlag.payUp ||
                        upgradingInfo.upgradeOptionSelected === exUpgradeConstants.eligibleFlag.payUpContract) {
                        return upgradingInfo.payUpAmount.toFixed(2);       //temporary round up, once service will fix the original issue will remove this
                    } else if (upgradingInfo.upgradeOptionSelected === exUpgradeConstants.eligibleFlag.payOff) {
                        return upgradingInfo.payOffAmount.toFixed(2);
                    }
                }

                /**
                 * Provide invoice number for device being upgrade.
                 * @param {object} upgrading type information.
                 */
                function getInvoiceNumber (upgradingInfo) {
                    var prefixForPayOff = 'IP';
                    var prefixForPayUp = 'IU';
                    if (upgradingInfo.upgradeOptionSelected === exUpgradeConstants.eligibleFlag.payUp ||
                        upgradingInfo.upgradeOptionSelected === exUpgradeConstants.eligibleFlag.payUpContract) {
                        return prefixForPayUp + upgradingInfo.installmentID;
                    } else if (upgradingInfo.upgradeOptionSelected === exUpgradeConstants.eligibleFlag.payOff) {
                        return prefixForPayOff + upgradingInfo.installmentID;
                    }
                }

                /**
                 * Passes serviceInput and userId to upgradePaymentContinue services.
                 * @function continueToPayment
                 * @todo provide meaningful information
                 * @see {@link ../services/#module_upgradeEligPaymentSrv..upgradePaymentContinue|upgradeEligPaymentSrv.upgradePaymentContinue}
                 */
                function continueToPayment () {
                    var serviceInput = {};

                    if (validatePrePaymentParams() === true) {
                        serviceInput = {
                            'upgradeType': $scope.upgradePayment.upgradeTypeInfo.upgradeType,
                            'systemDivision': $scope.upgradePayment.systemDivision,
                            'subscriberNumber': $scope.upgradePayment.upgradeTypeInfo.customerCtn,
                            'invoiceNumber': $scope.upgradePayment.upgradeTypeInfo.invoiceNumber,
                            'accountNumber': $scope.upgradePayment.accountNumber,
                            'customerAgreement': exUpgradeConstants.customerAgreement,
                            'paymentInfo': {
                                'type': $scope.upgradePayment.paymentInfo.paymentType,
                                'cardNumber': $scope.upgradePayment.paymentInfo.cardNumber,
                                'amount': $scope.upgradePayment.upgradeTypeInfo.paymentAmount
                            }
                        };

                        // set credit card other details if payment type is credit card
                        if ($scope.upgradePayment.paymentInfo.paymentType === exUpgradeConstants.creditCard) {
                            serviceInput.paymentInfo.expMonth = $scope.upgradePayment.paymentInfo.expMonth;
                            serviceInput.paymentInfo.expYear = $scope.upgradePayment.paymentInfo.expYear;
                            serviceInput.paymentInfo.cvv = $scope.upgradePayment.cvv;
                            serviceInput.paymentInfo.name = $scope.upgradePayment.paymentInfo.customerName;
                            serviceInput.paymentInfo.zip = $scope.upgradePayment.paymentInfo.zipCode;
                        }

                        var eventPayload = reportingDataSrv.getUpgradePaymentPayload($scope.upgradePayment.paymentInfo,
                             $scope.upgradePayment.upgradeTypeInfo);

                        $scope.$emit(exCommonConstants.event.DS_REPORTING_EVENT, {
                            eventAction: 'formSubmit',
                            eventCode: 'DS_Upgrade_Payment_Submit',
                            additionaldata: eventPayload
                        }, $scope);

                        upgradeEligPaymentSrv.upgradePaymentContinue($scope.upgradePayment.userId, serviceInput).then(function (data) {

                            if (data.response !== undefined &&
                                data.response !== null) {
                                if (data.response.status === ($filter('uppercase')(exUpgradeConstants.success))) {

                                    //do broadcasting
                                    var paymentDetail = {
                                        'amount': data.payload.amount,
                                        'cardType': $scope.upgradePayment.paymentInfo.displayName,
                                        'paymentDate': data.payload.paymentDate,
                                        'paymentType': $scope.upgradePayment.upgradeTypeInfo.upgradeType,
                                        'planId': $scope.upgradePayment.upgradeTypeInfo.installmentId,
                                        'referenceInformation': data.payload.referenceInformation
                                    };

                                    //Pass paymentDetail to upgradeSharedPaymentInfoSrv service.
                                    upgradeSharedPaymentInfoSrv.setSharedPaymentInfo(paymentDetail);

                                    //Redirection to payment confirmation page
                                    $location.path(exCommonConstants.upgradePaymentConfirmation);
                                } else if (data.response.status === ($filter('uppercase')(exUpgradeConstants.statusFailed)) &&
                                    data.response.errors[0] !== undefined &&
                                    data.response.errors[0] !== null) {
                                    if (data.response.errors[0].code === exUpgradeConstants.errorStatusCode.isPaymentCardInvalid) {
                                        $scope.upgradePayment.errorMessage = data.response.errors[0].message;
                                    } else if (data.response.errors[0].code === exUpgradeConstants.errorStatusCode.isCardDeclined) {
                                        $scope.upgradePayment.errorMessage = $scope.cardDeclinedMsg;
                                    } else if (data.response.errors[0].code === null ||
                                        data.response.errors[0].message === null) {
                                        $window.location.href = exCommonConstants.hardStopPage;
                                    }

                                    //update reporting event Payload
                                    eventPayload = reportingDataSrv.updateEventPayloadPaymentFailure(eventPayload, data);
                                }
                            }

                            $scope.$emit(exCommonConstants.event.DS_REPORTING_EVENT, {
                                eventAction: 'formResponse',
                                eventCode: 'DS_Upgrade_Payment_Submit',
                                additionaldata: eventPayload
                            }, $scope);
                        });
                    }
                }

                /**
                 * function to see ccc payment modal and broadcast customer information to modal
                 * @function changePaymentMethod
                 * @param {boolean} visible - ???
                 * @todo meaningful information is needed
                 * @emits DS_REPORTING_PAGELOAD_EVENT
                 * @see {@link ../../exCommon/#module_exCommonConstants.event.DS_REPORTING_PAGELOAD_EVENT|DS_REPORTING_PAGELOAD_EVENT}
                 */
                function changePaymentMethod (visible) {
                    $rootScope.$broadcast(exCommonConstants.event.paymentModalTriggered, $scope.upgradePayment.userBillingInfo);
                    $scope.upgradePayment.displayPaymentOptions = visible;

                    if (visible) {
                        $scope.$emit(exCommonConstants.event.DS_REPORTING_PAGELOAD_EVENT,
                            exUpgradeConstants.friendlyPageName.changePaymentMethodModal,
                            exUpgradeConstants.virtualUrl.changePaymentMethodModal
                        );
                    }
                }

                /**
                 * function to pre validate payment required parameters before passing to API
                 * @return {Boolean} based on validation
                 */
                function validatePrePaymentParams () {
                    if ($scope.upgradePayment.paymentInfo.paymentType === false ||
                        $scope.upgradePayment.upgradeTypeInfo.paymentAmount === 0) {
                        return false;
                    }
                    return true;
                }

                /**
                 * redirect to upgrade eligibility page.
                 * @function redirectToUpgradeElig
                 */
                function redirectToUpgradeElig () {
                    $location.path(exCommonConstants.upgradeEligibility);
                }
            }
        ]);
})();