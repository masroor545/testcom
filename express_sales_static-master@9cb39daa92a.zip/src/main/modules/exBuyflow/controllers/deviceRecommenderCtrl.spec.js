(function () {
    'use strict';

    define(['deviceRecommenderCtrl'], function () {
        describe('src/main/modules/exBuyflow/controllers/deviceRecommenderCtrl.spec.js', function () {
            describe('deviceRecommenderCtrl controller of exBuyflow', function () {
                var $controller, $scope, $document, $modal, $rootScope, deviceRecommenderSrv, selectedSkuSrv, reportingDataSrv,
                    upgradingUserInfoSrv, exCqTranslatorKeyService, imagePathService, $location, profileInfoService,
                    favStoreService, deviceConfigSrv, exBuyflowConstants, exCommonConstants, exHelpUtils;

                var createController = function () {
                    $controller('deviceRecommenderCtrl', {
                        $scope: $scope,
                        $modal: $modal,
                        deviceRecommenderSrv: deviceRecommenderSrv,
                        upgradingUserInfoSrv: upgradingUserInfoSrv,
                        exCqTranslatorKeyService: exCqTranslatorKeyService,
                        reportingDataSrv: reportingDataSrv,
                        imagePathService: imagePathService,
                        profileInfoService: profileInfoService,
                        favStoreService: favStoreService,
                        exCommonConstants: exCommonConstants
                    });
                };

                beforeEach(function () {
                    module('exBuyflow', function ($provide) {
                        deviceRecommenderSrv = jasmine.createSpyObj('deviceRecommenderSrv', ['getRecommendedDevices', 'getItemPriceData', 'getDeviceDataForReporting']);
                        upgradingUserInfoSrv = jasmine.createSpyObj('upgradingUserInfoSrv', ['getUpgradingDeviceDetailsData', 'getDeviceType']);
                        exCqTranslatorKeyService = jasmine.createSpyObj('exCqTranslatorKeyService', ['getCqTranslatorKeys']);
                        reportingDataSrv = jasmine.createSpyObj('reportingDataSrv', ['getDeviceRecommenderDevicePayload']);
                        imagePathService = jasmine.createSpyObj('imagePathService', ['getXpressImagePath']);
                        profileInfoService = jasmine.createSpyObj('profileInfoService', ['getProfileInfo', 'getProfileInfoForAAL']);
                        favStoreService = jasmine.createSpyObj('favStoreService', ['getFavStoreId']);
                        deviceConfigSrv = jasmine.createSpyObj('deviceConfigSrv', ['getColorTheme', 'getDeviceDetails']);
                        $provide.value('deviceRecommenderSrv', deviceRecommenderSrv);
                        $provide.value('deviceConfigSrv', deviceConfigSrv);
                        $provide.value('upgradingUserInfoSrv', upgradingUserInfoSrv);
                        $provide.value('exCqTranslatorKeyService', exCqTranslatorKeyService);
                        $provide.value('imagePathService', imagePathService);
                        $provide.value('profileInfoService', profileInfoService);
                        $provide.value('favStoreService', favStoreService);
                        $provide.value('$modalStack', {});
                    });

                    inject(function ($injector) {
                        $controller = $injector.get('$controller');
                        $rootScope = $injector.get('$rootScope');
                        selectedSkuSrv = $injector.get('selectedSkuSrv');
                        exHelpUtils = $injector.get('exHelpUtils');
                        $location = $injector.get('$location');
                        $document = $injector.get('$document');
                        exCommonConstants = $injector.get('exCommonConstants');
                        exBuyflowConstants = $injector.get('exBuyflowConstants');
                    });

                    $scope = $rootScope.$new();

                    // Values passed from the directive attributes
                    $scope.heroConfidenceThreshold = '0.8';
                    $scope.displayHeroDevice = 'false';
                    $scope.initialDevicesLoaded = '6';

                    $modal = jasmine.createSpyObj('$modal', ['open']);
                    $modal.open.and.returnValue(true);

                    spyOn(selectedSkuSrv, 'setSelectedDevice');

                    spyOn($location, 'search').and.returnValue({skuid: undefined});

                    deviceRecommenderSrv.getRecommendedDevices.and.returnValue({
                        'then': function (callBackFN) {
                            callBackFN(Endpoint_deviceRecommenderApi.get_Recommended_Devices.data);
                        }
                    });
                    deviceRecommenderSrv.getItemPriceData.and.returnValue({
                        'then': function (callBackFN) {
                            callBackFN(Endpoint_deviceRecommenderApi.getItemPrices.data);
                        }
                    });
                    deviceRecommenderSrv.getDeviceDataForReporting.and.returnValue({
                        'items': [{'itemSku': 'sku7840239'}]
                    });
                    upgradingUserInfoSrv.getUpgradingDeviceDetailsData.and.returnValue({
                        'then': function (callBackFN) {
                            callBackFN(Endpoint_deviceRecommenderApi.getUpgradingDetails_Phone.result);
                        }
                    });

                    exCqTranslatorKeyService.getCqTranslatorKeys.and.returnValue({
                        'then': function (callBackFN) {
                            callBackFN(Endpoint_cqTranslatorKeys.getShortLegalCmsKey.result);
                        }
                    });

                    reportingDataSrv.getDeviceRecommenderDevicePayload.and.returnValue({
                        'items': [{'itemSku': 'sku7840239'}]
                    });

                    imagePathService.getXpressImagePath.and.returnValue({
                        'then': function (callBackFN) {
                            callBackFN(true);
                        }
                    });

                    profileInfoService.getProfileInfo.and.returnValue({
                        'then': function (callBackFN) {
                            callBackFN(Endpoint_profileInfoApi.get_profile_info_auth.result);
                        }
                    });

                    profileInfoService.getProfileInfoForAAL.and.returnValue({
                        'then': function (callBackFN) {
                            callBackFN(Endpoint_profileInfoApi.get_profile_info_for_aal.result);
                        }
                    });

                    favStoreService.getFavStoreId.and.returnValue({
                        'then': function (callBackFN) {
                            callBackFN(true);
                        }
                    });

                    deviceConfigSrv.getColorTheme.and.returnValue('dark');
                    deviceConfigSrv.getDeviceDetails.and.returnValue({
                        'then': function (callBackFN) {
                            callBackFN(true);
                        }
                    });


                    createController();
                });

                afterEach(function () {
                    selectedSkuSrv.setSelectedDevice.calls.reset();
                });


                // Recommended devices
                describe('Recommended devices and their respective prices', function () {

                    it('get the user profile info and pass UUID to get fav store of user', function () {
                        var evt = $document.context.createEvent('Event');
                        evt.initEvent('FireNoneCriticalRenderingAssests', true, false);
                        $document.context.head.dispatchEvent(evt);
                        $rootScope.$digest();
                        expect(profileInfoService.getProfileInfo).toHaveBeenCalled();
                        profileInfoService.getProfileInfo().then(function (result) {
                            expect(favStoreService.getFavStoreId).toHaveBeenCalled();
                            expect(favStoreService.getFavStoreId).toHaveBeenCalledWith(result.ProfileInfo.uuid, true);
                        });
                    });

                    it('should slice initial X devices from all recommendations and get their respective prices', function () {
                        var itemsLoaded = $scope.deviceRecommender.items.length;
                        $scope.viewMoreDevices($scope.initDevicesLoaded);
                        expect($scope.deviceRecommender.items.length).toEqual(itemsLoaded + $scope.initDevicesLoaded);
                        expect($scope.deviceRecommender.items[0].skuId).toEqual('sku7840239');

                        var itemPriceLength = Object.keys($scope.deviceRecommender.itemPrice).length;
                        expect(itemPriceLength).toEqual($scope.initDevicesLoaded);
                        expect($scope.deviceRecommender.itemPrice['sku7840239'].defaultPrice).toEqual('19.84');
                    });

                    it('should display rex devices only on initial load if rex device count is greater than half the configured value', function () {
                        // REX API has 5 rex devices coming out of 27. Rest are coming from catalog.
                        expect($scope.deviceRecommender.totalDevicesLoaded).toEqual(5);
                        expect(deviceRecommenderSrv.getRecommendedDevices).toHaveBeenCalled();
                        expect($scope.deviceRecommender.items.length).not.toEqual($scope.initialDevicesLoaded);
                    });

                    it('should append more Y devices (X+Y) to the initial loaded recommendations and get their respective prices', function () {
                        // expect the updated count for recommended devices displayed on the page
                        $scope.deviceRecommender.devicesToBeDisplayed = 6;
                        expect($scope.deviceRecommender.devicesToBeDisplayed).toEqual(6);
                        $scope.viewMoreDevices(6);
                        expect($scope.deviceRecommender.devicesToBeDisplayed).toEqual(12);
                        // expect count for recommended devices displayed on the page equal to actual devices in the API
                        //Initial recommended devices loaded is set to 6. Mock REX API length is 27. At one point devicesToBeLoaded is 24 (6+6+6+6).
                        // In this scenario, devicesToBeDisplayed will be 24 + 6 = 30, so we need to update it with REX API length.
                        $scope.viewMoreDevices(24);
                        expect($scope.deviceRecommender.devicesToBeDisplayed).toEqual($scope.deviceRecommender.totalRecommendedDevices.length);
                    });

                    // Device Filter
                    describe('device filter', function () {
                        it('should list criteria for all criteria that can be used to filter devices sorted alphabetically', function () {
                            // Digest so filtered items can update
                            $scope.$digest();
                            // For filter by brand
                            var brands = $scope.deviceRecommender.filterOptions[0];
                            expect(Array.isArray($scope.deviceRecommender.filterOptions)).toEqual(true);
                            expect($scope.deviceRecommender.filterOptions.length).toBeGreaterThan(0);
                            expect(brands.criterion).toEqual('brand');
                            expect(Array.isArray(brands.values)).toEqual(true);
                            expect(brands.values.length).not.toEqual(0);
                            $scope.deviceRecommender.filterOptions.forEach(function (criterion) {
                                expect(criterion.criterion).toBeDefined();
                                criterion.values.forEach(function (value) {
                                    expect(typeof(value.value)).toBeDefined();
                                    expect(value.isSelected).toEqual(false);
                                });
                            });

                            // For filter by deviceType
                            var deviceType = $scope.deviceRecommender.deviceTypeFilterOptions[0];
                            expect(Array.isArray($scope.deviceRecommender.deviceTypeFilterOptions)).toEqual(true);
                            expect($scope.deviceRecommender.deviceTypeFilterOptions.length).toBeGreaterThan(0);
                            expect(deviceType.criterion).toEqual('deviceType');
                            expect(Array.isArray(deviceType.values)).toEqual(true);
                            expect(deviceType.values.length).not.toEqual(0);
                            $scope.deviceRecommender.deviceTypeFilterOptions.forEach(function (criterion) {
                                expect(criterion.criterion).toBeDefined();
                                criterion.values.forEach(function (value) {
                                    expect(typeof(value.value)).toBeDefined();
                                    expect(value.isSelected).toEqual(false);
                                });
                            });

                            var brandValues = brands.values.map(function (brand) { return brand.value; });
                            var itemsBrands = $scope.deviceRecommender.items.map(function (item) { return item.brand; });
                            var totalRecommendedDevicesBrands = $scope.deviceRecommender.totalRecommendedDevices.map(function (item) { return item.brand; });
                            expect(totalRecommendedDevicesBrands.length).toBeGreaterThan(itemsBrands.length);
                            $scope.deviceRecommender.totalRecommendedDevices.forEach(function (item) {
                                expect(brandValues).toContain(item.brand);
                            });

                            // Removes values not listed in the filter priority
                            var prioritySortedItems = $scope.deviceRecommender.filterOptions[0].values.filter(function (value) {
                                return exBuyflowConstants.deviceFilterPriority.indexOf(value.value) !== -1;
                            });

                            expect(prioritySortedItems.length).not.toEqual(0);

                            // Checks if the array of items that are in the filter priority list equals the options array whose length is sliced to equal the priority filtered items.
                            // If they are equal then all of the values that were filtered out (if any) are at the end of items.
                            expect(angular.equals(prioritySortedItems, $scope.deviceRecommender.filterOptions[0].values.slice(0, prioritySortedItems.length))).toEqual(true);
                        });

                        it('should append Y filtered devices to the item list', function () {
                            var selectedOption = $scope.deviceRecommender.filterOptions[0].values[0];
                            expect(selectedOption.value).toEqual('Apple');
                            selectedOption.isSelected = true;
                            $scope.filterItems('byBrand', selectedOption.isSelected);
                            expect(typeof $scope.deviceRecommender.filteredItems.length).toEqual('number');
                            expect($scope.deviceRecommender.filteredItems.length).not.toEqual(0);
                            $scope.deviceRecommender.filteredItems.forEach(function (filteredItem) {
                                expect(filteredItem.brand).toEqual(selectedOption.value);
                            });
                        });

                        it('should append Y filtered devices by deviceType to the item list', function () {
                            var selectedOption = $scope.deviceRecommender.deviceTypeFilterOptions[0].values[0];
                            expect(selectedOption.value).toEqual('pda');
                            selectedOption.isSelected = true;
                            $scope.filterItems('byDeviceType', selectedOption.isSelected);
                            expect(typeof $scope.deviceRecommender.filteredItems.length).toEqual('number');
                            expect($scope.deviceRecommender.filteredItems.length).not.toEqual(0);
                            $scope.deviceRecommender.filteredItems.forEach(function (filteredItem) {
                                expect(filteredItem.deviceType).toEqual(selectedOption.value);
                            });
                        });

                        describe('clearing filter selection', function () {
                            it('should clear the filter when called', function () {
                                // Click event
                                var fakeClickEvent = {
                                    type: 'click',
                                    stopPropagation: function () {}
                                };
                                $scope.deviceRecommender.devicesToBeDisplayed = $scope.initDevicesLoaded + 100;
                                $scope.deviceRecommender.filterOptions[0].values.forEach(function (value) {
                                    value.isSelected = true;
                                });
                                // clearing brand filter
                                $scope.clearFilterSelections('byBrand', fakeClickEvent);
                                $scope.deviceRecommender.filterOptions[0].values.forEach(function (value) {
                                    expect(value.isSelected).toEqual(false);
                                });
                                expect($scope.deviceRecommender.devicesToBeDisplayed).toEqual($scope.initDevicesLoaded);
                                
                                // clearing deviceType Filter
                                $scope.clearFilterSelections('byDeviceType', fakeClickEvent);
                                $scope.deviceRecommender.deviceTypeFilterOptions[0].values.forEach(function (value) {
                                    expect(value.isSelected).toEqual(false);
                                });
                                expect($scope.deviceRecommender.devicesToBeDisplayed).toEqual($scope.initDevicesLoaded);
                            });

                            it('should stop event propagataion even if program crashes during the function call', function () {
                                // Click event
                                var fakeClickEvent = {
                                    type: 'click',
                                    stopPropagation: function () {}
                                };

                                spyOn(fakeClickEvent, 'stopPropagation');

                                // Clearing $scope.deviceRecommender to crash the function
                                $scope.deviceRecommender = null;

                                expect(function () { $scope.clearFilterSelections('byBrand', fakeClickEvent); }).toThrow();
                                expect(fakeClickEvent.stopPropagation).toHaveBeenCalled();
                            });

                        });

                    });

                    it('should get the map of short legal content for device', function () {
                        expect(Object.keys($scope.deviceRecommender.commitmentTerms)[0]).toEqual(Object.keys($scope.deviceRecommender.itemPrice)[0]);
                        expect($scope.deviceRecommender.commitmentTerms[Object.keys($scope.deviceRecommender.commitmentTerms)[0]].name).toEqual(
                               $scope.deviceRecommender.itemPrice[Object.keys($scope.deviceRecommender.itemPrice)[0]].contractType);
                        expect($scope.deviceRecommender.commitmentTerms[Object.keys($scope.deviceRecommender.commitmentTerms)[0]].leaseTotalMonths).toEqual(
                               $scope.deviceRecommender.itemPrice[Object.keys($scope.deviceRecommender.itemPrice)[0]].contractLength);
                        expect($scope.deviceRecommender.shortLegalContent).toEqual(jasmine.objectContaining({
                            'label.dlist.legal.NE30M80P.pda': 'Requires 30-mo. installment agmt., qual. credit, and services.'
                        }));
                    });

                    it('should get long legal content for selected device on device tile for long legal overlay', function () {
                        $scope.showDeviceLegalDetailsOverlay('sku8040303');
                        expect(selectedSkuSrv.setSelectedDevice).toHaveBeenCalledWith('sku8040303');
                        expect($modal.open).toHaveBeenCalled();
                    });

                    it('should get images from imagePathService function', function () {
                        expect(imagePathService.getXpressImagePath).toHaveBeenCalled();
                        expect(typeof imagePathService.getXpressImagePath.calls.mostRecent().args[1]).toEqual('object');
                        expect(imagePathService.getXpressImagePath.calls.count()).toEqual(6);
                    });

                    it('should get the value of hero device tile background color', function () {
                        expect(deviceConfigSrv.getColorTheme).toHaveBeenCalled();
                        expect(deviceConfigSrv.getColorTheme.calls.mostRecent().args[0]).toEqual('#000000');
                        expect($scope.deviceRecommender.heroDeviceTileColorTheme).toEqual('dark');
                    });

                    it('should get the condition based theme for Hero Device', function () {
                        var item = {
                            'skuId': 'sku7840239', // skuId of Hero device
                            'source': 'rex'  // source of the returned devices i.e. REX or Catalog
                        };

                        // should return 'light' theme color if hero device color theme is 'light'
                        $scope.deviceRecommender.heroDeviceTileColorTheme = 'light';
                        expect($scope.getHeroDeviceBackgroundTheme(item)).toEqual('light-theme');

                        // should return 'dark' theme color if hero device color theme is 'dark'
                        $scope.deviceRecommender.heroDeviceTileColorTheme = 'dark';
                        expect($scope.getHeroDeviceBackgroundTheme(item)).toEqual('dark-theme');
                    });

                    it('should get the flair Flags against devices after filtering and sorting', function () {
                        $scope.filterFlairFlags($scope.deviceRecommender.items);
                        expect($scope.deviceRecommender.items[0].displayContentItems).toBeDefined();

                        // if all the conditions are satisfied and result is sorted
                        expect($scope.flairFlag['sku7840239'].enable).toEqual(true);
                        expect($scope.flairFlag['sku7840239'].displayType).toEqual('ribbon');
                        expect($scope.flairFlag['sku7840239'].contentType).toEqual('image');
                        expect($scope.flairFlag['sku7840239'].flowTypes).toContain('UP');
                        expect($scope.flairFlag['sku7840239'].marketingPriority).toEqual(1);

                        // if conditions are not satisfied for any sku
                        expect($scope.flairFlag['sku7870569']).toEqual('none');
                    });

                    //Shows the device_first instead of hero device in overlay
                    // if URL contains device skuId appended in it
                    it('should show the device_first in overlay if skuId is appended in URL', function () {
                        $location.search.and.returnValue({'skuId': 'sku7730376'});
                        $scope.checkDeviceFirst();
                        expect($location.search).toHaveBeenCalled();
                        expect($scope.deviceRecommender.deviceFirstSKU).toBeDefined();
                        expect($scope.deviceRecommender.deviceFirstSKU).toEqual('sku7730376');
                    });

                    it('should prefetch device details', function () {
                        var evt = $document.context.createEvent('Event');
                        evt.initEvent('FireNoneCriticalRenderingAssests', true, false);
                        $document.context.head.dispatchEvent(evt);
                        $rootScope.$digest();
                        expect(deviceConfigSrv.getDeviceDetails.calls.count()).toEqual($scope.deviceRecommender.totalRecommendedDevices.length);
                    });

                    it('should not call upgrading device details when user is in zippy add a line', function () {
                        profileInfoService.getProfileInfoForAAL('reload').then(function (profile) {
                            expect(profile.ProfileInfo.exAlFlow).toEqual(true);
                            upgradingUserInfoSrv.getUpgradingDeviceDetailsData.calls.reset();
                            expect(upgradingUserInfoSrv.getUpgradingDeviceDetailsData).not.toHaveBeenCalled();
                        });
                    });
                });

                // Device config overlay
                describe('Device config overlay', function () {

                    it('should set the selected sku to the first item in the device recommender', function () {
                        expect(selectedSkuSrv.setSelectedDevice).toHaveBeenCalled();
                    });

                    // Select device and open the modal
                    it('should update the device config', function () {
                        selectedSkuSrv.setSelectedDevice.calls.reset();
                        $scope.selectSku('sku7840239');
                        expect(selectedSkuSrv.setSelectedDevice).toHaveBeenCalledWith('sku7840239');
                        expect($modal.open).toHaveBeenCalled();
                    });

                    it('should initially show the device config when the confidence threshold is met and hero device is set to true', function () {
                        // Mock service for high confidence hero device
                        deviceRecommenderSrv.getRecommendedDevices.and.returnValue({
                            'then': function (callBackFN) {
                                callBackFN(Endpoint_deviceRecommenderApi.get_Recommended_Devices.data);
                            }
                        });
                        $scope.displayHeroDevice = 'false';
                        createController();
                        expect($modal.open).not.toHaveBeenCalled();

                        $scope.displayHeroDevice = 'true';
                        createController();
                        expect($scope.deviceRecommender.showRecommender).toEqual(false);
                        expect($modal.open).toHaveBeenCalled();
                    });

                    // Device config not initally shown
                    describe('Device config not initially shown', function () {

                        beforeEach(function () {
                            spyOn($rootScope, '$broadcast').and.callThrough();
                            // Mock service for low confidence hero device
                            deviceRecommenderSrv.getRecommendedDevices.and.returnValue({
                                'then': function (callBackFN) {
                                    callBackFN(Endpoint_deviceRecommenderApi.get_Recommended_Devices_Unconfident.data);
                                }
                            });
                            $scope.displayHeroDevice = 'false';
                        });

                        afterEach(function () {
                            $rootScope.$broadcast.calls.reset();
                        });

                        // Display flag set to false
                        it('should not initially show the device config when display hero device is set to false', function () {
                            // Mock service for high confidence hero device
                            deviceRecommenderSrv.getRecommendedDevices.and.returnValue({
                                'then': function (callBackFN) {
                                    callBackFN(Endpoint_deviceRecommenderApi.get_Recommended_Devices.data);
                                }
                            });
                            createController();
                            expect($modal.open).not.toHaveBeenCalled();
                        });

                        // Shows the device recommender when the confidence score is too to low to meet the threshold to recommend an actual device
                        it('should not show the device config when confidence threshold is not met', function () {
                            $scope.displayHeroDevice = 'false';
                            createController();
                            expect($modal.open).not.toHaveBeenCalled();
                            expect($rootScope.$broadcast).toHaveBeenCalledWith(exCommonConstants.event.showGlobalNav, null);
                            expect($scope.deviceRecommender.showRecommender).toEqual(true);
                        });

                        // Hides the device recommender when the confidence score is meets the threshold to recommend an actual device
                        it('should hide device recommender when confidence threshold is met', function () {
                            // Mock service for high confidence hero device
                            deviceRecommenderSrv.getRecommendedDevices.and.returnValue({
                                'then': function (callBackFN) {
                                    callBackFN(Endpoint_deviceRecommenderApi.get_Recommended_Devices.data);
                                }
                            });

                            $scope.displayHeroDevice = 'true';
                            createController();
                            expect($scope.deviceRecommender.showRecommender).toEqual(false);
                            expect($modal.open).toHaveBeenCalled();
                            expect($rootScope.$broadcast).toHaveBeenCalledWith(exCommonConstants.event.hideGlobalNav, null);
                        });

                        it('should still set the selected sku to the first item in the device recommender', function () {
                            expect(selectedSkuSrv.setSelectedDevice).toHaveBeenCalledWith('sku7840239');
                        });

                    });
                    describe('should check reporting functionalities', function () {

                        beforeEach(function () {
                            spyOn($scope, '$emit').and.callThrough();
                            $scope.$emit.calls.reset();
                        });

                        it('should report DS_System_Upgrade_Device_Details_Recommend_Display when the confidence threshold is met and hero device is set to true', function () {
                            var expectedReportingObject = {
                                eventAction: 'systemEvent',
                                eventCode: 'DS_System_Upgrade_Device_Details_Recommend_Display',
                                additionaldata: jasmine.objectContaining({
                                    items: [jasmine.objectContaining({itemSku: 'sku7840239'})]
                                }, 0)
                            };
                            // Mock service for high confidence hero device
                            deviceRecommenderSrv.getRecommendedDevices.and.returnValue({
                                'then': function (callBackFN) {
                                    callBackFN(Endpoint_deviceRecommenderApi.get_Recommended_Devices.data);
                                }
                            });
                            $scope.displayHeroDevice = 'true';
                            createController();
                            expect($scope.$emit).toHaveBeenCalledWith('DS_Reporting_Event', expectedReportingObject, $scope);
                            $scope.$apply();
                        });

                        it('should report DS_System_Upgrade_Device_Recommend_Display when the confidence threshold is met but hero device is set to false', function () {
                            var expectedReportingObject = jasmine.objectContaining({
                                eventAction: 'systemEvent',
                                eventCode: 'DS_System_Upgrade_Device_Recommend_Display',
                                additionaldata: jasmine.objectContaining({
                                    items: [jasmine.objectContaining({itemSku: 'sku7840239'})]
                                }, 0)
                            });
                            // Mock service for high confidence hero device
                            deviceRecommenderSrv.getRecommendedDevices.and.returnValue({
                                'then': function (callBackFN) {
                                    callBackFN(Endpoint_deviceRecommenderApi.get_Recommended_Devices.data);
                                }
                            });
                            $scope.displayHeroDevice = 'false';
                            createController();
                            expect($scope.$emit).toHaveBeenCalledWith('DS_Reporting_Event', expectedReportingObject, $scope);
                            $scope.$apply();
                        });

                        it('should report DS_System_Upgrade_Device_Recommend_Display when the confidence threshold is not met and hero device is set to true', function () {
                            var expectedReportingObject = jasmine.objectContaining({
                                eventAction: 'systemEvent',
                                eventCode: 'DS_System_Upgrade_Device_Recommend_Display',
                                additionaldata: jasmine.objectContaining({
                                    items: [jasmine.objectContaining({itemSku: 'sku7840239'})]
                                })
                            });
                            // Mock service for low confidence hero device
                            deviceRecommenderSrv.getRecommendedDevices.and.returnValue({
                                'then': function (callBackFN) {
                                    callBackFN(Endpoint_deviceRecommenderApi.get_Recommended_Devices_Unconfident.data);
                                }
                            });
                            $scope.displayHeroDevice = 'true';
                            createController();
                            expect($scope.$emit).toHaveBeenCalledWith('DS_Reporting_Event', expectedReportingObject, $scope);
                            $scope.$apply();
                        });

                        // check that page load event fires when Device selected
                        it('should fire page load event with appropriate value when modal device selected', function () {
                            var expectedReportingObject = jasmine.objectContaining({
                                eventAction: 'systemEvent',
                                eventCode: 'DS_System_Upgrade_Device_Details_Recommend_Display',
                                additionaldata: jasmine.objectContaining({
                                    items: [jasmine.objectContaining({itemSku: 'sku7840239'})]
                                }, 0)
                            });
                            // Mock service for high confidence hero device
                            deviceRecommenderSrv.getRecommendedDevices.and.returnValue({
                                'then': function (callBackFN) {
                                    callBackFN(Endpoint_deviceRecommenderApi.get_Recommended_Devices.data);
                                }
                            });
                            $scope.displayHeroDevice = 'true';
                            createController();
                            $scope.selectSku('sku7840249', 0, false);
                            expect($scope.$emit).toHaveBeenCalledWith('DS_Reporting_Event', expectedReportingObject, jasmine.any(Object));
                            expect($scope.$emit).toHaveBeenCalledWith('DS_Reporting_PageLoad_Event');
                        });

                        // check that page load event fires when Device selected Hero Scenario
                        it('should fire page load event with appropriate value when modal device selected Hero Scenario', function () {
                            var deviceTileIndex = 0;
                            $scope.selectSku('sku7840239', deviceTileIndex, true);
                            expect($scope.$emit).toHaveBeenCalledWith('DS_Reporting_PageLoad_Event');
                        });

                        // check that link click event fires when user clicks on see price details link for devices
                        it('should fire link clink event with appropriate value when user clicks on see price details link for devices', function () {
                            var expectedReportingObject = jasmine.objectContaining({
                                eventAction: 'linkClick',
                                eventCode: 'Link_Click',
                                additionaldata: {
                                    'linkName': 'See price details',
                                    'linkPosition': 'Body',
                                    'linkDestinationURL': '/shop/xpress/device-recommender.html'
                                }
                            });
                            $scope.showDeviceLegalDetailsOverlay('sku7840239');
                            expect($scope.$emit).toHaveBeenCalledWith('DS_Reporting_Event', expectedReportingObject,
                                $scope);
                        });
                    });
                });
            });
        });
    });
})();