(function () {
    'use strict';

    /**
     * This controller retrieves recommended devices from the service.
     *
     * __Requirements__
     * * @todo Implement details
     *
     * @module deviceRecommenderCtrl
     *
     * @see {@link ../directives/#module_exDeviceRecommender|exDeviceRecommender}
     */
    angular.module('exBuyflow')

        .controller('deviceRecommenderCtrl', ['$scope', '$window', '$modal', '$filter', '$location', '$q', 'deviceRecommenderSrv', 'exCommonConstants', 'exBuyflowConstants',
            'upgradingUserInfoSrv', 'reportingDataSrv', 'selectedSkuSrv', 'exCqTranslatorKeyService', 'imagePathService', 'profileInfoService', 'favStoreService', 
            'deviceConfigSrv', '$rootScope', 'exHelpUtils', 
            function ($scope, $window, $modal, $filter, $location, $q, deviceRecommenderSrv, exCommonConstants, exBuyflowConstants,
                upgradingUserInfoSrv, reportingDataSrv, selectedSkuSrv, exCqTranslatorKeyService, imagePathService, profileInfoService, favStoreService,
                deviceConfigSrv, $rootScope, exHelpUtils) {

                $scope.initDevicesLoaded = parseInt($scope.initialDevicesLoaded);
                $scope.deviceRecommender = {
                    items: [],
                    displayedItems: [],
                    displayedTotalItems: [],
                    filteredItems: [],
                    filteredTotalItems: [],
                    filterOptions: [],
                    selectionCount: 0,
                    showDeviceFilterContent: false,
                    showDeviceTypeFilterContent: false,
                    itemPrice: undefined,
                    totalRecommendedDevices: [],
                    devicesToBeDisplayed: 0,
                    upgradingDeviceType: undefined,
                    commitmentTerms: undefined,
                    shortLegalContent: undefined,
                    deviceFirstSKU: undefined,
                    heroDeviceTileColorTheme: undefined,
                    showRecommender: false,
                    upgradingDeviceDetails: undefined
                };
                $scope.imgUrl = [];
                $scope.flairFlag = [];
                $scope.exUpFlow = false;
                $scope.exAlFlow = false;

                /**
                 * Scope function to show device legal Overlay
                 * @param {String} deviceSkuId
                 */
                $scope.showDeviceLegalDetailsOverlay = function (deviceSkuId) {
                    selectedSkuSrv.setSelectedDevice(deviceSkuId);
                    $modal.open({
                        templateUrl: '/shop/xpress/modals/device-legaldetails.modal.html',
                        windowClass: 'modal-fullscreen'
                    });

                    // Fire link click event when user clicks on see price details link for devices
                    $scope.$emit(exCommonConstants.event.DS_REPORTING_EVENT, {
                        eventAction: 'linkClick',
                        eventCode: 'Link_Click',
                        additionaldata: {
                            'linkName': exBuyflowConstants.linkName.longLegalLink,
                            'linkPosition': exBuyflowConstants.linkPosition,
                            'linkDestinationURL': exBuyflowConstants.virtualUrl.deviceRecommenderDetailsUrl
                        }
                    }, $scope);
                };

                /**
                 * Scope function that displays the device config with the currently selected sku
                 * @param {String} skuId - sku ID of selected device
                 * @param {boolean} confidenceMet - Selected device is Hero device or not
                 */
                $scope.selectSku = function (skuId, deviceTileIndex, confidenceMet) {
                    selectedSkuSrv.setSelectedDevice(skuId);
                    var modalInstance = $modal.open({
                        templateUrl: '/shop/xpress/modals/device-details.modal.html',
                        windowClass: 'modal-fullscreen'
                    });

                    // Promise resolves when the modal close functionality is triggered.
                    if (modalInstance !== undefined && modalInstance.result !== undefined) {
                        modalInstance.result.then(function () {
                            // This block is never reached. Close is acting like a dismiss due to a Zippy code change.
                        }, function () {
                            // fired when user leaves details page any other way
                            showRecommender();
                        });
                    }

                    if (confidenceMet === false || confidenceMet === undefined) {
                        confidenceMet = ($scope.deviceRecommender.items[0].skuId === skuId) ? true : false;
                    }
                    profileInfoService.getProfileInfo().then(function (profile) {
                        if (profile.ProfileInfo.exUpFlow) {
                            $scope.$emit(exCommonConstants.event.DS_REPORTING_EVENT, {
                                eventAction: 'systemEvent',
                                eventCode: 'DS_System_Upgrade_Device_Details_Recommend_Display',
                                additionaldata: reportingDataSrv.getDeviceRecommenderDevicePayload($scope.deviceRecommender.items[deviceTileIndex],
                                    deviceTileIndex, $scope.deviceRecommender.upgradingDeviceDetails.ctn)
                            }, $scope);
                        }

                        if (profile.ProfileInfo.exAlFlow) {
                            $scope.$emit(exCommonConstants.event.DS_REPORTING_EVENT, {
                                eventAction: 'systemEvent',
                                eventCode: 'DS_System_AAL_Device_Details_Recommend_Display',
                                additionaldata: reportingDataSrv.getDeviceRecommenderDevicePayload($scope.deviceRecommender.items[deviceTileIndex],
                                    deviceTileIndex)
                            }, $scope);
                        }
                    });
                    //Fire page load event when Device displayed on device recommender page as a modal. Should only be fired if getting called to show modal.
                    if (confidenceMet === true) {
                        $scope.$emit(exCommonConstants.event.DS_REPORTING_PAGELOAD_EVENT);
                    } else {
                        $scope.$emit(exCommonConstants.event.DS_REPORTING_PAGELOAD_EVENT);
                    }

                };

                /**
                * gets the recommended devices from recommender API, their respective prices and short legal
                * @function getRecommendedDevices
                * @param {number} devicesToBeLoaded
                */
                $scope.getRecommendedDevices = function (devicesToBeLoaded) {
                    var skuids;

                    // Slice the number of filtered items needed
                    var loadedFilteredItemsCount = $scope.deviceRecommender.filteredItems.length || 0;
                    var newFilteredItemsCount = 0;
                    while (newFilteredItemsCount < devicesToBeLoaded && $scope.deviceRecommender.items.length < $scope.deviceRecommender.totalRecommendedDevices.length) {
                        newFilteredItemsCount = $scope.deviceRecommender.filteredItems.length - loadedFilteredItemsCount;
                        var devicesToSlice = Math.min(
                            $scope.deviceRecommender.items.length + (devicesToBeLoaded - newFilteredItemsCount),
                            $scope.deviceRecommender.totalRecommendedDevices.length);
                        $scope.deviceRecommender.items = $scope.deviceRecommender.totalRecommendedDevices.slice(0, devicesToSlice);
                        // Get more filtered items to be displayed on the basis of selected filters.
                        if ($scope.deviceRecommender.deviceTypeSelectionCount > 0 && $scope.deviceRecommender.selectionCount > 0) {

                            // get all the devices available after filtering the selected deviceTypes
                            var availableDevicesFilteredByDeviceType = exHelpUtils.memoize($filter('selectionFilter'),
                            JSON.stringify($scope.deviceRecommender.deviceTypeFilterOptions) +
                            JSON.stringify($scope.deviceRecommender.totalRecommendedDevices) +
                            'deviceRecommenderTotalRecommendedDevices')($scope.deviceRecommender.totalRecommendedDevices,
                            $scope.deviceRecommender.deviceTypeFilterOptions);

                            // Now filter the the devices by brand from the available devices filtered by device type.
                            $scope.deviceRecommender.filteredItems = exHelpUtils.memoize($filter('selectionFilter'),
                            JSON.stringify($scope.deviceRecommender.filterOptions) +
                            JSON.stringify(availableDevicesFilteredByDeviceType) +
                            'deviceRecommenderTotalRecommendedDevices')(availableDevicesFilteredByDeviceType,
                            $scope.deviceRecommender.filterOptions);

                        } else if ($scope.deviceRecommender.deviceTypeSelectionCount === 0 && $scope.deviceRecommender.selectionCount > 0) {
                            // If a brand is selected and no deviceType is selected for filter
                            $scope.deviceRecommender.filteredItems = exHelpUtils.memoize($filter('selectionFilter'),
                                JSON.stringify($scope.deviceRecommender.filterOptions) +
                                'deviceRecommenderTotalRecommendedDevices')($scope.deviceRecommender.totalRecommendedDevices,
                                $scope.deviceRecommender.filterOptions);
                        } else if ($scope.deviceRecommender.deviceTypeSelectionCount > 0 && $scope.deviceRecommender.selectionCount === 0) {
                            // If no brand is selected but deviceType was already selected for filter
                            $scope.deviceRecommender.filteredItems = exHelpUtils.memoize($filter('selectionFilter'),
                            JSON.stringify($scope.deviceRecommender.deviceTypeFilterOptions) +
                            'deviceRecommenderTotalRecommendedDevices')($scope.deviceRecommender.totalRecommendedDevices,
                            $scope.deviceRecommender.deviceTypeFilterOptions);
                        } else {
                            // If nothing to filter
                            $scope.deviceRecommender.filteredItems = [];
                        }
                    }

                    // Pass comma separated skuids to getItemPriceData function
                    skuids = exHelpUtils.uniqueByKey($scope.deviceRecommender.items.map(function (item) {
                        return item.skuId;
                    }).concat($scope.deviceRecommender.filteredItems.map(function (filteredItem) {
                        return filteredItem.skuId;
                    })
                    ), function (item) { return item; }).join(',');

                    if (skuids.length > 0) {
                        deviceRecommenderSrv.getItemPriceData(skuids).then(function (result) {
                            var commitmentTerms = {};
                            $scope.deviceRecommender.itemPrice = result.payload;
                            angular.forEach($scope.deviceRecommender.itemPrice, function (itemValue, itemKey) {
                                // Adding the price details to the recommended device array
                                $scope.deviceRecommender.totalRecommendedDevices.some(function (obj, i) {
                                    return obj.skuId === itemKey ?
                                    ($scope.deviceRecommender.totalRecommendedDevices[i].defaultPrice = itemValue.defaultPrice,
                                    $scope.deviceRecommender.totalRecommendedDevices[i].contractType = itemValue.contractType) : false;
                                });

                                // Adding commitment term details
                                var commitmentTerm = {};
                                commitmentTerm.name = itemValue.contractType;
                                commitmentTerm.leaseTotalMonths = itemValue.contractLength;
                                commitmentTerm.deviceType = itemValue.deviceType;
                                commitmentTerms[itemKey] = commitmentTerm;
                                // calling method to get all device image paths
                                $scope.imgUrl[itemKey] = imagePathService.getXpressImagePath(
                                    itemValue.brand, null, itemValue.shortDisplayName, itemValue.color, '-hero.png');
                            });
                            $scope.deviceRecommender.commitmentTerms = commitmentTerms;

                            $scope.fetchShortLegalContentForDevices($scope.deviceRecommender.commitmentTerms);
                        });
                    }
                    $scope.deviceRecommender.items = $scope.deviceRecommender.totalRecommendedDevices.slice(0, $scope.deviceRecommender.devicesToBeDisplayed);

                    // If filtered items is empty then we have no filters applied
                    $scope.deviceRecommender.displayedItems = $scope.deviceRecommender.filteredItems.length > 0 ?
                        $scope.deviceRecommender.filteredItems : $scope.deviceRecommender.items;
                    $scope.deviceRecommender.displayedTotalItems = $scope.deviceRecommender.filteredItems.length > 0 ?
                        $scope.deviceRecommender.filteredItems : $scope.deviceRecommender.totalRecommendedDevices;

                    // Applying FairFlag Filter and sorting the results
                    $scope.filterFlairFlags($scope.deviceRecommender.displayedItems);

                    // Gets hero device color theme based on hex value
                    $scope.deviceRecommender.heroDeviceTileColorTheme = deviceConfigSrv.getColorTheme($scope.deviceRecommender.items[0].htmlColor);
                };

                /**
                 * Filters and sorts the flairFlags against each skuId on the basis of business logic,
                 * and accordingly flair flag is displayed against each device on device recommender
                 * @function filterFlairFlags
                 * @param {Array} devicesToBeDisplayed
                 */
                $scope.filterFlairFlags = function (devicesToBeDisplayed) {
                    angular.forEach(devicesToBeDisplayed, function (deviceItem) {
                        var temp = [];
                        $scope.flairFlag[deviceItem.skuId] = {};
                        angular.forEach(deviceItem.displayContentItems, function (contentItem) {
                            if (contentItem.enable === true &&
                                contentItem.displayType === 'ribbon' &&
                                contentItem.contentType === 'image' &&
                                (contentItem.flowTypes).indexOf('UP') !== -1) {
                                temp.push(contentItem);
                                temp = $filter('orderBy')(temp, 'marketingPriority', false);
                            }
                        });

                        if (temp.length > 0) {
                            $scope.flairFlag[deviceItem.skuId] = temp[0];
                        } else {
                            $scope.flairFlag[deviceItem.skuId] = 'none';
                        }
                    });
                };

                /**
                 * Gets more recommended devices from recommender API and increases the number of devices to be displayed
                 * @function viewMoreDevices
                 * @param {number} devicesToBeLoaded
                 */
                $scope.viewMoreDevices = function (devicesToBeLoaded) {
                    // Update the number of devices that should be listed in the view
                    $scope.deviceRecommender.devicesToBeDisplayed = Math.min($scope.deviceRecommender.devicesToBeDisplayed +
                        parseInt(devicesToBeLoaded), $scope.deviceRecommender.totalRecommendedDevices.length);
                    // Call getRecommendedDevices function to display recommended devices and their prices
                    $scope.getRecommendedDevices(parseInt(devicesToBeLoaded));
                };


                /**
                 * Identify cms key for default price of recommended sku and call cms translator key service to get short legal content
                 * @function fetchShortLegalContentForDevices
                 * @param {list} commitmentTerms
                 */
                $scope.fetchShortLegalContentForDevices = function (commitmentTerms) {
                    var cmsKeys = [], legalCmsKey, commitRef, deviceTypeRef, commitRefObj = {};

                    angular.forEach(commitmentTerms, function (commitmentTerm) {

                        if (commitmentTerm.name === 'regular') {
                            commitRefObj = exCommonConstants.commitmentTermCmsKeyPartForLegal[commitmentTerm.leaseTotalMonths];
                        } else {
                            commitRefObj = exCommonConstants.commitmentTermCmsKeyPartForLegal[commitmentTerm.name];
                        }

                        commitRef = commitRefObj === undefined ? commitmentTerm.name : commitRefObj.termKey;

                        deviceTypeRef = (commitRefObj !== undefined && commitRefObj.deviceType !== undefined) ? commitRefObj.deviceType : commitmentTerm.deviceType;

                        legalCmsKey = exCommonConstants.shortLegalContentCmsKey.replace('{0}', commitRef);

                        legalCmsKey = legalCmsKey.replace('{1}', deviceTypeRef);

                        commitmentTerm.legalCmsKey = legalCmsKey;

                        cmsKeys.push(legalCmsKey);
                    });

                    exCqTranslatorKeyService.getCqTranslatorKeys(cmsKeys, true).then(function (result) {
                        $scope.deviceRecommender.shortLegalContent = result;
                    });
                };

                /**
                 * Checks if user has selected device first and then choosen to upgrade line.
                 * Open the overlay for selected device to upgrade inplace of hero device.
                 * @function checkDeviceFirst
                 */
                $scope.checkDeviceFirst = function () {
                    $scope.deviceRecommender.deviceFirstSKU = $location.search().skuId;
                    if ($scope.deviceRecommender.deviceFirstSKU !== undefined) {
                        $scope.selectSku($scope.deviceRecommender.deviceFirstSKU);
                    } else {
                        // Determines if initial device should be maximized
                        var confidenceMet = $scope.deviceRecommender.items[0].score >= $scope.heroConfidenceThreshold;
                        if (confidenceMet === true && $scope.displayHeroDevice === 'true') {
                            $scope.selectSku($scope.deviceRecommender.items[0].skuId, 0, true);
                        } else {
                            showRecommender();
                        }
                    }
                };

                /**
                 * Identify hero device and check source of respose should be REX api.
                 * To apply the background color of hero device tile
                 * @function getHeroDeviceBackgroundTheme
                 * @param {object} heroDeviceDetail
                 * @return {string} light-theme/dark-theme
                 */
                $scope.getHeroDeviceBackgroundTheme = function (heroDeviceDetail) {
                    if (heroDeviceDetail.skuId === $scope.deviceRecommender.items[0].skuId &&
                        heroDeviceDetail.source === 'rex' &&
                        $scope.deviceRecommender.heroDeviceTileColorTheme === 'light') {

                        return 'light-theme';

                    } else if (heroDeviceDetail.skuId === $scope.deviceRecommender.items[0].skuId &&
                        heroDeviceDetail.source === 'rex' &&
                        $scope.deviceRecommender.heroDeviceTileColorTheme === 'dark') {

                        return 'dark-theme';
                    }
                };

                /**
                 * Show recommender with global nav header and footer
                 * @function showRecommender
                 */
                function showRecommender () {
                    $rootScope.$broadcast(exCommonConstants.event.showGlobalNav, null);
                    $scope.deviceRecommender.showRecommender = true;

                    profileInfoService.getProfileInfo().then(function (profile) {
                        if (profile.ProfileInfo.exUpFlow) {
                            $scope.$emit(exCommonConstants.event.DS_REPORTING_EVENT, {
                                eventAction: 'systemEvent',
                                eventCode: 'DS_System_Upgrade_Device_Recommend_Display',
                                additionaldata: reportingDataSrv.getDeviceRecommenderDevicePayload($scope.deviceRecommender.items[0], -1,
                                    $scope.deviceRecommender.upgradingDeviceDetails.ctn)
                            }, $scope);
                        }

                        if (profile.ProfileInfo.exAlFlow) {
                            $scope.$emit(exCommonConstants.event.DS_REPORTING_EVENT, {
                                eventAction: 'systemEvent',
                                eventCode: 'DS_System_AAL_Device_Recommend_Display',
                                additionaldata: reportingDataSrv.getDeviceRecommenderDevicePayload($scope.deviceRecommender.items[0], -1)
                            }, $scope);
                        }
                    });

                    $scope.$emit(exCommonConstants.event.DS_REPORTING_PAGELOAD_EVENT);
                }

                /**
                 * Filters the listed devices with the filter options
                 * Sets the displayed items to the filtered items or items if there are no filtered items
                 * @function filterItems
                 * @param {string} filterBy - filterBy 'brand'/'deviceType'
                 */
                $scope.filterItems = function filterItems (filterBy) {
                    // Update selection count
                    $scope.deviceRecommender.selectionCount = updateSelectionCount();
                    // Update deviceType selection count
                    $scope.deviceRecommender.deviceTypeSelectionCount = updateDeviceTypeSelectionCount();
                    // Assumes total recommended devices never changes. If it does then both arguments MUST be passed as key to exHelpUtils.memoize.
                    // Both arguments would have to be added because memoize needs a better fingerprint (like the skuIds of totalRecommendedDevices and the stringified filter options) of the arguments.
                    // As it stands totalRecommendedDevices never changes, so a real fingerprint of it is not needed.
                    if (filterBy === 'byBrand') {
                        if ($scope.deviceRecommender.deviceTypeSelectionCount > 0 && $scope.deviceRecommender.selectionCount > 0) {

                            // get all the devices available after filtering the selected deviceTypes
                            var availableDevicesFilteredByDeviceType = exHelpUtils.memoize($filter('selectionFilter'),
                            JSON.stringify($scope.deviceRecommender.deviceTypeFilterOptions) +
                            JSON.stringify($scope.deviceRecommender.totalRecommendedDevices) +
                            'deviceRecommenderTotalRecommendedDevices')($scope.deviceRecommender.totalRecommendedDevices,
                            $scope.deviceRecommender.deviceTypeFilterOptions);

                            // Now filter the the devices by brand from the available devices filtered by device type.
                            $scope.deviceRecommender.filteredItems = exHelpUtils.memoize($filter('selectionFilter'),
                            JSON.stringify($scope.deviceRecommender.filterOptions) +
                            JSON.stringify(availableDevicesFilteredByDeviceType) +
                            'deviceRecommenderTotalRecommendedDevices')(availableDevicesFilteredByDeviceType,
                            $scope.deviceRecommender.filterOptions);

                            // Get the deviceTypes options available for the selected brand/brands
                            var allAvailableDeviceOptions = exHelpUtils.memoize($filter('selectionFilter'),
                                JSON.stringify($scope.deviceRecommender.filterOptions) +
                                'deviceRecommenderTotalRecommendedDevices')($scope.deviceRecommender.totalRecommendedDevices,
                                $scope.deviceRecommender.filterOptions);
                            allAvailableDeviceOptions.push.apply(allAvailableDeviceOptions, $scope.deviceRecommender.filteredItems);
                            getFilterOptionsByDeviceType(allAvailableDeviceOptions, 'getEnabledFilterOptionsByDeviceType');

                        } else if ($scope.deviceRecommender.deviceTypeSelectionCount === 0 && $scope.deviceRecommender.selectionCount > 0) {
                            // If a brand is selected and no deviceType is selected for filter
                            $scope.deviceRecommender.filteredItems = exHelpUtils.memoize($filter('selectionFilter'),
                                JSON.stringify($scope.deviceRecommender.filterOptions) +
                                'deviceRecommenderTotalRecommendedDevices')($scope.deviceRecommender.totalRecommendedDevices,
                                $scope.deviceRecommender.filterOptions);
                            getFilterOptionsByDeviceType($scope.deviceRecommender.filteredItems, 'getEnabledFilterOptionsByDeviceType');
                        } else if ($scope.deviceRecommender.deviceTypeSelectionCount > 0 && $scope.deviceRecommender.selectionCount === 0) {
                            // If no brand is selected but deviceType was already selected for filter
                            $scope.deviceRecommender.filteredItems = exHelpUtils.memoize($filter('selectionFilter'),
                            JSON.stringify($scope.deviceRecommender.deviceTypeFilterOptions) +
                            'deviceRecommenderTotalRecommendedDevices')($scope.deviceRecommender.totalRecommendedDevices,
                            $scope.deviceRecommender.deviceTypeFilterOptions);
                            getFilterOptionsByDeviceType($scope.deviceRecommender.totalRecommendedDevices, 'getAllFilterOptionsByDeviceType');
                        } else {
                            // If nothing to filter
                            $scope.deviceRecommender.filteredItems = [];
                            getFilterOptionsByDeviceType($scope.deviceRecommender.totalRecommendedDevices, 'getAllFilterOptionsByDeviceType');
                        }
                    } else if (filterBy === 'byDeviceType') {
                        if ($scope.deviceRecommender.selectionCount > 0 && $scope.deviceRecommender.deviceTypeSelectionCount > 0) {

                            // get all the devices available after filtering the selected brands
                            var availableDevicesFilteredByBrands = exHelpUtils.memoize($filter('selectionFilter'),
                            JSON.stringify($scope.deviceRecommender.filterOptions) +
                            JSON.stringify($scope.deviceRecommender.totalRecommendedDevices) +
                            'deviceRecommenderTotalRecommendedDevices')($scope.deviceRecommender.totalRecommendedDevices,
                            $scope.deviceRecommender.filterOptions);

                            // Now filter the the devices by device type from the available devices filtered by brands.
                            $scope.deviceRecommender.filteredItems = exHelpUtils.memoize($filter('selectionFilter'),
                            JSON.stringify($scope.deviceRecommender.deviceTypeFilterOptions) +
                            JSON.stringify(availableDevicesFilteredByBrands) +
                            'deviceRecommenderTotalRecommendedDevices')(availableDevicesFilteredByBrands,
                            $scope.deviceRecommender.deviceTypeFilterOptions);

                            // get the deviceTypes options available for the selected deviceType/es
                            var allAvailableBrandsOptions = exHelpUtils.memoize($filter('selectionFilter'),
                            JSON.stringify($scope.deviceRecommender.deviceTypeFilterOptions) +
                            'deviceRecommenderTotalRecommendedDevices')($scope.deviceRecommender.totalRecommendedDevices,
                            $scope.deviceRecommender.deviceTypeFilterOptions);
                            allAvailableBrandsOptions.push.apply(allAvailableBrandsOptions, $scope.deviceRecommender.filteredItems);
                            getFilterOptions(allAvailableBrandsOptions, 'getEnabledFilterOptions');

                        } else if ($scope.deviceRecommender.selectionCount === 0 && $scope.deviceRecommender.deviceTypeSelectionCount > 0) {
                            // If a deviceType is selected and no brand is selected for filter
                            $scope.deviceRecommender.filteredItems = exHelpUtils.memoize($filter('selectionFilter'),
                                JSON.stringify($scope.deviceRecommender.deviceTypeFilterOptions) +
                                'deviceRecommenderTotalRecommendedDevices')($scope.deviceRecommender.totalRecommendedDevices,
                                $scope.deviceRecommender.deviceTypeFilterOptions);
                            getFilterOptions($scope.deviceRecommender.filteredItems, 'getEnabledFilterOptions');
                        } else if ($scope.deviceRecommender.selectionCount > 0 && $scope.deviceRecommender.deviceTypeSelectionCount === 0) {
                            // If no deviceType is selected but brand was already selected for filter
                            $scope.deviceRecommender.filteredItems = exHelpUtils.memoize($filter('selectionFilter'),
                            JSON.stringify($scope.deviceRecommender.filterOptions) +
                            'deviceRecommenderTotalRecommendedDevices')($scope.deviceRecommender.totalRecommendedDevices,
                            $scope.deviceRecommender.filterOptions);
                            getFilterOptions($scope.deviceRecommender.totalRecommendedDevices, 'getAllFilterOptions');
                        } else {
                            // If nothing to filter
                            $scope.deviceRecommender.filteredItems = [];
                            getFilterOptions($scope.deviceRecommender.totalRecommendedDevices, 'getAllFilterOptions');
                        }
                    }
                    $scope.deviceRecommender.displayedItems = $scope.deviceRecommender.filteredItems.length > 0 ?
                        $scope.deviceRecommender.filteredItems : $scope.deviceRecommender.items;
                    $scope.deviceRecommender.displayedTotalItems = $scope.deviceRecommender.filteredItems.length > 0 ?
                        $scope.deviceRecommender.filteredItems : $scope.deviceRecommender.totalRecommendedDevices;
                };

                /**
                 * Toggles filter open and closed
                 * @function toggleFilter
                 * @param {string} filterBy - filterBy 'brand'/'deviceType'
                 */
                $scope.toggleFilter = function toggleFilter (filterBy) {
                    if (filterBy === 'brand') {
                        $scope.deviceRecommender.showDeviceFilterContent = !$scope.deviceRecommender.showDeviceFilterContent;
                    } else {
                        $scope.deviceRecommender.showDeviceTypeFilterContent = !$scope.deviceRecommender.showDeviceTypeFilterContent;
                    }
                };

                /**
                 * Clears filter selections and resets the number of items to be displayed to the initial devices listed
                 * @function clearFilterSelections
                 * @param {object} event - DOM event
                 * @param {string} filterBy - filterBy 'brand'/'deviceType'
                 */
                $scope.clearFilterSelections = function clearFilterSelections (filterBy, event) {
                    try {
                        $scope.deviceRecommender.devicesToBeDisplayed = $scope.initDevicesLoaded;
                        if (filterBy === 'byBrand') {
                            $scope.deviceRecommender.filterOptions.forEach(function (option) {
                                option.values.forEach(function (value) {
                                    value.isSelected = false;
                                    value.isDisabled = false;
                                });
                            });
                            $scope.filterItems('byBrand');
                        } else {
                            $scope.deviceRecommender.deviceTypeFilterOptions.forEach(function (option) {
                                option.values.forEach(function (value) {
                                    value.isSelected = false;
                                    value.isDisabled = false;
                                });
                            });
                            $scope.filterItems('byDeviceType');
                        }
                    } catch (e) {
                        throw e;
                    } finally {
                        event.stopPropagation();
                    }
                };

                /**
                 * Calls the getRecommendedDevices service for the device recommender
                 * @param {*} upgradingDeviceDetails the details of the device currently being upgraded (optional)
                 */
                function getRecommendedDevices (upgradingDeviceDetails) {

                    var upgradingDevicePayload;

                    if (upgradingDeviceDetails) {
                        $scope.deviceRecommender.upgradingDeviceDetails = upgradingDeviceDetails.payload;
                        upgradingDevicePayload = upgradingDeviceDetails.payload;
                    } else {
                        upgradingDevicePayload = {};
                    }

                    deviceRecommenderSrv.getRecommendedDevices(upgradingDevicePayload).then(function (result) {
                        $scope.deviceRecommender.totalRecommendedDevices = result;

                            //gets the initial recommended devices to be displayed from recommender API
                        var x, rexTrueRecommendations = 0;
                        for (x in $scope.deviceRecommender.totalRecommendedDevices) {
                            if ($scope.deviceRecommender.totalRecommendedDevices[x].source === 'rex') {
                                rexTrueRecommendations += 1;
                            }
                        }
                        if (rexTrueRecommendations < $scope.initDevicesLoaded / 2 || rexTrueRecommendations >= $scope.initDevicesLoaded) {
                            if ($scope.deviceRecommender.totalDevicesLoaded > $scope.deviceRecommender.totalRecommendedDevices.length) {
                                $scope.deviceRecommender.totalDevicesLoaded = $scope.deviceRecommender.totalRecommendedDevices.length;
                            }
                            $scope.viewMoreDevices($scope.initDevicesLoaded);
                        } else {
                            $scope.deviceRecommender.totalDevicesLoaded = rexTrueRecommendations;
                            $scope.viewMoreDevices(rexTrueRecommendations);
                        }

                        getFilterOptions($scope.deviceRecommender.totalRecommendedDevices, 'getAllFilterOptions', 'onPageLoad');
                        getFilterOptionsByDeviceType($scope.deviceRecommender.totalRecommendedDevices, 'getAllFilterOptionsByDeviceType', 'onPageLoad');

                        // Calls the selected sku service with the first item
                        selectedSkuSrv.setSelectedDevice($scope.deviceRecommender.items[0].skuId);

                        // Checks for device first scenario when user add a device then choose to upgrade
                        $scope.checkDeviceFirst();
                    });
                }

                /**
                 * Gets the filter(brand) options, also gets the enabled filter(brand) options for a selected deviceType
                 * @function getFilterOptions
                 * @param {object} devices - Devices from which unique filter(brand) options are to be collected
                 * @param {string} task - String which tells whether to get all the filter(brand) options,
                 * or only to find the enabled filter items among all the filter(brand) items
                 * @param {string} phase - get filter options on pageLoad or userSelection.
                 */
                function getFilterOptions (devices, task, phase) {
                    $scope.enabledFilterOptions = [];
                    if (task === 'getAllFilterOptions') {
                        // Adds sorted criteria to be displayed in the filter
                        $scope.deviceRecommender.filterOptions = exBuyflowConstants.deviceFilterOptions.map(function (option) {
                            devices.forEach(function (item) {
                                option.values.push({value: item[option.criterion], isSelected: false, isDisabled: false});
                                if ($scope.enabledFilterOptions.indexOf(item[option.criterion]) === -1) {
                                    $scope.enabledFilterOptions.push(item[option.criterion]);
                                }
                            });
                            option.values = exHelpUtils.uniqueByKey(option.values, function (item) {
                                return item.value;
                            });

                            return option;
                        }).map(function (option) {
                            option.values = option.values.sort(function (a, b) {
                                var aValue = exBuyflowConstants.deviceFilterPriority.indexOf(a.value);
                                aValue = aValue !== -1 ? aValue : Number.MAX_VALUE;
                                var bValue = exBuyflowConstants.deviceFilterPriority.indexOf(b.value);
                                bValue = bValue !== -1 ? bValue : Number.MAX_VALUE;
                                if (aValue < bValue) {
                                    return -1;
                                } else if (aValue > bValue) {
                                    return 1;
                                } else {
                                    return 0;
                                }
                            });
                            return option;
                        });
                        // Unselect all the pre-selected filter options on page load
                        if (phase === 'onPageLoad') {
                            $scope.deviceRecommender.filterOptions.forEach(function (option) {
                                option.values.forEach(function (value) { value.isSelected = false; });
                            });
                        }
                    } else {
                        // Only find the enabled brands among the all filter(brands) items
                        devices.forEach(function (item) {
                            if ($scope.enabledFilterOptions.indexOf(item['brand']) === -1) {
                                $scope.enabledFilterOptions.push(item['brand']);
                            }
                        });
                        unSelectDisabledFilterOptions($scope.enabledFilterOptions, 'byBrand');
                    }
                }

                /**
                 * Gets the filter(DeviceType) options, also gets the enabled filter(DeviceType) options for a selected brand
                 * @function getFilterOptionsByDeviceType
                 * @param {object} devices - Devices from which unique filter(DeviceType) options are to be collected
                 * @param {string} task - String which tells whether to get all the filter(DeviceType) options,
                 * or only to find the enabled filter items among all the filter(DeviceType) items
                 * @param {string} phase - get filter options on pageLoad or userSelection.
                 */
                function getFilterOptionsByDeviceType (devices, task, phase) {
                    var displayName = '';
                    $scope.enabledDeviceTypeFilterOptions = [];
                    if (task === 'getAllFilterOptionsByDeviceType') {
                        // Adds sorted criteria to be displayed in the filter by device type
                        $scope.deviceRecommender.deviceTypeFilterOptions = exBuyflowConstants.deviceTypeFilterOptions.map(function (option) {
                            devices.forEach(function (item) {
                                if (item[option.criterion] === 'pda') {
                                    displayName = 'Cell Phones';
                                } else if (item[option.criterion] === 'netbook') {
                                    displayName = 'Tablets';
                                } else if (item[option.criterion] === 'handset') {
                                    displayName = 'Other';
                                } else {
                                    displayName = 'Wearables';
                                }
                                option.values.push({value: item[option.criterion], displayName: displayName, isSelected: false, isDisabled: false});
                                if ($scope.enabledDeviceTypeFilterOptions.indexOf(item[option.criterion]) === -1) {
                                    $scope.enabledDeviceTypeFilterOptions.push(item[option.criterion]);
                                }
                            });
                            option.values = exHelpUtils.uniqueByKey(option.values, function (item) {
                                return item.value;
                            });
                            return option;
                        });
                        // Unselect all the pre-selected filter options on page load
                        if (phase === 'onPageLoad') {
                            $scope.deviceRecommender.deviceTypeFilterOptions.forEach(function (option) {
                                option.values.forEach(function (value) { value.isSelected = false; });
                            });
                        }
                    } else {
                        // Only find the enabled deviceType among the all filter(deviceType) items
                        devices.forEach(function (item) {
                            if ($scope.enabledDeviceTypeFilterOptions.indexOf(item['deviceType']) === -1) {
                                $scope.enabledDeviceTypeFilterOptions.push(item['deviceType']);
                            }
                        });
                        unSelectDisabledFilterOptions($scope.enabledDeviceTypeFilterOptions, 'byDeviceType');
                    }
                }

                /**
                 * Unselects/un-checks the disabled filter options, also updates the selected filter option count
                 * @function unSelectDisabledFilterOptions
                 * @param {object} enabledFilters - Enabled brand/deviceType filter options
                 * @param {string} filterBy - String filterBy brand or deviceType
                 */
                function unSelectDisabledFilterOptions (enabledFilters, filterBy) {
                    if (filterBy === 'byBrand') {
                        $scope.deviceRecommender.filterOptions.forEach(function (option) {
                            option.values.forEach(function (filterOption) {
                                if (enabledFilters.indexOf(filterOption.value) === -1) {
                                    filterOption.isSelected = false;
                                }
                            });
                        });
                        // Update selection count
                        $scope.deviceRecommender.selectionCount = updateSelectionCount();
                    } else {
                        $scope.deviceRecommender.deviceTypeFilterOptions.forEach(function (option) {
                            option.values.forEach(function (deviceTypeFilterOption) {
                                if (enabledFilters.indexOf(deviceTypeFilterOption.value) === -1) {
                                    deviceTypeFilterOption.isSelected = false;
                                }
                            });
                        });
                        // Update deviceType selection count
                        $scope.deviceRecommender.deviceTypeSelectionCount = updateDeviceTypeSelectionCount();
                    }
                }
                /**
                 * Updates selected deviceType filters count
                 */
                function updateDeviceTypeSelectionCount () {
                    return $scope.deviceRecommender.deviceTypeFilterOptions.reduce(function (count, option) {
                        return count + option.values.filter(function (value) {
                            return value.isSelected;
                        }).length;
                    }, 0);
                }

                /**
                 * Updates selected brands filters count
                 */
                function updateSelectionCount () {
                    return $scope.deviceRecommender.filterOptions.reduce(function (count, option) {
                        return count + option.values.filter(function (value) {
                            return value.isSelected;
                        }).length;
                    }, 0);
                }

                /**
                 * Starts up the controller
                 */
                function activate () {
                    var recommenderLoadedDeferred = $q.defer();
                    var recommenderInstance = {
                        loaded: recommenderLoadedDeferred.promise
                    };
                    $rootScope.$broadcast(exCommonConstants.event.hideGlobalNav, null);

                    profileInfoService.getProfileInfo('reload').then(function (profile) {

                        // Zippy upgrade flow
                        if (profile.ProfileInfo.exUpFlow) {
                            upgradingUserInfoSrv.getUpgradingDeviceDetailsData().then(function (upgradingDeviceDetails) {
                                getRecommendedDevices(upgradingDeviceDetails);
                                $scope.exUpFlow = true;
                            });
                        }

                        // Zippy add a line flow
                        if (profile.ProfileInfo.exAlFlow) {
                            getRecommendedDevices();
                            $scope.exAlFlow = true;
                        }
                    });

                    $window.document.addEventListener('FireNoneCriticalRenderingAssests', function () {
                        recommenderLoadedDeferred.resolve();
                    });
                    // Prefetch device details for all items once the recommender finishes its main load sequence
                    recommenderInstance.loaded.then(function () {

                        profileInfoService.getProfileInfo().then(function (result) {
                            favStoreService.getFavStoreId(result.ProfileInfo.uuid, true);
                        });
                        // Pass comma separated skuids to getItemPriceData function
                        var skuids = $scope.deviceRecommender.totalRecommendedDevices.map(function (item) {
                            return item.skuId;
                        }).join(',');

                        $scope.filterFlairFlags($scope.deviceRecommender.totalRecommendedDevices);
                        if (skuids.length > 0) {
                            deviceRecommenderSrv.getItemPriceData(skuids, true, true).then(function (result) {
                                var commitmentTerms = {};
                                $scope.deviceRecommender.itemPrice = result.payload;
                                angular.forEach($scope.deviceRecommender.itemPrice, function (itemValue, itemKey) {
                                    var commitmentTerm = {};
                                    commitmentTerm.name = itemValue.contractType;
                                    commitmentTerm.leaseTotalMonths = itemValue.contractLength;
                                    commitmentTerm.deviceType = itemValue.deviceType;
                                    commitmentTerms[itemKey] = commitmentTerm;
                                    $scope.imgUrl[itemKey] = imagePathService.getXpressImagePath(
                                        itemValue.brand, null, itemValue.shortDisplayName, itemValue.color, '-hero.png');
                                });
                                $scope.deviceRecommender.commitmentTerms = commitmentTerms;
                                $scope.fetchShortLegalContentForDevices($scope.deviceRecommender.commitmentTerms);
                            });
                        }
                        $scope.deviceRecommender.totalRecommendedDevices.forEach(function (item) {
                            var params = {
                                includeAssociatedProducts: true,
                                includePrices: true,
                                skuId: item.skuId,
                                groupResultsByVariants: true,
                                filterOffers: false
                            };
                            deviceConfigSrv.getDeviceDetails(item.skuId, params, true, true);
                        });
                    });
                }

                activate();
            }]);
})();