(function () {
    'use strict';

    /**
     * This controller shows the legal content on choosing subtotal tooltip.
     *
     * __Requirements__
     * * Get subtotal subtotal tooltip information from a REST service
     * * Expose tooltip information to scope
     *
     * @module accessorySubtotalTooltipCtrl
     *
     * @see {@link ../directives/#module_exAccessorySubtotalTooltip|exAccessorySubtotalTooltip}
     */
    angular.module('exBuyflow')

        .controller('accessorySubtotalTooltipCtrl', ['$scope', 'exBuyflowConstants', 'exCqTranslatorKeyService',
            function ($scope, exBuyflowConstants, exCqTranslatorKeyService) {
                var subtotalTooltipDetails = {
                    description: {}
                };
                $scope.fetchSubtotalTooltipDetails = fetchSubtotalTooltipDetails;
                $scope.subtotalTooltipDetails = subtotalTooltipDetails;

                /**
                 * Scope function to get subtotal tool tip legal
                 */
                function fetchSubtotalTooltipDetails () {
                    var cmsKeys = [];
                    cmsKeys.push(exBuyflowConstants.legalSubtotalToolTipContentKey);
                    exCqTranslatorKeyService.getCqTranslatorKeys(cmsKeys).then(function (result) {
                        if (result) {
                            subtotalTooltipDetails.description = result[exBuyflowConstants.legalSubtotalToolTipContentKey];
                        }
                    });
                }

                /**
                 * Starts up the controller
                 */
                function activate () {
                    fetchSubtotalTooltipDetails();
                }

                activate();
            }]);
})();
