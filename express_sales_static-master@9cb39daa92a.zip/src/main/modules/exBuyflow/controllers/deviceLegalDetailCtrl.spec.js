(function () {
    'use strict';

    define(['deviceLegalDetailCtrl'], function () {
        describe('src/main/modules/exBuyflow/controllers/deviceLegalDetailCtrl.spec.js', function () {
            describe('deviceLegalDetailCtrl controller of exBuyflow', function () {
                var $rootScope, controller, $scope, contentService, deviceConfigSrv, selectedSkuSrv,
                    params = {
                        groupResultsByVariants: true,
                        includeAssociatedProducts: false,
                        includePrices: true,
                        skuId: 'sku8030625'
                    };
                beforeEach(function () {
                    module('exBuyflow', function ($provide) {
                        contentService = jasmine.createSpyObj('contentService', ['getProductLegalPaths', 'getProductLegalContent']);
                        deviceConfigSrv = jasmine.createSpyObj('deviceConfigSrv', ['getDeviceDetails']);
                        selectedSkuSrv = jasmine.createSpyObj('selectedSkuSrv', ['getSelectedDevice']);
                        $provide.value('contentService', contentService);
                        $provide.value('deviceConfigSrv', deviceConfigSrv);
                        $provide.value('selectedSkuSrv', selectedSkuSrv);
                    });

                    inject(function ($injector) {
                        $rootScope = $injector.get('$rootScope');
                        controller = $injector.get('$controller');
                    });
                    $scope = $rootScope.$new();

                    contentService.getProductLegalPaths.and.returnValue({
                        'then': function (callBackFN) {
                            callBackFN(Endpoint_deviceLegalContentNode.get_content_node.result);
                        }
                    });

                    contentService.getProductLegalContent.and.returnValue({
                        'then': function (callBackFN) {
                            callBackFN(Endpoint_deviceLegalContentNode.get_shared_content.result);
                        }
                    });

                    deviceConfigSrv.getDeviceDetails.and.returnValue({
                        'then': function (callBackFN) {
                            var data = {data: Endpoint_deviceDetailsApi.get_device_details_legal_notes.result};
                            callBackFN(data);
                        }
                    });
                    selectedSkuSrv.getSelectedDevice.and.returnValue('sku8030625');
                    controller('deviceLegalDetailCtrl', {
                        $scope: $scope,
                        contentService: contentService,
                        deviceConfigSrv: deviceConfigSrv,
                        selectedSkuSrv: selectedSkuSrv
                    });
                });

                describe('general functionality', function () {
                    it('should get long legal content for selected device for long legal overlay', function () {
                        expect(deviceConfigSrv.getDeviceDetails).toHaveBeenCalledWith('sku8030625', params);
                        expect(contentService.getProductLegalPaths).toHaveBeenCalledWith('/cases/otterbox-defender-series-case-and-holster-iphone-7-plus');
                        expect(contentService.getProductLegalContent).toHaveBeenCalled();
                    });
                });
            });
        });
    });
})();
