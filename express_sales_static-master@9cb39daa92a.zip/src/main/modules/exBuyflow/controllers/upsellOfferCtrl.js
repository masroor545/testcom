(function () {
    'use strict';

    /**
     * Controls upsell offer information
     *
     * __Requirements__
     * * Get offer details from a REST service
     * * Format offer details based on display logic
     * * Add offer to cart
     * * Open device config modal for multiple offers
     * * Expose subtotal amounts
     *
     * @module upsellOfferCtrl
     *
     * @see {@link ../directives/#module_upsellOffer|upsellOffer}
     */
    angular.module('exBuyflow')

        .controller('upsellOfferCtrl', ['$scope', '$q', '$modal', 'upsellOfferSrv', 'exCommonConstants', 'exBuyflowConstants',
            'exCartService', 'selectedSkuSrv', 'imagePathService', 'reportingDataSrv',
            function ($scope, $q, $modal, upsellOfferSrv, exCommonConstants, exBuyflowConstants,
                 exCartService, selectedSkuSrv, imagePathService, reportingDataSrv) {

                var vm = this;
                vm.offers = [];
                vm.subtotal = {};

                vm.upsellOfferAddItemToCart = upsellOfferAddItemToCart;
                vm.multiSkuUpsellOffer = multiSkuUpsellOffer;
                vm.onSkipToCheckout = onSkipToCheckout;
                vm.openSeeOfferDetailsModal = upsellOfferSrv.openSeeOfferDetailsModal;


                activate();

                /**
                 * Starts up the controller
                 * @async
                 * @returns {Promise} Details of the offers
                 */
                function activate () {
                    return upsellOfferSrv.getUpsellOfferDetails().then(function (data) {
                        var payload = data.payload.methodReturnValue;

                        // Cart subtotal
                        vm.subtotal = {
                            cartTotalAmount: payload.cartTotalAmount,
                            cartMonthlyAmount: payload.cartMonthlyAmount
                        };

                        vm.offers = payload.wirelessProductDetailsBeans.map(function (offer) {
                            var formattedOffer = {};
                            formattedOffer.skuItems = getRequiredUpsellOfferDetails(offer);
                            formattedOffer.offerId = offer.offerId;
                            formattedOffer.multiSkuOffer = offer.multiSkuOffer;
                            formattedOffer.defaultSkuId = offer.defaultSkuId;

                            // Filters items array by skuId to a single item
                            formattedOffer.defaultSku = formattedOffer.skuItems.filter(function (sku) {
                                return sku.skuId === offer.defaultSkuId;
                            })[0];

                            return formattedOffer;
                        });

                        vm.offers.forEach(function (offer) {
                            upsellOfferSrv.getUpsellOfferContentDetails(offer.offerId).then(function (contentDetails) {
                                offer.offerContentDetails = getRequiredUpsellOfferLegalContentDetails(contentDetails);

                                // Gets upsell offer details - headline, subheadline, description, legal content
                                offer.offerHeadLine = offer.offerContentDetails[0].headLine;
                                offer.offerSubheadLine = offer.offerContentDetails[0].subheadLine;
                                offer.offerInBodyContent = offer.offerContentDetails[0].inBodyContent;
                            });

                        });

                        upsellOfferSrv.setOfferCount(vm.offers.length);

                        var eventPayload = reportingDataSrv.getUpsellPayload(vm.skuItems);

                        $scope.$emit(exCommonConstants.event.DS_REPORTING_EVENT, {
                            eventAction: 'systemEvent',
                            eventCode: 'DS_System_Upgrade_UpSell_Offer_Display',
                            additionaldata: eventPayload
                        }, $scope);

                    });
                }

                /**
                 * this method makes a post service when clicked on proceed to checkout button on upsellOffer page
                 * @public
                 * @function onSkipToCheckout
                 */
                function onSkipToCheckout () {
                    var eventPayload = reportingDataSrv.getUpsellPayload(vm.offerDetails);

                    // Fire link click event when user clicks No, thanks on upsell page
                    $scope.$emit(exCommonConstants.event.DS_REPORTING_EVENT, {
                        eventAction: 'linkClick',
                        eventCode: 'Link_Click',
                        additionaldata: {
                            'linkName': exBuyflowConstants.linkName.skipUpsellOffer,
                            'linkPosition': exBuyflowConstants.linkPosition,
                            'linkDestinationURL': exBuyflowConstants.virtualUrl.onePageCheckout
                        }
                    }, $scope);

                    $scope.$emit(exCommonConstants.event.DS_REPORTING_EVENT, {
                        eventAction: 'formSubmit',
                        eventCode: 'DS_Upgrade_Proceed_To_Checkout_Submit',
                        additionaldata: eventPayload
                    }, $scope);

                    upsellOfferSrv.skipToCheckout().then(function (data) {

                        if (data.response !== undefined && data.response !== null
                            && data.response.status === exCommonConstants.errorStatus) {
                            eventPayload = reportingDataSrv.updateEventPayloadFailure(eventPayload, data);
                        }

                        $scope.$emit(exCommonConstants.event.DS_REPORTING_EVENT, {
                            eventAction: 'formResponse',
                            eventCode: 'DS_Upgrade_Proceed_To_Checkout_Submit',
                            additionaldata: eventPayload
                        }, $scope);
                    });
                }

                /**
                 * gets the BOGO upsell offer details from UpsellOffer API
                 * @private
                 * @function getRequiredUpsellOfferDetails
                 * @param {Array<object>} offer
                 * @returns {Array<object>} device offers details
                 */
                function getRequiredUpsellOfferDetails (offer) {
                    var upsellOfferDetails = [];

                    Object.keys(offer.skuItems).forEach(function (key) {
                        var details = offer.skuItems[key];
                        upsellOfferDetails.push({
                            skuId: details.skuId,
                            productId: details.productId,
                            displayName: details.displayName,
                            model: details.model,
                            priceList: details.priceList,
                            imagePath: deviceImageUrl(details)
                        });
                    });

                    return upsellOfferDetails;
                }

                /**
                 * Gets the device image from imagePathService.
                 * @private
                 * @param {object} details offer details
                 * @return {string} xpress image url
                 */
                function deviceImageUrl (details) {
                    return imagePathService.getXpressImagePath(details.manufacturer,
                        details.shortDisplayName, details.displayName,
                        details.color, exCommonConstants.heroDeviceImageUrlExtension);
                }

                /**
                 * gets the offer legal content details from sharedContentRetrievalUrl
                 * @private
                 * @function getRequiredUpsellOfferLegalContentDetails
                 * @param {object} offerContent Offer legal content information
                 * @returns {object} offer specific legal content details
                 */
                function getRequiredUpsellOfferLegalContentDetails (offerContent) {
                    var upsellOfferContentDetails = [];
                    angular.forEach(offerContent, function (item, key) {
                        if (offerContent.hasOwnProperty(key)) {
                            upsellOfferContentDetails.push({
                                headLine: (item.pageTitle) ? item.pageTitle[0] : '',
                                subheadLine: (item.navTitle) ? item.navTitle[0] : '',
                                inBodyContent: (item.subtitle) ? item.subtitle[0] : '',
                                legalContent: (item['jcr:description']) ? item['jcr:description'][0] : ''
                            });
                        }
                    });
                    return upsellOfferContentDetails;
                }

                /**
                 * Adds the upsell offer item to the cart by passing Request Payload items and input parameters to UpsellOffer post service
                 * @public
                 * @param {object} offer
                 * @function upsellOfferAddItemToCart
                 */
                function upsellOfferAddItemToCart (offer) {
                    var sku = offer.defaultSku;
                    var offerDetailsData = [];
                    var valueMap = {};
                    var items = {
                        items: {
                            items: offerDetailsData
                        }
                    };
                    var priceList = sku.priceList[0];

                    // For a single skuId of an offer product
                    // Get the skuId details of a single product which is the offer that is
                    // being displayed
                    valueMap.contractType = priceList.type === 'regular' ? 'regular' : priceList.name;

                    // If the contract type is regular then the contract length is the name
                    valueMap.contractLength = valueMap.contractType === 'regular' ? priceList.name.toString() : priceList.leaseTotalMonths.toString();

                    offerDetailsData.push({
                        valueMap: valueMap,
                        catalogRefId: sku.skuId,
                        productId: sku.productId,
                        quantity: 1
                    });

                    var eventPayload = reportingDataSrv.getAddToCartUpsellPayload(items,
                        sku),
                        eventCode = sku.preOrderable ? 'DS_Upgrade_Cart_Preorder_Submit' : 'DS_Upgrade_Cart_Add_Submit';

                    $scope.$emit(exCommonConstants.event.DS_REPORTING_EVENT, {
                        eventAction: 'formSubmit',
                        eventCode: eventCode,
                        additionaldata: eventPayload
                    }, $scope);

                    // Request Payload items
                    exCartService.addItemToCart(items,
                        {
                            actionType: 'addItemAndGoToNextStep',
                            offerId: offer.offerId,
                            losgBuyFlowType: 'AL',
                            addNewLine: 'true',
                            wirelessBuyFlowType: 'MIXEDCART',
                            quantity: 1
                        }).then(function (data) {
                            if (data.response !== undefined && data.response !== null
                                && data.response.status === exCommonConstants.errorStatus) {
                                eventPayload = reportingDataSrv.updateEventPayloadFailure(eventPayload, data);
                            }

                            $scope.$emit(exCommonConstants.event.DS_REPORTING_EVENT, {
                                eventAction: 'formResponse',
                                eventCode: eventCode,
                                additionaldata: eventPayload
                            }, $scope);
                        });
                }

                /**
                 * Opens config modal and exposes the offerId to its scope
                 * @function multiSkuUpsellOffer
                 * @public
                 * @param {string} skuId
                 * @param {Array<object>} offer
                 */
                function multiSkuUpsellOffer (skuId, offer) {
                    selectedSkuSrv.setSelectedDevice(skuId);

                    var offerScope = $scope.$new();
                    offerScope.offerId = offer.offerId;
                    $modal.open({
                        templateUrl: '/shop/xpress/modals/upsell-offer.modal.html',
                        windowClass: 'modal-fullscreen',
                        scope: offerScope
                    });

                    //Fire page load event when Accessory displayed on accessory recommender page as a modal. Should only be fired if getting called to show modal.
                    $scope.$emit(exCommonConstants.event.DS_REPORTING_PAGELOAD_EVENT,
                        exBuyflowConstants.friendlyPageName.multiSkuUpsellOffer,
                        exBuyflowConstants.virtualUrl.multiSkuUpsellOffer);
                }


            }]);
})();