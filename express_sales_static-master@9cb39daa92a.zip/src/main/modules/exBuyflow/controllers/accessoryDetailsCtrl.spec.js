(function () {
    'use strict';

    define(['accessoryDetailsCtrl'], function () {
        describe('src/main/modules/exBuyflow/controllers/accessoryDetailsCtrl.spec.js', function () {
            describe('accessoryDetailsCtrl controller of exBuyflow', function () {
                var $rootScope, controller, scope, contentService, exAccessoryContentService, exCommonConstants,
                    exCqTranslatorKeyService;

                exAccessoryContentService = jasmine.createSpyObj('exAccessoryContentService',
                    ['getDetailsLegacyContent']);

                exAccessoryContentService.getDetailsLegacyContent.and.returnValue({
                    'then': function (callback) {
                        callback(true);
                    }
                });

                contentService = jasmine.createSpyObj('contentService',
                    ['getProductOverviewContent', 'getProductFeaturesContent', 'getProduct360Images',
                        'getProductLegalPaths', 'getProductLegalContent']);

                contentService.getProductOverviewContent.and.returnValue({
                    'then': function (callback) {
                        callback(true);
                    }
                });

                contentService.getProductFeaturesContent.and.returnValue({
                    'then': function (callback) {
                        callback(true);
                    }
                });

                contentService.getProduct360Images.and.returnValue({
                    'then': function (callback) {
                        callback(true);
                    }
                });

                contentService.getProductLegalPaths.and.returnValue({
                    'then': function (callback) {
                        contentService.getProductLegalContent.and.returnValue({
                            'then': function (callback) {
                                var unescapedHTML = ['&amp;', '&lt;'];
                                callback(unescapedHTML);
                            }
                        });
                        callback(true);
                    }
                });

                exCqTranslatorKeyService = jasmine.createSpyObj('exCqTranslatorKeyService',
                    ['getCqTranslatorKeys']);

                exCqTranslatorKeyService.getCqTranslatorKeys.and.returnValue({
                    'then': function (callback) {
                        callback(true);
                    }
                });

                beforeEach(function () {
                    module('exBuyflow', {
                        contentService: contentService,
                        exCqTranslatorKeyService: exCqTranslatorKeyService,
                        exAccessoryContentService: exAccessoryContentService
                    });

                    inject(function ($injector) {
                        exCommonConstants = $injector.get('exCommonConstants');
                        controller = $injector.get('$controller');
                        $rootScope = $injector.get('$rootScope');
                        scope = $rootScope.$new();
                    });
                    scope.accessoryConfig = {
                        selectedSku: {
                            skuID: 'sku7860293',
                            accessoryPageURL: '/content/att/cellphones/iphone/apple-iphone-7/'
                        }
                    };
                    controller('accessoryDetailsCtrl', {
                        $scope: scope
                    });

                    $rootScope.$digest();
                });

                describe('general functionality', function () {
                    it('should have all services needed to be defined', function () {
                        expect(contentService.getProductOverviewContent).toBeDefined();
                        expect(contentService.getProductOverviewContent).toBeDefined();
                        expect(contentService.getProductFeaturesContent).toBeDefined();
                        expect(contentService.getProduct360Images).toBeDefined();
                        expect(contentService.getProductLegalPaths).toBeDefined();
                        expect(contentService.getProductLegalContent).toBeDefined();
                        expect(exCqTranslatorKeyService.getCqTranslatorKeys).toBeDefined();
                    });
                    it('should have all services needed to be called on broadcast', function () {
                        var data = {
                            accessoryPageURL: '/content/att/cellphones/iphone/apple-iphone-7/',
                            skuId: 'sku7860293',
                            legalNotes: [{
                                'adminDisplay': 'California Legal Disclaimer',
                                'key': 'prop65'
                            }]
                        };
                        var translatorKeys = [
                            'proposition.header.lbl.prop65',
                            'proposition.content.body.prop65'
                        ];

                        $rootScope.$broadcast(exCommonConstants.event.selectedSkuInFocus, data);
                        expect(contentService.getProduct360Images).toHaveBeenCalled();
                        expect(exCqTranslatorKeyService.getCqTranslatorKeys).toHaveBeenCalledWith(translatorKeys);
                    });
                });

            });

        });
    });
})();
