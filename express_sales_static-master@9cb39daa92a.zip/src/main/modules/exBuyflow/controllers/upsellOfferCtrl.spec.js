(function () {
    'use strict';

    define(['upsellOfferCtrl'], function () {
        describe('src/main/modules/exBuyflow/controllers/upsellOfferCtrl.spec.js', function () {
            describe('upsellOfferCtrl of exBuyflow', function () {
                var vm, controller, mockUpsellController, scope, $modal, $modalStack, exHelpUtils, $rootScope, upsellOfferSrv, exCartService, selectedSkuSrv, reportingDataSrv;
                var offerDetails = Endpoint_upsellOfferDetailsApi.get_upsell_offer_details;
                var offerContentDetails = Endpoint_upsellOfferContentNode.get_legal_content_node;
                var addToCartDetails = Endpoint_addToCart.upsell_add_to_cart;

                beforeEach(function () {
                    module('exBuyflow', {
                        $modalStack: $modalStack
                    });

                    reportingDataSrv = jasmine.createSpyObj('reportingDataSrv', ['getAddToCartUpsellPayload', 'getOnProceedToCheckoutPayload', 'getUpsellPayload']);
                    reportingDataSrv.getAddToCartUpsellPayload.and.returnValue({
                        items: [{'itemSku': 'sku8040303'}]
                    });

                    reportingDataSrv.getOnProceedToCheckoutPayload.and.returnValue({
                        items: [{itemSku: 'sku1234567'}]
                    });

                    $modal = jasmine.createSpyObj('$modal', ['open']);
                    $modal.open.and.returnValue(true);

                    exHelpUtils = jasmine.createSpyObj('exHelpUtils', ['closeActiveModal']);
                    exHelpUtils.closeActiveModal.and.returnValue(true);

                    inject(function ($injector) {
                        controller = $injector.get('$controller');
                        $rootScope = $injector.get('$rootScope');
                        selectedSkuSrv = $injector.get('selectedSkuSrv');
                        scope = $rootScope.$new();

                        upsellOfferSrv = jasmine.createSpyObj('upsellOfferSrv',
                            [
                                'getUpsellOfferDetails',
                                'getUpsellOfferContentDetails',
                                'skipToCheckout',
                                'setOfferCount',
                                'openSeeOfferDetailsModal'
                            ]);
                        upsellOfferSrv.getUpsellOfferDetails.and.returnValue({
                            'then': function (callback) {
                                callback(offerDetails.result);
                            }
                        });
                        upsellOfferSrv.getUpsellOfferContentDetails.and.returnValue({
                            'then': function (callback) {
                                callback(offerContentDetails.result);
                            }
                        });
                        upsellOfferSrv.skipToCheckout.and.returnValue({
                            'then': function (callback) {
                                callback(offerDetails.result);
                            }
                        });
                        upsellOfferSrv.openSeeOfferDetailsModal.and.returnValue({
                            'then': function (cb) { cb(); }
                        });


                        spyOn(selectedSkuSrv, 'setSelectedDevice');
                        exCartService = jasmine.createSpyObj('exCartService', ['addItemToCart']);
                        exCartService.addItemToCart.and.returnValue({
                            'then': function (callback) {
                                callback(addToCartDetails.result);
                            }
                        });
                        vm = controller('upsellOfferCtrl', {
                            $scope: scope,
                            $modal: $modal,
                            upsellOfferSrv: upsellOfferSrv,
                            exCartService: exCartService,
                            reportingDataSrv: reportingDataSrv
                        });

                    });
                    $rootScope.$digest();
                });

                afterEach(function () {
                    selectedSkuSrv.setSelectedDevice.calls.reset();
                    $modal.open.calls.reset();
                });

                it('should return upsell details to view', function () {
                    vm.offers.forEach(function (offer) {
                        offer.skuItems.forEach(function (sku) {
                            expect(sku.skuId.indexOf('sku')).not.toBe(-1);
                            expect(sku.productId.indexOf('prod')).not.toBe(-1);
                            expect(typeof(sku.displayName)).toEqual('string');
                            expect(typeof(sku.model)).toEqual('string');
                        });
                        expect(typeof(offer.multiSkuOffer)).toEqual('boolean');
                        expect(offer.defaultSkuId.indexOf('sku')).not.toBe(-1);
                        expect(offer.defaultSku.skuId).toEqual(offer.defaultSkuId);
                        expect(typeof(offer.offerId)).toEqual('string');
                        expect(offer.offerId.length).toEqual(7);
                        expect(offer.offerHeadLine).toEqual(offerContentDetails.result['offercontent/200004']['pageTitle'][0]);
                        expect(offer.offerSubheadLine).toEqual(offerContentDetails.result['offercontent/200004']['navTitle'][0]);
                        expect(offer.offerInBodyContent).toEqual(offerContentDetails.result['offercontent/200004']['subtitle'][0]);
                    });
                });

                it('should update the service with the number of offers', function () {
                    expect(upsellOfferSrv.setOfferCount).toHaveBeenCalledWith(vm.offers.length);
                });

                it('should call getUpsellOfferDetails method on upsellOfferSrv on calling upsellOfferSrv', function () {
                    expect(upsellOfferSrv.getUpsellOfferDetails).toHaveBeenCalled();
                });

                it('should add the upsell offer item to cart', function () {
                    var offer = vm.offers[0];
                    vm.upsellOfferAddItemToCart(offer);
                    expect(exCartService.addItemToCart.calls.mostRecent().args.length).toEqual(2);
                    var cartItem = exCartService.addItemToCart.calls.mostRecent().args[0].items.items[0];
                    expect(cartItem).toBeDefined();
                    expect(typeof cartItem.valueMap).toEqual('object');
                    expect(typeof cartItem.valueMap.contractType).toEqual('string');
                    expect(typeof cartItem.valueMap.contractLength).toEqual('string');
                    expect(cartItem.quantity).toEqual(1);
                    expect(typeof cartItem.catalogRefId).toEqual('string');
                    expect(typeof cartItem.productId).toEqual('string');

                    var params = exCartService.addItemToCart.calls.mostRecent().args[1];
                    expect(params.offerId).toEqual(offer.offerId);
                });

                it('should make a post call to back-end', function () {
                    vm.onSkipToCheckout();
                    expect(upsellOfferSrv.skipToCheckout).toHaveBeenCalled();
                });

                // click on get this offer button and open modal
                it('should update the device config', function () {
                    var skuId = vm.offers[0].defaultSkuId;
                    selectedSkuSrv.setSelectedDevice.calls.reset();
                    vm.multiSkuUpsellOffer(skuId, vm.offers[0]);
                    expect(selectedSkuSrv.setSelectedDevice).toHaveBeenCalledWith(skuId);
                    expect($modal.open).toHaveBeenCalled();
                });

                it('should open the see offer details modal', function () {
                    vm.openSeeOfferDetailsModal();
                    expect(upsellOfferSrv.openSeeOfferDetailsModal).toHaveBeenCalled();
                });

                describe('should check add to cart accessory reporting functionalities', function () {

                    beforeEach(function () {
                        spyOn(scope, '$emit').and.callThrough();
                        scope.$emit.calls.reset();
                    });

                    xit('should check add to cart accessory reporting functionalities from accessory recommender page', function () {
                        var expectedReportingObjectSubmit = jasmine.objectContaining({
                                eventAction: 'formSubmit',
                                eventCode: 'DS_Upgrade_Cart_Add_Submit',
                                additionaldata: jasmine.objectContaining({
                                    items: [jasmine.objectContaining({itemSku: vm.offers[0].defaultSkuId})]
                                })
                            }),
                            expectedReportingObjectResponse = jasmine.objectContaining({
                                eventAction: 'formResponse',
                                eventCode: 'DS_Upgrade_Cart_Add_Submit',
                                additionaldata: jasmine.objectContaining({
                                    items: [jasmine.objectContaining({itemSku: vm.offers[0].defaultSkuId})]
                                })
                            });
                        vm.upsellOfferAddItemToCart(vm.offers[0]);
                        expect(scope.$emit).toHaveBeenCalledWith('DS_Reporting_Event', expectedReportingObjectSubmit, jasmine.any(Object));
                        expect(scope.$emit).toHaveBeenCalledWith('DS_Reporting_Event', expectedReportingObjectResponse, jasmine.any(Object));
                        scope.$apply();
                    });

                    xit('should check add to cart accessory reporting functionalities from accessory recommender page', function () {
                        var expectedReportingObjectSubmit = jasmine.objectContaining({
                                eventAction: 'formSubmit',
                                eventCode: 'DS_Upgrade_Cart_Preorder_Submit',
                                additionaldata: jasmine.objectContaining({
                                    items: [jasmine.objectContaining({itemSku: vm.offers[0].skuItems[0].skuId})]
                                })
                            }),
                            expectedReportingObjectResponse = jasmine.objectContaining({
                                eventAction: 'formResponse',
                                eventCode: 'DS_Upgrade_Cart_Preorder_Submit',
                                additionaldata: jasmine.objectContaining({
                                    items: [jasmine.objectContaining({itemSku: vm.offerDetails[0].skuId})]
                                })
                            });
                        vm.offerDetails[0].preOrderable = true;
                        vm.upsellOfferAddItemToCart();
                        expect(scope.$emit).toHaveBeenCalledWith('DS_Reporting_Event', expectedReportingObjectSubmit, jasmine.any(Object));
                        expect(scope.$emit).toHaveBeenCalledWith('DS_Reporting_Event', expectedReportingObjectResponse, jasmine.any(Object));
                        scope.$apply();
                    });

                    it('should check add to cart accessory reporting functionalities from accessory recommender page', function () {
                        var expectedReportingObjectSubmit = jasmine.objectContaining({
                                eventAction: 'formSubmit',
                                eventCode: 'DS_Upgrade_Proceed_To_Checkout_Submit'
                            }),
                            expectedReportingObjectResponse = jasmine.objectContaining({
                                eventAction: 'formResponse',
                                eventCode: 'DS_Upgrade_Proceed_To_Checkout_Submit'
                            });
                        vm.onSkipToCheckout();
                        expect(scope.$emit).toHaveBeenCalledWith('DS_Reporting_Event', expectedReportingObjectSubmit, jasmine.any(Object));
                        expect(scope.$emit).toHaveBeenCalledWith('DS_Reporting_Event', expectedReportingObjectResponse, jasmine.any(Object));
                        scope.$apply();
                    });

                    it('should check page load event called when opening multisku offer modal', function () {
                        var friendlyPageName = 'DS Upgrade Add A Line Device Details Pg',
                            virtualUrl = '/shop/xpress/virtual/device-details.html+AddALineOffer';
                        vm.multiSkuUpsellOffer(vm.offers[0].defaultSkuId, vm.offers[0]);
                        expect(scope.$emit).toHaveBeenCalledWith('DS_Reporting_PageLoad_Event', friendlyPageName, virtualUrl);
                    });

                    // check that link click event fires when user clicks on No, thanks on upsell offer page
                    it('should fire link clink event with appropriate value when user clicks on No, thanks on upsell offer page', function () {
                        var expectedReportingObject = jasmine.objectContaining({
                            eventAction: 'linkClick',
                            eventCode: 'Link_Click',
                            additionaldata: {
                                'linkName': 'No, thanks',
                                'linkPosition': 'Body',
                                'linkDestinationURL': '/checkout/onepagecheckout.html'
                            }
                        });
                        vm.onSkipToCheckout();
                        expect(scope.$emit).toHaveBeenCalledWith('DS_Reporting_Event', expectedReportingObject, jasmine.anything());
                        scope.$apply();
                    });
                });
            });
        });
    });
})();
