(function () {
    'use strict';

    /**
     * This controller retrieves and displays device details.
     *
     * __Requirements__
     * * Get skuId of details from a broadcast
     * * Call services to get device details
     *
     * @module deviceDetailsCtrl
     *
     * @see {@link ../directives/#module_exDeviceDetails|exDeviceDetails}
     */
    angular.module('exBuyflow')

        .controller('deviceDetailsCtrl', ['$scope', '$controller', '$rootScope', 'contentService', 'exCommonConstants', 'exBuyflowConstants',
            'exCqTranslatorKeyService', 'accessoryRecommenderService', 'favStoreService', 'imagePathService', '$window', 'deviceRecommenderSrv', 'protectionPlanService',
            function ($scope, $controller, $rootScope, contentService, exCommonConstants, exBuyflowConstants,
                exCqTranslatorKeyService, accessoryRecommenderService, favStoreService, imagePathService, $window, deviceRecommenderSrv, protectionPlanService) {

                $scope.deviceDetails = {
                    showFeatureContent: false,
                    showImagesContent: false,
                    showDeviceLegalContent: false,
                    showOverviewContent: false
                };
                $scope.deviceConfig = {};
                $scope.displayDeviceDetails = displayDeviceDetails;
                $scope.triggerAddToCart = triggerAddToCart;
                $scope.reviewAccordianToBeDisplayed = reviewAccordianToBeDisplayed;
                $scope.accessoryCategories =
                    typeof($scope.accessoryCategories) !== 'undefined' ? $scope.accessoryCategories : '[]';
                $scope.categories = JSON.parse($scope.accessoryCategories);
                $scope.RSI = $scope.relaxStoreIndicator;

                //scope level broadcasts that gets set when the device details information is returned
                //returns us an object that has SkuID and DevicePathPagePath
                $scope.$on(exCommonConstants.event.selectedSkuInFocus, function (event, data) {
                    $scope.deviceConfig = data;
                    activate(data);
                });

                /**
                 * Calls addToCart function when user has clicked add to cart button from device details
                 * @public
                 */
                function triggerAddToCart () {
                    $rootScope.$broadcast(exCommonConstants.event.deviceAddedFromDetails, true);
                }

                /**
                 * Gets the translator keys and their content for the legalNotes array from the getDeviceProductDetails
                 *  and exCqTranslatorKey services.
                 * @function getLegalNotesTranslatorKeys
                 * @param {Array} legalNotes Legal notes array from the getDeviceProductDetails service.
                 * @returns {Array} Legal notes translator keys ready for submission to the exCqTranslatorKey service.
                 * @private
                 */
                function getLegalNotesTranslatorKeys (legalNotes) {
                    var partialHeader = 'proposition.header.lbl.';
                    var partialBody = 'proposition.content.body.';
                    var translatorKeys = [];
                    var legalNoteContent = [];

                    // catch undefined and null
                    legalNotes = legalNotes || [];

                    // step through each object in the legalNotes array and create head/body translator keys for each.
                    for (var i = 0, len = legalNotes.length; i < len; i++) {
                        translatorKeys.push(partialHeader + legalNotes[i].key);
                        translatorKeys.push(partialBody + legalNotes[i].key);
                    }

                    if (translatorKeys !== []) {
                        exCqTranslatorKeyService.getCqTranslatorKeys(translatorKeys).then(function (cqContent) {
                            // step through the translator keys, two keys at once. One for the head, another for the body.
                            for (var i = 0, len = translatorKeys.length; i < len; i += 2) {
                                legalNoteContent.push({
                                    head: cqContent[translatorKeys[i]],
                                    body: cqContent[translatorKeys[i + 1]]
                                });
                            }
                        });
                    }

                    return legalNoteContent;
                }

                /**
                 * Scope function setter to show or hide the device details section
                 * @public
                 * @param {boolean} visible
                 */
                function displayDeviceDetails (visible) {
                    if (visible === false) {
                        $scope.deviceConfig.openReviewsTab = false;
                        $scope.deviceConfig.legalAccordionOpen = false;
                        $scope.deviceDetails.openQATab = false;
                        $scope.deviceDetails.openImageTab = false;
                    }
                    $scope.deviceConfig.displayDeviceDetails = visible;
                }

                /**
                 * Helper function to get accessory Lists
                 * @private
                 * @param {Array} accessories Array of objects containing products
                 * @param {boolean} protectionPlanFlag
                 * @return {Array} Accessory list
                 */
                function getfilteredAccessories (accessories, protectionPlanFlag) {

                    var filteredAccessories;

                    // filter accessories by business rules with protection plan flag enabled and disabled
                    filteredAccessories = accessoryRecommenderService.getAccessoryList(accessories, protectionPlanFlag);
                    if (protectionPlanFlag === false) {
                        var firstSkuID = filteredAccessories.slice(0, 1);
                        var newSkuIDs = filteredAccessories.slice(1);
                        filteredAccessories = newSkuIDs.concat(firstSkuID);
                    }

                    return filteredAccessories;
                }

                /**
                 * Helper function to create image paths for all of the filtered accessories
                 * @private
                 * @param {Array} accessories Array of objects containing products
                 * @param {boolean} protectionPlanFlag
                 * @return {string} xpress image path
                 */
                function parseImagePaths (accessories, protectionPlanFlag) {
                    var filteredAccessories = getfilteredAccessories(accessories, protectionPlanFlag)
                        .concat(getfilteredAccessories(accessories, !protectionPlanFlag));

                    // create image paths for all of the filtered accessories
                    return filteredAccessories.map(function (accessory) {
                        return imagePathService.getXpressImagePath(accessory.brand, accessory.name, accessory.name, accessory.color, '-hero.png');
                    });
                }
                /**
                 * Parses accessories product array and prefetches images found within it.
                 * @param {Array} accessories Array of objects containing products
                 */
                function parseAndPrefetch (accessories) {

                    /**
                     * Checks an array for the existence of a value.
                     * @param {Array} _array Array to check for value.
                     * @param {string} value Value to find in the array.
                     * @returns {Boolean} Returns true if value has been found, otherwise false.
                     */
                    var foundIn = function foundIn (_array, value) {
                        for (var i = 0, len = _array.length; i > len; i++) {
                            if (_array[i] === value) {
                                return true;
                            }
                        }
                        return false;
                    };

                    var imagePaths;
                    var uniqueImagePaths = [];
                    var filteredAccessorySkuIds;
                    var filteredAccessorySkuIdsWithProtectionFlag;
                    var protectionPlanFlag = false;
                    protectionPlanService.getInsuranceFeatures('reload');

                    // filter accessories by business rules with protection plan flag enabled and disabled
                    filteredAccessorySkuIdsWithProtectionFlag = getfilteredAccessories(accessories, !protectionPlanFlag).map(function (item) {
                        return item.skuId;
                    }).join(',');
                    deviceRecommenderSrv.getItemPriceData(filteredAccessorySkuIdsWithProtectionFlag, true, true);

                    filteredAccessorySkuIds = getfilteredAccessories(accessories, protectionPlanFlag).map(function (item) {
                        return item.skuId;
                    }).join(',');
                    deviceRecommenderSrv.getItemPriceData(filteredAccessorySkuIds, true, true);

                    imagePaths = parseImagePaths(accessories, protectionPlanFlag);

                    // create an array with unique image paths
                    angular.forEach(imagePaths, function (path) {
                        if (!foundIn(uniqueImagePaths, path)) {
                            uniqueImagePaths.push(path);
                        }
                    });

                    // prefetch the unique accessory images
                    angular.forEach(uniqueImagePaths, function (path) {
                        var img = new $window.Image();
                        img.src = path;
                    });
                    // Prefetch the subtotal legal content
                    var cmsKeys = [];
                    cmsKeys.push(exBuyflowConstants.legalSubtotalToolTipContentKey);
                    exCqTranslatorKeyService.getCqTranslatorKeys(cmsKeys, true);

                    // prefetch the CCC resources for zippy
                    $window.require(['zippyCccPrefetch']);
                }

                /**
                 * Prefetch the accessory recommendations from the REX service, so that they
                 * are available for the accessory recommender page.
                 * @param {object} data Device details of the device in focus
                 */
                function prefetchAccessoryRecommendations (data) {

                    // only run prefetching code if we are not in a widget
                    if (!$scope.deviceConfig.isWidget === true) {
                        var favStoreId = favStoreService.getFavStoreIdFromSessionStorage();

                        contentService.getAuthoredAccessories(data.devicePageURL).then(function (authoredSkus) {
                            // content service was successful
                            buildRecommenderRequest(data, favStoreId, authoredSkus);
                        }).catch(function () {
                            // content service was not successful
                            buildRecommenderRequest(data, favStoreId);
                        });
                    }
                }

                /**
                 * Builds the options for the accessory recommender and passes them to the service
                 * @function buildRecommenderRequest
                 * @param {object} data Object from the broadcast which returns the sku id and productDetailsPagePath
                 * @param {string} favStoreId ID of the favorite store
                 * @param {string} [authoredSkus] list of skus authored specifically for the device
                 */
                function buildRecommenderRequest (data, favStoreId, authoredSkus) {
                    var options = {'hideSpinner': true},
                        authoredAccessoriesSkus;
                    if (authoredSkus !== '' || authoredSkus !== null) {
                        authoredAccessoriesSkus = authoredSkus;
                    }

                    if (data.selectedSku.skuExcludedFromBOPISForFlow === false
                        && favStoreId !== ''
                        && favStoreId !== undefined
                        && favStoreId !== null) {

                        options['favStoreId'] = favStoreId;
                        options['RSI'] = $scope.RSI;
                    }
                    // Passing RSI indicator and favStoreId to REX if favStore is available
                    accessoryRecommenderService.getAccessoryRecommendations(data.skuId, $scope.categories, authoredAccessoriesSkus, options
                    ).then(function (result) {
                        parseAndPrefetch(result);
                    });
                }

                /**
                 * Calls the product tabs services for each tab and outputs the result
                 * @function getRecommendedAccessories
                 * @param {object} data Object from the broadcast which returns the sku id and productDetailsPagePath
                 * @returns {html} Returned result of each tab
                 */
                function activate (data) {
                    var numberOnlySku = data.skuId.substring(3);

                    contentService.getProductOverviewContent(data.devicePageURL).then(function (overviewContent) {
                        $scope.deviceDetails.overviewContent = overviewContent;
                        $scope.deviceDetails.showOverviewContent = $scope.deviceDetails.overviewContent !== undefined &&
                            $scope.deviceDetails.overviewContent.length !== 0;
                    });

                    contentService.getProductFeaturesContent(data.devicePageURL).then(function (featureContent) {
                        $scope.deviceDetails.featureContent = featureContent;
                        $scope.deviceDetails.showFeatureContent = $scope.deviceDetails.featureContent !== undefined &&
                            $scope.deviceDetails.featureContent.length !== 0;
                    });

                    $scope.deviceDetails.legalNotes = getLegalNotesTranslatorKeys(data.selectedSku.legalNotes);

                    contentService.getProduct360Images(numberOnlySku).then(function (device360Images) {
                        $scope.deviceDetails.imagesContent = device360Images;
                        $scope.deviceDetails.showImagesContent = $scope.deviceDetails.imagesContent !== undefined &&
                            $scope.deviceDetails.imagesContent.length !== 0;
                    });

                    contentService.getProductLegalPaths(data.devicePageURL).then(function (deviceLegalPaths) {
                        $scope.deviceDetails.deviceLegalPaths = deviceLegalPaths;
                        contentService.getProductLegalContent(deviceLegalPaths).then(function (deviceLegalContent) {
                            $scope.deviceDetails.deviceLegal = deviceLegalContent;
                            $scope.deviceDetails.showDeviceLegalContent = $scope.deviceDetails.deviceLegal !== undefined &&
                                $scope.deviceDetails.deviceLegal.length !== 0;
                        });
                    });

                    prefetchAccessoryRecommendations(data);
                }

                /**
                 * Checks whether review accordian is to be displayed or not
                 * @function reviewAccordianToBeDisplayed
                 * @param {Boolean} renderBV flag tells whether bazaar voice is rendered or not
                 * @param {number} rating of the selected device
                 * @returns {boolean} true/false
                 */
                function reviewAccordianToBeDisplayed (renderBV, rating) {
                    return (renderBV === true && rating !== 0);
                }
            }
        ]);
})();
