## Modules

<table>
  <thead>
    <tr>
      <th>Module</th><th>Description</th>
    </tr>
  </thead>
  <tbody>
<tr>
    <td><a href="#module_accessoryDetailsCtrl">accessoryDetailsCtrl</a></td>
    <td><p>@todo Implement details</p>
<p><strong>Requirements</strong></p>
<ul>
<li>@todo Implement Details</li>
</ul>
</td>
    </tr>
<tr>
    <td><a href="#module_accessoryRecommenderCtrl">accessoryRecommenderCtrl</a></td>
    <td><p>This controller retrieves recommended accessories from the service.</p>
<p><strong>Requirements</strong></p>
<ul>
<li>get the recommended accessories from a service</li>
<li>get prices for the accessories loaded</li>
</ul>
</td>
    </tr>
<tr>
    <td><a href="#module_accessorySubtotalTooltipCtrl">accessorySubtotalTooltipCtrl</a></td>
    <td><p>This controller shows the legal content on choosing subtotal tooltip.</p>
<p><strong>Requirements</strong></p>
<ul>
<li>Get subtotal subtotal tooltip information from a REST service</li>
<li>Expose tooltip information to scope</li>
</ul>
</td>
    </tr>
<tr>
    <td><a href="#module_deviceDetailsCtrl">deviceDetailsCtrl</a></td>
    <td><p>This controller retrieves and displays device details.</p>
<p><strong>Requirements</strong></p>
<ul>
<li>Get skuId of details from a broadcast</li>
<li>Call services to get device details</li>
</ul>
</td>
    </tr>
<tr>
    <td><a href="#module_deviceLegalDetailCtrl">deviceLegalDetailCtrl</a></td>
    <td><p>@todo Implement details</p>
<p><strong>Requirements</strong></p>
<ul>
<li>@todo Implement details</li>
</ul>
</td>
    </tr>
<tr>
    <td><a href="#module_deviceRecommenderCtrl">deviceRecommenderCtrl</a></td>
    <td><p>This controller retrieves recommended devices from the service.</p>
<p><strong>Requirements</strong></p>
<ul>
<li>@todo Implement details</li>
</ul>
</td>
    </tr>
<tr>
    <td><a href="#module_upsellOfferCtrl">upsellOfferCtrl</a></td>
    <td><p>Controls upsell offer information</p>
<p><strong>Requirements</strong></p>
<ul>
<li>Get offer details from a REST service</li>
<li>Format offer details based on display logic</li>
<li>Add offer to cart</li>
<li>Open device config modal for multiple offers</li>
<li>Expose subtotal amounts</li>
</ul>
</td>
    </tr>
</tbody>
</table>

<a name="module_accessoryDetailsCtrl"></a>

## accessoryDetailsCtrl
@todo Implement details__Requirements__* @todo Implement Details

**See**: [exAccessoryDetails](../directives/#module_exAccessoryDetails)  

* * *

<a name="module_accessoryDetailsCtrl..getRecommendedAccessories"></a>

### accessoryDetailsCtrl~getRecommendedAccessories(data)
Calls the product tabs services for each tab and outputs the result

**Kind**: inner method of [<code>accessoryDetailsCtrl</code>](#module_accessoryDetailsCtrl)  

| Param | Type | Description |
| --- | --- | --- |
| data | <code>object</code> | Object from the broadcast which returns the skuid and productDetailsPagePath |


* * *

<a name="module_accessoryRecommenderCtrl"></a>

## accessoryRecommenderCtrl
This controller retrieves recommended accessories from the service.__Requirements__* get the recommended accessories from a service* get prices for the accessories loaded

**See**: [exAccessoryRecommender](../directives/#module_exAccessoryRecommender)  

* [accessoryRecommenderCtrl](#module_accessoryRecommenderCtrl)
    * [~getRecommendedAccessories(deviceSku, category, skuExcludedFromBOPISForFlow)](#module_accessoryRecommenderCtrl..getRecommendedAccessories) ⇒ <code>object</code>
    * [~isPreorderAccessory(skuId)](#module_accessoryRecommenderCtrl..isPreorderAccessory) ⇒ <code>boolean</code>
    * [~accFilterFlairFlags(accessoriesToBeDisplayed)](#module_accessoryRecommenderCtrl..accFilterFlairFlags)
    * [~isVariantAvailableWithoutEol(skuSiblingsMap, accessorySkuId)](#module_accessoryRecommenderCtrl..isVariantAvailableWithoutEol)


* * *

<a name="module_accessoryRecommenderCtrl..getRecommendedAccessories"></a>

### accessoryRecommenderCtrl~getRecommendedAccessories(deviceSku, category, skuExcludedFromBOPISForFlow) ⇒ <code>object</code>
gets the recommended accessories from recommender API and their respective prices

**Kind**: inner method of [<code>accessoryRecommenderCtrl</code>](#module_accessoryRecommenderCtrl)  
**Returns**: <code>object</code> - recommended accessories in items array  

| Param | Type | Description |
| --- | --- | --- |
| deviceSku | <code>String</code> | Device Sku for which we are looking up accessory recommendations |
| category | <code>Array.&lt;String&gt;</code> | categories Array of categories that we want recommendations for. Ex: ['cases', 'screen-protectors'] |
| skuExcludedFromBOPISForFlow | <code>boolean</code> | skuExcludedFromBOPISForFlow flag telling the selected device is availlable for BOPIS or not. |


* * *

<a name="module_accessoryRecommenderCtrl..isPreorderAccessory"></a>

### accessoryRecommenderCtrl~isPreorderAccessory(skuId) ⇒ <code>boolean</code>
returns whether an sku is marked as preorderable on the accessory recommender

**Kind**: inner method of [<code>accessoryRecommenderCtrl</code>](#module_accessoryRecommenderCtrl)  
**Returns**: <code>boolean</code> - returns true if sku is found and sku is preorderable else returns false  

| Param | Type | Description |
| --- | --- | --- |
| skuId | <code>String</code> | Device Sku for which we are looking up accessory recommendations |


* * *

<a name="module_accessoryRecommenderCtrl..accFilterFlairFlags"></a>

### accessoryRecommenderCtrl~accFilterFlairFlags(accessoriesToBeDisplayed)
Filters and sorts the flairFlags against each skuId on the basis of business logic,and accordingly flair flag is displayed against each accessory onaccessory-service-recommender page

**Kind**: inner method of [<code>accessoryRecommenderCtrl</code>](#module_accessoryRecommenderCtrl)  

| Param | Type |
| --- | --- |
| accessoriesToBeDisplayed | <code>Array</code> | 


* * *

<a name="module_accessoryRecommenderCtrl..isVariantAvailableWithoutEol"></a>

### accessoryRecommenderCtrl~isVariantAvailableWithoutEol(skuSiblingsMap, accessorySkuId)
It checks if any 2 or more variants are availablewith endOfLife as false for any accessorySku passed

**Kind**: inner method of [<code>accessoryRecommenderCtrl</code>](#module_accessoryRecommenderCtrl)  

| Param | Type |
| --- | --- |
| skuSiblingsMap | <code>Object</code> | 
| accessorySkuId | <code>string</code> | 


* * *

<a name="module_accessorySubtotalTooltipCtrl"></a>

## accessorySubtotalTooltipCtrl
This controller shows the legal content on choosing subtotal tooltip.__Requirements__* Get subtotal subtotal tooltip information from a REST service* Expose tooltip information to scope

**See**: [exAccessorySubtotalTooltip](../directives/#module_exAccessorySubtotalTooltip)  

* * *

<a name="module_deviceDetailsCtrl"></a>

## deviceDetailsCtrl
This controller retrieves and displays device details.__Requirements__* Get skuId of details from a broadcast* Call services to get device details

**See**: [exDeviceDetails](../directives/#module_exDeviceDetails)  

* [deviceDetailsCtrl](#module_deviceDetailsCtrl)
    * [~getRecommendedAccessories(data)](#module_deviceDetailsCtrl..getRecommendedAccessories) ⇒ <code>html</code>
    * [~reviewAccordianToBeDisplayed(renderBV, rating)](#module_deviceDetailsCtrl..reviewAccordianToBeDisplayed) ⇒ <code>boolean</code>


* * *

<a name="module_deviceDetailsCtrl..getRecommendedAccessories"></a>

### deviceDetailsCtrl~getRecommendedAccessories(data) ⇒ <code>html</code>
Calls the product tabs services for each tab and outputs the result

**Kind**: inner method of [<code>deviceDetailsCtrl</code>](#module_deviceDetailsCtrl)  
**Returns**: <code>html</code> - Returned result of each tab  

| Param | Type | Description |
| --- | --- | --- |
| data | <code>object</code> | Object from the broadcast which returns the sku id and productDetailsPagePath |


* * *

<a name="module_deviceDetailsCtrl..reviewAccordianToBeDisplayed"></a>

### deviceDetailsCtrl~reviewAccordianToBeDisplayed(renderBV, rating) ⇒ <code>boolean</code>
Checks whether review accordian is to be displayed or not

**Kind**: inner method of [<code>deviceDetailsCtrl</code>](#module_deviceDetailsCtrl)  
**Returns**: <code>boolean</code> - true/false  

| Param | Type | Description |
| --- | --- | --- |
| renderBV | <code>Boolean</code> | flag tells whether bazaar voice is rendered or not |
| rating | <code>number</code> | of the selected device |


* * *

<a name="module_deviceLegalDetailCtrl"></a>

## deviceLegalDetailCtrl
@todo Implement details__Requirements__* @todo Implement details

**See**: [exDeviceLegalDetails](../directives/#module_exDeviceLegalDetails)  

* * *

<a name="module_deviceLegalDetailCtrl..getDeviceInformation"></a>

### deviceLegalDetailCtrl~getDeviceInformation(skuId)
Retrieve the devicePageURL of selected sku and get the long legal content for the selected device. .

**Kind**: inner method of [<code>deviceLegalDetailCtrl</code>](#module_deviceLegalDetailCtrl)  

| Param | Type | Description |
| --- | --- | --- |
| skuId | <code>string</code> | The selected SKU |


* * *

<a name="module_deviceRecommenderCtrl"></a>

## deviceRecommenderCtrl
This controller retrieves recommended devices from the service.__Requirements__* @todo Implement details

**See**: [exDeviceRecommender](../directives/#module_exDeviceRecommender)  

* [deviceRecommenderCtrl](#module_deviceRecommenderCtrl)
    * [~getRecommendedDevices(devicesToBeLoaded)](#module_deviceRecommenderCtrl..getRecommendedDevices)
    * [~filterFlairFlags(devicesToBeDisplayed)](#module_deviceRecommenderCtrl..filterFlairFlags)
    * [~viewMoreDevices(devicesToBeLoaded)](#module_deviceRecommenderCtrl..viewMoreDevices)
    * [~fetchShortLegalContentForDevices(commitmentTerms)](#module_deviceRecommenderCtrl..fetchShortLegalContentForDevices)
    * [~checkDeviceFirst()](#module_deviceRecommenderCtrl..checkDeviceFirst)
    * [~getHeroDeviceBackgroundTheme(heroDeviceDetail)](#module_deviceRecommenderCtrl..getHeroDeviceBackgroundTheme) ⇒ <code>string</code>
    * [~showRecommender()](#module_deviceRecommenderCtrl..showRecommender)
    * [~filterItems()](#module_deviceRecommenderCtrl..filterItems)
    * [~toggleFilter()](#module_deviceRecommenderCtrl..toggleFilter)
    * [~clearFilterSelections(event)](#module_deviceRecommenderCtrl..clearFilterSelections)


* * *

<a name="module_deviceRecommenderCtrl..getRecommendedDevices"></a>

### deviceRecommenderCtrl~getRecommendedDevices(devicesToBeLoaded)
gets the recommended devices from recommender API, their respective prices and short legal

**Kind**: inner method of [<code>deviceRecommenderCtrl</code>](#module_deviceRecommenderCtrl)  

| Param | Type |
| --- | --- |
| devicesToBeLoaded | <code>number</code> | 


* * *

<a name="module_deviceRecommenderCtrl..filterFlairFlags"></a>

### deviceRecommenderCtrl~filterFlairFlags(devicesToBeDisplayed)
Filters and sorts the flairFlags against each skuId on the basis of business logic,and accordingly flair flag is displayed against each device on device recommender

**Kind**: inner method of [<code>deviceRecommenderCtrl</code>](#module_deviceRecommenderCtrl)  

| Param | Type |
| --- | --- |
| devicesToBeDisplayed | <code>Array</code> | 


* * *

<a name="module_deviceRecommenderCtrl..viewMoreDevices"></a>

### deviceRecommenderCtrl~viewMoreDevices(devicesToBeLoaded)
Gets more recommended devices from recommender API and increases the number of devices to be displayed

**Kind**: inner method of [<code>deviceRecommenderCtrl</code>](#module_deviceRecommenderCtrl)  

| Param | Type |
| --- | --- |
| devicesToBeLoaded | <code>number</code> | 


* * *

<a name="module_deviceRecommenderCtrl..fetchShortLegalContentForDevices"></a>

### deviceRecommenderCtrl~fetchShortLegalContentForDevices(commitmentTerms)
Identify cms key for default price of recommended sku and call cms translator key service to get short legal content

**Kind**: inner method of [<code>deviceRecommenderCtrl</code>](#module_deviceRecommenderCtrl)  

| Param | Type |
| --- | --- |
| commitmentTerms | <code>list</code> | 


* * *

<a name="module_deviceRecommenderCtrl..checkDeviceFirst"></a>

### deviceRecommenderCtrl~checkDeviceFirst()
Checks if user has selected device first and then choosen to upgrade line.Open the overlay for selected device to upgrade inplace of hero device.

**Kind**: inner method of [<code>deviceRecommenderCtrl</code>](#module_deviceRecommenderCtrl)  

* * *

<a name="module_deviceRecommenderCtrl..getHeroDeviceBackgroundTheme"></a>

### deviceRecommenderCtrl~getHeroDeviceBackgroundTheme(heroDeviceDetail) ⇒ <code>string</code>
Identify hero device and check source of respose should be REX api.To apply the background color of hero device tile

**Kind**: inner method of [<code>deviceRecommenderCtrl</code>](#module_deviceRecommenderCtrl)  
**Returns**: <code>string</code> - light-theme/dark-theme  

| Param | Type |
| --- | --- |
| heroDeviceDetail | <code>object</code> | 


* * *

<a name="module_deviceRecommenderCtrl..showRecommender"></a>

### deviceRecommenderCtrl~showRecommender()
Show recommender with global nav header and footer

**Kind**: inner method of [<code>deviceRecommenderCtrl</code>](#module_deviceRecommenderCtrl)  

* * *

<a name="module_deviceRecommenderCtrl..filterItems"></a>

### deviceRecommenderCtrl~filterItems()
Filters the listed devices with the filter optionsSets the displayed items to the filtered items or items if there are no filtered items

**Kind**: inner method of [<code>deviceRecommenderCtrl</code>](#module_deviceRecommenderCtrl)  

* * *

<a name="module_deviceRecommenderCtrl..toggleFilter"></a>

### deviceRecommenderCtrl~toggleFilter()
Toggles filter open and closed

**Kind**: inner method of [<code>deviceRecommenderCtrl</code>](#module_deviceRecommenderCtrl)  

* * *

<a name="module_deviceRecommenderCtrl..clearFilterSelections"></a>

### deviceRecommenderCtrl~clearFilterSelections(event)
Clears filter selections and resets the number of items to be displayed to the initial devices listed

**Kind**: inner method of [<code>deviceRecommenderCtrl</code>](#module_deviceRecommenderCtrl)  

| Param | Type | Description |
| --- | --- | --- |
| event | <code>object</code> | DOM event |


* * *

<a name="module_upsellOfferCtrl"></a>

## upsellOfferCtrl
Controls upsell offer information__Requirements__* Get offer details from a REST service* Format offer details based on display logic* Add offer to cart* Open device config modal for multiple offers* Expose subtotal amounts

**See**: [upsellOffer](../directives/#module_upsellOffer)  

* [upsellOfferCtrl](#module_upsellOfferCtrl)
    * [~onSkipToCheckout()](#module_upsellOfferCtrl..onSkipToCheckout)
    * [~upsellOfferAddItemToCart(offer)](#module_upsellOfferCtrl..upsellOfferAddItemToCart)
    * [~multiSkuUpsellOffer(skuId, offer)](#module_upsellOfferCtrl..multiSkuUpsellOffer)


* * *

<a name="module_upsellOfferCtrl..onSkipToCheckout"></a>

### upsellOfferCtrl~onSkipToCheckout()
this method makes a post service when clicked on proceed to checkout button on upsellOffer page

**Kind**: inner method of [<code>upsellOfferCtrl</code>](#module_upsellOfferCtrl)  
**Access**: public  

* * *

<a name="module_upsellOfferCtrl..upsellOfferAddItemToCart"></a>

### upsellOfferCtrl~upsellOfferAddItemToCart(offer)
Adds the upsell offer item to the cart by passing Request Payload items and input parameters to UpsellOffer post service

**Kind**: inner method of [<code>upsellOfferCtrl</code>](#module_upsellOfferCtrl)  
**Access**: public  

| Param | Type |
| --- | --- |
| offer | <code>object</code> | 


* * *

<a name="module_upsellOfferCtrl..multiSkuUpsellOffer"></a>

### upsellOfferCtrl~multiSkuUpsellOffer(skuId, offer)
Opens config modal and exposes the offerId to its scope

**Kind**: inner method of [<code>upsellOfferCtrl</code>](#module_upsellOfferCtrl)  
**Access**: public  

| Param | Type |
| --- | --- |
| skuId | <code>string</code> | 
| offer | <code>Array.&lt;object&gt;</code> | 


* * *

