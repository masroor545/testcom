# exBuyflow

This module contains functionality specifically for Buyflow

### Directory
* **controllers** - controllers expose in the module
* **directives** - directives exposed in the module
* **html** - markup used by the directives
* **services** - service used by the controllers / directives 

