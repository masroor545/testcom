(function () {
    'use strict';

    define(['accessoryRecommenderService'], function () {
        describe('src/main/modules/exBuyflow/services/accessoryRecommenderService.spec.js', function () {
            describe('accessoryRecommenderService service of exBuyflow', function () {
                var $httpBackend, service, $log, exBuyflowConstants, $timeout;

                beforeEach(function () {

                    module('exBuyflow');

                    inject(function ($injector) {
                        $httpBackend = $injector.get('$httpBackend');
                        $log = $injector.get('$log');
                        service = $injector.get('accessoryRecommenderService');
                        exBuyflowConstants = $injector.get('exBuyflowConstants');
                        $timeout = $injector.get('$timeout');
                        spyOn($log, 'error');
                    });
                });

                describe('backend service call behavior', function () {
                    afterEach(function () {
                        $log.error.calls.reset();
                        EndpointUtils.verifyExpectationsComplete($httpBackend);
                    });

                    it('should return data from rex when appropriate parameters passed', function () {
                        var endpoint = Endpoint_rexBySku.get_accessory_recommendations;

                        EndpointUtils.performServiceTest(
                            service.getAccessoryRecommendations,
                            [endpoint.sku, endpoint.params.filter, endpoint.params.authoredskus, {'favStoreId': endpoint.params.storeId, 'RSI': endpoint.params.rsi}],
                            {
                                method: 'GET',
                                endpoint: endpoint,
                                $httpBackend: $httpBackend,
                                callback: function (url, params) {
                                    expect(url).toContain(endpoint.sku);
                                    expect(params).toEqual(endpoint.params_sent);
                                }
                            },
                            {
                                callback: function (result) {
                                    expect(result).toEqual(endpoint.result);
                                }
                            }
                        );
                    });

                    it('should have a timeout and log an error when rex call times out', function () {
                        var endpoint = Endpoint_rexBySku.get_accessory_recommendations;

                        EndpointUtils.createMockServiceCall({
                            method: 'GET',
                            endpoint: endpoint,
                            $httpBackend: $httpBackend,
                            callback: function () {
                                fail('this services should have timed out with no response');
                            }
                        });

                        service.getAccessoryRecommendations(
                            endpoint.sku, endpoint.params.filter, endpoint.params.authoredskus, {'favStoreId': endpoint.params.storeId, 'RSI': endpoint.params.rsi})
                            .then(function () {
                                fail('this service should not get success response');
                            });

                        expect($log.error).not.toHaveBeenCalled();

                        $timeout.flush(exBuyflowConstants.rexServiceTimeout + 100);

                        expect($log.error).toHaveBeenCalledWith(
                            jasmine.stringMatching(/accessoryRecommenderService/));
                    });
                });

                it('should make CSI call for upsell offer eligibility checking', function () {
                    var key = exBuyflowConstants.exCheckUpsellOfferEligibility;
                    $httpBackend.whenGET(Endpoint_upsellOfferDetailsApi.get_upsell_offer_eligibility.url_match)
                        .respond(200, Endpoint_upsellOfferDetailsApi.get_upsell_offer_eligibility.result);

                    service.checkUpsellOfferEligibility(key);
                    $httpBackend.flush();
                });
            });
        });
    });
})();
