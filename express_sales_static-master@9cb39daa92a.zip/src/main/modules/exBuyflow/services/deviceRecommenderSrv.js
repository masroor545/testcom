(function () {
    'use strict';

    angular.module('exBuyflow')

        .factory('deviceRecommenderSrv', ['$http', 'exBuyflowConstants', 'exCacheManager',
            function ($http, exBuyflowConstants, exCacheManager) {
                var services = {};

                /**
                 * Gets the recommended devices from device recommender API
                 * @function getRecommendedDevices
                 * @param {object} upgradingDeviceDetails - Details of the upgrading device
                 * @returns {object} promise of recommended devices from the REX API
                 */
                services.getRecommendedDevices = function (upgradingDeviceDetails) {

                    if (Object.keys(upgradingDeviceDetails).length > 0) {
                        var deviceRecommenderApi = exBuyflowConstants.rexBySkuRecommenderApi,
                            params = services.createParams(upgradingDeviceDetails),
                            recommendationsFromCatalog,
                            recommendedDevices;
                        deviceRecommenderApi = deviceRecommenderApi + upgradingDeviceDetails.deviceSkuId;

                        recommendedDevices = $http.get(deviceRecommenderApi, params)
                            .then(function (response) {
                                if (!response.data || response.data[0] === undefined) {
                                    // returns the promise of getRecommendationsFromCatalog
                                    return recommendationsFromCatalog;
                                } else {
                                    return response.data;
                                }
                            }).catch(function () {
                                // returns promise of getRecommendationsFromCatalog
                                return recommendationsFromCatalog;
                            });

                        recommendationsFromCatalog = services.getRecommendationsFromCatalog();

                        return recommendedDevices;
                    } else {
                        return services.getRecommendationsFromCatalog();
                    }
                };

                /**
                 * Builds and returns the $http params object for a REX request.
                 * @param {object} upgradingDeviceDetails - Details of the upgrading device
                 * @return {Object} $http param object
                 */
                services.createParams = function (upgradingDeviceDetails) {

                    var params = {
                        params: {
                            profile: 'DeviceUpgrade',
                            filter: ['type:device', 'type:displayByGrp'],
                            exclude: ['type:removeDuplicateSibling', 'flowTypes:up'],
                            plancode: upgradingDeviceDetails.planSocCode,
                            sdgid: upgradingDeviceDetails.sharedDataGroupSocCode,
                            // REX needs this flag to expose special flair flags for each recommendation
                            showDisplayContent: 'true'
                        },
                        timeout: exBuyflowConstants.rexServiceTimeout,
                        spinner: true
                    };

                    return params;
                };

                /**
                 * Gets the recommended devices from Catalog if REX fails
                 * @function getRecommendationsFromCatalog
                 * @returns {object} promise object recommended devices
                 */
                services.getRecommendationsFromCatalog = function () {
                    return $http.get(exBuyflowConstants.catalogApi, {
                        params: {
                            actionType: 'getdeviceskus'
                        },
                        spinner: true
                    }).then(function (catalogApiResponse) {
                        return catalogApiResponse.data.payload;
                    });
                };

                /**
                 * Gets the Item price based on comma separated skuId
                 * @function getItemPriceData
                 * @param {boolean} [hideSpinner] Hides the spinner
                 * @returns {object} promise object map of skuid and item price
                 */
                services.getItemPriceData = function (skuId, hideSpinner, flushCache) {
                    var pricingAPI = exBuyflowConstants.catalogApi;
                    var paramsToCall = {
                        actionType: 'getskuprices',
                        skuId: skuId
                    };
                    if (flushCache === true) {
                        exCacheManager.clearCacheItem(pricingAPI, paramsToCall);
                    }
                    return $http.get(exBuyflowConstants.catalogApi, {
                        params: paramsToCall,
                        cache: exCacheManager.getCache(),
                        spinner: (hideSpinner === true) ? false : true
                    }).then(function (response) {
                        return response.data;
                    });
                };

                return services;
            }
        ]);
})();