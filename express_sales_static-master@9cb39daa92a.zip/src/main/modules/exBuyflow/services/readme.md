## Modules

<table>
  <thead>
    <tr>
      <th>Module</th><th>Description</th>
    </tr>
  </thead>
  <tbody>
<tr>
    <td><a href="#module_exBuyflowConstants">exBuyflowConstants</a></td>
    <td><p>Constants for exBuyflow module</p>
</td>
    </tr>
</tbody>
</table>

## Objects

<dl>
<dt><a href="#accessoryRecommender">accessoryRecommender</a> ⇒ <code>Promise.&lt;Object&gt;</code></dt>
<dd><p>Makes a request to the accessory recommendations API for the device sku and categories in context and
 returns a promise. If the promise resolves the result of the request will be returned.</p>
</dd>
</dl>

## Functions

<dl>
<dt><a href="#getRecommendationsCompleted">getRecommendationsCompleted(result)</a> ⇒ <code>Promise.&lt;Object&gt;</code></dt>
<dd><p>Returns the data property of the accessory recommendation response object.</p>
</dd>
<dt><a href="#proceedToCheckOut">proceedToCheckOut()</a> ⇒ <code>Object</code></dt>
<dd><p>Makes a post service when clicked on proceed to checkout button</p>
</dd>
<dt><a href="#proceedToContinue">proceedToContinue()</a> ⇒ <code>Object</code></dt>
<dd><p>Makes a post service when clicked on proceed to continue button</p>
</dd>
<dt><a href="#getRecommendedDevices">getRecommendedDevices(upgradingDeviceDetails)</a> ⇒ <code>object</code></dt>
<dd><p>Gets the recommended devices from device recommender API</p>
</dd>
<dt><a href="#getRecommendationsFromCatalog">getRecommendationsFromCatalog()</a> ⇒ <code>object</code></dt>
<dd><p>Gets the recommended devices from Catalog if REX fails</p>
</dd>
<dt><a href="#getItemPriceData">getItemPriceData()</a> ⇒ <code>object</code></dt>
<dd><p>Gets the Item price based on comma separated skuId</p>
</dd>
</dl>

<a name="module_exBuyflowConstants"></a>

## exBuyflowConstants
Constants for exBuyflow module


* [exBuyflowConstants](#module_exBuyflowConstants)
    * [~accessoryCategories](#module_exBuyflowConstants..accessoryCategories) : <code>Array.&lt;String&gt;</code>
    * [~catalogApi](#module_exBuyflowConstants..catalogApi) : <code>String</code>
    * [~deviceFilterOptions](#module_exBuyflowConstants..deviceFilterOptions) : <code>Array.&lt;FilterOption&gt;</code>
    * [~deviceFilterPriority](#module_exBuyflowConstants..deviceFilterPriority) : <code>Array.&lt;String&gt;</code>
    * [~exUpHandOffToCheckoutUrl](#module_exBuyflowConstants..exUpHandOffToCheckoutUrl) : <code>String</code>
    * [~exUpHandOffUpgradeToContinueUrl](#module_exBuyflowConstants..exUpHandOffUpgradeToContinueUrl) : <code>String</code>
    * [~friendlyPageName](#module_exBuyflowConstants..friendlyPageName)
    * [~insuranceCategories](#module_exBuyflowConstants..insuranceCategories) : <code>Object</code>
    * [~legalContentKeyPrefix](#module_exBuyflowConstants..legalContentKeyPrefix) : <code>String</code>
    * [~legalSubtotalToolTipContentKey](#module_exBuyflowConstants..legalSubtotalToolTipContentKey) : <code>String</code>
    * [~linkName](#module_exBuyflowConstants..linkName) : <code>object</code>
    * [~linkPosition](#module_exBuyflowConstants..linkPosition) : <code>String</code>
    * [~rexBySkuRecommenderApi](#module_exBuyflowConstants..rexBySkuRecommenderApi) : <code>String</code>
    * [~rexServiceTimeout](#module_exBuyflowConstants..rexServiceTimeout) : <code>Number</code>
    * [~showPdpContent](#module_exBuyflowConstants..showPdpContent) : <code>Boolean</code>
    * [~upsellOfferApi](#module_exBuyflowConstants..upsellOfferApi) : <code>String</code>
    * [~virtualUrl](#module_exBuyflowConstants..virtualUrl) : <code>object</code>


* * *

<a name="module_exBuyflowConstants..accessoryCategories"></a>

### exBuyflowConstants~accessoryCategories : <code>Array.&lt;String&gt;</code>
@todo Implement details

**Kind**: inner constant of [<code>exBuyflowConstants</code>](#module_exBuyflowConstants)  

* * *

<a name="module_exBuyflowConstants..catalogApi"></a>

### exBuyflowConstants~catalogApi : <code>String</code>
@todo Implement details

**Kind**: inner constant of [<code>exBuyflowConstants</code>](#module_exBuyflowConstants)  

* * *

<a name="module_exBuyflowConstants..deviceFilterOptions"></a>

### exBuyflowConstants~deviceFilterOptions : <code>Array.&lt;FilterOption&gt;</code>
Criteria determined by business that can be filtered by the user

**Kind**: inner constant of [<code>exBuyflowConstants</code>](#module_exBuyflowConstants)  
**Properties**

| Name | Type | Description |
| --- | --- | --- |
| criterion | <code>String</code> | Criterion (e.g. brand) |
| values | <code>Array.&lt;\*&gt;</code> | Default filter options (if any) |


* * *

<a name="module_exBuyflowConstants..deviceFilterPriority"></a>

### exBuyflowConstants~deviceFilterPriority : <code>Array.&lt;String&gt;</code>
Brands listed in order of priority, with the first item being the highest priority item

**Kind**: inner constant of [<code>exBuyflowConstants</code>](#module_exBuyflowConstants)  

* * *

<a name="module_exBuyflowConstants..exUpHandOffToCheckoutUrl"></a>

### exBuyflowConstants~exUpHandOffToCheckoutUrl : <code>String</code>
@todo Implement details

**Kind**: inner constant of [<code>exBuyflowConstants</code>](#module_exBuyflowConstants)  

* * *

<a name="module_exBuyflowConstants..exUpHandOffUpgradeToContinueUrl"></a>

### exBuyflowConstants~exUpHandOffUpgradeToContinueUrl : <code>String</code>
@todo Implement details

**Kind**: inner constant of [<code>exBuyflowConstants</code>](#module_exBuyflowConstants)  

* * *

<a name="module_exBuyflowConstants..friendlyPageName"></a>

### exBuyflowConstants~friendlyPageName
**Kind**: inner constant of [<code>exBuyflowConstants</code>](#module_exBuyflowConstants)  
**Properties**

| Name | Type | Description |
| --- | --- | --- |
| deviceDetails | <code>String</code> | friendly page name of deviceDetails page |
| deviceDetailsHero | <code>String</code> | friendly page name of hero deviceDetails page |
| accessoryDetails | <code>String</code> | friendly page name of accessoryDetails page. |
| accessoryRecommenderDetails | <code>String</code> | friendly page name of accessoryRecommenderDetails page. |


* * *

<a name="module_exBuyflowConstants..insuranceCategories"></a>

### exBuyflowConstants~insuranceCategories : <code>Object</code>
@todo Implement details

**Kind**: inner constant of [<code>exBuyflowConstants</code>](#module_exBuyflowConstants)  
**Properties**

| Name | Type | Description |
| --- | --- | --- |
| sku5370279 | <code>String</code> | @todo Implement details |
| sku7250407 | <code>String</code> | @todo Implement details |
| sku1040075 | <code>String</code> | @todo Implement details |


* * *

<a name="module_exBuyflowConstants..legalContentKeyPrefix"></a>

### exBuyflowConstants~legalContentKeyPrefix : <code>String</code>
@todo Implement details

**Kind**: inner constant of [<code>exBuyflowConstants</code>](#module_exBuyflowConstants)  

* * *

<a name="module_exBuyflowConstants..legalSubtotalToolTipContentKey"></a>

### exBuyflowConstants~legalSubtotalToolTipContentKey : <code>String</code>
@todo Implement details

**Kind**: inner constant of [<code>exBuyflowConstants</code>](#module_exBuyflowConstants)  

* * *

<a name="module_exBuyflowConstants..linkName"></a>

### exBuyflowConstants~linkName : <code>object</code>
**Kind**: inner constant of [<code>exBuyflowConstants</code>](#module_exBuyflowConstants)  
**Properties**

| Name | Type | Description |
| --- | --- | --- |
| chooseOptions | <code>String</code> | text for choose your options link |
| longLegalLink | <code>String</code> | text for see price details link |
| skipUpsellOffer | <code>String</code> | text for no, thanks link |


* * *

<a name="module_exBuyflowConstants..linkPosition"></a>

### exBuyflowConstants~linkPosition : <code>String</code>
constant for Body text

**Kind**: inner constant of [<code>exBuyflowConstants</code>](#module_exBuyflowConstants)  

* * *

<a name="module_exBuyflowConstants..rexBySkuRecommenderApi"></a>

### exBuyflowConstants~rexBySkuRecommenderApi : <code>String</code>
@todo Implement details

**Kind**: inner constant of [<code>exBuyflowConstants</code>](#module_exBuyflowConstants)  

* * *

<a name="module_exBuyflowConstants..rexServiceTimeout"></a>

### exBuyflowConstants~rexServiceTimeout : <code>Number</code>
@todo Implement details

**Kind**: inner constant of [<code>exBuyflowConstants</code>](#module_exBuyflowConstants)  

* * *

<a name="module_exBuyflowConstants..showPdpContent"></a>

### exBuyflowConstants~showPdpContent : <code>Boolean</code>
@todo Implement details

**Kind**: inner constant of [<code>exBuyflowConstants</code>](#module_exBuyflowConstants)  

* * *

<a name="module_exBuyflowConstants..upsellOfferApi"></a>

### exBuyflowConstants~upsellOfferApi : <code>String</code>
@todo Implement details

**Kind**: inner constant of [<code>exBuyflowConstants</code>](#module_exBuyflowConstants)  

* * *

<a name="module_exBuyflowConstants..virtualUrl"></a>

### exBuyflowConstants~virtualUrl : <code>object</code>
**Kind**: inner constant of [<code>exBuyflowConstants</code>](#module_exBuyflowConstants)  
**Properties**

| Name | Type | Description |
| --- | --- | --- |
| accessoryDetails | <code>String</code> | url of accessoryDetails page |
| accessoryRecommenderDetails | <code>String</code> | url of accessoryRecommenderDetails page |
| deviceDetails | <code>String</code> | url of deviceDetails page |
| deviceDetailsHero | <code>String</code> | url of hero deviceDetails page |
| deviceRecommenderDetailsUrl | <code>String</code> | url of device Recommender Details page |
| multiSkuUpsellOffer | <code>String</code> | @todo Implement details |
| onePageCheckout | <code>String</code> | url of order review page |


* * *

<a name="accessoryRecommender"></a>

## accessoryRecommender ⇒ <code>Promise.&lt;Object&gt;</code>
Makes a request to the accessory recommendations API for the device sku and categories in context and returns a promise. If the promise resolves the result of the request will be returned.

**Kind**: global namespace  
**Returns**: <code>Promise.&lt;Object&gt;</code> - Returns a promise of accessory recommendations results.  

| Param | Type | Description |
| --- | --- | --- |
| deviceSku | <code>String</code> | Device Sku for which we are looking up accessory recommendations |
| categories | <code>Array.&lt;String&gt;</code> | Array of categories that we want recommendations for. Ex: ['cases', 'screen-protectors'] |
| options | <code>Object</code> | Object with optional parameters. |

**Properties**

| Name | Type | Description |
| --- | --- | --- |
| options.FavStoreId | <code>String</code> | if the upgrading user if any Ex: '311' |
| options.RSI | <code>Boolean</code> | Relax StoreId Indicator telling storeId is to be considered while |
| options.hideSpinner | <code>Boolean</code> | Hides the spinner for this request if set to true. fetching the recommendations or not i.e True/False; |


* * *

<a name="getRecommendationsCompleted"></a>

## getRecommendationsCompleted(result) ⇒ <code>Promise.&lt;Object&gt;</code>
Returns the data property of the accessory recommendation response object.

**Kind**: global function  
**Returns**: <code>Promise.&lt;Object&gt;</code> - Returns the accessory recommendation response data  

| Param | Type | Description |
| --- | --- | --- |
| result | <code>Object</code> | Accessory recommendations response |


* * *

<a name="proceedToCheckOut"></a>

## proceedToCheckOut() ⇒ <code>Object</code>
Makes a post service when clicked on proceed to checkout button

**Kind**: global function  
**Returns**: <code>Object</code> - data post response  

* * *

<a name="proceedToContinue"></a>

## proceedToContinue() ⇒ <code>Object</code>
Makes a post service when clicked on proceed to continue button

**Kind**: global function  
**Returns**: <code>Object</code> - data post response  

* * *

<a name="getRecommendedDevices"></a>

## getRecommendedDevices(upgradingDeviceDetails) ⇒ <code>object</code>
Gets the recommended devices from device recommender API

**Kind**: global function  
**Returns**: <code>object</code> - promise of recommended devices from the REX API  

| Param | Type | Description |
| --- | --- | --- |
| upgradingDeviceDetails | <code>object</code> | Details of the upgrading device |


* * *

<a name="getRecommendationsFromCatalog"></a>

## getRecommendationsFromCatalog() ⇒ <code>object</code>
Gets the recommended devices from Catalog if REX fails

**Kind**: global function  
**Returns**: <code>object</code> - promise object recommended devices  

* * *

<a name="getItemPriceData"></a>

## getItemPriceData() ⇒ <code>object</code>
Gets the Item price based on comma separated skuId

**Kind**: global function  
**Returns**: <code>object</code> - promise object map of skuid and item price  

* * *

