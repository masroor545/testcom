(function () {
    'use strict';

    angular.module('exBuyflow')

        .factory('accessoryRecommenderService', ['$log', '$q', '$http', 'exBuyflowConstants', 'exCacheManager', '$window',
            function ($log, $q, $http, exBuyflowConstants, exCacheManager, $window) {
                var accessoryRecommender = {
                    getAccessoryRecommendations: getAccessoryRecommendations,
                    createParams: createParams,
                    getAccessoryList: getAccessoryList,
                    checkUpsellOfferEligibility: checkUpsellOfferEligibility
                };

                /**
                 * Makes a request to the accessory recommendations API for the device sku and categories in context and
                 *  returns a promise. If the promise resolves the result of the request will be returned.
                 * @function getAccessoryRecommendations
                 * @param {String} deviceSku Device Sku for which we are looking up accessory recommendations
                 * @param {Array<String>} categories Array of categories that we want recommendations for. Ex: ['cases', 'screen-protectors']
                 * @param {String} authoredSkus - authored sku list which override accessory recommendations from REX.
                 * @param {Object} options Object with optional parameters.
                 * @property {String} options.FavStoreId if the upgrading user if any Ex: '311'
                 * @property {Boolean} options.RSI Relax StoreId Indicator telling storeId is to be considered while
                 * @property {Boolean} options.hideSpinner Hides the spinner for this request if set to true.
                 * fetching the recommendations or not i.e True/False;
                 * @returns {Promise<Object>} Returns a promise of accessory recommendations results.
                 * @namespace accessoryRecommender
                 */
                function getAccessoryRecommendations (deviceSku, categories, authoredSkus, options) {
                    options = typeof(options) !== 'undefined' ? options : {};
                    options.favStoreId = typeof(options.favStoreId) !== 'undefined' ? options.favStoreId : undefined;
                    options.RSI = typeof(options.RSI) !== 'undefined' ? options.RSI : undefined;
                    options.hideSpinner = typeof(options.hideSpinner) !== 'undefined' ? options.hideSpinner : false;

                    var params = createParams(categories, authoredSkus, options.favStoreId, options.RSI, options.hideSpinner);

                    return $http.get(exBuyflowConstants.rexBySkuRecommenderApi + deviceSku, params)
                        .then(getRecommendationsCompleted)
                        .catch(getRecommendationsFailed);
                }

                /**
                 * Returns the data property of the accessory recommendation response object.
                 * @function getRecommendationsCompleted
                 * @param {Object} result Accessory recommendations response
                 * @returns {Promise<Object>} Returns the accessory recommendation response data
                 */
                function getRecommendationsCompleted (result) {
                    return result.data;
                }

                /**
                 * Logs an error and rejects the promise returned by the getAccessoryRecommendations function.
                 * @param {Error} error Accessory recommendation response error object.
                 * @return {Promise<Error>} Returns rejected promise
                 */
                function getRecommendationsFailed (error) {
                    var message = 'accessoryRecommenderService.getAccessoryRecommendations call failed.';
                    if (error.data && error.data.description) {
                        message += '\n' + error.data.description;
                    }
                    $log.error(message);
                    return $q.reject(error);
                }

                /**
                 * Builds and returns the $http params object from the categories array
                 * @function createParams
                 * @param {Array<String>} categories Array of categories.
                 * @param {String} authoredSkus - authored recommended accessories of the selected device.
                 * @param {String} favStoreId of the upgrading user.
                 * @param {Boolean} Relax StorId Indicator, a boolean flag indicating whether favStoreId is to be
                 * considered by REX while fetching the recommendations or not.
                 * @return {Object} $http param object including the categories.
                 * @namespace accessoryRecommender
                 */
                function createParams (categories, authoredSkus, favStoreId, RSI, hideSpinner) {
                    var params = {
                        params: {
                            exclude: 'type:device',
                            // REX needs this flag to expose special flair flags for each recommendation
                            showDisplayContent: 'true'
                        },
                        timeout: exBuyflowConstants.rexServiceTimeout,
                        cache: exCacheManager.getCache()
                    };

                    params['spinner'] = hideSpinner ? false : true;

                    if (authoredSkus !== undefined) {
                        params.params['authoredskus'] = authoredSkus;
                    }

                    var filters = [];

                    // build the categories filter array as per REX API
                    categories.forEach(function (category) {
                        filters.push('Category:' + category);
                    });

                    // to get compatible accessories for the selected device.
                    filters.push('COMPATIBILITY');
                    params.params['filter'] = filters;

                    if (favStoreId !== undefined) {

                        // If favStoreId is available then only the Relax Store Indicator is to
                        // be passed as parameter to REX
                        params.params['storeId'] = favStoreId;
                        // The 'rsi' param key name is to be passed in lower case
                        // It will let REX know if no accessories in every category requested due to invalid/closed store
                        params.params['rsi'] = RSI;
                    }
                    return params;
                }

                /**
                 * filters, sorts, and colates accessories as per the configuration and returns an
                 * array with the matching accessories
                 * @function getAccessoryList
                 * @param {Array} allAccessories All accessories returned from REX
                 * @param {Boolean} protectionPlanFlag Indicates if the protection plan is shown,
                 * or if it's space should be occupied by a hero accessory
                 * @returns {Array} Array of matching accessories
                 * @namespace accessoryRecommender
                 */
                function getAccessoryList (allAccessories, protectionPlanFlag) {
                    allAccessories = typeof(allAccessories) !== undefined ? allAccessories : [];
                    var casesInAccessories = [];
                    var screenProtectorsInAccessories = [];
                    var chargersInAccessories = [];
                    var audioInAccessories = [];
                    var categorizedAccessories = [];

                    angular.forEach(allAccessories, function (accessory) {

                        // Filter out out-of-stock and end-of-life accessories
                        if (accessory.outOfStock === false && accessory.endOfLife === false) {

                            // Create accessories list based on categories
                            if (accessory.categories.indexOf(exBuyflowConstants.accessoryCategories[0]) > -1) {
                                casesInAccessories.push(accessory);
                            } else if (accessory.categories.indexOf(exBuyflowConstants.accessoryCategories[1]) > -1) {
                                screenProtectorsInAccessories.push(accessory);
                            } else if (accessory.categories.indexOf(exBuyflowConstants.accessoryCategories[2]) > -1) {
                                chargersInAccessories.push(accessory);
                            } else if (accessory.categories.indexOf(exBuyflowConstants.accessoryCategories[3]) > -1) {
                                audioInAccessories.push(accessory);
                            }
                        }
                    });

                    switch (protectionPlanFlag) {
                    case (true):
                        if (casesInAccessories && casesInAccessories.length > 0) {
                            // enter first element if case available
                            categorizedAccessories.push(casesInAccessories[0]);
                        }
                        if (categorizedAccessories && categorizedAccessories.length < 3 &&
                            screenProtectorsInAccessories && screenProtectorsInAccessories.length > 0) {
                            //enter second element if screen-protector available
                            categorizedAccessories.push(screenProtectorsInAccessories[0]);
                        }
                        if (categorizedAccessories && categorizedAccessories.length < 3 &&
                            chargersInAccessories && chargersInAccessories.length > 0) {
                            //enter 3rd element if charger available
                            categorizedAccessories.push(chargersInAccessories[0]);
                        }
                        if (categorizedAccessories && categorizedAccessories.length < 3 &&
                            audioInAccessories && audioInAccessories.length > 0) {
                            //enter 3rd element as audio if any of the above categories not available
                            categorizedAccessories.push(audioInAccessories[0]);
                        }
                        break;
                    case (false):
                        if (casesInAccessories && casesInAccessories.length > 0) {
                            // enter first element if case available
                            categorizedAccessories.push(casesInAccessories[0]);
                        }
                        if (categorizedAccessories && categorizedAccessories.length < 4 &&
                            screenProtectorsInAccessories && screenProtectorsInAccessories.length > 0) {
                            //enter second element if screen-protector available
                            categorizedAccessories.push(screenProtectorsInAccessories[0]);
                        }
                        if (categorizedAccessories && categorizedAccessories.length < 4 &&
                            chargersInAccessories && chargersInAccessories.length > 0) {
                            //enter 3rd element if charger available
                            categorizedAccessories.push(chargersInAccessories[0]);
                        }
                        if (categorizedAccessories && categorizedAccessories.length < 4 &&
                            audioInAccessories && audioInAccessories.length > 0) {
                            //enter 4th element if audio available
                            categorizedAccessories.push(audioInAccessories[0]);
                        }
                        break;
                    default:
                        categorizedAccessories.push('No accessories is recommended for selected device');
                    }

                    return categorizedAccessories;
                }

                /**
                 * function will be called in case the call to upsell service has not been made at
                 * the loading time of the accessory page.
                 * @function checkUpsellOfferEligibility
                 * @param {Object} storageKey - the key store in window session storage to keep
                 * track if the call to service has been made
                 * @returns {Object} the object of accessoryRecommender service
                 * @namespace accessoryRecommender
                 */
                function checkUpsellOfferEligibility (storageKey) {
                    var defer = $q.defer(),
                        storedUpLine = $window.sessionStorage.getItem(storageKey);

                    if (storedUpLine === null || storedUpLine === undefined) {
                        $http.get(exBuyflowConstants.exCheckUpsellOfferEligibility, {
                            params: {
                                actionType: 'getUpsellEligibilty'
                            },
                            cache: true
                        }).then(function (response) {
                            defer.resolve(response);
                        });
                    } else {
                        defer.resolve();
                    }
                    return defer.promise;
                }

                return accessoryRecommender;
            }]);
})();