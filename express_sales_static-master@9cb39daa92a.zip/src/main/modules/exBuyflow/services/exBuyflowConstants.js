(function () {
    'use strict';

    /**
     * Constants for exBuyflow module
     *
     * @module exBuyflowConstants
     */

    /**
     * @constant {Array<String>} accessoryCategories - @todo Implement details
     */

    /**
     * @constant {String} catalogApi - @todo Implement details
     */

    /**
     * @constant {Array<FilterOption>} deviceFilterOptions - Criteria determined by business that can be filtered by the user
     *
     * @property {String} criterion - Criterion (e.g. brand)
     * @property {Array<*>} values - Default filter options (if any)
     */

    /**
     * @constant {Array<String>} deviceFilterPriority - Brands listed in order of priority, with the first item being the highest priority item
     */

      /**
     * @constant {String} exCheckUpsellOfferEligibility - @todo Implement details
     */

    /**
     * @constant {String} exUpHandOffToCheckoutUrl - @todo Implement details
     */

    /**
     * @constant {String} exUpHandOffUpgradeToContinueUrl - @todo Implement details
     */

    /**
     * @constant friendlyPageName
     *
     * @property {String} deviceDetails - friendly page name of deviceDetails page
     * @property {String} deviceDetailsHero - friendly page name of hero deviceDetails page
     * @property {String} accessoryDetails - friendly page name of accessoryDetails page.
     * @property {String} accessoryRecommenderDetails - friendly page name of accessoryRecommenderDetails page.
     */

    /**
     * @constant {Object} insuranceCategories - @todo Implement details
     *
     * @property {String} sku5370279 - @todo Implement details
     * @property {String} sku7250407 - @todo Implement details
     * @property {String} sku1040075 - @todo Implement details
     */

    /**
     * @constant {String} legalContentKeyPrefix - @todo Implement details
     */

    /**
     * @constant {String} legalSubtotalToolTipContentKey - @todo Implement details
     */

    /**
     * @constant {object} linkName
     *
     * @property {String} chooseOptions - text for choose your options link
     * @property {String} longLegalLink - text for see price details link
     * @property {String} skipUpsellOffer - text for no, thanks link
     */

    /**
     * @constant {String} linkPosition - constant for Body text
     */

    /**
     * @constant {String} rexBySkuRecommenderApi - @todo Implement details
     */

    /**
     * @constant {Number} rexServiceTimeout - @todo Implement details
     */

    /**
     * @constant {Boolean} showPdpContent - @todo Implement details
     */

    /**
     * @constant {String} upsellOfferApi - @todo Implement details
     */

    /**
     * @constant {object} virtualUrl
     *
     * @property {String} accessoryDetails - url of accessoryDetails page
     * @property {String} accessoryRecommenderDetails - url of accessoryRecommenderDetails page
     * @property {String} deviceDetails - url of deviceDetails page
     * @property {String} deviceDetailsHero - url of hero deviceDetails page
     * @property {String} deviceRecommenderDetailsUrl - url of device Recommender Details page
     * @property {String} multiSkuUpsellOffer - @todo Implement details
     * @property {String} onePageCheckout - url of order review page
     */
    angular.module('exBuyflow')
        .constant('exBuyflowConstants', {
            accessoryCategories: [
                'cases',
                'screen-protectors',
                'charge-sync-cables',
                'audio'
            ],

            catalogApi: '/services/shopwireless/model/att/ecom/api/CatalogServiceController/catalogService',

            deviceFilterOptions: [
                {
                    criterion: 'brand',
                    values: []
                }
            ],
            deviceTypeFilterOptions: [
                {
                    criterion: 'deviceType',
                    values: []
                }
            ],
            deviceFilterPriority: [
                'Apple',
                'Samsung',
                'LG',
                'AT&T',
                'BlackBerry',
                'Kyocera',
                'Motorola',
                'Sonim'
            ],

            exCheckUpsellOfferEligibility: '/services/shopwireless/model/att/ecom/api/UpsellServiceController/upsellService',

            exUpHandOffToCheckoutUrl: '/services/shopwireless/model/att/ecom/api/ExUpHandOffToCheckoutActor/exUpCheckoutHandoffService',

            exUpHandOffUpgradeToContinueUrl: '/services/shopwireless/model/att/ecom/api/WirelessUpgradeSelectionActor/configureNextUpgradeLine',

            friendlyPageName: {
                deviceDetails: 'DS Upgrade Device Details Pg',
                deviceDetailsHero: 'DS Upgrade Hero Device Details Pg',
                accessoryDetails: 'DS Upgrade Protection And Accessories Details Pg',
                accessoryRecommenderDetails: 'DS Upgrade Protection And Accessories Pg',
                multiSkuUpsellOffer: 'DS Upgrade Add A Line Device Details Pg'
            },

            insuranceCategories: {
                sku5370279: 'label.md5hdr.mpp',
                sku7250407: 'label.md5hdr.mdpp',
                sku1040075: 'label.md5hdr.mi'
            },

            legalContentKeyPrefix: 'tos.sku.',

            legalSubtotalToolTipContentKey: 'label.exup.subtotal.description',

            linkName: {
                chooseOptions: 'Choose your options',
                longLegalLink: 'See price details',
                skipUpsellOffer: 'No, thanks'
            },

            linkPosition: 'Body',

            rexBySkuRecommenderApi: '/rex/recommendation/rexBySku/',

            rexServiceTimeout: 7000,

            showPdpContent: true,

            upsellOfferApi: '/services/shopwireless/model/att/ecom/api/UpsellServiceController/upsellService',


            virtualUrl: {
                accessoryDetails: '/shop/xpress/virtual/protection-accessory-details.html',
                accessoryRecommenderDetails: '/shop/xpress/accessory-service-recommender.html',
                deviceDetails: '/shop/xpress/virtual/device-details.html',
                deviceDetailsHero: '/shop/xpress/virtual/device-details.html+HeroDevice',
                deviceRecommenderDetailsUrl: '/shop/xpress/device-recommender.html',
                multiSkuUpsellOffer: '/shop/xpress/virtual/device-details.html+AddALineOffer',
                onePageCheckout: '/checkout/onepagecheckout.html'
            }
        });
})();
