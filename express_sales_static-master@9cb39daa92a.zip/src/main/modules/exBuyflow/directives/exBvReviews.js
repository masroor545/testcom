(function () {
    'use strict';

    /**
     * This directive serves the purpose show bazaar voice reviews on the details pages.
     *
     * __Requirements:__
     * * Shows the bv review ratings for the selected device/accessory
     * * Loads the bv script on window load
     * * Depends on the "bazaar-voice" script being fired by $window.require when directive is called
     * * Depends on a broadcast (BVSkuSelected) set from the device details service once renderend will send out skuid to us
     *
     * @module exBvReviews
     *
     * @fires bvInitiated - @todo Implement details
     *
     * @example @lang html
     * <ex-bv-reviews></ex-bv-reviews>
     */
    angular.module('exBuyflow')

        .directive('exBvReviews', ['$window', 'exCommonConstants', '$rootScope', function ($window, exCommonConstants, $rootScope) {
            return {
                restrict: 'E',
                templateUrl: function (ele, attr) {
                    return attr.templateName ? attr.templateName : '/templates/exbvreviews.html';
                },
                link: function (scope) {
                    scope.$on(exCommonConstants.event.BVSkuSelected, function (event, data) {
                        $window.require(['bazaar-voice'], function () {
                            if ($window.$BV !== 'undefined') {
                                $window.$BV.ui('rr', 'show_reviews', {
                                    productId: data.skuId
                                });
                            }
                        });

                    });
                    $rootScope.$broadcast(exCommonConstants.event.BVInitiated, null);
                }
            };
        }]);
})();
