(function () {
    'use strict';

    /**
     * Display the long legal content. The template defaults to /templates/exdevicelegaldetails.html
     *
     * __Requirements:__
     * * Display the long legal content for the selected sku on device legal overlay.
     *
     * @module exDeviceLegalDetails
     *
     * @see {@link ../controllers/#module_deviceLegalDetailCtrl|deviceLegalDetailCtrl}
     *
     * @example @lang html
     * <ex-device-legal-details></ex-device-legal-details>
     */
    angular.module('exBuyflow')

        .directive('exDeviceLegalDetails', [function () {
            return {
                restrict: 'E',
                templateUrl: function (ele, attr) {
                    return attr.templateName ? attr.templateName : '/templates/exdevicelegaldetails.html';
                },
                controller: 'deviceLegalDetailCtrl'
            };
        }]);
})();
