(function () {
    'use strict';

    define(['exProtectionPlanFooter'], function () {
        describe('src/main/modules/exBuyflow/directives/exProtectionPlanFooter.spec.js', function () {
            describe('exProtectionPlanFooter directive of exBuyflow', function () {
                var element, scope, $rootScope, $compile, html;

                beforeEach(function () {
                    module('exBuyflow', function ($provide, $controllerProvider) {
                        $controllerProvider.register('protectionPlanDetailsCtrl', function ($scope) {
                            $scope.addProtectionPlanToCart = function () { return true; };
                        });
                    });

                    inject(function ($injector) {
                        $rootScope = $injector.get('$rootScope');
                        $compile = $injector.get('$compile');
                    });

                    html = '<div ex-protection-plan-footer></div>';
                    element = angular.element(html);
                    scope = $rootScope.$new();
                    $compile(element)(scope);
                    scope = element.isolateScope() || element.scope();
                });

                it('should have a button to add to cart and addProtectionPlanToCart function should be called when clicked', function () {
                    var updatedTemplate;
                    scope.$apply();
                    spyOn(scope, 'addProtectionPlanToCart');
                    //button's visibility before first click event
                    expect(element.find('.protection-add-to-cart').length).toEqual(1);
                    element.find('.protection-add-to-cart')[0].click();
                    expect(scope.addProtectionPlanToCart).toHaveBeenCalled();
                    updatedTemplate = $compile(html)(scope);
                    //checking the updatedTemplate that the button is hidden from the page after first button click,
                    //if not visible then multiple click is not possible.
                    expect(updatedTemplate.find('.protection-add-to-cart').length).toEqual(0);
                });
            });
        });
    });
})();