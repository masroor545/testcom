(function () {
    'use strict';

    define(['upsellOffer'], function () {
        describe('src/main/modules/exBuyflow/directives/upsellOffer.spec.js', function () {
            describe('upsellOffer directive of exBuyflow', function () {
                var element, scope, $rootScope, $compile;


                beforeEach(function () {
                    module('exBuyflow', function ($controllerProvider) {
                        $controllerProvider.register('upsellOfferCtrl', function ($scope) {
                            $scope.vm.offers = [{
                                'offerHeadLine': 'Buy a Samsung Galaxy S8',
                                'upsellSubtotalDetails': {
                                    'offerCartTotalAmount': 0,
                                    'offerCartMonthlyAmount': 0
                                },
                                'offerSubheadLine': 'Buy a Samsung Galaxy S8, and get one free',
                                'offerInBodyContent': 'Free after $750 in credits over 30 months. Credits start in 2 to 3 bills.'
                            }];

                            $scope.vm.upsellOfferAddItemToCart = function () { return true; };
                            $scope.vm.multiSkuUpsellOffer = function () { return true; };
                            $scope.vm.onSkipToCheckout = function () { return true; };
                        });
                    });

                    inject(function ($injector) {
                        $rootScope = $injector.get('$rootScope');
                        $compile = $injector.get('$compile');
                    });


                    var html = '<upsell-offer' +
                    '</upsell-offer>';

                    element = angular.element(html);
                    scope = $rootScope.$new();
                    $compile(element)(scope);
                    $rootScope.$digest();
                    scope = element.isolateScope() || element.scope();
                });

                describe('upsell offer template of exBuyflow', function () {
                    it('should display subtotal details', function () {
                        expect(element.html()).toContain(scope.vm.offers[0].offerHeadLine);
                        expect(element.html()).toContain(scope.vm.offers[0].offerSubheadLine);
                        expect(element.html()).toContain(scope.vm.offers[0].offerInBodyContent);
                        expect(element.html()).toContain(scope.vm.offers[0].upsellSubtotalDetails.offerCartTotalAmount);
                        expect(element.html()).toContain(scope.vm.offers[0].upsellSubtotalDetails.offerCartMonthlyAmount);
                    });

                    it('should have a button to add to cart', function () {
                        scope.vm.offers[0].multiSkuOffer = false;
                        spyOn(scope.vm, 'upsellOfferAddItemToCart');
                        element.find('.upsell-add-to-cart')[0].click();
                        expect(scope.vm.upsellOfferAddItemToCart).toHaveBeenCalled();
                    });

                    it('should have a button to get this offer', function () {
                        scope.vm.offers[0].multiSkuOffer = true;
                        $rootScope.$digest();
                        spyOn(scope.vm, 'multiSkuUpsellOffer');
                        element.find('.upsell-add-to-cart')[0].click();
                        expect(scope.vm.multiSkuUpsellOffer).toHaveBeenCalled();
                    });

                    it('should have a no thanks button if there is only a single offer', function () {
                        spyOn(scope.vm, 'onSkipToCheckout');
                        element.find('.upsell-no-thanks')[0].click();
                        expect(scope.vm.onSkipToCheckout).toHaveBeenCalled();
                    });

                    it('should not have a no thanks button if there are multiple offers', function () {
                        scope.vm.offers = [{}, {}];
                        $rootScope.$digest();

                        // The element shouldn't exist so no elements should be found
                        expect(element.find('.upsell-no-thanks').length).toEqual(0);
                    });


                });
            });
        });
    });
})();

