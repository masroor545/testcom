(function () {
    'use strict';

    /**
     * This directive serves the purpose to show subtotal tooltip modal to user
     *
     * __Requirements:__
     * * Open the subtotal tooltip modal when user clicks on subtotal tooltip
     *
     * @module exAccessorySubtotalTooltip
     *
     * @see {@link ../controllers/#module_accessorySubtotalTooltipCtrl|accessorySubtotalTooltipCtrl}
     *
     * @example @lang html
     * <ex-accessory-subtotal-tooltip></ex-accessory-subtotal-tooltip>
     */
    angular.module('exBuyflow')

        .directive('exAccessorySubtotalTooltip', [function () {
            return {
                restrict: 'EA',
                templateUrl: function (ele, attr) {
                    return attr.templateName ? attr.templateName : '/templates/exaccessorysubtotaltooltip.html';
                },
                controller: 'accessorySubtotalTooltipCtrl'
            };
        }]);
})();