(function () {
    'use strict';

    /**
     * This directive serves the purpose show bazaar voice QA on the details pages.
     *
     * __Requirements:__
     * * Depends on the "bazaar-voice" script being fired by $window.require when directive is called
     * * Depends on a broadcast (BVSkuSelected) set from the device details service once renderend will send out skuid to us.
     *
     * @module exBvQa
     *
     * @fires bvInitiated - @todo Implement details
     *
     * @example @lang html
     * <ex-bv-qa></ex-bv-qa>
     */
    angular.module('exBuyflow')

        .directive('exBvQa', ['$window', 'exCommonConstants', '$rootScope', function ($window, exCommonConstants, $rootScope) {
            return {
                restrict: 'E',
                templateUrl: function (ele, attr) {
                    return attr.templateName ? attr.templateName : '/templates/exbvqa.html';
                },
                link: function (scope) {
                    scope.$on(exCommonConstants.event.BVSkuSelected, function (event, data) {
                        $window.require(['bazaar-voice'], function () {
                            if ($window.$BV !== 'undefined') {
                                $window.$BV.ui('qa', 'show_questions', {
                                    subjectType: 'product',
                                    productId: data.skuId
                                });
                            }
                        });

                    });
                    $rootScope.$broadcast(exCommonConstants.event.BVInitiated, null);
                }
            };
        }]);
})();
