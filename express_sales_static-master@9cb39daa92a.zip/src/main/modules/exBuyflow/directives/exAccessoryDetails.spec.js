(function () {
    'use strict';

    define(['exAccessoryDetails'], function () {
        describe('src/main/modules/exBuyflow/directives/exAccessoryDetails.spec.js', function () {
            describe('exAccessoryDetails directive of exBuyflow', function () {
                var element, scope, $rootScope, $compile;
                beforeEach(function () {
                    module('exBuyflow', function ($provide, $controllerProvider, $compileProvider) {
                        $controllerProvider.register('accessoryDetailsCtrl', function ($scope) {
                            $scope.accessoryConfig = {
                                'productDisplayName': 'Fitbit',
                                'manufacturer': 'Fitbit',
                                selectedSku: {
                                    'color': 'Blue',
                                    'reviewCount': 2758,
                                    'rating': 4.3,
                                    'showRating': true,
                                    'price': 25.00,
                                    'imgUrl': '/path/to/accessories-4974f-964x750.png'
                                }
                            };

                            $scope.displayAccessoryDetails = function () { return true; };
                            $scope.accessoryConfigAddToCart = function () { return true; };
                            $scope.accessoryConfigRemoveItemFromCart = function () { return true; };

                        });
                        $compileProvider.directive('exBvReviews', function () {
                            var def = {
                                priority: 10000,
                                terminal: true,
                                restrict: 'E',
                                link: function () {
                                    // do nothing
                                }
                            };
                            return def;
                        });
                        $compileProvider.directive('exBvQa', function () {
                            var def = {
                                priority: 10000,
                                terminal: true,
                                restrict: 'E',
                                link: function () {
                                    // do nothing
                                }
                            };
                            return def;
                        });
                    });

                    inject(function ($injector) {
                        $rootScope = $injector.get('$rootScope');
                        $compile = $injector.get('$compile');
                    });

                    var html = '<ex-accessory-details>' +
                                '</ex-accessory-details>';

                    element = angular.element(html);
                    scope = $rootScope.$new();
                    $compile(element)(scope);
                    scope.$apply();
                    scope = element.isolateScope() || element.scope();
                });

                describe('exaccessorydetails template of exBuyflow', function () {
                    it('should display information about the selected sku', function () {
                        expect(element.html()).toContain(scope.accessoryConfig.manufacturer);
                        expect(element.html()).toContain(scope.accessoryConfig.productDisplayName);
                        expect(element.html()).toContain(scope.accessoryConfig.selectedSku.color);
                    });

                    it('should have a control to close it when clicked', function () {
                        spyOn(scope, 'displayAccessoryDetails');
                        element.find('.details-drawer-button')[0].click();
                        expect(scope.displayAccessoryDetails).toHaveBeenCalledWith(false);
                    });

                    it('should have a button to add to cart', function () {
                        spyOn(scope, 'accessoryConfigAddToCart');
                        element.find('.details-add-to-cart')[0].click();
                        expect(scope.accessoryConfigAddToCart).toHaveBeenCalled();
                    });

                    it('should have a button to add to cart', function () {
                        spyOn(scope, 'accessoryConfigRemoveItemFromCart');
                        element.find('.details-remove-cart')[0].click();
                        expect(scope.accessoryConfigRemoveItemFromCart).toHaveBeenCalled();
                    });

                });

            });
        });
    });
})();
