(function () {
    'use strict';

    /**
     * Displays subtotal information
     *
     * __Requirements__
     * * Display due today and due monthly amounts
     * * Provide a functionless checkout button which calls cta
     * * CTA section which can be transcluded to allow arbitrary content wrapped by the subtotal bar (e.g. a button to skip to checkout and a button to upgrade another device)
     * * It is recommended to only include the cta attribute if you are not transcluding content and vice versa
     *
     * @module exSubtotal
     *
     * @property {String|Number} dueToday - The amount due today
     * @property {String|Number} dueMonthly - The amount due monthly
     * @property {function} [cta] - The call to action function to be called when the default checkout button is clicked
     *
     * @example <caption>Using cta</caption> @lang html
     * <ex-subtotal due-today="129.99" due-monthly="23.99" cta="function () { }"></ex-subtotal>
     *
     * @example <caption>Transcluding the cta section</caption> @lang html
     * <ex-subtotal due-today="129.99" due-monthly="23.99">
     *  <button ng-click="myFunction1()"></button>
     *  <button ng-click="myFunction2()"></button>
     * </ex-subtotal>
     *
     */
    angular.module('exBuyflow')

        .directive('exSubtotal', [function () {
            return {
                restrict: 'E',
                templateUrl: function (ele, attr) {
                    return attr.templateName ? attr.templateName : '/templates/exsubtotal.html';
                },
                transclude: true,
                controllerAs: 'vm',
                scope: {
                    dueToday: '<',
                    dueMonthly: '<',
                    cta: '=?'
                }
            };
        }]);
})();
