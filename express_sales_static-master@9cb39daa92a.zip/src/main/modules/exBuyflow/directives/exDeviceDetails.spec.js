(function () {
    'use strict';

    define(['exDeviceDetails'], function () {
        describe('src/main/modules/exBuyflow/directives/exDeviceDetails.spec.js', function () {
            describe('exDeviceDetails directive of exBuyflow', function () {
                var element, scope, $rootScope, $compile;
                beforeEach(function () {
                    module('exBuyflow', function ($provide, $controllerProvider, $compileProvider) {
                        $controllerProvider.register('deviceDetailsCtrl', function ($scope) {
                            $scope.deviceConfig = {
                                'model': 'iPhone 7',
                                'manufacturer': 'Apple',
                                selectedSku: {
                                    'capacity': '32 GB',
                                    'color': 'Rose Gold',
                                    'reviewCount': 2758,
                                    'rating': 4.3,
                                    'showRating': true,
                                    'price': 25.00,
                                    'imgUrl': '/path/to/iphone7.png'
                                }
                            };

                            $scope.displayDeviceDetails = function () { return true; };
                            $scope.triggerAddToCart = function () { return true; };

                        });
                        $compileProvider.directive('exBvReviews', function () {
                            var def = {
                                priority: 10000,
                                terminal: true,
                                restrict: 'E',
                                link: function () {
                                    // do nothing
                                }
                            };
                            return def;
                        });
                        $compileProvider.directive('exBvQa', function () {
                            var def = {
                                priority: 10000,
                                terminal: true,
                                restrict: 'E',
                                link: function () {
                                    // do nothing
                                }
                            };
                            return def;
                        });
                    });

                    inject(function ($injector) {
                        $rootScope = $injector.get('$rootScope');
                        $compile = $injector.get('$compile');
                    });

                    var html = '<ex-device-details>' +
                                '</ex-device-details>';

                    element = angular.element(html);
                    scope = $rootScope.$new();
                    $compile(element)(scope);
                    scope.$apply();
                    scope = element.isolateScope() || element.scope();
                });

                describe('exdevicedetails template of exBuyflow', function () {
                    it('should display information about the selected sku', function () {
                        expect(element.html()).toContain(scope.deviceConfig.manufacturer);
                        expect(element.html()).toContain(scope.deviceConfig.model);
                        expect(element.html()).toContain(scope.deviceConfig.selectedSku.capacity);
                        expect(element.html()).toContain(scope.deviceConfig.selectedSku.color);
                        expect(element.html()).not.toContain('Pre-order');
                    });

                    it('should have a control to close it when clicked', function () {
                        spyOn(scope, 'displayDeviceDetails');
                        element.find('.details-drawer-button')[0].click();
                        expect(scope.displayDeviceDetails).toHaveBeenCalledWith(false);
                    });

                    it('should have a button to add to cart', function () {
                        spyOn(scope, 'triggerAddToCart');
                        element.find('.details-add-to-cart')[0].click();
                        expect(scope.triggerAddToCart).toHaveBeenCalled();
                    });

                });

            });
        });
    });
})();
