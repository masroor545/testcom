(function () {
    'use strict';

    /**
     * Displays details of an accessory
     *
     * __Requirements__
     * * displays the selected item's make, model, color, capacity
     * * displays an accordion of other device details
     * * displays an add to cart button
     * * displays a button to return to the device config on mobile
     *
     * @module exAccessoryDetails
     *
     * @see {@link ../controllers/#modules_accessoryDetailsCtrl|accessoryDetailsCtrl}
     *
     * @example @lang html
     * <ex-accessory-details></ex-accessory-details>
     */
    angular.module('exBuyflow')

        .directive('exAccessoryDetails', [function () {
            return {
                restrict: 'E',
                templateUrl: function (ele, attr) {
                    return attr.templateName ? attr.templateName : '/templates/exaccessorydetails.html';
                },
                controller: 'accessoryDetailsCtrl'
            };
        }]);
})();
