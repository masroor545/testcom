(function () {
    'use strict';

    /**
     * @desc @todo Implement details
     *
     * __Requirements:__
     * * @todo Implement details
     *
     * @module exProtectionPlanFooter
     *
     * @see {@link ../controllers/#module_protectionPlanDetailsCtrl|protectionPlanDetailsCtrl}
     *
     * @example @lang html
     * <ex-protection-plan-footer></ex-protection-plan-footer>
     */
    angular.module('exBuyflow')

        .directive('exProtectionPlanFooter', [function () {
            return {
                restrict: 'EA',
                templateUrl: function (ele, attr) {
                    return attr.templateName ? attr.templateName : '/templates/exprotectionplanfooter.html';
                },
                controller: 'protectionPlanDetailsCtrl'
            };
        }]);
})();