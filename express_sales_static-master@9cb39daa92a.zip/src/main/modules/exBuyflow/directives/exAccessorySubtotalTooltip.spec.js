(function () {
    'use strict';

    define(['exAccessorySubtotalTooltip'], function () {
        describe('src/main/modules/exBuyflow/directives/exAccessorySubtotalTooltip.spec.js', function () {
            describe('exAccessorySubtotalTooltip directive of exBuyflow', function () {
                var element, scope, $rootScope, $compile;

                beforeEach(function () {
                    module('exBuyflow', function ($provide, $controllerProvider) {
                        $controllerProvider.register('accessorySubtotalTooltipCtrl', function ($scope) {
                            $scope.getSubtotalTooltipDetails = function () { return true; };
                        });
                    });
                    inject(function ($injector) {
                        $rootScope = $injector.get('$rootScope');
                        $compile = $injector.get('$compile');
                    });

                    var html = '<div ex-accessory-subtotal-tooltip ></div>';
                    element = angular.element(html);
                    scope = $rootScope.$new();
                    $compile(element)(scope);
                    scope = element.isolateScope() || element.scope();
                });

                it('should have the correct HTML rendered and binding for legal content shown be for subtotal tool tip', function () {
                    scope.$apply();
                    expect(element.html()).toContain('Subtotal details');
                    expect(element.html()).toContain('ng-bind-html="subtotalTooltipDetails.description"');
                });

            });
        });
    });
})();
