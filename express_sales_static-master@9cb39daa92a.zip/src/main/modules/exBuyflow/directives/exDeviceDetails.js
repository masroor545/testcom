(function () {
    'use strict';

    angular.module('exBuyflow')

        .directive('exDeviceDetails', [function () {
            return {
                restrict: 'EA',
                templateUrl: function (ele, attr) {
                    return attr.templateName ? attr.templateName : '/templates/exdevicedetails.html';
                },
                scope: {
                    accessoryCategories: '@',
                    relaxStoreIndicator: '@'
                },
                controller: 'deviceDetailsCtrl'
            };
        }]);
})();
