(function () {
    'use strict';

    /**
     * Directive for special offers given to the user based on their eligibility (e.g. BOGO iPhone X)
     *
     * __Requirements:__
     * * displays offers available to the user
     * * displays upsell offer legal content details
     * * displays an upsell offer add to cart button
     *
     * @module upsellOffer
     *
     * @see {@link ../controllers/#module_upsellOfferCtrl|upsellOfferCtrl}
     *
     * @example @lang html
     * <upsell-offer></upsell-offer>
     */
    angular.module('exBuyflow')

        .directive('upsellOffer', [function () {
            return {
                restrict: 'EA',
                templateUrl: function (ele, attr) {
                    return attr.templateName ? attr.templateName : '/templates/upselloffer.html';
                },
                controller: 'upsellOfferCtrl',
                bindToController: true,
                controllerAs: 'vm'
            };
        }]);
})();
