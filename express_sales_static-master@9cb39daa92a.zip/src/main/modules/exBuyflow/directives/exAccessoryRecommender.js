(function () {
    'use strict';

    /**
     * This directive serves the purpose show accessory recommender page.
     *
     * __Requirements:__
     * * Loads the accessory recommender page
     * * Initially X accessories are loaded
     *
     * @module exAccessoryRecommender
     *
     * @property {Number} initialAccessoriesLoaded - number of accessories to display on page load
     * @property {*} defaultInsuranceBillCode - @todo Implement details
     * @property {Array<String>} accessoryCategories - Array of categories that we want recommendations for. Ex: ['cases', 'screen-protectors']
     * @property {*} subTitle - @todo Implement details
     * @property {Boolean} relaxStoreIndicator - StoreId to be considered while recommending accessories from REX API or not.
     * @property {*} subTitleNoAccessory - @todo Implement details
     *
     * @see {@link ../controllers/#module_accessoryRecommenderCtrl|accessoryRecommenderCtrl}
     *
     * @example @lang html
     * <div ex-accessory-recommender></div>
     */
    angular.module('exBuyflow')

        .directive('exAccessoryRecommender', [function () {
            return {
                restrict: 'A',
                templateUrl: function (ele, attr) {
                    return attr.templateName ? attr.templateName : '/templates/exaccessoryrecommender.html';
                },
                scope: {
                    initialAccessoriesLoaded: '@',
                    defaultInsuranceBillCode: '@',
                    accessoryCategories: '@',
                    subTitle: '@',
                    relaxStoreIndicator: '@',
                    subTitleNoAccessory: '@'
                },
                controller: 'accessoryRecommenderCtrl'
            };
        }]);
})();
