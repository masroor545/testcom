(function () {
    'use strict';

    /**
     * Directive for displaying the user's recommended devices
     *
     * __Requirements:__
     * Loads the device recommender page
     * Initially X devices are loaded, first device being the hero device(depending on the configuration of hero device's display flag).
     * Filter displayed devices based on user's selected options
     *
     * @module exDeviceRecommender
     *
     * @property {Number} initialDevicesLoaded - number of devices to display on page load
     * @property {Number} heroConfidenceThreshold - confidence threshold for hero device recommendation
     * @property {Boolean} displayHeroDevice - flag to initially display hero device maximized
     *
     * @see {@link ../controllers/#module_deviceRecommenderCtrl|deviceRecommenderCtrl}
     *
     * @example @lang html
     * <div ex-device-recommender></div>
     */
    angular.module('exBuyflow')

        .directive('exDeviceRecommender', [function () {
            return {
                restrict: 'A',
                templateUrl: function (ele, attr) {
                    return attr.templateName ? attr.templateName : '/templates/exdevicerecommender.html';
                },
                scope: {
                    initialDevicesLoaded: '@',
                    heroConfidenceThreshold: '@',
                    displayHeroDevice: '@'
                },
                controller: 'deviceRecommenderCtrl'
            };
        }]);
})();
