## Modules

<table>
  <thead>
    <tr>
      <th>Module</th><th>Description</th>
    </tr>
  </thead>
  <tbody>
<tr>
    <td><a href="#module_exAccessoryDetails">exAccessoryDetails</a></td>
    <td><p>Displays details of an accessory</p>
<p><strong>Requirements</strong></p>
<ul>
<li>displays the selected item&#39;s make, model, color, capacity</li>
<li>displays an accordion of other device details</li>
<li>displays an add to cart button</li>
<li>displays a button to return to the device config on mobile</li>
</ul>
</td>
    </tr>
<tr>
    <td><a href="#module_exAccessoryRecommender">exAccessoryRecommender</a></td>
    <td><p>This directive serves the purpose show accessory recommender page.</p>
<p><strong>Requirements:</strong></p>
<ul>
<li>Loads the accessory recommender page</li>
<li>Initially X accessories are loaded</li>
</ul>
</td>
    </tr>
<tr>
    <td><a href="#module_exAccessorySubtotalTooltip">exAccessorySubtotalTooltip</a></td>
    <td><p>This directive serves the purpose to show subtotal tooltip modal to user</p>
<p><strong>Requirements:</strong></p>
<ul>
<li>Open the subtotal tooltip modal when user clicks on subtotal tooltip</li>
</ul>
</td>
    </tr>
<tr>
    <td><a href="#module_exBvQa">exBvQa</a></td>
    <td><p>This directive serves the purpose show bazaar voice QA on the details pages.</p>
<p><strong>Requirements:</strong></p>
<ul>
<li>Depends on the &quot;bazaar-voice&quot; script being fired by $window.require when directive is called</li>
<li>Depends on a broadcast (BVSkuSelected) set from the device details service once renderend will send out skuid to us.</li>
</ul>
</td>
    </tr>
<tr>
    <td><a href="#module_exBvReviews">exBvReviews</a></td>
    <td><p>This directive serves the purpose show bazaar voice reviews on the details pages.</p>
<p><strong>Requirements:</strong></p>
<ul>
<li>Shows the bv review ratings for the selected device/accessory</li>
<li>Loads the bv script on window load</li>
<li>Depends on the &quot;bazaar-voice&quot; script being fired by $window.require when directive is called</li>
<li>Depends on a broadcast (BVSkuSelected) set from the device details service once renderend will send out skuid to us</li>
</ul>
</td>
    </tr>
<tr>
    <td><a href="#module_exDeviceLegalDetails">exDeviceLegalDetails</a></td>
    <td><p>Display the long legal content. The template defaults to /templates/exdevicelegaldetails.html</p>
<p><strong>Requirements:</strong></p>
<ul>
<li>Display the long legal content for the selected sku on device legal overlay.</li>
</ul>
</td>
    </tr>
<tr>
    <td><a href="#module_exDeviceRecommender">exDeviceRecommender</a></td>
    <td><p>Directive for displaying the user&#39;s recommended devices</p>
<p><strong>Requirements:</strong>
Loads the device recommender page
Initially X devices are loaded, first device being the hero device(depending on the configuration of hero device&#39;s display flag).
Filter displayed devices based on user&#39;s selected options</p>
</td>
    </tr>
<tr>
    <td><a href="#module_exProtectionPlanFooter">exProtectionPlanFooter</a></td>
    <td><p>@todo Implement details</p>
<p><strong>Requirements:</strong></p>
<ul>
<li>@todo Implement details</li>
</ul>
</td>
    </tr>
<tr>
    <td><a href="#module_exSubtotal">exSubtotal</a></td>
    <td><p>Displays subtotal information</p>
<p><strong>Requirements</strong></p>
<ul>
<li>Display due today and due monthly amounts</li>
<li>Provide a functionless checkout button which calls cta</li>
<li>CTA section which can be transcluded to allow arbitrary content wrapped by the subtotal bar (e.g. a button to skip to checkout and a button to upgrade another device)</li>
<li>It is recommended to only include the cta attribute if you are not transcluding content and vice versa</li>
</ul>
</td>
    </tr>
<tr>
    <td><a href="#module_upsellOffer">upsellOffer</a></td>
    <td><p>Directive for special offers given to the user based on their eligibility (e.g. BOGO iPhone X)</p>
<p><strong>Requirements:</strong></p>
<ul>
<li>displays offers available to the user</li>
<li>displays upsell offer legal content details</li>
<li>displays an upsell offer add to cart button</li>
</ul>
</td>
    </tr>
</tbody>
</table>

<a name="module_exAccessoryDetails"></a>

## exAccessoryDetails
Displays details of an accessory__Requirements__* displays the selected item's make, model, color, capacity* displays an accordion of other device details* displays an add to cart button* displays a button to return to the device config on mobile

**See**: [accessoryDetailsCtrl](../controllers/#modules_accessoryDetailsCtrl)  
**Example**  
```html
<ex-accessory-details></ex-accessory-details>
```

* * *

<a name="module_exAccessoryRecommender"></a>

## exAccessoryRecommender
This directive serves the purpose show accessory recommender page.__Requirements:__* Loads the accessory recommender page* Initially X accessories are loaded

**See**: [accessoryRecommenderCtrl](../controllers/#module_accessoryRecommenderCtrl)  
**Properties**

| Name | Type | Description |
| --- | --- | --- |
| initialAccessoriesLoaded | <code>Number</code> | number of accessories to display on page load |
| defaultInsuranceBillCode | <code>\*</code> | @todo Implement details |
| accessoryCategories | <code>Array.&lt;String&gt;</code> | Array of categories that we want recommendations for. Ex: ['cases', 'screen-protectors'] |
| subTitle | <code>\*</code> | @todo Implement details |
| relaxStoreIndicator | <code>Boolean</code> | StoreId to be considered while recommending accessories from REX API or not. |
| subTitleNoAccessory | <code>\*</code> | @todo Implement details |

**Example**  
```html
<div ex-accessory-recommender></div>
```

* * *

<a name="module_exAccessorySubtotalTooltip"></a>

## exAccessorySubtotalTooltip
This directive serves the purpose to show subtotal tooltip modal to user__Requirements:__* Open the subtotal tooltip modal when user clicks on subtotal tooltip

**See**: [accessorySubtotalTooltipCtrl](../controllers/#module_accessorySubtotalTooltipCtrl)  
**Example**  
```html
<ex-accessory-subtotal-tooltip></ex-accessory-subtotal-tooltip>
```

* * *

<a name="module_exBvQa"></a>

## exBvQa
This directive serves the purpose show bazaar voice QA on the details pages.__Requirements:__* Depends on the "bazaar-voice" script being fired by $window.require when directive is called* Depends on a broadcast (BVSkuSelected) set from the device details service once renderend will send out skuid to us.

**Emits**: <code>event:bvInitiated - @todo Implement details</code>  
**Example**  
```html
<ex-bv-qa></ex-bv-qa>
```

* * *

<a name="module_exBvReviews"></a>

## exBvReviews
This directive serves the purpose show bazaar voice reviews on the details pages.__Requirements:__* Shows the bv review ratings for the selected device/accessory* Loads the bv script on window load* Depends on the "bazaar-voice" script being fired by $window.require when directive is called* Depends on a broadcast (BVSkuSelected) set from the device details service once renderend will send out skuid to us

**Emits**: <code>event:bvInitiated - @todo Implement details</code>  
**Example**  
```html
<ex-bv-reviews></ex-bv-reviews>
```

* * *

<a name="module_exDeviceLegalDetails"></a>

## exDeviceLegalDetails
Display the long legal content. The template defaults to /templates/exdevicelegaldetails.html__Requirements:__* Display the long legal content for the selected sku on device legal overlay.

**See**: [deviceLegalDetailCtrl](../controllers/#module_deviceLegalDetailCtrl)  
**Example**  
```html
<ex-device-legal-details></ex-device-legal-details>
```

* * *

<a name="module_exDeviceRecommender"></a>

## exDeviceRecommender
Directive for displaying the user's recommended devices__Requirements:__Loads the device recommender pageInitially X devices are loaded, first device being the hero device(depending on the configuration of hero device's display flag).Filter displayed devices based on user's selected options

**See**: [deviceRecommenderCtrl](../controllers/#module_deviceRecommenderCtrl)  
**Properties**

| Name | Type | Description |
| --- | --- | --- |
| initialDevicesLoaded | <code>Number</code> | number of devices to display on page load |
| heroConfidenceThreshold | <code>Number</code> | confidence threshold for hero device recommendation |
| displayHeroDevice | <code>Boolean</code> | flag to initially display hero device maximized |

**Example**  
```html
<div ex-device-recommender></div>
```

* * *

<a name="module_exProtectionPlanFooter"></a>

## exProtectionPlanFooter
@todo Implement details__Requirements:__* @todo Implement details

**See**: [protectionPlanDetailsCtrl](../controllers/#module_protectionPlanDetailsCtrl)  
**Example**  
```html
<ex-protection-plan-footer></ex-protection-plan-footer>
```

* * *

<a name="module_exSubtotal"></a>

## exSubtotal
Displays subtotal information__Requirements__* Display due today and due monthly amounts* Provide a functionless checkout button which calls cta* CTA section which can be transcluded to allow arbitrary content wrapped by the subtotal bar (e.g. a button to skip to checkout and a button to upgrade another device)* It is recommended to only include the cta attribute if you are not transcluding content and vice versa

**Properties**

| Name | Type | Description |
| --- | --- | --- |
| dueToday | <code>String</code> \| <code>Number</code> | The amount due today |
| dueMonthly | <code>String</code> \| <code>Number</code> | The amount due monthly |
| cta | <code>function</code> | The call to action function to be called when the default checkout button is clicked |

**Example** *(Using cta)*  
```js
<ex-subtotal due-today="129.99" due-monthly="23.99" cta="function () { }"></ex-subtotal>
```
**Example** *(Transcluding the cta section)*  
```js
<ex-subtotal due-today="129.99" due-monthly="23.99">
 <button ng-click="myFunction1()"></button>
 <button ng-click="myFunction2()"></button>
</ex-subtotal>
```

* * *

<a name="module_upsellOffer"></a>

## upsellOffer
Directive for special offers given to the user based on their eligibility (e.g. BOGO iPhone X)__Requirements:__* displays offers available to the user* displays upsell offer legal content details* displays an upsell offer add to cart button

**See**: [upsellOfferCtrl](../controllers/#module_upsellOfferCtrl)  
**Example**  
```html
<upsell-offer></upsell-offer>
```

* * *

