(function () {
    'use strict';

    define(['exSubtotal'], function () {
        describe('src/main/modules/exBuyflow/directives/exSubtotal.spec.js', function () {
            describe('exSubtotal directive of exBuyflow', function () {
                var element, scope, $rootScope, $compile;

                beforeEach(function () {
                    module('exBuyflow');

                    inject(function ($injector) {
                        $rootScope = $injector.get('$rootScope');
                        $compile = $injector.get('$compile');
                        scope = $rootScope.$new();
                    });

                    scope.data = {
                        dueToday: 500,
                        dueMonthly: 12.29,
                        cta: angular.noop
                    };
                    var html = "<ex-subtotal due-today='data.dueToday' due-monthly='data.dueMonthly' cta='data.cta'></ex-subtotal>";
                    element = angular.element(html);
                    $compile(element)(scope);
                    $rootScope.$digest();
                    scope = element.isolateScope() || element.scope();
                });

                it('should bind its attributes to scope', function () {
                    expect(typeof scope.cta).toEqual('function');
                    expect(scope.dueToday).toEqual(500);
                    expect(scope.dueMonthly).toEqual(12.29);
                });

                it('should expose its scope to the view', function () {
                    var ctaElement = element.find('button');
                    spyOn(scope, ['cta']);
                    ctaElement.click();
                    expect(scope.cta).toHaveBeenCalled();

                    expect(element.html()).toContain(scope.dueToday);
                    expect(element.html()).toContain(scope.dueMonthly);
                });

            });
        });
    });
})();
