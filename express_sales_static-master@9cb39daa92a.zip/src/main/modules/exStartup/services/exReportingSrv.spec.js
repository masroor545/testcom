(function () {
    'use strict';

    define(['exReportingSrv'], function () {
        describe('src/main/modules/exStartup/services/exReportingSrv.spec.js', function () {
            describe('exReportingSrv service of exStartup', function () {
                var mockWindow, service, exLoginGuardService, exStartupConstants, $scope;

                beforeEach(function () {
                    var exDetmManager = jasmine.createSpyObj('exDetmManager', ['whenDetmReady']);

                    EndpointUtils.createFakePromiseFunc({spyFn: exDetmManager.whenDetmReady});

                    mockWindow = {
                        sessionStorage: jasmine.createSpyObj('sessionStorage', ['getItem', 'setItem']),
                        DataMappingInterface: jasmine.createSpyObj('DataMappingInterface', ['customEventNotification']),
                        location: {pathname: '/shop/xpress/es-us/devices/smartphones.html'},
                        innerWidth: 750
                    };

                    exLoginGuardService = jasmine.createSpyObj('exLoginGuardService', ['getProfileData']);

                    module('exStartup', {
                        $window: mockWindow,
                        exLoginGuardService: exLoginGuardService,
                        exDetmManager: exDetmManager
                    });

                    inject(function ($injector) {
                        $scope = $injector.get('$rootScope').$new();
                        exStartupConstants = $injector.get('exStartupConstants');
                        service = $injector.get('exReportingSrv');
                    });

                    service.init();
                    mockWindow.sessionStorage.getItem.and.returnValue('WLS~657067869278|DTV~336012503~156013403');

                });

                afterEach(function () {
                    mockWindow.DataMappingInterface.customEventNotification.calls.reset();
                    mockWindow.sessionStorage.setItem.calls.reset();
                    mockWindow.sessionStorage.getItem.calls.reset();
                });

                it('should produce a page load event for [logged in user] with appropriate values',
                    performPageLoadDataTests(
                        Endpoint_profileInfoApi.get_profile_info_logged_in.result,
                        {innerWidth: 600, pathname: '/shop/xpress/device/configuration.html'},
                        {
                            'page.pageInfo.viewedUIExperience': 'Smartphone',
                            'page.pageInfo.language': 'EN'
                        }
                    ));

                it('should produce a page load event for [anonymous user] with appropriate values',
                    performPageLoadDataTests(
                        Endpoint_profileInfoApi.get_profile_info_anonymous.result,
                        undefined,
                        {
                            'user.attributes.state': 'CA',
                            'user.login.type': undefined
                        }
                    ));

                it('should produce a page load event for [reporting user 1] with appropriate values',
                    performPageLoadDataTests(
                        Endpoint_profileInfoApi.get_profile_info_reporting1.result,
                        {innerWidth: 1300, pathname: '/shop/xpress/en-us/device/configuration.html'},
                        {
                            'page.pageInfo.viewedUIExperience': 'Desktop',
                            'page.pageInfo.language': 'EN',
                            'user.account.ctn': 'SLID',
                            'user.login.id': 'MM285B@ATT.COM',
                            'user.account.plentiLinkedFlag': '0',
                            'user.account.slidAssocAccts': 'WLS~177067869278|UVS~336013403~336013403'
                        }
                    ));

                it('should produce a page load event for [reporting user 2] with appropriate values',
                    performPageLoadDataTests(
                        Endpoint_profileInfoApi.get_profile_info_reporting2.result,
                        {innerWidth: 1000, pathname: '/shop/xpress/es-us/device/configuration.html'},
                        {
                            'page.pageInfo.viewedUIExperience': 'Tablet',
                            'page.pageInfo.language': 'ES',
                            'user.account.sdgFlag': '0',
                            'user.account.ctn': '4253813234',
                            'user.login.type': 'CTN',
                            'user.login.id': '4253813234',
                            'user.account.plentiLinkedFlag': '1',
                            'user.customerType': 'SMB',
                            'user.account.accountInFocusUserType': 'SMB',
                            'user.account.wirelessAccountStatus': 'HS',
                            'user.account.accountInFocusStatus': 'HS',
                            'user.account.slidAssocAccts': 'WLS~657067869278|DTV~336012503~156013403'
                        }
                    ));

                it('should pass along whatever data is emitted in the reporting event to the DataMappingInterface',
                    performEventTest({param: 34, param2: 3455, param3: 'waterbox'}));

                function performEventTest (emitInfo) {
                    return function () {
                        $scope.$emit(exStartupConstants.events.DS_REPORTING_EVENT, emitInfo, $scope);
                        $scope.$apply();

                        expect(mockWindow.DataMappingInterface.customEventNotification)
                            .toHaveBeenCalledWith(emitInfo, jasmine.any(Object));
                    };
                }

                function performPageLoadDataTests (profileData, windowData, expectations) {
                    return function (done) {
                        exLoginGuardService.getProfileData.and.returnValue({
                            then: function (callback) {
                                return callback(profileData);
                            }
                        });

                        mockWindow.innerWidth = (windowData && windowData.innerWidth) ?
                            windowData.innerWidth : mockWindow.innerWidth;
                        mockWindow.location.pathname = (windowData && windowData.pathname) ?
                            windowData.pathname : mockWindow.location.pathname;

                        service.firePageLoad().then(function () {
                            var results = mockWindow.DataMappingInterface.customEventNotification.calls.mostRecent().args[0];

                            expect(results.eventCode).toEqual('page_load');
                            expect(results.eventAction).toEqual('pageLoad');

                            Object.keys(expectations).forEach(function (key) {
                                expect(results.additionaldata[key]).toEqual(expectations[key]);
                            });

                            done();
                        });

                        $scope.$apply();
                    };
                }
            });
        });
    });
})();
