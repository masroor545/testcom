(function () {
    'use strict';

    /**
     * Service encapsulates functionality for communication with Satellite and DETM.  Specifically,
     * notifying it when specific scripts can be loaded on a given page.
     * @module exDetmManager
     */
    angular.module('exStartup')

        .factory('exDetmManager', ['$window', '$document', '$q', function ($window, $document, $q) {
            var detmLoadedDefer = $q.defer();

            return {
                whenDetmReady: whenDetmReady,
                notifyHtmlAssetsLoaded: notifyHtmlAssetsLoaded
            };

            function createAndFireEvent (name) {
                var evt = $document.context.createEvent('Event');
                evt.initEvent(name, true, false);
                $document.context.head.dispatchEvent(evt);
            }

            /**
             * Get promise for completion of tag management scripts
             * @function whenDetmReady
             * @returns {Promise} DETM scripts have been loaded
             *
             * @example
             * exDetmManager.whenDetmReady().then(function () {
             *     // DataManager calls can happen here
             * });
             */
            function whenDetmReady () {
                return detmLoadedDefer.promise;
            }


            /**
             * Trigger custom event to notify satellite script that HTML
             * assets have been loaded for the page and other scripts can now
             * be added.
             * @function notifyHtmlAssetsLoaded
             */
            function notifyHtmlAssetsLoaded () {

                var listenForDetmEvent = $window.document.addEventListener || $window.document.attachEvent;

                listenForDetmEvent('DETM_DMF_READY', function () {
                    detmLoadedDefer.resolve();
                });

                createAndFireEvent('loadDetmNow');
                createAndFireEvent('HTMLAssetsLoaded');
            }
        }]);
})();
