(function () {
    'use strict';

    define(['validateBuyflowInterceptor'], function () {
        describe('src/main/modules/exStartup/services/validateBuyflowInterceptor.spec.js', function () {
            describe('validateBuyflowInterceptor service of exStartup', function () {
                var $httpBackend, service, $scope, storageMock, $http, $window, exStartupConstants;

                beforeEach(function () {                 
                    module('exStartup', {
                        $window: {
                            location: {
                                href: ''
                            }
                        }
                    });

                    inject(function ($injector) {
                        $httpBackend = $injector.get('$httpBackend');
                        $scope = $injector.get('$rootScope').$new();
                        service = $injector.get('validateBuyflowInterceptor');
                        $http = $injector.get('$http');
                        $window = $injector.get('$window')
                        exStartupConstants = $injector.get('exStartupConstants');
                    });
                });

                describe('when service calls are made', function () {
                    afterEach(function () {
                        EndpointUtils.verifyExpectationsComplete($httpBackend);
                    });

                    it('should call validateBuyflowData when redirect URL points to checkout',
                    function () {
                        var endpoint = {
                            url_match: '/something/random.html',
                            response_code: 200,
                            result: {
                                response: {
                                    redirectURL: exStartupConstants.checkoutUrls[0],
                                    redirectKey: '',
                                    redirect: true
                                }
                            }
                        };

                        $httpBackend.expectPOST(endpoint.url_match)
                            .respond(endpoint.response_code, endpoint.result);
                        $httpBackend.expectGET(Endpoint_validateBuyflowDataApi.validate_buyflow_data.url_match)
                            .respond(Endpoint_validateBuyflowDataApi.validate_buyflow_data.response_code, Endpoint_validateBuyflowDataApi.validate_buyflow_data.result);

                        $http.post(endpoint.url_match).then(function (){
                            expect($window.location.href).toBe(endpoint.result.response.redirectURL);
                        });
                        $httpBackend.flush();
                    });

                    it('should not call validateBuyflowData when redirect URL does not point to checkout',
                    function () {
                        var endpoint = {
                            url_match: '/something/random.html',
                            response_code: 200,
                            result: {
                                response: {
                                    redirectURL: '/not/checkout.html',
                                    redirectKey: '',
                                    redirect: true
                                }
                            }
                        };

                        $httpBackend.expectPOST(endpoint.url_match)
                            .respond(endpoint.response_code, endpoint.result);

                        $http.post(endpoint.url_match).then(function (){
                            expect($window.location.href).toBe(endpoint.result.response.redirectURL);
                        });

                        $httpBackend.flush();
                    });

                    it('should not call validateBuyflowData when redirect URL does not exist',
                    function () {
                        var endpoint = {
                            url_match: '/something/random.html',
                            response_code: 200,
                            result: {
                                response: {
                                    redirectURL: '',
                                    redirectKey: '',
                                    redirect: false
                                }
                            }
                        };

                        $httpBackend.expectPOST(endpoint.url_match)
                            .respond(endpoint.response_code, endpoint.result);

                        $http.post(endpoint.url_match).then(function (){
                            expect($window.location.href).toBe('');
                        });
                        $httpBackend.flush();
                    });
                })

            });
        });
    });
})();
