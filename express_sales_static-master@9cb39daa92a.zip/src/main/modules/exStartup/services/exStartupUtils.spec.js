(function () {
    'use strict';

    define(['exStartupUtils'], function () {
        describe('src/main/modules/exStartup/services/exStartupUtils.spec.js', function () {
            describe('exStartupUtils service of exStartup', function () {
                var service;

                beforeEach(function () {
                    module('exStartup');

                    inject(function (exStartupUtils) {
                        service = exStartupUtils;
                    });
                });

                describe('interceptor functionality', function () {

                    it('should accurately respond if config contains the key being searched for', function () {
                        var config = {att: ['abcd', 'efgh']};

                        expect(service.interceptorRequired(config, 'abcd')).toEqual(true);
                        expect(service.interceptorRequired(config, 'bcde')).toEqual(false);
                        expect(service.interceptorRequired(config, 'cdef')).toEqual(false);
                        expect(service.interceptorRequired(config, 'defg')).toEqual(false);
                        expect(service.interceptorRequired(config, 'efgh')).toEqual(true);

                        config = {}; // with no 'att' array

                        expect(service.interceptorRequired(config, 'abcd')).toEqual(false);
                    });
                });
            });
        });
    });
})();
