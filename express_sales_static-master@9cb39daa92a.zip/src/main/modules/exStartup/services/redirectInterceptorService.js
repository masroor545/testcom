(function () {
    'use strict';

    /**
     * Middleware to handle redirect responses in HTTP calls
     * @module redirectInterceptorService
     */
    angular.module('exStartup')

        .factory('redirectInterceptorService', ['$location', '$state', '$window', 'exStartupConstants',
            function ($location, $state, $window, exStartupConstants) {

                /**
                 * Redirects an xpress url vis $location.url and a xpress external url via $window.location.href.
                 * @param redirectUrl Url that the user will be redirected to.
                 */
                function redirectToUrl (redirectUrl) {
                    // is this a URL within the xpress eco system?
                    if (redirectUrl.indexOf(exStartupConstants.contextRoot) === 0) {
                        // yes, use $location.url for redirect
                        $location.url(redirectUrl);
                    } else {
                        // nope, not xpress eco system, reload page via $window.location.href as per
                        // AngularJS $location documentation.
                        $window.location.href = redirectUrl;
                    }
                }
                /**
                 * Starts the redirect transition to the given stateName
                 * @param {string} stateName state the user will redirect to
                 */
                function redirectToState (stateName) {
                    $state.go(stateName);
                }

                return {
                    'response': function (response) {
                        try {
                            if (response.data.response.redirect === true) {

                                // Check for redirect key first
                                if (response.data.response.redirectKey !== null) {

                                    // Try to resolve the redirect key
                                    try {
                                        // Splits string by dot and accesses member by property
                                        // 'url.foo.bar.baz' -> exStartupConstants.url.foo.bar.baz
                                        var url = response.data.response.redirectKey
                                            .split('.')
                                            .reduce(function (object, property) {
                                                return object[property];
                                            }, exStartupConstants);
                                        if (url.state) {
                                            redirectToState(url.state);
                                        } else {
                                            redirectToUrl(url);
                                        }

                                    // Use redirect url, resolving redirect key failed
                                    } catch (e) {

                                        // Check for existence of redirect url
                                        if (response.data.response.redirectURL !== null) {

                                            redirectToUrl(response.data.response.redirectURL);
                                        }
                                    }

                                // Check for redirect URL
                                } else if (response.data.response.redirectURL !== null) {

                                    redirectToUrl(response.data.response.redirectURL);
                                }
                            }

                        } catch (e) {
                            // Ignore error because we don't expect response to always be defined
                        }

                        return response;
                    }
                };
            }])

        .config(['$httpProvider', function ($httpProvider) {
            $httpProvider.interceptors.push('redirectInterceptorService');
        }]);

})();
