(function () {
    'use strict';

    /**
     * Middleware to validate the buyflow data before redirecting to checkout
     * @module validateBuyflowInterceptor
     */
    angular.module('exStartup')

        .factory('validateBuyflowInterceptor', ['$injector', 'exStartupConstants',
            function ($injector, exStartupConstants) {
                return {
                    'response': function (response) {
                        try {
                            var redirectURL = response.data.response.redirectURL,
                                urlMatches = [];

                            // chcek url against constants array
                            urlMatches = exStartupConstants.checkoutUrls.filter(function (url) {
                                return redirectURL.indexOf(url) > -1;
                            });

                            // if any url matches, call the service
                            if (urlMatches.length > 0) {
                                // we are leaving to checkout, validate buyflow data
                                return validateBuyflowData().then(function () {
                                    return response;
                                });
                            } else {
                                // we are not going to checkout, treat response as normal
                                return response;
                            }
                        } catch (e) {
                            // redirectURL is undefined or otherwise not available
                            // return response unchanged
                            return response;
                        }
                    }
                };

                /**
                 * Makes a get call to the buyflow data validation service.
                 * the data validation service checks and fixes the order data and ensures no data is missing
                 * @return {Object} data post response
                 */
                function validateBuyflowData () {
                    var params = '?actionType=validatebuyflowdata',
                        $http = $injector.get('$http'); // using the $injector service to avoid circular dependency errors
                    return $http.get(exStartupConstants.exBuyFlowDataValidatingServiceUrl + params)
                        .then(function (response) {
                            return response.data;
                        });
                }
            }])
        .config(['$httpProvider', function ($httpProvider) {
            $httpProvider.interceptors.push('validateBuyflowInterceptor');
        }]);
})();
