/* global isContained*/
(function () {
    'use strict';

    /**
     * Capture routing events for further processing of events
     * @module routeEventService
     */
    angular.module('exStartup')

        .run([
            '$rootScope', '$document', '$route', '$transitions', '$modalStack', 'exReportingSrv', 'exSessionMonitor', '$window',
            'exStartupConstants', 'exDetmManager', 'spinnerInterceptor', 'exPostAuthGlobalApi', 'exLoginGuardService', '$timeout',
            function ($rootScope, $document, $route, $transitions, $modalStack, exReportingSrv, exSessionMonitor, $window,
                      exStartupConstants, exDetmManager, spinnerInterceptor, exPostAuthGlobalApi, exLoginGuardService, $timeout) {
                $transitions.onBefore({}, function (transition) {
                    var to = transition.$to();
                    if (to.authorize === true) {
                        exLoginGuardService.authorize();
                    }
                    // When the user navigates through the single page application through clicks instead of hard refresh,
                    // We check to see if there is an ab test on the next page and if there is then we fire mbox.
                    if (isContained(JSON.parse($window.sessionStorage.abTestPaths), [$window.location.hostname + to.url.pattern]) === true) {
                        require(['mbox'], function () {
                            // adding mbox to the page.
                        });
                    }
                });

                $transitions.onStart({}, function () {
                    var top = $modalStack.getTop();
                    if (top) {
                        $modalStack.dismiss(top.key);
                    }
                });

                $transitions.onSuccess({}, function (transition) {
                    var current = transition.$to(),
                        friendlyPageName = current.friendlyPageName;

                    if (current.authorize === true) {
                        exPostAuthGlobalApi.perform();
                    }

                    // restart session timeout on successful page load
                    exSessionMonitor.restartTimer();

                    // Sets page title
                    $document[0].title = current.title;

                    /**
                     * This is to notify satellite that scripts can be loaded
                     */
                    spinnerInterceptor.whenUserAccessible().then(function () {
                        notifyCorePageIntentReady();
                        require(['env-goldeneye'], function () {
                            // adding goldeneye to the page if it has not been called
                        });
                        if (friendlyPageName) {
                            exReportingSrv.firePageLoad(friendlyPageName);
                        }
                        setUpSatelliteCalls();
                    });
                });

                // setup global event listener for the session timeout
                $rootScope.$on(exStartupConstants.events.SESSION_STATE_EVENT, function (evt, data) {
                    // session timeout event captured
                    if (data.type === 'expired') {
                        // timeout expired

                        $window.location.href = exStartupConstants.shopLoginURL;
                    } else if (data.type === 'warning') {
                        // timeout warning
                    }
                });

                // setup global event listener to refresh cart of global nav component
                $rootScope.$on(exStartupConstants.events.REFRESH_GLOBAL_NAV_CART, function () {
                    // GlobalNavHandler is defined globally once global nav initalizes it, defined in the globals at the top of this file
                    if ($window.GlobalNavHandler && $window.GlobalNavHandler.refreshCart) {
                        $window.GlobalNavHandler.refreshCart();
                    }
                });

                // setup global event listener for the hidding the global nav component
                $rootScope.$on(exStartupConstants.events.hideGlobalNav, function () {
                    // GlobalNavHandler is defined globally once global nav initalizes it, defined in the globals at the top of this file
                    if ($window.GlobalNavHandler) {
                        $window.GlobalNavHandler.toggleHeader(true);
                        $window.GlobalNavHandler.toggleFooter(true);
                    }
                });

                // setup global event listener for the showing the global nav component when it is hidden
                $rootScope.$on(exStartupConstants.events.showGlobalNav, function () {
                    // GlobalNavHandler is defined globally once global nav initalizes it, defined in the globals at the top of this file
                    if ($window.GlobalNavHandler) {
                        $window.GlobalNavHandler.toggleHeader(false);
                        $window.GlobalNavHandler.toggleFooter(false);
                    }
                });

                /**
                 * Setting up special param 'sputnik' to delay satellite scripts firing
                 * If the param sputnik has a number as a value, then the satellite script will be deferred by that value in milliseconds.
                 * If no params are passed then satellite scripts fire after page load
                 * @example
                 * https://www.att.com/shop/xpress/device-recommender.html?sputnik=4000
                 */
                function setUpSatelliteCalls () {
                    $timeout(function () {
                        notifyNoneCriticalRenderingAssestsTofire();
                        exDetmManager.notifyHtmlAssetsLoaded();
                    }, exStartupConstants.thirdPartyScriptDeferTime);
                }

                function notifyCorePageIntentReady () {
                    // send event primarily for dynatrace to know when page / url is ready
                    var evt = $document.context.createEvent('Event');
                    evt.initEvent('CriticalPathComplete', true, false);
                    $document.context.head.dispatchEvent(evt);
                }

                function notifyNoneCriticalRenderingAssestsTofire () {
                    // send event primarily for dynatrace so none critical rendering assests fire
                    var evt = $document.context.createEvent('Event');
                    evt.initEvent('FireNoneCriticalRenderingAssests', true, false);
                    $document.context.head.dispatchEvent(evt);
                }
            }]);
})();
