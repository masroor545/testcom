(function () {
    'use strict';

    define(['profileServiceInterceptor'], function () {
        describe('src/main/modules/exStartup/services/profileServiceInterceptor.spec.js', function () {
            describe('profileServiceInterceptor of exStartup', function () {
                var $httpBackend, service, $http, $window, exStartupConstants, $cookies;

                beforeEach(function () {
                    module('exStartup', {
                        $window: {
                            location: {
                                href: ''
                            }
                        }
                    });
                    inject(function ($injector) {
                        $httpBackend = $injector.get('$httpBackend');
                        service = $injector.get('profileServiceInterceptor');
                        $http = $injector.get('$http');
                        $cookies = $injector.get('$cookies');
                        $window = $injector.get('$window');
                        exStartupConstants = $injector.get('exStartupConstants');
                    });

                    spyOn($cookies, 'remove');

                });

                it('should navigate to login page if we are not authenticated', function () {
                    var result = Endpoint_profileInfoApi.get_profile_info_unauth.result;
                    result.config = {authorize: true};
                    service.response(result);
                    expect($window.location.href).toBe(exStartupConstants.shopLoginURL);

                });

            });
        });
    });
})();
