(function () {
    'use strict';

    /**
     * Used to create constant variables related to startup module
     * @module exStartupConstants
     * @property {string} btmInfoUrl - API used to perisist Bill to Mobile (BTM) to COSC.
     * @property {boolean} btmPersistToCosc - A flag that allows us to enable/disable the persisting of BTM to COSC.
     * @property {string} btmStorageKey - Key name to save the BTM state to session storage.
     * @property {string} contextRoot - Context root of the xpress web site.
     * @property {string} customerAuthState - State at which customer is authenticated.
     * @property {object} events -
     * @property {string} events.DS_REPORTING_EVENT -
     * @property {string} events.DS_REPORTING_PAGELOAD_EVENT -
     * @property {string} events.hideGlobalNav -
     * @property {string} events.REFRESH_GLOBAL_NAV_CART -
     * @property {string} events.SESSION_STATE_EVENT -
     * @property {string} events.showGlobalNav -
     * @property {string} exCheckUpsellOfferEligibility - API to call upsell offer eligibility service.
     * @property {string} storedFavStoreKey - Key name to save the favorite store API state to session storage.
     * @property {string} getFavoriteStoreApi - API that retrieves and stores the favorite store id into Cassandra if nothing is available for users UUID
     * @property {string} loginCookie - key of the cookie set at login
     * @property {string} storedFavStoreDataKey - key name that retrieves and stores the favorite store data into session storage
     * @property {object} http - contains keys used for interceptor configuration
     * @property {string} http.postAuthReq - key for requests that are configured to depend on CSI authorization completion
     * @property {string} invokeCSICallURL - Url for CSI Call.
     * @property {string} upgradeEligibility - API for user's upgrade eligibility information.
     * @property {string} exBuyFlowDataValidatingServiceUrl -  Service URL for the buyflow controller service for validating buyflow data
     * @property {number} thirdPartyScriptDeferTime - The amount of time the third party scripts will wait before they are invoked.
     * @property {number} [maxSpinRequestTime = 4000] - Maximum amount of time the spinner will be displayed without getting a response from a spinner
     * @property {number} [maxSpinStatusTime = 750] - The amount of time between checks of if the page spinner is currently being shown.
     * @property {string} profileServiceURL - Url for the profile service.
     * @property {object} url.xpress.page - contains keys for various urls & states within the xpress application passed by backend
     * @property {object} visualBreakpoints - width for viewedUIExperience in reporting
     * @property {number} [visualBreakpoints.desktop = 1024]
     * @property {number} [visualBreakpoints.smartphone = 768]
     * @property {string} xpressEventMappingPath - path to the location of the edd.json file for reporting.
     * @property {String[]} checkoutUrls - array of strings to check against to determine if redirecting to checkout
     */
    angular.module('exStartup')
        .constant('exStartupConstants', {
            btmInfoUrl: '/apis/checkout/btmPaymentInfo/v1/btminfo/{0}',
            btmPersistToCosc: true,
            btmStorageKey: 'btmState',
            contextRoot: '/shop/xpress/',
            customerAuthState: 'authenticated',
            getFavoriteStoreApi: '/services/shopwireless/model/att/ecom/api/store/StoreService/getFavoriteStore?uuid={0}',
            loginCookie: 'v_wirelessAuth',
            storedFavStoreKey: 'storedFavStoreState',
            storedFavStoreDataKey: 'myFavLocalData',
            maxSpinRequestTime: 4000,
            maxSpinStatusTime: 750,
            thirdPartyScriptDeferTime: 1500,
            profileServiceURL: '/services/shopwireless/model/att/ecom/api/ProfileServiceActor/getProfileInfo?viewType=zippy',
            profileStorageKey: 'exUpProfile',
            xpressEventMappingPath: '/shop/xpress/ui/express_sales_static/0.1.0/lib/json/edd.json',
            shopLoginURL: '/shop/login/login.html',
            invokeCSICallURL: '/services/shopwireless/model/att/ecom/api/CsiCallForPostAuthorizationServiceActor/invokeCSIService',
            upgradeEligibility: '/services/shopwireless/model/att/ecom/api/WirelessUpgradeSelectionActor/getUpgradeEligibility',
            exCheckUpsellOfferEligibility: '/services/shopwireless/model/att/ecom/api/UpsellServiceController/upsellService',
            exBuyFlowDataValidatingServiceUrl: '/services/shopwireless/model/att/ecom/api/BuyFlowController/service',
            checkoutUrls: ['mycart.html', 'onepagecheckout.html'],
            http: {
                postAuthReq: 'postAuthRequired'
            },
            events: {
                hideGlobalNav: 'HIDE_GLOBALNAV',
                SESSION_STATE_EVENT: 'SESSION_STATE_CHANGED',
                showGlobalNav: 'DISPLAY_GLOBALNAV',
                DS_REPORTING_EVENT: 'DS_Reporting_Event',
                DS_REPORTING_PAGELOAD_EVENT: 'DS_Reporting_PageLoad_Event',
                REFRESH_GLOBAL_NAV_CART: 'Refresh_Global_Nav_Cart'
            },
            titles: {
                deviceRecommender: 'Pick your new device',
                deviceDetails: 'Device Details',
                accessoryServiceRecommender: 'Protection and accessories',
                upgradeEligibility: 'Upgrade Eligibility',
                upgradeEligibilityPayment: 'Upgrade Payment',
                upsellOffer: 'Device Offer',
                upgradeTradeinConsent: 'Upgrade Tradein Consent',
                upgradePaymentConfirm: 'Upgrade Payment Confirm'
            },
            friendlyPageName: {
                deviceRecommender: 'DS Upgrade Device Recommender Pg',
                deviceDetails: 'DS Upgrade Device Details Pg',
                accessoryServiceRecommender: 'DS Upgrade Protection And Accessories Pg',
                upgradeEligibility: 'DS Upgrade Eligibility And Options Pg',
                upgradeEligibilityPayment: 'DS Upgrade Payment Pg',
                upsellOffer: 'DS Upgrade Upsell Offer Pg',
                upgradeTradeinConsent: 'DS Upgrade Tradein Only Consent Pg',
                upgradePaymentConfirm: 'DS Upgrade Payment Confirmation Pg'
            },
            url: {
                xpress: {
                    page: {
                        accessoryServiceRecommender: {
                            url: '/shop/xpress/accessory-service-recommender.html',
                            state: 'accessory-recommender'
                        },
                        deviceRecommender: {
                            url: '/shop/xpress/device-recommender.html',
                            state: 'device-recommender'
                        },
                        upgradeTradeinConsent: {
                            url: '/shop/xpress/upgrade-tradein-consent.html',
                            state: 'upgrade-tradein-consent'
                        },
                        upgradeEligibilityPayment: {
                            url: '/shop/xpress/upgrade-eligibility-payment.html',
                            state: 'upgrade-eligibility-payment'
                        },
                        upgradePaymentConfirm: {
                            url: '/shop/xpress/upgrade-payment-confirm.html',
                            state: 'upgrade-eligibility-payment'
                        }
                    }
                }
            },
            visualBreakpoints: {
                desktop: 1024,
                smartphone: 768
            }
        });
})();