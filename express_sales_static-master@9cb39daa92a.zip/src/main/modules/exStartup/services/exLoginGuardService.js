(function () {
    'use strict';

    /**
     * Gets customer's authentication state from user's profile data.
     * @module exLoginGuardService
     */
    angular.module('exStartup')

        .factory('exLoginGuardService', ['$cookies', '$http', '$q', '$window', '$log', '$cacheFactory', 'exStartupConstants',
            function ($cookies, $http, $q, $window, $log, $cacheFactory, exStartupConstants) {
                var services = {};

                /**
                 * Gets the profile data from profile API
                 * Only called once per browser page refresh data freshness not priority from cache: true
                 *
                 * @function getProfileData
                 * @returns {object} promise object profile data
                 * @example
                 * exLoginGuardService.getProfileData();
                 *     .then(function (data) {
                 *         // do something with said data object
                 *     });
                 */
                services.getProfileData = function () {
                    return $http.get(exStartupConstants.profileServiceURL, {
                        spinner: false,
                            // prevent multiple calls, only needed once to check if user is logged in.
                        cache: true
                    }).then(function (results) {
                            // saving profile to session storage so later calls are pulled from cache
                            // only if authenticated tho
                        if (isCustomerAuthorized(results.data)) {
                            $window.sessionStorage.setItem(exStartupConstants.profileStorageKey, JSON.stringify(results.data));
                        }
                            // return the profile
                        return results.data;
                    });
                };

                /**
                 * Gets the current user's profile authentication state and accordingly redirects the unauthenticated
                 * user to login page. Authorized users without wireless accounts are also being redirected to the
                 * login page.
                 * @function authorize
                 * @returns {object} promise object profile data
                 * @example
                 * exLoginGuardService.authorize()
                 *     .then(function (data) {
                 *         // do something with said data object
                 *     });
                 */
                services.authorize = function () {
                    var maxAttempts = 2;
                    return $q(function (resolve, reject) {
                        profileRepeater(resolve, reject, maxAttempts);
                    });

                    // do not remove this is for the cookie logic
                    // function checkAuthCookie (resolve, reject) {
                    //     var authCookie = $cookies.get(exStartupConstants.loginCookie);
                    //     if (authCookie && authCookie === 'true') {
                    //         resolve(true);
                    //     } else {
                    //         reject(false);
                    //         $log.info('Auth cookie is undefined or false, redirecting to login page');
                    //         $window.location.href = exStartupConstants.shopLoginURL;
                    //     }

                    // }

                    function profileRepeater (resolve, reject, count) {
                        if (count > 0) {
                            services.getProfileData().then(function (data) {
                                if (data && data.ProfileInfo) { // verify service response is valid
                                    if (isCustomerAuthorized(data)) { // customer authenticated
                                        resolve(data);
                                    } else { // customer not authenticated
                                        reject(getProfileDataFailed(data));
                                        $window.location.href = exStartupConstants.shopLoginURL;
                                    }
                                } else { // invalid service response
                                    $cacheFactory.get('$http').remove(exStartupConstants.profileServiceURL);
                                    profileRepeater(resolve, reject, count -= 1);
                                }
                            }, function (data) {
                                reject(getProfileDataFailed(data)); // service failed
                                $window.location.href = exStartupConstants.shopLoginURL;
                            });
                        } else { // no valid data provided on any request
                            reject(getProfileDataFailed({
                                data: {
                                    description: 'Multiple attempts made no valid service response!!!'
                                }
                            }));
                            $window.location.href = exStartupConstants.shopLoginURL;
                        }
                    }
                };

                 /**
                 * Logs an error and rejects the promise returned by the getProfileData function.
                 * @param error response error object.
                 * @return {Promise} Returns rejected promise
                 */
                function getProfileDataFailed (error) {
                    var message = 'exLoginGuardService.getProfileDataFailed authentication failed';
                    if (error && error.data && error.data.description) {
                        message += '\n' + error.data.description;
                    }
                    $log.error(message);
                    return $q.reject(error);
                }

                /**
                 * Gets the current user's upgrade eligibility information by invoking the upgrade eligibility service
                 * @function fetchUserDetails
                 * @returns {boolean} true indicating service has been called
                 * @example
                 * exLoginGuardService.fetchUserDetails()
                 *     .then(function (response) {
                 *         // set data in session storage and return true
                 *     });
                 */
                services.fetchUserDetails = function fetchUserDetails () {
                    var storageKey = exStartupConstants.upgradeEligibility;
                    var storedUpLine = $window.sessionStorage.getItem(storageKey);
                    // Clears the sessionStorage before we fetch the user information to fetch the latest data
                    if ((storedUpLine !== null && storedUpLine !== undefined)) {
                        $window.sessionStorage.removeItem(storageKey);
                    }
                    // load the profile, store it and then return it.
                    return $http.get(exStartupConstants.upgradeEligibility).then(function (response) {
                        $window.sessionStorage.setItem(storageKey, JSON.stringify(response.data));
                        return true;
                    });
                };

                 /**
                 * Check profile data for authentication
                 * @param profileData profile json data
                 * @return {boolean} Returns true if customer is authenticated
                 */
                function isCustomerAuthorized (profileData) {
                    if (profileData &&
                        profileData.ProfileInfo &&
                        profileData.ProfileInfo.customerState === exStartupConstants.customerAuthState &&
                        profileData.ProfileInfo.wirelessAuthenticated === true) {
                        return true;
                    }
                    return false;
                }

                return services;
            }]);
})();