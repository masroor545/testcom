(function () {
    'use strict';

    /**
     * Interceptor that looks for responses with the authorize value set in config
     * Ensures we are authenticated even if the cookie set at log in is true
     * @module profileServiceInterceptor
     */
    angular.module('exStartup')

        .factory('profileServiceInterceptor', ['exStartupConstants', '$window', '$cookies',
            function (exStartupConstants, $window, $cookies) {
                return {
                    'response': function (response) {
                        if (response.config.authorize === undefined || response.config.authorize === 'true') {
                            return response;
                        } else if (response.data &&
                                response.data.ProfileInfo &&
                                response.data.ProfileInfo.customerState === exStartupConstants.customerAuthState &&
                                response.data.ProfileInfo.wirelessAuthenticated === true) {
                            return response;
                        }
                        // We are not authenticated, redirect to the login page
                        $cookies.remove(exStartupConstants.loginCookie);
                        $window.location.href = exStartupConstants.shopLoginURL;
                        return response;
                    }
                };
            }])
        .config(['$httpProvider', function ($httpProvider) {
            $httpProvider.interceptors.push('profileServiceInterceptor');
        }]);
})();
