(function () {
    'use strict';

    angular.module('exStartup')

        .factory('exPostAuthGlobalApi', [
            '$log', '$q', '$http', '$cookies', '$window', 'exStartupConstants', 'exPostAuthGlobalInterceptor',
            function ($log, $q, $http, $cookies, $window, exStartupConstants, exPostAuthGlobalInterceptor) {

                return {
                    perform: perform,
                    postAuthCallsNeeded: postAuthCallsNeeded,
                    checkUpsellOfferEligibility: checkUpsellOfferEligibility
                };

                /**
                 * Enables blocking nature of this service and makes call
                 * @returns {promise} promise resolved when processing complete
                 */
                function perform () {
                    exPostAuthGlobalInterceptor.initialize();
                    return executePostAuthCalls().then(exPostAuthGlobalInterceptor.complete);
                }

                /**
                 * Save favorite store info into Cassandra.
                 * @function saveFavStore
                 */
                function saveFavStoreId () {
                    var uuid;
                    var favStoreUrlPlusUuid;
                    var favStoreState = 'stored';
                    var storedFavStoreState = $window.sessionStorage.getItem(exStartupConstants.storedFavStoreKey);

                    if (storedFavStoreState !== favStoreState) {

                        uuid = $cookies.get('UUID');

                        if (uuid) {
                            $log.info('Storing favStoreId.');
                            favStoreUrlPlusUuid = exStartupConstants.getFavoriteStoreApi.replace('{0}', uuid);
                            $http({
                                method: 'GET',
                                url: favStoreUrlPlusUuid
                            }).then(
                                function (response) {
                                    $window.sessionStorage.setItem(exStartupConstants.storedFavStoreKey, favStoreState);
                                    $window.sessionStorage.setItem(exStartupConstants.storedFavStoreDataKey, JSON.stringify(response.data));
                                    $log.info('Storing favStore succeeded.');
                                },
                                function () {
                                    $log.info('Storing favStore failed.');
                                }
                            );
                        }
                    }
                }

                /**
                 * Persists BTM to COSC via an API request, given that this functionality
                 * is enabled and a valid UUID cookie is found. Returns nothing.
                 * @function persistBtmToCosc
                 */
                function persistBtmToCosc () {
                    var uuid;
                    var btmUrlPlusUuid;
                    var btmState = 'persisted';
                    var storedBtmState = $window.sessionStorage.getItem(exStartupConstants.btmStorageKey);

                    if (exStartupConstants.btmPersistToCosc === true
                        && storedBtmState !== btmState) {

                        uuid = $cookies.get('UUID');

                        if (uuid) {
                            $log.info('Persisting BTM.');
                            btmUrlPlusUuid = exStartupConstants.btmInfoUrl.replace('{0}', uuid);
                            $http({
                                method: 'GET',
                                url: btmUrlPlusUuid
                            }).then(
                                function () {
                                    $window.sessionStorage.setItem(exStartupConstants.btmStorageKey, btmState);
                                    $log.info('Persisting BTM succeeded.');
                                },
                                function () {
                                    $log.info('Persisting BTM failed.');
                                }
                            );
                        }
                    }
                }

                /**
                 * Makes the necessary network calls if needed and handles response. If call is made and successful then
                 * we need to refresh globalnav cart
                 * @returns {promise} object that is resolved or rejected given when process complete
                 */
                function executePostAuthCalls () {
                    if (postAuthCallsNeeded()) {
                        return $http.get(exStartupConstants.invokeCSICallURL, {cache: true})
                            .then(
                                function (response) {
                                    var data = response.data || {};
                                    if (data.authenticationError === true) {
                                        $log.info('exPostAuthGlobalApi: performing redirect due to error');
                                        $window.location.href = response.data.redirectURL;
                                        return $q.reject();
                                    } else {
                                        $log.info('exPostAuthGlobalApi: process completed with success');
                                        persistBtmToCosc();
                                        saveFavStoreId();
                                    }
                                },
                                function () {
                                    $window.location.href = exStartupConstants.shopLoginURL;
                                    return $q.reject();
                                });
                    } else {
                        persistBtmToCosc();
                        saveFavStoreId();

                        return $q.resolve();
                    }
                }

                function postAuthCallsNeeded () {
                    return ($cookies.get('v_coscGlobalSwitch')
                        && $cookies.get('v_coscSalesSwitch')
                        && !$cookies.get('v_coscPayLoadError')) ? true : false;
                }

                 /**
                 * Check for upsell offer eligibility of the current losg beforehand.
                 * @function checkUpsellOfferEligibility
                 * @returns {object} promise upsell offer eligibility
                 */
                function checkUpsellOfferEligibility () {
                    var storageKey = exStartupConstants.exCheckUpsellOfferEligibility;
                    var storedUpLine = $window.sessionStorage.getItem(storageKey);
                    // Clears the sessionStorage before we fetch the user information to fetch the latest data
                    if ((storedUpLine !== null && storedUpLine !== undefined)) {
                        $window.sessionStorage.removeItem(storageKey);
                    }
                    $http.get(exStartupConstants.exCheckUpsellOfferEligibility, {
                        params: {
                            actionType: 'getUpsellEligibilty'
                        },
                        cache: true
                    }).then(function (response) {
                        $window.sessionStorage.setItem(storageKey, JSON.stringify(response.data));
                    });
                    return true;
                }
            }]);
})();
