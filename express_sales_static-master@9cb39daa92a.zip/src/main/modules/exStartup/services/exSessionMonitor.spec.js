(function () {
    'use strict';

    define(['exSessionMonitor'], function () {
        describe('src/main/modules/exStartup/services/exSessionMonitor.spec.js', function () {
            describe('exSessionMonitor service of exStartup', function () {
                var mockSessionMonitor, exStartupConstants, $rootScope, exSessionMonitor;

                function createAndDispatchEvent (name) {
                    var evt = document.createEvent('Event');
                    evt.initEvent(name, true, false);
                    document.dispatchEvent(evt);
                }

                beforeEach(function () {
                    mockSessionMonitor = jasmine.createSpyObj('sessionMonitor', ['restartTimer']);
                    mockSessionMonitor.SESSION_WARNING_EVENT = 'testWarning';
                    mockSessionMonitor.SESSION_EXPIRED_EVENT = 'testExpired';

                    module('exStartup', {
                        $window: {
                            sessionMonitor: mockSessionMonitor,
                            document: document
                        }
                    });

                    inject(function ($injector) {
                        exSessionMonitor = $injector.get('exSessionMonitor');
                        $rootScope = $injector.get('$rootScope');
                        exStartupConstants = $injector.get('exStartupConstants');
                    });

                    mockSessionMonitor.restartTimer.calls.reset();
                });

                it('should listen for session warning event and broadcast to child scopes', function (done) {
                    var $scope = $rootScope.$new(), cleanup;

                    cleanup = $scope.$on(exStartupConstants.events.SESSION_STATE_EVENT, function (evt, data) {
                        expect(data).toEqual(jasmine.objectContaining({type: 'warning'}));
                        cleanup();
                        done();
                    });

                    createAndDispatchEvent(mockSessionMonitor.SESSION_WARNING_EVENT);
                });

                it('should listen for session expired event and broadcast to child scopes', function (done) {
                    var $scope = $rootScope.$new(), cleanup;

                    cleanup = $scope.$on(exStartupConstants.events.SESSION_STATE_EVENT, function (evt, data) {
                        expect(data).toEqual(jasmine.objectContaining({type: 'expired'}));
                        cleanup();
                        done();
                    });

                    createAndDispatchEvent(mockSessionMonitor.SESSION_EXPIRED_EVENT);
                });

                it('should trigger session refresh function whenever the angular service restart is called', function () {
                    expect(mockSessionMonitor.restartTimer).not.toHaveBeenCalled();
                    exSessionMonitor.restartTimer(); // call angular service function to pass through
                    expect(mockSessionMonitor.restartTimer).toHaveBeenCalled();
                });
            });
        });
    });
})();
