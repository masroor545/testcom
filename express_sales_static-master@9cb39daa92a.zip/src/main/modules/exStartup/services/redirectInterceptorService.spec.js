(function () {
    'use strict';

    define(['redirectInterceptorService'], function () {
        describe('src/main/modules/exStartup/services/redirectInterceptorService.spec.js', function () {
            describe('redirectInterceptorService service of exStartup', function () {
                var $http, $httpBackend, $location, $window, exStartupConstants, $state;

                beforeEach(function () {
                    module('exStartup', {
                        $window: {
                            location: {
                                href: ''
                            }
                        }
                    });

                    inject(function ($injector) {
                        $httpBackend = $injector.get('$httpBackend');
                        $location = $injector.get('$location');
                        $window = $injector.get('$window');
                        $http = $injector.get('$http');
                        exStartupConstants = $injector.get('exStartupConstants');
                        $state = $injector.get('$state');
                    });

                    spyOn($state, 'go');
                });

                function performTestSteps (test, endpoint) {
                    $httpBackend.expectPOST(endpoint.url_match)
                        .respond(endpoint.response_code, endpoint.result);

                    $http.post(endpoint.url_match).then(function () {
                        test();
                    });

                    $httpBackend.flush();
                }

                describe('when service calls are made', function () {

                    afterEach(function () {
                        EndpointUtils.verifyExpectationsComplete($httpBackend);
                    });

                    it('should perform in application angular redirect when configured for application context path',
                        function () {
                            var endpoint = {
                                url_match: '/something/random.html',
                                response_code: 200,
                                result: {
                                    response: {
                                        redirectURL: '/shop/xpress/correct/url.html',
                                        redirectKey: '',
                                        redirect: true
                                    }
                                }
                            };

                            performTestSteps(function () {
                                expect($location.path()).toBe(endpoint.result.response.redirectURL);
                                expect($window.location.href).toBe('');
                            }, endpoint);
                        });

                    it('should perform full browser redirect when configured outside application context path',
                        function () {
                            var endpoint = {
                                url_match: '/something/random.html',
                                response_code: 200,
                                result: {
                                    response: {
                                        redirectURL: '/correct/url.html',
                                        redirectKey: '',
                                        redirect: true
                                    }
                                }
                            };

                            performTestSteps(function () {
                                expect($location.path()).toBe('');
                                expect($window.location.href).toBe(endpoint.result.response.redirectURL);
                            }, endpoint);
                        });

                    it('should default to using the redirection key over the URL when available', function () {
                        var endpoint = {
                            url_match: '/something/random.html',
                            response_code: 200,
                            result: {
                                response: {
                                    redirectURL: '/wrong/url.html',
                                    redirectKey: 'url.xpress.page.deviceRecommender',
                                    redirect: true
                                }
                            }
                        };

                        performTestSteps(function () {
                            expect($window.location.href).toBe('');
                        }, endpoint);
                    });

                    it('should use the state name in the constant when available', function () {
                        var endpoint = {
                            url_match: '/something/random.html',
                            response_code: 200,
                            result: {
                                response: {
                                    redirectURL: '/wrong/url.html',
                                    redirectKey: 'url.xpress.page.accessoryServiceRecommender',
                                    redirect: true
                                }
                            }
                        };

                        performTestSteps(function () {
                            expect($state.go).toHaveBeenCalled();
                            expect($window.location.href).toBe('');
                        }, endpoint);
                    });

                    it('should use the redirection URL if the key cannot be mapped to a URL', function () {
                        var endpoint = {
                            url_match: '/something/random.html',
                            response_code: 200,
                            result: {
                                response: {
                                    redirectURL: '/shop/xpress/accessory-service-recommender.html',
                                    redirectKey: 'url.key.does.not.exist',
                                    redirect: true
                                }
                            }
                        };

                        performTestSteps(function () {
                            expect($location.path()).toBe(endpoint.result.response.redirectURL);
                            expect($window.location.href).toBe('');
                        }, endpoint);
                    });

                    it('should use the redirection URL if no key value is provided', function () {
                        var endpoint = {
                            url_match: '/something/random.html',
                            response_code: 200,
                            result: {
                                response: {
                                    redirectURL: '/shop/xpress/accessory-service-recommender.html',
                                    redirectKey: null,
                                    redirect: true
                                }
                            }
                        };

                        performTestSteps(function () {
                            expect($location.path()).toBe(endpoint.result.response.redirectURL);
                            expect($window.location.href).toBe('');
                        }, endpoint);
                    });

                    it('should not redirect unless redirect is set to true', function () {
                        var endpoint = {
                            url_match: '/something/random.html',
                            response_code: 200,
                            result: {
                                response: {
                                    redirectURL: '/shop/xpress/accessory-service-recommender.html',
                                    redirectKey: 'url.xpress.page.accessoryServiceRecommender',
                                    redirect: false
                                }
                            }
                        };

                        performTestSteps(function () {
                            expect($location.path())
                                .not.toBe(exStartupConstants.url.xpress.page.accessoryServiceRecommender);
                            expect($location.path())
                                .not.toBe(endpoint.result.response.redirectURL);
                            expect($window.location.href)
                                .not.toBe(exStartupConstants.url.xpress.page.accessoryServiceRecommender);
                            expect($window.location.href)
                                .not.toBe(endpoint.result.response.redirectURL);
                        }, endpoint);
                    });
                });
            });
        });
    });
})();