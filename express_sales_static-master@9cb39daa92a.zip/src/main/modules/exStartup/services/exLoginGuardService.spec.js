(function () {
    'use strict';

    define(['exLoginGuardService'], function () {
        describe('src/main/modules/exStartup/services/exLoginGuardService.spec.js', function () {
            describe('exLoginGuardService service of exStartup', function () {
                var $httpBackend, service, $window, exStartupConstants, $rootScope, $log, $cache;

                beforeEach(function () {

                    $window = {
                        // now, $window.location.href will update that empty object
                        location: {'href': ''},
                        sessionStorage: jasmine.createSpyObj('sessionStorage', ['getItem', 'setItem']),
                        document: window.document
                    };

                    $window.sessionStorage.getItem.and.returnValue(undefined); // nothing in storage
                    $log = jasmine.createSpyObj('$log', ['error']);

                    module('exStartup', {
                        $window: $window,
                        $log: $log
                    });

                    inject(function ($injector) {
                        $httpBackend = $injector.get('$httpBackend');
                        $rootScope = $injector.get('$rootScope');
                        service = $injector.get('exLoginGuardService');
                        exStartupConstants = $injector.get('exStartupConstants');
                        $cache = $injector.get('$cacheFactory').get('$http');
                    });

                    spyOn($cache, 'put');
                    spyOn($cache, 'get');
                    spyOn($cache, 'remove');
                });

                afterEach(function () {
                    $httpBackend.verifyNoOutstandingExpectation();
                    $httpBackend.verifyNoOutstandingRequest();
                    $window.sessionStorage.setItem.calls.reset();
                    $window.sessionStorage.getItem.calls.reset();
                    $window.location.href = '';
                    $log.error.calls.reset();
                    $cache.put.calls.reset();
                    $cache.get.calls.reset();
                    $cache.remove.calls.reset();
                });

                describe('getProfileData function of the exLoginGuardService', function () {

                    it('should retrieve profile info and not store it when user unauthenticated', function () {
                        var endpoint = Endpoint_profileInfoApi.get_profile_info_unauth;

                        EndpointUtils.performServiceTest(service.getProfileData, undefined,
                            {
                                $httpBackend: $httpBackend,
                                endpoint: endpoint,
                                method: 'GET'
                            }, {
                                callback: function (results) {
                                    expect(results).toEqual(endpoint.result);
                                    expect($window.sessionStorage.setItem).not.toHaveBeenCalledWith(
                                        exStartupConstants.profileStorageKey, jasmine.anything());
                                }
                            });

                        EndpointUtils.verifyExpectationsComplete($httpBackend);
                    });
                });

                describe('authorize function of the exLoginGuardService', function () {
                    afterEach(function () {
                        EndpointUtils.verifyExpectationsComplete($httpBackend);
                    });
                });
            });
        });
    });
})();