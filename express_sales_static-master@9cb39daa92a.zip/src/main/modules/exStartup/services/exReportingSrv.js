(function () {
    'use strict';

    /**
     * Capture reporting events and create custom event notifications for DataMappingInterface
     * @module exReportingSrv
     * @see exStartupConstants.events.DS_REPORTING_EVENT
     * @see exStartupConstants.events.DS_REPORTING_PAGELOAD_EVENT
     */
    angular.module('exStartup')

        .factory('exReportingSrv', ['$q', '$window', '$rootScope', 'exLoginGuardService', 'exStartupConstants', 'exDetmManager', 'spinnerInterceptor',
            function ($q, $window, $rootScope, exLoginGuardService, exStartupConstants, exDetmManager, spinnerInterceptor) {
                return {
                    init: initialize,
                    firePageLoad: firePageLoad
                };

                /**
                 * Adds the necessary scope listener to pass on reporting events.
                 * @function init
                 */
                function initialize () {
                    // add event listener for reporting events
                    $rootScope.$on(exStartupConstants.events.DS_REPORTING_EVENT, function (scope, data, currentscope) {
                        exDetmManager.whenDetmReady().then(function () {
                            if ($window.DataMappingInterface) {
                                $window.DataMappingInterface.eventmapdefaulturl = exStartupConstants.xpressEventMappingPath;
                                $window.DataMappingInterface.customEventNotification(data, currentscope);
                            }
                        });
                    });

                    $rootScope.$on(exStartupConstants.events.DS_REPORTING_PAGELOAD_EVENT, function (scope, friendlyPageName, pageLocationUrl) {
                        spinnerInterceptor.whenUserAccessible().then(function () {
                            exDetmManager.whenDetmReady().then(function () {
                                firePageLoad(friendlyPageName, pageLocationUrl);
                            });
                        });

                    });
                }

                /**
                 * Performs the task of sending the page load event.
                 * @function firePageLoad
                 * @param {string} [friendlyPageName] - The title of the page provided by the EDD document
                 * @param {string} [pageLocationUrl] - The reference url of the page that is currently being viewed by the user
                 * @returns {Promise} signifies page load event has been sent and necessary data has been collected
                 * @emits DS_REPORTING_EVENT#pageLoad
                 *
                 * @example
                 * exReportingSrv.firePageLoad('DS Upgrade Device Details Pg', '/shop/xpress/virtual/device-details.html');
                 */
                function firePageLoad (friendlyPageName, pageLocationUrl) {
                    return $q.all({
                        browser: getBrowserData(friendlyPageName, pageLocationUrl),
                        profile: getProfileData()
                    }).then(function (data) {
                        $rootScope.$emit(exStartupConstants.events.DS_REPORTING_EVENT, {
                            eventAction: 'pageLoad',
                            eventCode: 'page_load',
                            prioritypush: true,
                            additionaldata: angular.extend(
                                {}, data.profile, data.browser
                            )
                        }, $rootScope);
                    });
                }

                /**
                 * Gets data from the users profile object returned from the service
                 */
                function getProfileData () {
                    return exLoginGuardService.getProfileData().then(function (data) {
                        var results = {}, profileStorage = data.ProfileInfo;

                        if (profileStorage) {
                            if (profileStorage.accountFirstName) {
                                results['user.attributes.customerName'] = profileStorage.accountFirstName + ((profileStorage.accountLastName) ? ' ' + profileStorage.accountLastName : '');
                            } else if (profileStorage.accountLastName) {
                                results['user.attributes.customerName'] = profileStorage.accountLastName;
                            }

                            if (profileStorage.exUpFlow) {
                                results['page.pageInfo.flowCode'] = 'DSUP';
                            } else {
                                results['page.pageInfo.flowCode'] = 'DSAAL';
                            }

                            if (profileStorage.emailAddress) {
                                results['user.attributes.email'] = profileStorage.emailAddress;
                            }

                            if (profileStorage.addressLine1) {
                                results['user.attributes.streetAddress'] = profileStorage.addressLine1;
                            }

                            if (profileStorage.city) {
                                results['user.attributes.city'] = profileStorage.city;
                            }

                            if (profileStorage.state) {
                                results['user.attributes.state'] = profileStorage.state;
                            }

                            if (profileStorage.zip5) {
                                results['page.pageInfo.zipCode'] = profileStorage.zip5;
                            }

                            results['user.account.sdgFlag'] = (profileStorage.isMobileShareOnAccount === 'true') ? '1' : '0';

                            if (profileStorage.slidAssocAccts) {
                                results['user.account.slidAssocAccts'] = profileStorage.slidAssocAccts;

                            } else if ($window.sessionStorage.getItem('slidAssocAccts')) {
                                results['user.account.slidAssocAccts'] = $window.sessionStorage.getItem('slidAssocAccts');
                            }

                            if (profileStorage.loginType) {
                                var pLoginType = profileStorage.loginType,
                                    loginId = profileStorage.loginId,
                                    loginType = '';

                                if (pLoginType === 'WIRELESS') {
                                    // Check if login Id is a CTN
                                    if ((/^-?(?:\d+|\d{1,3}(?:,\d{3})+)(?:\.\d+)?$/).test(loginId)) {
                                        loginType = 'CTN';
                                        //Check if login Id is an Email
                                    } else if ((/[a-zA-Z]+@[a-zA-Z]+\.[a-zA-Z]/).test(loginId)) {
                                        loginType = 'SLID';
                                    }
                                } else {
                                    loginType = pLoginType;
                                }

                                if (loginType.toUpperCase() === 'CTN') {
                                    results['user.account.ctn'] = loginId;
                                } else if (loginType.toUpperCase() === 'SLID') {
                                    results['user.account.ctn'] = 'SLID';
                                    results['user.account.sdgId'] = loginId;
                                }

                                if (loginType) {
                                    results['user.login.type'] = loginType;
                                }
                            }

                            if (profileStorage.ban) {
                                results['user.account.wirelessAccountNumber'] = profileStorage.ban;
                            }

                            if (profileStorage.loginId) {
                                results['user.login.id'] = profileStorage.loginId;
                            }

                            results['user.account.plentiLinkedFlag'] = (profileStorage.plentiLinkedFlag) ? '1' : '0';

                            if (profileStorage.accountInFocusIdentifier) {
                                results['user.account.accountInFocusIdentifier'] = profileStorage.accountInFocusIdentifier;
                            } else {
                                results['user.account.accountInFocusIdentifier'] = profileStorage.loginId;
                            }

                            if (profileStorage.uuid) {
                                results['user.uuid'] = profileStorage.uuid;
                            }

                            if (profileStorage.iruAuthorized === true) {
                                if (profileStorage.fanNumber) {
                                    results['user.account.liabilityType'] = 'IRU';
                                    results['user.account.fan'] = profileStorage.fanNumber;
                                }
                            }

                            if (profileStorage.liabilityType) {
                                switch (profileStorage.liabilityType.toUpperCase()) {
                                case 'SMB':
                                    results['user.customerType'] = 'SMB';
                                    results['user.login.userType'] = 'SMB';
                                    results['user.account.accountInFocusUserType'] = 'SMB';
                                    break;
                                case 'EMP':
                                    results['user.customerType'] = 'EMP';
                                    results['user.login.userType'] = 'CONS';
                                    results['user.account.accountInFocusUserType'] = 'CONS';
                                    break;
                                case 'RET':
                                    results['user.customerType'] = 'RET';
                                    results['user.login.userType'] = 'CONS';
                                    results['user.account.accountInFocusUserType'] = 'CONS';
                                    break;
                                case 'IRU':
                                    results['user.customerType'] = 'IRU';
                                    results['user.login.userType'] = 'CONS';
                                    results['user.account.accountInFocusUserType'] = 'CONS';
                                    break;
                                default:
                                    results['user.customerType'] = 'CONS';
                                    results['user.login.userType'] = 'CONS';
                                    results['user.account.accountInFocusUserType'] = 'CONS';
                                }
                            }

                            if (profileStorage.accountStatus) {
                                switch (profileStorage.accountStatus.toUpperCase()) {
                                case 'SUSPENDED':
                                    results['user.account.wirelessAccountStatus'] = 'S';
                                    results['user.account.accountInFocusStatus'] = 'S';
                                    break;
                                case 'HARD-SUSPENDED':
                                    results['user.account.wirelessAccountStatus'] = 'HS';
                                    results['user.account.accountInFocusStatus'] = 'HS';
                                    break;
                                case 'CANCELLED':
                                    results['user.account.wirelessAccountStatus'] = 'C';
                                    results['user.account.accountInFocusStatus'] = 'C';
                                    break;
                                default:
                                    results['user.account.wirelessAccountStatus'] = 'A';
                                    results['user.account.accountInFocusStatus'] = 'A';
                                }
                            }
                        }

                        return results;
                    });
                }

                /**
                 * gets data from the built in browser objects
                 */
                function getBrowserData (friendlyPageName, pageLocationUrl) {
                    return $q(function (resolve) {
                        var results = {};

                        if ($window.innerWidth > exStartupConstants.visualBreakpoints.desktop) {
                            results['page.pageInfo.viewedUIExperience'] = 'Desktop';
                        } else if ($window.innerWidth < exStartupConstants.visualBreakpoints.smartphone) {
                            results['page.pageInfo.viewedUIExperience'] = 'Smartphone';
                        } else {
                            results['page.pageInfo.viewedUIExperience'] = 'Tablet';
                        }

                        if (friendlyPageName) {
                            results['page.pageInfo.friendlyPageName'] = friendlyPageName;
                        }

                        if (pageLocationUrl) {
                            results['page.location.url'] = pageLocationUrl;
                        }

                        // check for Spanish url structure
                        results['page.pageInfo.language'] = /\/es-us\//.test($window.location.pathname) ? 'ES' : 'EN';

                        resolve(results);
                    });
                }
            }])

        .run(['exReportingSrv', function (exReportingSrv) {
            exReportingSrv.init();
        }]);
})();
