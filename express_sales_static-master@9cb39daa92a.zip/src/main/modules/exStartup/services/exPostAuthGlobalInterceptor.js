(function () {
    'use strict';

    angular.module('exStartup')

        .factory('exPostAuthGlobalInterceptor', ['$log', '$q', 'exStartupConstants', 'exStartupUtils',
            function ($log, $q, exStartupConstants, exStartupUtils) {
                var status = undefined;

                return {
                    initialize: reset,
                    complete: processComplete,
                    request: requestIntercept
                };

                function requestIntercept (config) {
                    return (status !== undefined
                        && exStartupUtils.interceptorRequired(config, exStartupConstants.http.postAuthReq))
                        ? status.promise.then(function () { return config; })
                        : config;
                }

                function reset () {
                    $log.info('exPostAuthInterceptor: has been enabled');
                    status = $q.defer();
                }

                function processComplete () {
                    $log.info('exPostAuthInterceptor: process is complete');
                    status.resolve();
                }

            }])

        .config(['$httpProvider', function ($httpProvider) {
            $httpProvider.interceptors.push('exPostAuthGlobalInterceptor');
        }]);
})();
