(function () {
    'use strict';

    define(['exPostAuthGlobalInterceptor'], function () {
        describe('src/main/modules/exStartup/services/exPostAuthGlobalInterceptor.spec.js', function () {
            describe('exPostAuthGlobalInterceptor service of exStartup', function () {
                var service, $http, $httpBackend, exStartupConstants, testRequest1, testRequest2;

                beforeEach(function () {
                    module('exStartup');

                    inject(function ($injector) {
                        $http = $injector.get('$http');
                        $httpBackend = $injector.get('$httpBackend');
                        exStartupConstants = $injector.get('exStartupConstants');
                        service = $injector.get('exPostAuthGlobalInterceptor');
                    });

                    testRequest1 = {url: '/test1.json', data: {a: '1234', b: '5678'}, handled: false};
                    testRequest2 = {url: '/test2.json', data: {c: '1234', d: '5678'}, handled: false};
                });

                afterEach(function () {
                    $httpBackend.verifyNoOutstandingExpectation();
                });

                describe('when the service has not been initialized', function () {
                    it('should not impact any requests regardless of if configured', function () {
                        createRequestBackend(testRequest1);
                        createRequestBackend(testRequest2);

                        // make both requests, configured and not configured
                        $http.get(testRequest1.url, {
                            params: testRequest1.data,
                            att: [exStartupConstants.http.postAuthReq]
                        });

                        $http.get(testRequest2.url, {
                            params: testRequest2.data
                        });

                        // no requests handled yet
                        expect(testRequest1.handled).toEqual(false);
                        expect(testRequest2.handled).toEqual(false);

                        $httpBackend.flush(); // flush all requests that have been sent

                        // both configured and non configured requests are handled
                        expect(testRequest1.handled).toEqual(true);
                        expect(testRequest2.handled).toEqual(true);
                    });
                });

                describe('when the service has been initialized', function () {
                    beforeEach(function () {
                        service.initialize();
                    });

                    it('should only delay requests that have been configured until process complete', function () {
                        createRequestBackend(testRequest1);
                        createRequestBackend(testRequest2);

                        // make both requests, configured and not configured
                        $http.get(testRequest1.url, {
                            params: testRequest1.data,
                            att: [exStartupConstants.http.postAuthReq]
                        });

                        $http.get(testRequest2.url, {
                            params: testRequest2.data
                        });

                        // no requests handled yet
                        expect(testRequest1.handled).toEqual(false);
                        expect(testRequest2.handled).toEqual(false);

                        $httpBackend.flush(); // flush all requests that have been sent

                        // the non configured request is only one completed
                        expect(testRequest1.handled).toEqual(false);
                        expect(testRequest2.handled).toEqual(true);

                        service.complete(); // post authorization process is now done

                        $httpBackend.flush(); // flush any requests that have been delayed

                        // both requests have been completed
                        expect(testRequest1.handled).toEqual(true);
                        expect(testRequest2.handled).toEqual(true);
                    });

                    it('should not delay any requests if process has already been completed', function () {
                        createRequestBackend(testRequest1);
                        createRequestBackend(testRequest2);

                        service.complete(); // post authorization process is now done

                        // make both requests, configured and not configured
                        $http.get(testRequest1.url, {
                            params: testRequest1.data,
                            att: [exStartupConstants.http.postAuthReq]
                        });

                        $http.get(testRequest2.url, {
                            params: testRequest2.data
                        });

                        // no requests handled yet
                        expect(testRequest1.handled).toEqual(false);
                        expect(testRequest2.handled).toEqual(false);

                        $httpBackend.flush(); // flush all requests that have been sent

                        // both configured and non configured requests are handled immediately
                        expect(testRequest1.handled).toEqual(true);
                        expect(testRequest2.handled).toEqual(true);
                    });
                });

                function createRequestBackend (testRequest) {
                    $httpBackend.whenGET(function (url) { return url.indexOf(testRequest.url) >= 0; })
                        .respond(function (method, url, data, headers, params) {
                            expect(params).toEqual(testRequest.data);
                            testRequest.handled = true;
                            return [200];
                        });
                }
            });
        });
    });
})();
