(function () {
    'use strict';

    angular.module('exStartup', ['ngSanitize', 'ngRoute', 'ngCookies', 'ui.router', 'oc.lazyLoad', 'ddh.att', 'com.att.widgetframework']);

}());

