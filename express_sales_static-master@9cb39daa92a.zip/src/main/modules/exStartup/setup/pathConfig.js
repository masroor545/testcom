(function () {
    'use strict';

    function funcDependencyLoader (depArr) {
        return ['$ocLazyLoad', function ($ocLazyLoad) {
            return $ocLazyLoad.load({files: depArr, serie: false});
        }];
    }

    // Fetches the user details information asynchronously
    var getUpgradeEligibilityService = ['exLoginGuardService', function (exLoginGuardService) {
        return exLoginGuardService.fetchUserDetails();
    }];

    // Gets the user profile information asynchronously
    var getProfileInfoService = ['exLoginGuardService', function (exLoginGuardService) {
        return exLoginGuardService.getProfileData();
    }];


    // check upsell offer eligibility for current losg item
    var getUpsellOfferEligibility = ['exPostAuthGlobalApi', function (exPostAuthGlobalApi) {
        exPostAuthGlobalApi.checkUpsellOfferEligibility();
        return true;
    }];


    angular.module('exStartup')

        .config(['$routeProvider', '$stateProvider', '$locationProvider', 'exStartupConstants', function ($routeProvider, $stateProvider, $locationProvider, exStartupConstants) {
            $stateProvider

                .state({
                    name: 'device-recommender',
                    url: '/shop/xpress/device-recommender.html',
                    templateUrl: '/shop/xpress/device-recommender.template.html',
                    resolve: {
                        pageDeps: funcDependencyLoader(['express-static-exbuyflow-tpl'])
                    },
                    title: exStartupConstants.titles.deviceRecommender,
                    authorize: true
                })

                .state({
                    name: 'accessory-recommender',
                    url: '/shop/xpress/accessory-service-recommender.html',
                    templateUrl: '/shop/xpress/accessory-service-recommender.template.html',
                    resolve: {
                        pageDeps: funcDependencyLoader(['express-static-exbuyflow-tpl']),
                        upsellEligibilityChecked: getUpsellOfferEligibility
                    },
                    title: exStartupConstants.titles.accessoryServiceRecommender,
                    authorize: true
                })
                .state({
                    name: 'upgrade-eligibility',
                    url: '/shop/xpress/upgrade-eligibility.html',
                    templateUrl: '/shop/xpress/upgrade-eligibility.template.html',
                    resolve: {
                        pageDeps: funcDependencyLoader(['express-static-exupgrade-tpl']),
                        userInfoLoaded: getUpgradeEligibilityService,
                        userProfileLoaded: getProfileInfoService
                    },
                    title: exStartupConstants.titles.upgradeEligibility,
                    friendlyPageName: exStartupConstants.friendlyPageName.upgradeEligibility,
                    authorize: true
                })

                .state({
                    name: 'upgrade-eligibility-payment',
                    url: '/shop/xpress/upgrade-eligibility-payment.html',
                    templateUrl: '/shop/xpress/upgrade-eligibility-payment.template.html',
                    resolve: {
                        pageDeps: funcDependencyLoader(['express-static-exupgrade-tpl'])
                    },
                    title: exStartupConstants.titles.upgradeEligibilityPayment,
                    friendlyPageName: exStartupConstants.friendlyPageName.upgradeEligibilityPayment,
                    authorize: true
                })

                .state({
                    name: 'upsell-offer',
                    url: '/shop/xpress/upsell-offer.html',
                    templateUrl: '/shop/xpress/upsell-offer.template.html',
                    resolve: {
                        pageDeps: funcDependencyLoader(['express-static-exbuyflow-tpl'])
                    },
                    title: exStartupConstants.titles.upsellOffer,
                    friendlyPageName: exStartupConstants.friendlyPageName.upsellOffer,
                    authorize: true
                })

                .state({
                    name: 'upgrade-tradein-consent',
                    url: '/shop/xpress/upgrade-tradein-consent.html',
                    templateUrl: '/shop/xpress/upgrade-tradein-consent.template.html',
                    resolve: {
                        pageDeps: funcDependencyLoader(['express-static-exupgrade-tpl'])
                    },
                    title: exStartupConstants.titles.upgradeTradeinConsent,
                    friendlyPageName: exStartupConstants.friendlyPageName.upgradeTradeinConsent,
                    authorize: true
                })

                .state({
                    name: 'upgrade-payment-confirm',
                    url: '/shop/xpress/upgrade-payment-confirm.html',
                    templateUrl: '/shop/xpress/upgrade-payment-confirm.template.html',
                    resolve: {
                        pageDeps: funcDependencyLoader(['express-static-exupgrade-tpl'])
                    },
                    title: exStartupConstants.titles.upgradePaymentConfirm,
                    friendlyPageName: exStartupConstants.friendlyPageName.upgradePaymentConfirm,
                    authorize: true
                });

            $locationProvider.html5Mode({
                enabled: true,
                requireBase: true,
                rewriteLinks: 'xpress-spa'
            });
        }]);
}());
