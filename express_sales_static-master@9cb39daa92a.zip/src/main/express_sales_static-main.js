require.config({
    waitSeconds: 0,
    paths: {
        'angular': '/shop/xpress/ui/express_sales_static/<%= version %>/js/lib/angular/angular.min',
        'angular-animate': '/ui/global_all_cms_common/libs/angular/1.4.8/angular-animate.min',
        'angular-aria': '/ui/global_all_cms_common/libs/angular/1.4.8/angular-aria.min',
        'angular-cookies': '/ui/global_all_cms_common/libs/angular/1.4.8/angular-cookies.min',
        'angular-resource': '/ui/global_all_cms_common/libs/angular/1.4.8/angular-resource.min',
        'angular-route': '/ui/global_all_cms_common/libs/angular/1.4.8/angular-route.min',
        'angular-sanitize': '/ui/global_all_cms_common/libs/angular/1.4.8/angular-sanitize.min',
        'angular-touch': '/ui/global_all_cms_common/libs/angular/1.4.8/angular-touch.min',
        'angular-messages': '/ui/global_all_cms_common/libs/angular/1.4.8/angular-messages.min',
        'angular-ui-router' : '/shop/xpress/ui/express_sales_static/<%= version %>/js/lib/angular-ui-router/release/angular-ui-router.min',
        'jquery': '/ui/frameworks/rwd/2017.04/js/jquery/2.1.0/jquery.min',
        'ocLazyLoad': '/ui/global_all_cms_common/libs/ocLazyLoad/1.0.9/ocLazyLoad.require.min',
        'widgetFramework': '/ui/frameworks/widget-container-framework/2017.07/js/angular/1.2.5/widget-container-framework.min',
        'widgetFrameworkCommunication': '/ui/global_all_cms_common/libs/communication_lib/1.0.2/communicationAPI.min',
        'ds2-framework': '/ui/frameworks/rwd/2017.04/js/angular/2.1.0/digital-design-library.min',
        'ds2-framework-css': '/ui/frameworks/rwd/2017.04/js/angular/2.1.0/digital-design-library',
        'ds2-framework-global-css': '/ui/frameworks/rwd/2017.04/styles/2.1.0/css/global.min',
        'ds2-framework-accordion-css':'/ui/frameworks/rwd/2017.04/styles/2.1.0/css/ds2-accordion.min',
        'ds2-framework-modal-css':'/ui/frameworks/rwd/2017.04/styles/2.1.0/css/ds2-modal.min',
        'ds2-framework-tooltip-css':'/ui/frameworks/rwd/2017.04/styles/2.1.0/css/ds2-tooltip.min',
        'globalnav-handler': '/ui/global_all_cms_globalnav/globalnav-handler/1.0.0/globalnav-handler.min',
        'lobinitializer-cmpl-support': '/salesui/sales_co_combined-cart/17.11.25/js/lob-initializer/lobinitializer-cmpl-support.min',
        'sessionmonitor': '/salesui/sales_co_combined-cart/17.11.25/js/misc/sessionmonitor/sessionmonitor.min',
        'tealeaf': '/shop/xpress/ui/express_sales_static/0.1.0/js/lib/tealeaf/tealeaf.min.5.2.MobileMyAtt_20170620',
        'bazaar-voice': '//display.ugc.bazaarvoice.com/static/ATT/bvapi',
        'zippyCccPrefetch' : '/shop/xpress/ui/express_sales_static/prefetch/prefetchZippyCccOnly',
        // not ideal implementation only needed until single virtual URL is created via apache config do not expand on this!!!!
        'env-goldeneye': (!/stage/.test(location.host)) ?
            '/scripts/goldeneye/scripts/goldeneye' : '/scripts/goldeneye/staging/scripts/goldeneye.staging',
        'mbox': (!/stage/.test(location.host)) ?
            '/scripts/adobe/prod/mbox-contents' : '/scripts/adobe/stage/mbox-contents'
    },
    map: {
        '*': {
            'css': '/ui/global_all_cms_common/libs/cssLoader/0.1.8/cssLoader.js'
        }
    },
    shim: {
        'angular': {
            deps: ['jquery'],
            exports: 'angular'
        },
        'jquery': {
            exports: '$'
        },
        'ocLazyLoad': {
            deps: ['angular']
        },
        'angular-route': {
            deps: ['angular']
        },
        'angular-sanitize': {
            deps: ['angular']
        },
        'angular-touch': {
            deps: ['angular']
        },
        'angular-cookies': {
            deps: ['angular']
        },
        'angular-animate': {
            deps: ['angular']
        },
        'angular-messages': {
            deps: ['angular']
        },
        'angular-ui-router': {
            deps: ['angular'],
            exports: 'angular'
        },
        'ds2-framework': {
            deps: ['angular']
        },
        'widgetFramework': {
            deps: ['angular']
        },
        'widgetFrameworkCommunication': {
            deps: ['angular']
        },
        'globalnav-handler': {
            deps: ['express-static-exstartup-tpl']
        },
        'sessionmonitor': {
            deps: ['lobinitializer-cmpl-support']
        },
        'mbox': {
            deps: ['env-goldeneye']
        }
    }
});

require.config({
    'waitSeconds': 0,
    'baseUrl': '/shop/xpress/ui',
    'paths': {<% _.forEach(files, function (file) {%>
        'express-static-<%= file.name.toLowerCase() %>': '<%= file.path %>',<% }); %>
        'tealeaf-or-something': 'express_sales_static/<%= version %>/js/express_sales_static-app.min'
    },
    'shim': {
        'express-static-exstartup-tpl': {
            'deps': [
                'angular',
                'angular-cookies',
                'angular-touch',
                'angular-sanitize',
                'angular-animate',
                'angular-route',
                'angular-messages',
                'angular-ui-router',
                'ocLazyLoad',
                'widgetFramework',
                'widgetFrameworkCommunication',
                'ds2-framework',
                'css!ds2-framework-global-css',
                'css!ds2-framework-css',
                'css!ds2-framework-accordion-css',
                'css!ds2-framework-modal-css',
                'css!ds2-framework-tooltip-css',
                'sessionmonitor',
                'tealeaf'
            ]
        },
        'express-static-excommon-tpl': {
            'deps': ['css!express-static-main-css']
        },
        'express-static-exbuyflow-tpl': {
            'deps': ['express-static-excommon-tpl']
        },
        'express-static-exupgrade-tpl': {
            'deps': ['express-static-excommon-tpl']
        }
    }
});

