# content

This folder contains all the content of the express\_sales\_static application in json files. This folder has a bunch of stuff.

**Example:**
	
	{
	  "greatstuff": "this content is the <b>best</b> content ever",
	  "close": "close",
	  "modal": {
	    "close": "close",
	    "title": "Generic Modal Title",
	    "body": {
	      "content": "Some default modal body content."
	    },
	    "footer": {
	      "button1": "Default Button 1",
	      "button2": "Default Button 2"
	    }
	  }
	}

# url.json

This file contains all urls used throughout the express application. If you want a json property for a URL, add it here.

# config.json

This file is for configuring settings for the page. Items that aren't displayed on the page should go here.

## accessoryRecommenderList

* **accessoryCategories** - the categories of recommended accessories initially displayed on the accessory hub page

* **defaultInsuranceBillCode** - default insurance to be displayed on the accessory hub page

* **initialAccessoriesLoaded** - the number of recommended accessories initially displayed on the accessory hub page

## deviceRecommenderList
    
* **recommendedDevicesAmount** - the number of devices requested from the device recommender API

* **initialDevicesLoaded** - the number of recommended devices initially displayed on the device recommender page

* **displayHeroDevice** - flag to display a hero device modal on page device recommendation page load

* **heroConfidenceThreshold** - number to determine the confidence threshold for displaying an item as a hero device

## timer

* **deviceCard** - the number of milliseconds to hide device card

## queueIt

* **enabled** - the state of the Queue-It script. If set to *true* (no quotes), it is enabled. Values: *true* and *false*.

# url.json

This file contains all urls used throughout the express application. If you want a json property for a URL, add it here.

# cta.json

This file will contain all the content for buttons and links, commonly known as **c**all **t**o **a**ction.

# deviceRecommender.json

This file contains device recommender related content.

# accessory_recommender.json

This file will contain all the content that is specific for the accessories and services recommender page.

# upgrade_eligibility.json

Contains content for the upgrade eligibility page.

# product_config.json

Contains product config content.

# upsell-offer.json

Contains upsell offer details content.

# device_card.json

Contains content for device card

# page_titles.json

HTML page titles when routing to the page from outside Zippy. See exStartupConstants.js (src/main/content/modules/exStartup/services/exStartupConstants.js) for the in-application title counterpart.

# note.json
Contains warning, alert, notification, information content