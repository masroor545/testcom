// Karma configuration
// Generated on Tue Apr 26 2016 23:16:24 GMT-0700 (PDT)
const packageJson = require('./package')
module.exports = function (config) {
    config.set({

        // frameworks to use
        // available frameworks: https://npmjs.org/browse/keyword/karma-adapter
        frameworks: ['jasmine', 'requirejs'],


        // list of files / patterns to load in the browser
        files: [
            { pattern: 'bower_components/jquery/dist/jquery.js', include: true },
            { pattern: 'bower_components/angular/angular.js', included: true },
            { pattern: 'bower_components/angular-cookies/angular-cookies.min.js', include: true },
            { pattern: 'bower_components/communicationapi/communicationAPI.min.js', include: true },
            { pattern: 'bower_components/ocLazyLoad/dist/ocLazyLoad.min.js', include: true },
            { pattern: 'bower_components/widget-container/widget-container-framework.min.js', include: true },
            { pattern: 'bower_components/ddh.att/digital-design-library.min.js', include: true },
            { pattern: 'bower_components/angular-route/angular-route.min.js', include: true },
            { pattern: 'bower_components/angular-messages/angular-messages.min.js', include: true },
            { pattern: 'bower_components/angular-sanitize/angular-sanitize.min.js', include: true },
            { pattern: 'bower_components/angular-animate/angular-animate.min.js', include: true },
            { pattern: 'node_modules/angular-mocks/angular-mocks.js', included: true },
            { pattern: 'node_modules/angular-mocks/*.js', included: false },
            { pattern: 'node_modules/jasmine-ajax/lib/mock-ajax.js', included: false },
            { pattern: 'node_modules/promise-polyfill/promise.js', included: false },
            { pattern: 'bower_components/angular-ui-router/release/angular-ui-router.min.js', included: false },
            { pattern: 'src/**/*.js', included: false },
            { pattern: 'src/**/*.spec.js', included: false },
            { pattern: 'src/test/endpoints/*.js', included: true },
            'test-require.js',
            'test-main.js'
        ],

        exclude: [
            `src/main/${packageJson.name}-*.js`
        ],

        // start these browsers
        // available browser launchers: https://npmjs.org/browse/keyword/karma-launcher
        browsers: ['PhantomJS_mod'],

        logLevel: config.LOG_INFO,

        customLaunchers: {
            'PhantomJS_mod': {
                base: 'PhantomJS',
                flags: ['--load-images=false']
            }
        }
    })
}
