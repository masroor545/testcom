/*global module */
module.exports = function (grunt) {
    'use strict';

    grunt.loadNpmTasks('grunt-exec');

    grunt.initConfig({
        exec: {
            gulp: 'node node_modules/gulp/bin/gulp.js'
        }
    });

    grunt.registerTask('default', ['exec:gulp']);
    grunt.registerTask('build', ['exec:gulp']);
};
