
# Build for Express Sales Static

### One time tasks:

1. Configure proxy for npm
    ```
    $ npm config set proxy http://one.proxy.att.com:8080
    $ npm config set https-proxy http://one.proxy.att.com:8080
    ```
2. Configure proxy for bower
    1. Navigate to Environment Variables in Windows
    2. Add a new **HTTP_PROXY** user variable with value **http://one.proxy.att.com:8080**
    3. Add a new **HTTPS_PROXY** user variable with value **http://one.proxy.att.com:8080**

3. Install modules
    ```
    $ npm install
    ```
4. Install gulp globally
    ```
    $ npm install --global gulp-cli
    ```
### To execute build:

```
$ gulp
```

This build task executes the following:
* creates the "dist" directory with compiled widgets and other source files
* creates combined files based on configuration in "package.json"
* creates minified versions of all source files
* runs unit tests when present
* runs eslint on script source files

To see specific some specific tasks that can be executed and what they do run:

```
$ gulp help
``` 

```
[15:04:01] Starting 'help'...

Usage
  gulp [TASK] [OPTIONS...]

Available tasks
  clean             deletes generated files and dist folder
  default           execute complete build and test process [build-all]
  fix-script-style  updates the spacing used in code files to be in line with general styleguide
  help              Display this help text.
  lint              execute lint tests
  lint-tests        runs lint and style rules against unit test files
  test              execute unit tests once [process-html]
  test-tdd          execute continuous unit tests [process-html]
  watch-lint        watches javascript files for changes and performs lint task

[15:04:01] Finished 'help' after 1.76 ms
```

### Build Configuration

The build is primary configured in the package.json file.  Most properties are set in the *attconfig* object as seen
below.

* **maintemplate** - specifies the main file that will contain auto generated requireJS mappings.
* **sourceDir** - specifies the source directory that contains repository code.
* **moduleDirs** - an array that contains objects that specify the directories that contains angular 
modules/widget framework widgets. This object also specifies the directory within the output directory for these 
generated files.
* **outputDir** - specifies the output directory for build process. 
* **combined** - specifies combined files to create (the file name), including the output directory to put them in 
within *outputDir* 
and the source file mappings also within *outputDir* to specify files to include.
* **move** - other files / file types that are processed including the direcotry to output them into within *outputDir*.
* **bowerFiles** - files from *bower_components* directory to move into *lib* directory.
* **generateDocModuleDirs** - the folders within each angular module to generate documentation for.
* **generateDocOtherDirs** - other folders not within an angular module for which to generate documentation for.

Example:
```
"attconfig": {
  "maintemplate": "src/sales_co_combined-cart/combined-cart-main.js",
  "sourceDir": "src/sales_co_combined-cart",
  "moduleDirs": [
    {"in": "src/sales_co_combined-cart/modules/", "out": "js/modules/"}
  ],
  "outputDir": "dist/ui/sales_co_combined-cart/",
  "generateDocModuleDirs": ["controllers", "directives", "services", "filters"],
  "generateDocOtherDirs": ["src/main/lib/prefetch/", "src/main/lib/mydir/"],
  "bowerFiles": [
    "**/*.js",
    "!**/widgetLoade*.js"
  ],
  "combined": {
    "lobinitializer-cmpl": {
      "outputDir": "js/lob-initializer",
      "sources": [
        "js/misc/lob-initializer/lobinitializer.js",
        "js/misc/lob-initializer/lobinitializer-boot.js"
      ]
    },
    "cartcontent-complete": {
      "outputDir": "js/misc/cart-content",
      "sources": [
        "js/misc/cart-content/cartcontent.js",
        "js/misc/cart-content/cartcontent-boot.js"
      ]
    }
  },
  "move": {
    "less": {
      "outputDir": "",
      "sources": [
        "**/*.less",
        "!**/_*.less"
      ]
    },
    "css": {
      "outputDir": "",
      "sources": [
        "**/*.css",
        "!**/*.min.css"
      ]
    },
    "other": {
      "sources": [
        "**/*.{eot,ttf,woff,json,txt}"
      ]
    }
  }
}
```

### Content Configuration

The _remotecontent.json_ file exist containing configuration for remote content to be fetched.
The content is fetched and saved to the _src/content_ directory.  These fetched files can be checked into git repository
so build can succeed even when remote content source is not accessible (due to network or other issues).

**Note** - If a network (base or path) location is not accessible or a connection fails the build will attempt to continue with the
content files that happen to be available in the content directory.

```json
{
  "base": "http://tst04.stage.att.com",

  "paths": [
    "/services/shopwireless/Content/myContentSpecial",
    "/cart/mycart/somecontent.json",
    "/content/att/Shared/sales/consumer/dtv/messages"
  ]
}
```

The _base_ property can be configured based on where a given release is getting its content from.

Will results in three files being created (**note filenames and paths are converted to lowercase**):
* _src/content/services/shopwireless/content/mycontentspecial.json_
* _src/content/cart/mycart/somecontent.json_
* _src/content/content/att/shared/sales/consumer/dtv.messages.json_

The content can be accessed in pug based on path followed by filename followed by json structure:

```
//- somefile.pug

//- store in variable so I do not have to repeat long path many times
- var mycontentspecial = services.shopwireless.content.mycontentspecial

//- accessed through variable because of inconvenient extra long path
div #{mycontentspecial.abcd}
div #{mycontentspecial.buttons.someText}

//- accessed directly if more convenient
div #{services.shopwireless.content.mycontentspecial.abcd}
div #{services.shopwireless.content.mycontentspecial.buttons.someText}
```

### Unit Tests

By default tests only run in PhantomJS you can add Chrome browser by modifying karma.conf.js line:
```
browsers: ['PhantomJS']
```
To read:
```
browsers: ['PhantomJS', 'Chrome']
```

### Version Changes

Every release of this application requires the `version` value in `package.json` to be updated, this is due
to files being cached indefinitely, failure to update will result in unpredictable behavior upon release.

* _Internal APP Update_ - 
There are various files that contain specific version numbers that need to be updated occasionally.  For updates to
the version number of this application changes will need to be manuallly made to the ``src/content/widget.json`` file the 
`src/content/url.json` file and finally the `requireJsConfig.js` file of any widget in the modules directory.  Other 
locations such as the `express_sales_static-main.js` file automatically updates itself based on the version in the
`package.json` file.  
* _External APP Update_ -
For changes to code from other projects or repositories the version numbers need to be updated manually in 
`express_sales_static-main.js` as well as the other locations listed above.  This is only if you intend to get the latest
code from these other applications, if there is no requirement to get updated functionality or bug fixes the version number
can remain with the older value.